import React from "react";
import Header2 from "../../components/common/header2/Header2";
import styles from "./setting.module.css";

const Setting = () => {
  return (
    <div>
      <Header2 text="Settings" />
    </div>
  );
};

export default Setting;
