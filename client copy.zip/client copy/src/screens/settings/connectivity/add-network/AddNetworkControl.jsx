import React, { useEffect, useState } from "react";
import BackButton from "../../../../components/settings/back-button/BackButton";
import BrightnessSlider from "../../../../components/settings/brightness-slider/BrightnessSlider";
import SettingRow from "../../../../components/settings/setting-row/SettingRow";
import ThemeChanger from "../../../../components/settings/theme-changer/ThemeChanger";
import { SETTINGS_LINKS } from "constants/CONST";
import styles from "./addnetwork.module.css";
import { useLocation, useNavigate, useOutletContext } from "react-router-dom";
import HeaderCustomButton from "components/settings/header-custom-button/HeaderCustomButton";
import SecurityTypeControl from "../common/network-security/SecurityTypeControl";
import NetworkNameControl from "../common/network-name/NetworkNameControl";
import NetworkPasswordControl from "../common/network-password/NetworkPasswordControl";
import { JoinNetworkDialog } from "components/settings/join-network-dialog/JoinNetworkDialog";


const AddNetworkControl = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [setActiveTab, data, refreshDataImmediate] = useOutletContext();
  const [formStep, setFormStep] = useState(0);

  const addNetworkData = data?.[0]?.tabs?.filter(
    (tab) => `${tab.name}` === "UiSettingsConnectivity"
  )[0].details?.[0]?.data?.[0]?.data?.[0]?.items?.[1]?.data?.[0]?.data[1]?.data?.[2]?.data?.[0];

  console.log("addNetworkData", addNetworkData)

  return (
    <>
      {formStep == 0 ? (
        <>
          <div className={styles.header}>
            <div className={styles.backBtn}>
              <BackButton handler={() => navigate(-1)} />
            </div>
            <p className={styles.headingText}>Add Wi-FI Network</p>
            <div className={styles.nextBtn}>
              <HeaderCustomButton name="Next" handler={() => setFormStep(1)} />
            </div>
          </div>
          <SecurityTypeControl />
        </>
      ) : formStep == 1 ? (

        <>
          <div className={styles.header}>
            <div className={styles.backBtn}>
              <BackButton handler={() => setFormStep(0)} />
            </div>
            <p className={styles.headingText}>Add Wi-FI Network</p>
            <div className={styles.nextBtn}>
              <HeaderCustomButton name="Next" handler={() => setFormStep(2)} />
            </div>
          </div>
          <NetworkNameControl />
        </>
      ) : (
        <>
          
          <div className={styles.itemContainer}>
                <p className={styles.containerHeading}>{"Network Password"}
                    <span className={styles.containerHeadingSub}>Step 3 of 3</span>
                </p>
                <div className={styles.contentContainer}>
                    <React.Fragment>
                    <JoinNetworkDialog close={() => setFormStep(1)} />
                    </React.Fragment>
                </div>
            </div>
        </>
      )}




    </>
  );
};

export default AddNetworkControl;
