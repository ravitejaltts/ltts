import React, { useEffect, useState } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import styles from "./networkname.module.css";
import SettingRow from "components/lighting/SettingRow";

const NetworkNameControl = () => {
    const navigate = useNavigate();

    return (
        <>
            <div className={styles.itemContainer}>
                <p className={styles.containerHeading}>{"Network Name"}
                    <span className={styles.containerHeadingSub}>Step 2 of 3</span>
                </p>
                <div className={styles.contentContainer}>
                    <React.Fragment>

                    </React.Fragment>
                </div>
            </div>
        </>
    )
}

export default NetworkNameControl;