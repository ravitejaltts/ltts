import React, { useEffect, useState } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import styles from "./networkpassword.module.css";
import { JoinNetworkDialog } from "components/settings/join-network-dialog/JoinNetworkDialog";

const NetworkPasswordControl = () => {
    const navigate = useNavigate();

    return (
        <>
            <div className={styles.itemContainer}>
                <p className={styles.containerHeading}>{"Network Password"}
                    <span className={styles.containerHeadingSub}>Step 3 of 3</span>
                </p>
                <div className={styles.contentContainer}>
                    <React.Fragment>
                    
                    </React.Fragment>
                </div>
            </div>
        </>
    )
}

export default NetworkPasswordControl;