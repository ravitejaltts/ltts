export const LIGHT_MODE = "LIGHT";
export const DARK_MODE = "DARK";
