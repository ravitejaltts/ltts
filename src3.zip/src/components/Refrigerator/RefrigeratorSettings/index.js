import RefrigeratorSettings from "./RefrigeratorSettings";
export default RefrigeratorSettings;
