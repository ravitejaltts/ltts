import FeatureTemperatureAlerts from "./FeatureTemperatureAlerts";
export default FeatureTemperatureAlerts;
