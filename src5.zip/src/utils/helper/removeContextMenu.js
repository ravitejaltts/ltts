const removeContextMenu = (e) => {
  e.preventDefault();
};

export default removeContextMenu;
