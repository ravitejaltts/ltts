import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import BackButton from "../../../../components/settings/back-button/BackButton";
import { AppContext } from "../../../../context/AppContext";
import { useFetch } from "../../../../hooks/useFetch";
import { API_ENDPOINT, LOCAL_ENDPOINT } from "../../../../utils/api";
import styles from "./connected.module.css";
import SettingRow from "../../../../components/settings/setting-row/SettingRow";
import SettingRow2 from "../../../../components/settings/setting-row-2/SettingRow2";
import SecurityTypeControl from "../common/network-security/SecurityTypeControl";
import { SETTINGS_LINKS } from "constants/CONST";


const ConnectedDetailedControl = () => {
  const navigate = useNavigate();
  const { pollingInterval } = useContext(AppContext);
  const { data, refreshDataImmediate } = useFetch(
    API_ENDPOINT.SETTING,
    LOCAL_ENDPOINT.SETTING,
    true,
    pollingInterval
  );
  const [displayInnerDetail, setDisplayInnerDetail] = useState(false);


  const connectedData = data?.[0]?.tabs
    ?.filter((tab) => `${tab.name}` === SETTINGS_LINKS.CONNECTIVITY)[0]
    ?.details?.[0]?.data?.[0].data?.[0]?.items?.[1]?.data?.[0]?.data?.[0]?.data?.[1];

  const handleButtonClick = (buttonData) => {
    setDisplayInnerDetail(true)
  };
  const toggleForgotNetwork = () => {

  };

  return (
    <>
      {!displayInnerDetail ? (
        <>
          <div className={styles.header}>
            <div className={styles.backBtn}>
              <BackButton handler={() => navigate(-1)} />
            </div>
            <p className={styles.headingText}>{connectedData?.value}</p>
          </div>

          {connectedData?.data?.map(
            (item, ind) => (
              <>
                <React.Fragment key={ind}>
                  <div className={styles.itemContainer}>
                    <p className={styles.containerHeading}>{item?.title}</p>
                    <div className={styles.contentContainer}>
                      {item?.items?.map((dat, ind, arr) => (
                        <div key={ind}>
                          {dat?.type === "MULTI_NAVIGATION_BUTTON" && (
                            <SettingRow2
                              name={dat?.title}
                              bottomText={dat?.subtitle}
                              buttonData={dat?.button}
                              noBorder={arr.length - 1 === ind}
                              handleButtonClick={handleButtonClick}
                            />
                          )}
                          {dat?.type !== "MULTI_NAVIGATION_BUTTON" && (
                            <SettingRow
                              name={dat?.title}
                              text={dat?.value?.version || dat?.value}
                              toggle={dat?.state}
                              refreshDataImmediate={refreshDataImmediate}
                              action={dat?.actions?.TOGGLE?.action}
                              toggleState={dat?.state?.onoff}
                              noBorder={arr.length - 1 === ind}
                              toggleDisplay={true}
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </React.Fragment>
                <p className={styles.info}>{item?.items[0]?.belowtext}</p>
              </>
            )
          )}
          <React.Fragment key={"forgotNetwork"}>
            <div className={styles.container}>
              <button className={styles.removeUser} onClick={toggleForgotNetwork}>
                Forgot This Network
              </button>
            </div>
          </React.Fragment>
        </>
      ) : (
        <>
          <div className={styles.header}>
            {displayInnerDetail && (
              <div className={styles.backBtn}>
                <BackButton handler={() => setDisplayInnerDetail(false)} />
              </div>
            )}
            <p className={styles.headingText}>{connectedData?.value}</p>
          </div>
          <SecurityTypeControl />
        </>
      )}
    </>
  );
};

export default ConnectedDetailedControl;
