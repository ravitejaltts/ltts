import React, { } from "react";
import {  useNavigate } from "react-router-dom";
import { JoinNetworkDialog } from "components/settings/join-network-dialog/JoinNetworkDialog";


const JoinNetworkControl = () => {
    const navigate = useNavigate();

    return (
        <>
            <JoinNetworkDialog headerTitle={"Join Network"} close={() => navigate(-1)} next={(input) => navigate(-1)} />
        </>
    );
};

export default JoinNetworkControl;
