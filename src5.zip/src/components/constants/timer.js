export const IDLE_TIME_DEFAULT = 5;
export const OFF_TIME_DEFAULT = 10;
export const POLLING_INTERVAL = 2;
