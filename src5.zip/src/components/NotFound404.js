import React from "react";
import Header2 from "./common/header2/Header2";

function NotFound404() {
  return (
    <div>
      <Header2 text="Page not found" />
    </div>
  );
}

export default NotFound404;
