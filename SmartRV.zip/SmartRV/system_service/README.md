# Introduction 
The IoT Service handles communication to/from the cloud, enabling command&control and passing telemetry data.


# Getting Started

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
