# What controls does the water system need
# Who is providing this control

from copy import deepcopy
import subprocess
import time

from main_service.modules.hardware.common import HALBaseClass


init_script = {
    # Should a real script go here for init
}

shutdown_script = {}
