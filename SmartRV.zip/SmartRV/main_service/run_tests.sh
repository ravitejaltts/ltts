#!/bin/bash


export WGO_USER_STORAGE='/Users/dom/Documents/1_Projects/1_Winnebago/2_Dev/SmartRV/storage/'
python3 -m pytest -o log_cli=true
