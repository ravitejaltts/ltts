from fastapi import APIRouter

router = APIRouter(
    prefix='',
    tags=['UI',]
)
