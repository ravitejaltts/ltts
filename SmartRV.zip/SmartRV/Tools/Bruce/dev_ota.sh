#!/bin/bash


mkdir /opt/smartrv/utils

mv /opt/smartrv/iot_service/smartrv-iot.service /opt/smartrv/utils/.

mv /opt/smartrv/iot_service/smartrv-ota.service /opt/smartrv/utils/.



