# About This Version

## Version Details
- **Version Number**: 1.1.2
- **Release Date**: August 06, 2024


Thank you for using WinnConnect!
