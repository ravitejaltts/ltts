scp -r CAN_Service UI_Service pi@192.168.1.214:/home/pi/hmi/
