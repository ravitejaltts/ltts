https://punchthrough.com/maximizing-ble-throughput-part-2-use-larger-att-mtu-2/
