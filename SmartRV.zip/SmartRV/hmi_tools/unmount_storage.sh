#!/bin/bash

umount /dev/mmcblk1p1
umount /dev/sda1