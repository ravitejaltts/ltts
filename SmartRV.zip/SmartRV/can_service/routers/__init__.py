from os import lseek


