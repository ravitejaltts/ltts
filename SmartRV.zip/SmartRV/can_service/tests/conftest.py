# import sys
# import pytest


# TODO: Figure out how this can only apply to tests in this folder, this currently skips all
# if sys.platform.startswith("darwin"):
#     pytest.skip("skipping windows-only tests", allow_module_level=True)
