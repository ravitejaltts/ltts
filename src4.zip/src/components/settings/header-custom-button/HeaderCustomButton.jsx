import React from "react";
import styles from "./headerCustom.module.css";

function HeaderCustomButton({ name, handler }) {
  return (
    <div>
      <div className={styles.container} onClick={handler}>
        {name}
      </div>
    </div>
  );
}

export default HeaderCustomButton;
