import React, { useEffect, useState } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import { SETTINGS_LINKS } from "constants/CONST";
import styles from "./security.module.css";
import SettingRow from "components/lighting/SettingRow";

const SecurityTypeControl = ({ input, cb }) => {
    const navigate = useNavigate();
    const [setActiveTab, data, refreshDataImmediate] = useOutletContext();  
    const [selectedSecurityType, setSelectedSecurityType] = useState(input);

    const networkData = data?.[0]?.tabs?.filter(
        (tab) => `${tab.name}` === SETTINGS_LINKS.CONNECTIVITY
    )[0].details?.[0]?.data?.[0]?.data?.[0]?.items?.[1]?.data?.[0]?.data[1]?.data;

    const addNetworkData = networkData?.[networkData.length-1]?.data?.[0];

    const changeSecurity = async (value) => {
        setSelectedSecurityType(value);

        setTimeout(() => {
            cb(value)
        }, 1500);
    };

    return (
        <>
            <div className={styles.itemContainer}>
                <p className={styles.containerHeading}>{addNetworkData.title}</p>
                <div className={styles.contentContainer}>
                    {addNetworkData?.options?.map((option, ind, arr) => (
                        <React.Fragment key={ind}>
                            <div key={ind} onClick={() => changeSecurity(option.value)}>
                                <SettingRow
                                    name={option?.key}
                                    selected={selectedSecurityType === option.value }
                                    noBorder={arr.length - 1 === ind}
                                    action={addNetworkData?.actions?.TAP?.action}
                                    value={option.value}
                                    refreshDataImmediate={refreshDataImmediate}
                                    className={selectedSecurityType === option.value ? styles.selected : ''}
                                />
                            </div>
                        </React.Fragment>
                    ))}
                </div>
            </div>
        </>
    )
}

export default SecurityTypeControl;