module.exports = {
    root: true,
    extends: ["@react-native", "prettier"],
    ignorePatterns: [
        "node_modules",
        "coverage",
        "babel.config.js",
        "metro.config.js",
        "string.extensions.ts",
    ],
    rules: {
        "no-useless-escape": "off", // We use custom regex strings that make use of
        "no-control-regex": "off", // We use control characters for character ranges
        radix: "off", // Uses of parseInt without radix are intentional
        eqeqeq: "off", // Off temporarily
        "no-bitwise": "off", // We use bitwise operators intentionally for BLE message serialization
        "@typescript-eslint/no-explicit-any": "off", // "any" as a type is occasionally intentionally used
        "@typescript-eslint/no-var-requires": "off", // React allows the use of "requires" for images
        "@typescript-eslint/no-empty-function": "warn",
        "@typescript-eslint/ban-ts-comment": "off", // allow ts-ignore comments
        "@typescript-eslint/no-unused-vars": [
            "warn",
            { argsIgnorePattern: "^_" }, // Underscore before parameter name prevents warning
        ],
        "react-native/no-unused-styles": "off",
        "react-native/split-platform-components": "off",
        "react-native/no-inline-styles": "off", // Inline styles are used throughout the app
        "react-native/no-color-literals": "warn",
        "react-native/no-single-element-style-arrays": "warn",
        "react/no-unstable-nested-components": [
            "warn",
            {
                allowAsProps: true, // Allow nested components as props
            },
        ],
        "react-hooks/exhaustive-deps": "warn",
    },
};
