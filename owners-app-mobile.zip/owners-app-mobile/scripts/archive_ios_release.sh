#!/bin/sh

# Fail if any command fails
set -e

pod install --project-directory=ios
npm run set-env -- --env prod
xcodebuild clean archive -workspace ./ios/Owners.xcworkspace -configuration DefaultRelease -scheme Owners -archivePath ./ios/build/release/com.winnebago.owners.xcarchive
xcodebuild -exportArchive -archivePath ./ios/build/release/com.winnebago.owners.xcarchive -exportPath ./ios/build/release -exportOptionsPlist ./ios/ExportOptions.Release.plist