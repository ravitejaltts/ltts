#!/bin/sh

# Fail if any command fails
set -e

pod install --project-directory=ios
npm run set-env -- --env test
xcodebuild clean archive -workspace ./ios/Owners.xcworkspace -configuration QARelease -scheme Owners -archivePath ./ios/build/qa/com.winnebago.owners.qa.xcarchive
xcodebuild -exportArchive -archivePath ./ios/build/qa/com.winnebago.owners.qa.xcarchive -exportPath ./ios/build/qa -exportOptionsPlist ./ios/ExportOptions.QA.plist