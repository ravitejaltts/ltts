#!/bin/sh

# Fail if any command fails
set -e

npm run set-env -- --env mock
mkdir -p android/app/src/main/assets
react-native bundle --platform android --dev false --entry-file index.js --bundle-output android/app/src/main/assets/index.android.bundle --assets-dest android/app/src/main/res
cd android
./gradlew clean
rm -rf app/src/main/res/drawable-*
rm -rf app/src/main/res/raw/*
./gradlew bundleMockRelease
mkdir -p build/mock
cp app/build/outputs/bundle/mockRelease/app-mock-release.aab build/mock/com.winnebago.owners.mock.aab
