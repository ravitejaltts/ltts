#!/bin/sh

# Fail if any command fails
set -e

pod install --project-directory=ios
npm run set-env -- --env dev
xcodebuild clean archive -workspace ./ios/Owners.xcworkspace -configuration AlphaRelease -scheme Owners -archivePath ./ios/build/alpha/com.winnebago.owners.alpha.xcarchive
xcodebuild -exportArchive -archivePath ./ios/build/alpha/com.winnebago.owners.alpha.xcarchive -exportPath ./ios/build/alpha -exportOptionsPlist ./ios/ExportOptions.Alpha.plist