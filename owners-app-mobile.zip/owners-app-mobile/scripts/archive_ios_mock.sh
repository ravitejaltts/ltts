#!/bin/sh

# Fail if any command fails
set -e

pod install --project-directory=ios
npm run set-env -- --env mock
xcodebuild clean archive -workspace ./ios/Owners.xcworkspace -configuration MockRelease -scheme Owners -archivePath ./ios/build/mock/com.winnebago.owners.mock.xcarchive
xcodebuild -exportArchive -archivePath ./ios/build/mock/com.winnebago.owners.mock.xcarchive -exportPath ./ios/build/mock -exportOptionsPlist ./ios/ExportOptions.Mock.plist