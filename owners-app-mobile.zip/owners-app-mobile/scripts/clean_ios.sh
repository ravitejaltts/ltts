#!/bin/sh

# Fail if any command fails
set -e

cd ios
rm -rf Owners.xcodeproj
rm -rf Owners.xcworkspace
rm -rf Pods
tuist generate --no-open
pod install
xcodebuild clean -workspace ./Owners.xcworkspace -configuration DevelopmentDebug -scheme Owners
cd ..
