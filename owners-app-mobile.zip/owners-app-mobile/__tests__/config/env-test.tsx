import { expect, it } from "@jest/globals";
import { env } from "../../src/config/env";

it("is defined", () => {
    expect(env).not.toBeUndefined();
});

it("defines the environment name", () => {
    expect(env.name).not.toBeUndefined();
});
