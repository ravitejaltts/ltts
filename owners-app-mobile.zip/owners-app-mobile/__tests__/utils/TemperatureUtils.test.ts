import { describe, expect, it } from "@jest/globals";
import { SystemTemperatureUnit } from "../../src/models/domain/system/SystemTemperatureUnit";
import TemperatureUtils from "../../src/utils/TemperatureUtils";

describe("Temperature formatting", () => {
    it("should return a format of XX°X", () => {
        expect(
            TemperatureUtils.format(77, SystemTemperatureUnit.Fahrenheit)
        ).toBe("77°F");
        expect(TemperatureUtils.format(13, SystemTemperatureUnit.Celsius)).toBe(
            "13°C"
        );
    });
    it("should return a format of XX°", () => {
        expect(TemperatureUtils.format(77)).toBe("77°");
        expect(TemperatureUtils.format(13)).toBe("13°");
    });
    it("should return a format of --°X", () => {
        expect(
            TemperatureUtils.format(null, SystemTemperatureUnit.Fahrenheit)
        ).toBe("--°F");
        expect(
            TemperatureUtils.format(null, SystemTemperatureUnit.Celsius)
        ).toBe("--°C");
    });
    it("should return a format of --°", () => {
        expect(TemperatureUtils.format(null)).toBe("--°");
    });
    it("should return a format of 0°", () => {
        expect(TemperatureUtils.format(0)).toBe("0°");
    });
    it("should return a format of 0°X", () => {
        expect(
            TemperatureUtils.format(0, SystemTemperatureUnit.Fahrenheit)
        ).toBe("0°F");
        expect(TemperatureUtils.format(0, SystemTemperatureUnit.Celsius)).toBe(
            "0°C"
        );
    });
});

describe("Convert to Celsius", () => {
    const temperatures = [
        { fahrenheit: -40, celsius: -40 },
        { fahrenheit: -39, celsius: -39.5 },
        { fahrenheit: -1, celsius: -18.5 },
        { fahrenheit: 0, celsius: -18 },
        { fahrenheit: 1, celsius: -17 },
        { fahrenheit: 14, celsius: -10 },
        { fahrenheit: 31, celsius: -0.5 },
        { fahrenheit: 32, celsius: 0 },
        { fahrenheit: 32.5, celsius: 0.5 },
        { fahrenheit: 50, celsius: 10 },
        { fahrenheit: 95, celsius: 35 },
        { fahrenheit: 113, celsius: 45 },
        { fahrenheit: 140, celsius: 60 },
    ];

    it("should not convert Celsius temperatures", () => {
        for (const temperature of temperatures) {
            expect(
                TemperatureUtils.convertToC(
                    temperature.celsius,
                    SystemTemperatureUnit.Celsius
                )
            ).toBe(temperature.celsius);
        }
    });
    it("should convert Fahrenheit temperatures", () => {
        for (const temperature of temperatures) {
            expect(
                TemperatureUtils.convertToC(
                    temperature.fahrenheit,
                    SystemTemperatureUnit.Fahrenheit
                )
            ).toBe(temperature.celsius);
        }
    });
});

describe("Convert from Celsius", () => {
    const temperatures = [
        { celsius: -40, fahrenheit: -40 },
        { celsius: -39.5, fahrenheit: -39 },
        { celsius: -1, fahrenheit: 30 },
        { celsius: -0.5, fahrenheit: 31 },
        { celsius: 0, fahrenheit: 32 },
        { celsius: 0.5, fahrenheit: 33 },
        { celsius: 1, fahrenheit: 34 },
        { celsius: 35, fahrenheit: 95 },
        { celsius: 45, fahrenheit: 113 },
        { celsius: 60, fahrenheit: 140 },
    ];

    it("should not convert Celsius temperatures", () => {
        for (const temperature of temperatures) {
            expect(
                TemperatureUtils.convertFromC(
                    temperature.celsius,
                    SystemTemperatureUnit.Celsius
                )
            ).toBe(temperature.celsius);
        }
    });
    it("should convert to Fahrenheit temperatures", () => {
        for (const temperature of temperatures) {
            expect(
                TemperatureUtils.convertFromC(
                    temperature.celsius,
                    SystemTemperatureUnit.Fahrenheit
                )
            ).toBe(temperature.fahrenheit);
        }
    });
});
