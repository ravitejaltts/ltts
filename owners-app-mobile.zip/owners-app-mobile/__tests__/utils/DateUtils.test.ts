import { describe, expect, it } from "@jest/globals";
import { DateUtil } from "../../src/utils/DateUtil";

describe("Timestamp formatting", () => {
    it("should return a format of H:MM AM", () => {
        expect(DateUtil.formatTimestamp("1 AM")).toBe("1:00 AM");
    });

    it("should return a format of HH:MM PM", () => {
        expect(DateUtil.formatTimestamp("12 PM")).toBe("12:00 PM");
    });
});
