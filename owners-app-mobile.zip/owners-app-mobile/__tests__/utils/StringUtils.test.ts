import { describe, expect, it } from "@jest/globals";
import StringUtils from "../../src/utils/StringUtils";

describe("toPercentString", () => {
    it("Should generate the string 33.33%", () => {
        expect(StringUtils.toPercentageString(1 / 3, 2)).toEqual("33.33%");
    });
});

describe("toValueString", () => {
    it("Should generate the string 2.12", () => {
        expect(StringUtils.toValueString(2.1234, 2)).toEqual("2.12");
    });
});

describe("parseUrlQueryParams", () => {
    it("Should be able to parse a URL without query parameters", () => {
        expect(
            StringUtils.parseUrlQueryParams("http://test-website.com")
        ).toEqual({});
    });
    it("Should be able to parse a URL with a single query parameter", () => {
        expect(
            StringUtils.parseUrlQueryParams(
                "http://test-website.com?key1=value1"
            )
        ).toEqual({ key1: "value1" });
    });
    it("Should be able to parse a URL with a multiple query parameters", () => {
        expect(
            StringUtils.parseUrlQueryParams(
                "http://test-website.com?key1=value1&key2=value2"
            )
        ).toEqual({ key1: "value1", key2: "value2" });
    });
});
