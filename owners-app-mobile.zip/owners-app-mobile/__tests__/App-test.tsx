import { expect, it } from "@jest/globals";
import "react-native";

it("passes", () => {
    expect(true).toBeTruthy();
});

// import React from 'react';
// import App from '../src/App';

// // Note: test renderer must be required after react-native.
// import renderer from 'react-test-renderer';

// it('renders correctly', () => {
//   renderer.create(<App />);
// });
