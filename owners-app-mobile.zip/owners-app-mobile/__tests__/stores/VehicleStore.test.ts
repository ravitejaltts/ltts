import { describe, expect, jest, test } from "@jest/globals";
import SecureStorageService from "../../src/services/SecureStorageService";
import WgoSettingService from "../../src/services/WgoSettingService";
import ConsoleLogger from "../../src/services/impl/ConsoleLogger";
import MockAuthenticationService from "../../src/services/mock/MockAuthenticationService";
import MockAuthorizationService from "../../src/services/mock/MockAuthorizationService";
import MockContentService from "../../src/services/mock/MockContentService";
import { MockKeychainService } from "../../src/services/mock/MockKeychainService";
import { MockPlatformVehicleService } from "../../src/services/mock/MockPlatformVehicleService";
import { MockTrackingService } from "../../src/services/mock/MockTrackingService";
import MockUserService from "../../src/services/mock/MockUserService";
import AuthStore from "../../src/stores/AuthStore";
import VehicleStore from "../../src/stores/VehicleStore";

jest.mock("../../src/services/SecureStorageService");
const mockSecureStorageService = jest.mocked(SecureStorageService);

jest.mock("../../src/services/WgoSettingService");
const mockWgoSettingsService = jest.mocked(WgoSettingService);

const logger = new ConsoleLogger();

describe("Test VehicleStore", () => {
    const settingService = mockWgoSettingsService.mock.instances[0];
    const secureStorageService = mockSecureStorageService.mock.instances[0];

    const authStore = new AuthStore(
        logger,
        new MockAuthenticationService(
            logger,
            settingService,
            secureStorageService
        ),
        new MockAuthorizationService(settingService),
        secureStorageService,
        settingService,
        new MockKeychainService(),
        new MockTrackingService()
    );
    authStore.isLoggedIn = true;

    const vehicleStore = new VehicleStore(
        logger,
        settingService,
        new MockPlatformVehicleService(),
        new MockUserService(settingService),
        new MockContentService(),
        authStore,
        () => {
            throw new Error("Not implemented");
        }
    );

    test("modelId should be 4728", async () => {
        const vehicle = await vehicleStore.findVehicle("00000000000000000");
        expect(vehicle.modelId).toBe(4728);
    });

    test("serialNumber should be 75000", async () => {
        const vehicle = await vehicleStore.findVehicle("00000000000000000");
        expect(vehicle.serialNumber).toBe("75000");
    });

    test("modelId should be 1915", async () => {
        const vehicle = await vehicleStore.findVehicle("11111111111111111");
        expect(vehicle.modelId).toBe(1915);
    });

    test("serialNumber should be 22348", async () => {
        const vehicle = await vehicleStore.findVehicle("11111111111111111");
        expect(vehicle.serialNumber).toBe("22348");
    });

    test("seriesId should be 1", async () => {
        const series = await vehicleStore.getSeries(1);
        expect(series.length).toBe(2);
        expect(series[0].seriesId).toBe(1);
    });
});
