import { describe, test, expect } from "@jest/globals";
import { Vehicle } from "../../../../src/models/domain/vehicle/Vehicle";

describe("Test Vehicle.getShortenedFloorPlan()", () => {
    const testCases = [
        {
            input: "",
            expected: "",
        },
        {
            input: "Hike 100",
            expected: "Hike 100",
        },
        {
            input: "MicroFLX",
            expected: "MicroFLX",
        },
        {
            input: "AC25ML",
            expected: "25ML",
        },
        {
            input: "MI2832FK",
            expected: "2832FK",
        },
        {
            input: "BF848EC",
            expected: "848EC",
        },
    ];

    testCases.forEach((x) => {
        test(`shortens "${x.input}" to "${x.expected}"`, () => {
            const result = Vehicle.getShortenedFloorPlan(x.input);
            expect(result).toBe(x.expected);
        });
    });
});
