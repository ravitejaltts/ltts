import type { JestConfigWithTsJest } from "ts-jest";
import { defaults as tsjPreset } from "ts-jest/presets";
/*
Recommended by expo: https://docs.expo.dev/develop/unit-testing/
"preset": "jest-expo",
"transformIgnorePatterns": [
    "node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@unimodules/.*|unimodules|sentry-expo|native-base|react-native-svg)"
]
*/

const jestConfig: JestConfigWithTsJest = {
    ...tsjPreset,
    verbose: true,
    preset: "react-native",
    transform: {
        "^.+\\.jsx$": "babel-jest",
        "^.+\\.tsx?$": [
            "ts-jest",
            {
                tsconfig: "tsconfig.spec.json",
            },
        ],
    },
    moduleNameMapper: {
        "\\.(jpg|ico|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$":
            "<rootDir>/jest/mock/assets/fileMock.js",
    },
    moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json", "node"],
    setupFilesAfterEnv: ["@testing-library/jest-native/extend-expect"],
    collectCoverage: true,
    collectCoverageFrom: [
        "./src/utils/**",
        "./src/stores/**",
        "./src/models/**",
        "./src/hooks/**",
        "!**/jest/**",
    ],
    coverageThreshold: {
        global: {},
        "./src/utils/**": {
            functions: 0,
        },
    },
    coverageReporters: ["cobertura", "json", "html"],
    transformIgnorePatterns: [
        "<rootDir>/node_modules/(?!(uuid|expo-clipboard|expo-file-system|expo-secure-store|expo-modules-core|@react-native|react-native|(.*)\\.svg$|(.*)\\.png$)/).*/",
    ],
    setupFiles: ["<rootDir>/jest/setup.ts"],
    globals: {
        __DEV__: true,
    },
};

export default jestConfig;
