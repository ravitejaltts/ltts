module.exports = "FileMocks";
// module.exports.ReactComponent = "FileMocks";
