import { jest } from "@jest/globals";

jest.mock("../src/services/realm/RealmStorageService.ts", () => jest.fn())
    .mock("../src/services/GooglePlacesService.ts", () => jest.fn())
    .mock("../src/services/impl/PlxBleManagerService.ts", () => jest.fn())
    .mock("../src/stores/BluetoothStore.ts", () => jest.fn())
    .mock("../src/models/domain/connection/CloudVehicleConnection.ts", () =>
        jest.fn()
    )
    .mock("../src/models/domain/connection/BleVehicleConnection", () =>
        jest.fn()
    )
    .mock("../src/models/domain/bluetooth/services/SecurityBleService.ts", () =>
        jest.fn()
    )
    .mock("expo-file-system", () => jest.fn())
    .mock("expo-location", () => jest.fn())
    .mock("expo-modules-core", () => jest.fn())
    .mock("expo-notifications", () => jest.fn())
    .mock("expo-secure-store", () => jest.fn())
    .mock("expo-camera", () => jest.fn())
    .mock("@okta/okta-react-native", () => jest.fn())
    .mock("react-native-map-link", () => jest.fn())
    .mock("react-native-version-number", () => jest.fn())
    .mock("appcenter-analytics", () => jest.fn())
    .mock("appcenter-crashes", () => jest.fn());
