# Winnebago Owners App

## Configure your environment

1. Install dependencies with npm

```bash
npm install
```

2. Set your configured platform environment.

```bash
npm run set-env:{env}
```

Where `{env}` is `dev`, `test`, `mock`, or `prod`.

### iOS

---

#### 1. Follow the [React Native guide](https://reactnative.dev/docs/environment-setup?platform=ios) to set up your development environment

#### 2. Install Cocoapods, Fastlane, and other Ruby packages:

```bash
bundle install
```

#### 3. [Install Tuist 3.19.0](https://docs.tuist.io/tutorial/get-started)

```bash
curl -Ls https://install.tuist.io | bash
```

then

```bash
tuist install 3.19.0
```

#### 4. Create your development certificate

Sign in to [developer.apple.com](https://developer.apple.com). Navigate to Certificates > Add and select "Apple Development". Generate your CSR by opening Keychain Access and navigating to Keychain Access > Certificate Assistant > Request a Certificate from a Certificate Authority. Fill out your information, save to disk, and upload to the developer portal. Once the developer certificate is created, **immediately download it**. This is important. If you do not download it at that time, you will not receive the private key and will be unable to use the certificate to sign development builds. Once downloaded, double click it to load it into your keychain.

#### 5. Add your development certificate to the development profiles.

In the Apple developer portal, navigate to Profiles. For each development profile, click "edit", click the checkbox next to your newly created certificate, and click "save". To download all of the profiles easily, open Xcode and navigate to Xcode > Settings > Accounts. Sign in to your developer account. Then, click the Winnebago team and tap "Download Manual Profiles". At this point, you should be able to build the iOS app.

#### 6. Run a clean

```bash
npm run clean:ios
```

This will install pods, generate the Xcode projects, and clean your build directories.

### Android

---

#### 1. Follow the [React Native guide](https://reactnative.dev/docs/environment-setup?platform=android) to set up your development environment

#### 2. Add the debug keystore

Download the [WGO OneDrive](https://winnebagoind-my.sharepoint.com/:f:/g/personal/cpearson_wgo_net/EnzXn9u8JHFPsx7bNSpX8esBKsqsiZQOmq00EDGvaxzgUQ?e=yjfxpK) debug keystore and place it in `/android/app`. This keystore is registered with Google Firebase.

#### 3. Add keystore environment variables

Add these environment variables (below) to your `.zshrc` or `.bashrc`, which allow you to run debug builds. Make sure to `source ~/.zshrc` afterward or restart your terminal for these to take effect.

```bash
# Winnebago Environment Variables
export UPLOAD_KEYSTORE_STORE_PASSWORD="test"
export UPLOAD_KEYSTORE_KEY_PASSWORD="test"
```

#### Note

If you are unable to build the app for Android because the Android SDK cannot be located, you can set the SDK location explicitly in `/android/local.properties`:

```bash
sdk.dir = /Users/{YOUR_USERNAME}/Library/Android/sdk
```

## Code Formatting with Prettier

We use [Prettier](https://prettier.io/) to format our JavaScript and TypeScript files. To check formatting without writing to files, you can run:

```bash
npm run format:check
```

To write the formatting to files, run:

```bash
npm run format:write
```

### Easy Formatting with the VS Code Extension

1. Open the extensions tab and search for "Prettier - Code formatter"
2. Open the `settings.json` file by holding shift, command, P and searching "Open Settings (JSON)"
3. Add the following to your `settings.json` file:

```json
{
    "editor.defaultFormatter": "esbenp.prettier-vscode",
    "[javascript]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    }
}
```

4. To format a file, press shift, option, F
5. If you would like to format on save, enable this option via Settings > Format > Format on Save or add the following to your `settings.json`:

```json
{
    "editor.formatOnSave": true
}
```

## Running the app

For a list of build configurations, see [this wiki page](https://dev.azure.com/WGO-Web-Development/Owners%20App/_wiki/wikis/Owners-App.wiki/1531/Build-Configurations)

### Android Emulator

1. Start the desired emulator
1. Run the app

```bash
npm run run:android
```

### iOS Simulator

1. Start the desired simulator
1. Run the app

```bash
npm run run:ios
```

## Archiving the app

```bash
npm run archive:android:{env}
```

OR

```bash
npm run archive:ios:{env}
```
