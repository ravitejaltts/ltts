module.exports = {
    tabWidth: 4,
    semi: true,
    bracketSpacing: true,
    bracketSameLine: true,
    trailingComma: "es5",
};
