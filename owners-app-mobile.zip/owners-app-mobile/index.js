/**
 * @format
 */

// Shim "getRandomValues"
import "react-native-get-random-values";
import { AppRegistry } from "react-native";
import App from "./src/App";

AppRegistry.registerComponent("Owners", () => App);
