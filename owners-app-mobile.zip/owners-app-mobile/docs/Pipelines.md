# Pipelines

[Wiki Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_wiki/wikis/Owners-App.wiki/843/Mobile-Pipelines)

## Validate Build
* [Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_build?definitionId=64)
* [YAML](/pipelines/validate_build.yml)
* Trigger: Branch policies on `main`, `develop`, and `release/*` branches.

Validates the build by running the `npm run build` and `npm run test` scripts when a pull request is submitted targeting one of the branches listed above.

## Deploy Mock
* [Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_build?definitionId=68)
* [YAML](/pipelines/deploy_mock.yml)
* Trigger: merges to `develop`

Builds the app pointing to the `mock` environment and deploys it to the AppCenter (Mock) channel.

## Deploy Alpha
* [Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_build?definitionId=62)
* [YAML](/pipelines/deploy_alpha.yml)
* Trigger: merges to `develop`

Builds the app pointing to the `test` environment and deploys it to the AppCenter (Alpha) channel.

## Deploy QA
* [Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_build?definitionId=97)
* [YAML](/pipelines/deploy_qa.yml)
* Trigger: merges to `develop`

Builds the app pointing to the `qa` environment and deploys it to the AppCenter (QA) channel.

## Deploy Release
* [Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_build?definitionId=63)
* [YAML](/pipelines/deploy_release.yml)
* Trigger: merges to `release/*`

Builds the app pointing to the `prod` environment and deploys it to the AppCenter (Store) channel, the Google Play store internal test track, and the TestFlight internal testers track.
