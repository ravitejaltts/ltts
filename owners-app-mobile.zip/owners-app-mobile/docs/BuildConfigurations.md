[Wiki Link](https://dev.azure.com/WGO-Web-Development/Owners%20App/_wiki/wikis/Owners-App.wiki/1531/Build-Configurations)

# iOS
Default bundle identifier: `com.winnebago.owners`

## Configurations
|Name|Suffix|Debuggable|Profile Type|
|--|--|--|--|
|`DefaultDebug`|None|✅|Development|
|`DefaultRelease`|None|❌|App Store|
|`DevelopmentDebug`|`.debug`|✅|Development|
|`AlphaDebug`|`.alpha`|✅|Development|
|`AlphaRelease`|`.alpha`|❌|Ad Hoc|
|`QADebug`|`.qa`|✅|Development|
|`QARelease`|`.qa`|❌|Ad Hoc|
|`MockDebug`|`.mock`|✅|Development|
|`MockRelease`|`.mock`|❌|Ad Hoc|

## Run Scripts
|Script|Suffix|Environment|
|--|--|--|
|`run:ios`|`.debug`|Last run|
|`run:ios:dev`|`.debug`|`dev`|
|`run:ios:test`|`.debug`|`test`|
|`run:ios:mock`|`.debug`|`mock`|
|`run:ios:prod`|`.debug`|`prod`|
|`run:ios:alpha`|`.alpha`|`dev`|
|`run:ios:qa`|`.qa`|`test`|
|`run:ios:default`|None|`prod`|

## Archive Scripts
|Script|Suffix|Environment|Output|
|--|--|--|--|
|`archive:ios:alpha`|`.alpha`|`dev`|`/ios/build/alpha/`|
|`archive:ios:qa`|`.qa`|`test`|`/ios/build/qa/`|
|`archive:ios:mock`|`.mock`|`mock`|`/ios/build/mock/`|
|`archive:ios:release`|None|`prod`|`/ios/build/release/`|

# Android
Default application identifier: `com.winnebago.owners`

## Tasks
The following tasks allow you to build and APK or AAB file. If the task is an installer, the app will be installed on your device and launched.
|Task|Suffix|Debuggable|Signing Config|
|--|--|--|--|
|`installDefaultDebug`|None|✅|`debug`|
|`bundleDefaultRelease`|None|❌|`release`|
|`installDevelopmentDebug`|`.debug`|✅|`debug`|
|`installAlphaDebug`|`.alpha`|✅|`debug`|
|`assembleAlphaAppCenter`|`.alpha`|❌|`debug`|
|`installQaDebug`|`.qa`|✅|`debug`|
|`assembleQaAppCenter`|`.qa`|❌|`debug`|
|`assembleMockRelease`|`.mock`|❌|`debug`|


## Run Scripts
The following scripts allow you to run and debug various versions of the app.
|Script|Suffix|Environment|
|--|--|--|
|`run:android`|`.debug`|Last run|
|`run:android:dev`|`.debug`|`dev`|
|`run:android:test`|`.debug`|`test`|
|`run:android:mock`|`.debug`|`mock`|
|`run:android:prod`|`.debug`|`prod`|
|`run:android:alpha`|`.alpha`|`dev`|
|`run:android:qa`|`.qa`|`test`|
|`run:android:default`|None|`prod`|

## Archive Scripts
The following scripts allow you to archive the app as an APK or AAB file.
|Script|Suffix|Environment|Output|
|--|--|--|--|
|`archive:android:alpha`|`.alpha`|`dev`|`/android/build/alpha/com.winnebago.owners.alpha.apk`|
|`archive:android:qa`|`.qa`|`test`|`/android/build/qa/com.winnebago.owners.qa.apk`|
|`archive:android:mock`|`.mock`|`mock`|`/android/build/mock/com.winnebago.owners.mock.apk`|
|`archive:android:release`|None|`prod`|`/android/build/release/com.winnebago.owners.aab`|