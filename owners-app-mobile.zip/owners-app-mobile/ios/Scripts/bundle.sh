#!/bin/sh

set -e

export NODE_BINARY=node
../node_modules/react-native/scripts/react-native-xcode.sh
