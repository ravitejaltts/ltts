import ProjectDescription

let project = Project(
        name: "Owners",
        organizationName: "Winnebago",
        settings: .settings(base: [
            "REACT_NATIVE_PATH": "../node_modules/react-native",
        ], configurations: [
            .debug(
                name: "DefaultDebug",
                settings: ["MTL_ENABLE_DEBUG_INFO": "YES"],
                xcconfig: "./ConfigFiles/Default/Default.xcconfig"
            ),
            .release(
                name: "DefaultRelease",
                settings: ["MTL_ENABLE_DEBUG_INFO": "NO"],
                xcconfig: "./ConfigFiles/Default/Default.xcconfig"
            ),
            .debug(
                name: "DevelopmentDebug",
                settings: ["MTL_ENABLE_DEBUG_INFO": "YES"],
                xcconfig: "./ConfigFiles/Development/Development.xcconfig"
            ),
            .debug(
                name: "AlphaDebug",
                settings: ["MTL_ENABLE_DEBUG_INFO": "YES"],
                xcconfig: "./ConfigFiles/Alpha/Alpha.xcconfig"
            ),
            .release(
                name: "AlphaRelease",
                settings: ["MTL_ENABLE_DEBUG_INFO": "NO"],
                xcconfig: "./ConfigFiles/Alpha/Alpha.xcconfig"
            ),
            .debug(
                name: "QADebug",
                settings: ["MTL_ENABLE_DEBUG_INFO": "YES"],
                xcconfig: "./ConfigFiles/QA/QA.xcconfig"
            ),
            .release(
                name: "QARelease",
                settings: ["MTL_ENABLE_DEBUG_INFO": "NO"],
                xcconfig: "./ConfigFiles/QA/QA.xcconfig"
            ),
            .debug(
                name: "MockDebug",
                settings: ["MTL_ENABLE_DEBUG_INFO": "YES"],
                xcconfig: "./ConfigFiles/Mock/Mock.xcconfig"
            ),
            .release(
                name: "MockRelease",
                settings: ["MTL_ENABLE_DEBUG_INFO": "NO"],
                xcconfig: "./ConfigFiles/Mock/Mock.xcconfig"
            )
        ]),
        targets: [
            Target(
                    name: "Owners",
                    platform: .iOS,
                    product: .app,
                    bundleId: "com.winnebago.owners",
                    deploymentTarget: .iOS(targetVersion: "13.0", devices: .iphone),
                    infoPlist: "./Owners/Info.plist",
                    sources: ["./Owners/**"],
                    resources: [
                        "./Owners/images.xcassets/**",
                        "../src/assets/fonts/**",
                        "./Owners/LaunchScreen.storyboard",
                        "./GoogleService-Info.plist",
                        "./PrivacyInfo.xcprivacy"
                    ],
                    scripts: [
                        .pre(
                            path: "./Scripts/start_packager.sh",
                            name: "Start Packager",
                            basedOnDependencyAnalysis: false
                        ),
                        .post(
                            path: "./Scripts/bundle.sh",
                            name: "Bundle React Native code and images",
                            basedOnDependencyAnalysis: false
                        )
                    ],
                    // pod dependencies are added to the ios project 
                    // by running "pod install" after running "tuist generate"
                    // "pod install" links our CP dependencies automagically to
                    // our ios project files
                    // https://docs.tuist.io/guides/third-party-dependencies/
                    dependencies: [
                        .sdk(name: "JavaScriptCore", type: .framework)
                    ],
                    settings: .settings(
                        configurations: [
                        .debug(
                            name: "DefaultDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - Release Development",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersDefault.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Developer",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "c2b67f49-ac9f-48b6-93ae-de2f8155a2aa",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon"
                            ]
                        ),
                        .release(
                            name: "DefaultRelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - App Store",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersDefault.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Distribution",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "c2b67f49-ac9f-48b6-93ae-de2f8155a2aa",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon"
                            ]
                        ),
                        .debug(
                            name: "DevelopmentDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.debug",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - Debug",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersDevelopment.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Developer",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "425ae0ec-d4db-4808-8eff-8a43ec5850b4",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon"
                            ]
                        ),
                        .debug(
                            name: "AlphaDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.alpha",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - Alpha Development",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersAlpha.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Developer",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "e1e03f99-70a8-488d-8095-3a569495a24a",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon"
                            ]
                        ),
                        .release(
                            name: "AlphaRelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.alpha",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - Alpha App Store",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersAlpha.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Distribution",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "e1e03f99-70a8-488d-8095-3a569495a24a",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "AlphaAppIcon"
                            ]
                        ),
                        .debug(
                            name: "QADebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.qa",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - QA Development",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersQA.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Developer",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "7210dba0-81ce-46eb-8497-73d86a0bc035",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon"
                            ]
                        ),
                        .release(
                            name: "QARelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.qa",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - QA App Store",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersQA.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Distribution",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "7210dba0-81ce-46eb-8497-73d86a0bc035",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "QAAppIcon"
                            ]
                        ),
                        .debug(
                            name: "MockDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.mock",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - Mock Development",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersMock.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Developer",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "c9c13522-fe0b-4484-ad27-adf6cb17c543",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "MockAppIcon"
                            ]
                        ),
                        .release(
                            name: "MockRelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "com.winnebago.owners.mock",
                                "PROVISIONING_PROFILE_SPECIFIER": "Owners App - Mock App Store",
                                "DEVELOPMENT_TEAM": "GM7KUB62TU",
                                "CODE_SIGN_ENTITLEMENTS": "./Owners/OwnersMock.entitlements",
                                "CODE_SIGN_IDENTITY": "iPhone Distribution",
                                "CODE_SIGN_STYLE": "Manual",
                                "APP_CENTER_APP_SECRET": "c9c13522-fe0b-4484-ad27-adf6cb17c543",
                                "ASSETCATALOG_COMPILER_APPICON_NAME": "MockAppIcon"
                            ]
                        )
                    ])
            ),
            Target(
                name: "OwnersTests",
                platform: .iOS,
                product: .unitTests,
                bundleId: "org.reactjs.native.example.OwnersTests",
                infoPlist: "./OwnersTests/Info.plist",
                sources: ["./OwnersTests/**"],
                dependencies: [
                    .target(name: "Owners")
                ],
                settings: .settings(configurations: [
                        .debug(
                            name: "DefaultDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .release(
                            name: "DefaultRelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .debug(
                            name: "DevelopmentDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .debug(
                            name: "AlphaDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .release(
                            name: "AlphaRelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .debug(
                            name: "QADebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .release(
                            name: "QARelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .debug(
                            name: "MockDebug",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        ),
                        .release(
                            name: "MockRelease",
                            settings: [
                                "PRODUCT_BUNDLE_IDENTIFIER": "org.reactjs.native.example.OwnersTests"
                            ]
                        )
                ])
            )
        ],
        schemes: [
            Scheme(
                name: "Owners",
                shared: true,
                buildAction: .buildAction(targets: ["Owners"]),
                testAction: .targets(["OwnersTests"], configuration: "DevelopmentDebug", attachDebugger: true),
                runAction: .runAction(configuration: "DevelopmentDebug", attachDebugger: true, executable: "Owners"),
                archiveAction: .archiveAction(configuration: "Release", customArchiveName: "Owners"),
                profileAction: .profileAction(configuration: "Release", executable: "Owners.app"),
                analyzeAction: .analyzeAction(configuration: "DevelopmentDebug")
            )
        ]
)
