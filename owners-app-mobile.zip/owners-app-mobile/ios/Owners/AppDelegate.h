#import <RCTAppDelegate.h>
#import <UIKit/UIKit.h>

// expo
#import <Expo/Expo.h>

@interface AppDelegate : EXAppDelegateWrapper

@end
