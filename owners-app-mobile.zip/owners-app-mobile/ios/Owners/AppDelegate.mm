#import "AppDelegate.h"

#import <React/RCTBundleURLProvider.h>
#import <React/RCTLinkingManager.h>

// appcenter
#import <AppCenterReactNativeShared/AppCenterReactNativeShared.h>
#import <AppCenterReactNative.h>
#import <AppCenterReactNativeAnalytics.h>
#import <AppCenterReactNativeCrashes.h>

// react-native-orientation-locker
#import "Orientation.h"

// @react-native-firebase/*
#import <Firebase.h>

// react-native-maps
#import <GoogleMaps/GoogleMaps.h>

// react-native-splash-screen
#import "RNSplashScreen.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  // react-native-firebase
  [FIRApp configure];

  // react-native-maps
  [GMSServices provideAPIKey:@"AIzaSyBNKPHmVHpuWuRp3ZgubY89Qdg_veBmH4E"]; // add this line using the api key obtained from Google Console

  // appcenter
  NSDictionary* infoDict = [[NSBundle mainBundle] infoDictionary];
  NSString* appCenterAppSecret = infoDict[@"APP_CENTER_APP_SECRET"];
  [AppCenterReactNativeShared setStartAutomatically:YES];
  [AppCenterReactNativeShared setAppSecret:appCenterAppSecret];
  [AppCenterReactNative register];
  [AppCenterReactNativeAnalytics registerWithInitiallyEnabled:true];
  [AppCenterReactNativeCrashes registerWithAutomaticProcessing];

  self.moduleName = @"Owners";
  // You can add your custom initial props in the dictionary below.
  // They will be passed down to the ViewController used by React Native.
  self.initialProps = @{};
    
  BOOL success = [super application:application didFinishLaunchingWithOptions:launchOptions];
  
  [RNSplashScreen show];
  
  return success;
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
#if DEBUG
  return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index"];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}

// https://reactnative.dev/docs/linking#enabling-deep-links
- (BOOL)application:(UIApplication *)application
   openURL:(NSURL *)url
   options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
  return [RCTLinkingManager application:application openURL:url options:options];
}

// https://reactnative.dev/docs/linking#enabling-deep-links
- (BOOL)application:(UIApplication *)application
    continueUserActivity:(nonnull NSUserActivity *)userActivity
    restorationHandler:(nonnull void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
  return [RCTLinkingManager application:application continueUserActivity:userActivity restorationHandler:restorationHandler];
}

// react-native-orientation-locker
- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
  return [Orientation getOrientation];
}

@end
