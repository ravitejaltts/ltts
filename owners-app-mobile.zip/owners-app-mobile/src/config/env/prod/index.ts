import { EnvironmentConfig } from "../EnvironmentConfig";

export const env: EnvironmentConfig = {
    name: "prod",
    apiDomain: "apim.ownersapp.winnebago.com",
    oktaDomain: "id.winnebago.com",
    oktaAuthServer: "ausqv1ke7SqiChC4H696",
    oktaClientId: "0oaqv0i2erknUGEJr696",
    googleApiKey: "AIzaSyBZkemiTawTZmKf_LOVwGABwgzcCpreiNc",
    isDebugVisible: __DEV__,
};
