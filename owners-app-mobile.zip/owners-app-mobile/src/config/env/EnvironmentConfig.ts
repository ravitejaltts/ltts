export type EnvironmentConfig = {
    name: "dev" | "mock" | "prod" | "test";
    apiDomain: string;
    oktaDomain: string;
    oktaAuthServer: string;
    oktaClientId: string;
    googleApiKey: string;
    isDebugVisible: boolean;
};
