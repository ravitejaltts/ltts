import { EnvironmentConfig } from "../EnvironmentConfig";

export const env: EnvironmentConfig = {
    name: "dev",
    apiDomain: "dev-apim.ownersapp.winnebago.com",
    oktaDomain: "test-id.winnebago.com",
    oktaAuthServer: "aus2nqukbrzKZ1pU51d7",
    oktaClientId: "0oa2p293qdHr9FmSR1d7",
    googleApiKey: "AIzaSyBZkemiTawTZmKf_LOVwGABwgzcCpreiNc",
    isDebugVisible: true,
};
