import { EnvironmentConfig } from "../EnvironmentConfig";
// Mock should not use any Azure or Okta APIs
export const env: EnvironmentConfig = {
    name: "mock",
    apiDomain: "dev-apim.ownersapp.winnebago.com",
    oktaDomain: "",
    oktaAuthServer: "",
    oktaClientId: "",
    googleApiKey: "AIzaSyBZkemiTawTZmKf_LOVwGABwgzcCpreiNc",
    isDebugVisible: true,
};
