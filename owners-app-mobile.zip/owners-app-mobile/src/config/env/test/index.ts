import { EnvironmentConfig } from "../EnvironmentConfig";

export const env: EnvironmentConfig = {
    name: "test",
    apiDomain: "tst-apim.ownersapp.winnebago.com",
    oktaDomain: "test-id.winnebago.com",
    oktaAuthServer: "aus2nr0amrIgjo4oZ1d7",
    oktaClientId: "0oa2p29uroIPFjZKR1d7",
    googleApiKey: "AIzaSyBZkemiTawTZmKf_LOVwGABwgzcCpreiNc",
    isDebugVisible: true,
};
