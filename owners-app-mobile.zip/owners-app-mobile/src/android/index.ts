import { IntentAction } from "./IntentAction";
import { IntentCategory } from "./IntentCategory";

export {
    IntentAction,
    IntentCategory
}