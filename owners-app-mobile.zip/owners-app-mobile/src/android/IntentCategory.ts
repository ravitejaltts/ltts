// See: https://developer.android.com/reference/android/content/Intent#constants
export enum IntentCategory {
    EmailApp = "android.intent.category.APP_EMAIL"
}