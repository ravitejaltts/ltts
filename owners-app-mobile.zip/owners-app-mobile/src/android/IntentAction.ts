// See: https://developer.android.com/reference/android/content/Intent#constants
export enum IntentAction {
    Main = "android.intent.action.MAIN"
}