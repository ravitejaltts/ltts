import React from "react";
import { RefreshControl, RefreshControlProps } from "react-native";
import { useTheme } from "../context";

export const ThemedRefreshControl: React.FunctionComponent<
    RefreshControlProps
> = (props) => {
    const [theme] = useTheme();

    return (
        <RefreshControl
            {...props}
            colors={[theme.color.black]}
            tintColor={theme.color.white}
            progressBackgroundColor={theme.color.white}
        />
    );
};
