import React from "react";
import { Text, View } from "react-native";
import { useTheme } from "../../context";
import StackView from "../StackView";
import { TextStyles } from "../../styles";

const PetTemperature: React.FunctionComponent<{
    tempText: string;
    preferredTemperatureUnit: string;
}> = ({ tempText, preferredTemperatureUnit }) => {
    const [theme] = useTheme();
    return (
        <View>
            <View
                style={{
                    position: "absolute",
                    left: 0,
                    right: 0,
                    top: 0,
                    height: "50%",
                    backgroundColor: theme.color.black,
                }}
            />
            {/* Temperature Card */}
            <StackView
                spacing={12}
                spacerColor={theme.color.dividers.gray1}
                style={{
                    flexDirection: "row",
                    marginHorizontal: 20,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    backgroundColor: theme.color.background.elevation3,
                }}>
                <View
                    style={{
                        flex: 1,
                        padding: 20,
                        alignItems: "center",
                    }}>
                    <StackView
                        spacing={2}
                        style={{
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        <Text
                            style={[
                                TextStyles.bold80,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {tempText}
                            <Text
                                style={[
                                    TextStyles.listItemSmall,
                                    { color: theme.color.text.deemphasized },
                                ]}>
                                ˚{preferredTemperatureUnit}
                            </Text>
                        </Text>

                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                    bottom: 10,
                                },
                            ]}>
                            Current Indoor Temp
                        </Text>
                    </StackView>
                </View>
            </StackView>
        </View>
    );
};

export { PetTemperature };
