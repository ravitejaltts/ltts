import React, { useState } from "react";
import { observer } from "mobx-react-lite";
import { Text, View } from "react-native";
import { AddIcon, SubtractIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { ThermostatMode } from "../../models/domain/climate";
import { PetComfortRangeType } from "../../models/domain/features/PetMinder";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { TemperatureModeCard } from "../climate";
import { ThermostatCircleButton } from "../climate/ThermostatCircleButton";
import { useSmartVehicle } from "../../hooks";
import { TemperatureUtils } from "../../utils";

const MAX_CIRCLE_BUTTON_SIZE = 60;
const MIN_CIRCLE_BUTTON_SIZE = 48;

export const PetComfortRangeSection: React.FunctionComponent<{
    disabled?: boolean;
}> = observer(({ disabled }) => {
    const container = useRootContainer();
    const [theme] = useTheme();
    // Shrink the circle buttons if the screen is small
    const [circleButtonSize, setCircleButtonSize] = useState(0);
    const [cardSelected, setCardSelected] = useState<PetComfortRangeType>(
        PetComfortRangeType.Max
    );

    const settingStore = container.stores.setting;
    const preferredTemperatureUnit = settingStore.preferredTemperatureUnit;

    const vehicle = useSmartVehicle();

    if (!vehicle) {
        return null;
    }

    const features = vehicle.features;
    const petMinder = features.petMinder;

    if (!petMinder) {
        return;
    }

    const minTemp = TemperatureUtils.convertFromC(
        petMinder.minTemp,
        preferredTemperatureUnit
    );
    const maxTemp = TemperatureUtils.convertFromC(
        petMinder.maxTemp,
        preferredTemperatureUnit
    );

    // card selections
    const isMax = cardSelected === PetComfortRangeType.Max;
    const isMin = cardSelected === PetComfortRangeType.Min;

    function onTempCardPress(selected: PetComfortRangeType) {
        switch (selected) {
            case PetComfortRangeType.Max:
                setCardSelected(PetComfortRangeType.Max);
                break;
            case PetComfortRangeType.Min:
                setCardSelected(PetComfortRangeType.Min);
                break;
        }
    }

    const onTempIncrement = () => {
        petMinder.increment(cardSelected, preferredTemperatureUnit);
    };

    const onTempDecrement = () => {
        petMinder.decrement(cardSelected, preferredTemperatureUnit);
    };

    const leftCircleButton = (size: number) => (
        <ThermostatCircleButton
            size={size}
            icon={SubtractIcon}
            iconFillColor={theme.color.blue.dark}
            disabled={disabled}
            onPress={onTempDecrement}
        />
    );

    const rightCircleButton = (size: number) => (
        <ThermostatCircleButton
            size={size}
            icon={AddIcon}
            iconFillColor={theme.color.orange.dark}
            disabled={disabled}
            onPress={onTempIncrement}
        />
    );

    return (
        <StackView
            spacing={2}
            style={{
                borderWidth: 1,
                borderRadius: 8,
                borderColor: theme.color.dividers.gray1,
            }}>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: disabled
                            ? theme.color.text.disabled
                            : theme.color.text.main,
                        padding: 18,
                    },
                ]}>
                Pet Comfort Range
            </Text>
            {/* Divider */}
            <View
                style={{
                    height: 1,
                    width: "100%",
                    backgroundColor: theme.color.dividers.gray1,
                }}
            />
            <StackView spacing={12} style={{ padding: 20 }}>
                <StackView
                    spacing={12}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    {/* Left Circle Button */}
                    <View
                        style={{
                            flex: 1,
                            alignItems: "flex-start",
                        }}
                        onLayout={(e) => {
                            const width = e.nativeEvent.layout.width;
                            setCircleButtonSize(
                                Math.min(MAX_CIRCLE_BUTTON_SIZE, width)
                            );
                        }}>
                        {circleButtonSize >= MIN_CIRCLE_BUTTON_SIZE &&
                            leftCircleButton(circleButtonSize)}
                    </View>
                    {/* Min Temp */}
                    <TemperatureModeCard
                        mode={ThermostatMode.Cool}
                        title={"MIN\nTEMP"}
                        titleStyle={[
                            TextStyles.contentEyebrow,
                            {
                                color: disabled
                                    ? theme.color.text.disabled
                                    : theme.color.text.deemphasized,
                                textAlign: "center",
                            },
                        ]}
                        containerStyle={[
                            {
                                borderWidth: isMin ? 2 : 1,
                                padding: isMin ? 18 : 19,
                            },
                            disabled ? { borderWidth: 1 } : null,
                        ]}
                        showIcon={false}
                        temperature={minTemp}
                        unit={preferredTemperatureUnit}
                        isOn={true}
                        isSelected={isMin}
                        disabled={disabled}
                        onPress={() => onTempCardPress(PetComfortRangeType.Min)}
                        isActive={false}
                    />
                    {/* Max Temp */}
                    <TemperatureModeCard
                        mode={ThermostatMode.Heat}
                        title={"MAX\nTEMP"}
                        titleStyle={[
                            TextStyles.contentEyebrow,
                            {
                                color: disabled
                                    ? theme.color.text.disabled
                                    : theme.color.text.deemphasized,
                                textAlign: "center",
                            },
                        ]}
                        containerStyle={[
                            {
                                borderWidth: isMax ? 2 : 1,
                                padding: isMax ? 18 : 19,
                            },
                            disabled ? { borderWidth: 1 } : null,
                        ]}
                        showIcon={false}
                        temperature={maxTemp}
                        unit={preferredTemperatureUnit}
                        isOn={true}
                        isSelected={isMax}
                        disabled={disabled}
                        onPress={() => onTempCardPress(PetComfortRangeType.Max)}
                        isActive={false}
                    />

                    {/* Right Circle Button */}
                    <View
                        style={{
                            flex: 1,
                            alignItems: "flex-end",
                        }}>
                        {circleButtonSize >= MIN_CIRCLE_BUTTON_SIZE &&
                            rightCircleButton(circleButtonSize)}
                    </View>
                </StackView>

                {circleButtonSize < MIN_CIRCLE_BUTTON_SIZE && (
                    <StackView
                        spacing={12}
                        style={{
                            flexDirection: "row",
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        {leftCircleButton(MAX_CIRCLE_BUTTON_SIZE)}
                        {rightCircleButton(MAX_CIRCLE_BUTTON_SIZE)}
                    </StackView>
                )}
            </StackView>
        </StackView>
    );
});
