import React from "react";
import { Text, TouchableHighlight } from "react-native";
import { useRootContainer, useTheme } from "../../context";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";

import { PawIcon } from "../../assets/icons";
import StackView from "../StackView";
import { observer } from "mobx-react-lite";

const PetMinderButton: React.FunctionComponent<{ disabled: boolean }> =
    observer(({ disabled }) => {
        const [theme] = useTheme();

        const container = useRootContainer();
        const vehicleStore = container.stores.vehicle;
        const vehicle = vehicleStore.associatedVehicle;

        if (!(vehicle instanceof SmartVehicle)) {
            return;
        }

        const features = vehicle.features;

        const petMinder = features.petMinder;
        const isEngaged = petMinder?.isEngaged;

        function onButtonPress() {
            petMinder?.toggleIsEngaged(!isEngaged);
        }

        return (
            <TouchableHighlight
                disabled={disabled}
                onPress={onButtonPress}
                underlayColor={
                    isEngaged
                        ? theme.color.background.defaultInverted
                        : theme.color.background.elevation1
                }
                style={{
                    width: 70,
                    height: 30,
                    borderWidth: 1,
                    borderRadius: 16,
                    justifyContent: "center",
                    borderColor: disabled
                        ? theme.color.text.disabled
                        : isEngaged
                        ? theme.color.background.defaultInverted
                        : theme.color.dividers.gray1,
                    backgroundColor: disabled
                        ? theme.color.text.disabled
                        : isEngaged
                        ? theme.color.background.defaultInverted
                        : theme.color.background.default,
                }}>
                <StackView
                    spacing={4}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                    }}>
                    <PawIcon
                        height={20}
                        width={20}
                        fill={
                            disabled || isEngaged
                                ? theme.color.text.mainInverted
                                : theme.color.text.main
                        }
                    />
                    <Text
                        style={[
                            TextStyles.tag,
                            {
                                color:
                                    disabled || isEngaged
                                        ? theme.color.text.mainInverted
                                        : theme.color.text.main,
                                textTransform: "uppercase",
                            },
                        ]}>
                        {isEngaged ? "On" : "Off"}
                    </Text>
                </StackView>
            </TouchableHighlight>
        );
    });

export { PetMinderButton };
