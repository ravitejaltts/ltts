import { NavigationAction, useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React from "react";
import {
    ColorValue,
    Text,
    TouchableOpacity,
    View,
    ViewProps,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { ForwardArrowIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { PetMinderNavigtionProp } from "../../screens/pet/PetMinderScreen";
import { TextStyles } from "../../styles";
import StackView from "../StackView";

export type PetMinderDashboardHeaderViewProps = {
    title: string;
    subtitle: string;
    messages: string[];
    icon: React.FunctionComponent<SvgProps>;
    color: ColorValue;
    action: NavigationAction | null;
};

export const PetMinderDashboardHeaderView: React.FunctionComponent<
    ViewProps & PetMinderDashboardHeaderViewProps
> = observer(
    ({ title, subtitle, messages, icon, color, action, ...viewProps }) => {
        const [theme] = useTheme();
        const navigation = useNavigation<PetMinderNavigtionProp>();

        const onAlertPress = () => {
            if (action) {
                navigation.dispatch(action);
            }
        };

        const isAlertTextWrapped = title.length > 30;

        return (
            <StackView spacing={4} {...viewProps}>
                {/* Icon (if text wrapped) */}
                {isAlertTextWrapped &&
                    icon({
                        width: 22,
                        height: 22,
                        fill: color,
                    })}
                {/* Horizontal StackView for icon and header */}
                <StackView
                    spacing={6}
                    style={{
                        flexDirection: "row",
                    }}>
                    {!isAlertTextWrapped &&
                        icon({
                            width: 22,
                            height: 22,
                            fill: color,
                        })}
                    <TouchableOpacity
                        disabled={!action}
                        activeOpacity={0.5}
                        onPress={onAlertPress}
                        style={{
                            flex: 1,
                        }}>
                        <StackView
                            spacing={6}
                            style={{
                                flexDirection: "row",
                                flex: 1,
                            }}>
                            <Text
                                style={[
                                    TextStyles.listItemLarge,
                                    {
                                        color: color,
                                    },
                                ]}>
                                {title}
                            </Text>

                            {action && <ForwardArrowIcon fill={color} />}
                        </StackView>
                    </TouchableOpacity>
                </StackView>

                {/* Subheading */}
                {Boolean(subtitle) && (
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.white,
                            },
                        ]}>
                        {subtitle}
                    </Text>
                )}

                <View>
                    {messages.map((message, index) => {
                        return (
                            <StackView
                                spacing={8}
                                key={`${message}_${index}`}
                                style={{
                                    flexDirection: "row",
                                    alignItems: "flex-start",
                                }}>
                                <Text
                                    style={[
                                        TextStyles.subheading,
                                        {
                                            color: theme.color.white,
                                        },
                                    ]}>
                                    •
                                </Text>
                                <Text
                                    style={[
                                        TextStyles.subheading,
                                        {
                                            flexShrink: 1,
                                            color: theme.color.white,
                                        },
                                    ]}>
                                    {message}
                                </Text>
                            </StackView>
                        );
                    })}
                </View>
            </StackView>
        );
    }
);
