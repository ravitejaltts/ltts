import React, { Fragment } from "react";
import {
    NativeScrollEvent,
    NativeSyntheticEvent,
    ScrollView,
    ScrollViewProps,
    StyleSheet,
    View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "../context";
import { useLargeTitleNavigation, useStatusBar } from "../hooks";
import { LargeTitleHeaderView } from "./LargeTitleHeaderView";

interface LargeTitleScrollViewProps extends ScrollViewProps {
    title: string;
    navigationHeaderShown?: boolean;
    titleHeaderView?: React.ReactNode;
    statusBarView?: React.ReactNode;
    keyboardAware?: boolean;
}

export const LargeTitleScrollView: React.FunctionComponent<
    LargeTitleScrollViewProps
> = ({
    title,
    navigationHeaderShown = true,
    titleHeaderView,
    statusBarView,
    keyboardAware = false,
    children,
    ...scrollViewProps
}) => {
    const [theme] = useTheme();
    useStatusBar("light-content");
    const safeAreaInsets = useSafeAreaInsets();

    const { headerHeightRef, onScroll } = useLargeTitleNavigation(
        title,
        navigationHeaderShown
    );

    const _onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
        scrollViewProps.onScroll?.(event);
        onScroll(event);
    };

    const contentContainerStyle = StyleSheet.flatten(
        scrollViewProps.contentContainerStyle
    );
    const contentContainerBackgroundColor =
        contentContainerStyle?.backgroundColor ??
        theme.color.background.elevation3;

    const containerProps: ScrollViewProps = {
        ...scrollViewProps,
        onScroll: _onScroll,
        scrollEventThrottle: 16,
        keyboardDismissMode: "on-drag",
        keyboardShouldPersistTaps: "never",
        style: [
            {
                backgroundColor: theme.color.black,
            },
            scrollViewProps.style,
        ],
        contentContainerStyle: [
            {
                flexGrow: 1,
                backgroundColor: contentContainerBackgroundColor,
                paddingBottom: 40,
            },
            scrollViewProps.contentContainerStyle,
        ],
    };

    const containerChildren = (
        <Fragment>
            {/* Header */}
            <LargeTitleHeaderView
                title={title}
                headerHeightRef={headerHeightRef}
                titleHeaderView={titleHeaderView}
            />

            {/* Children */}
            {children}

            {/* Overscroll Background */}
            <View
                style={{
                    backgroundColor: contentContainerBackgroundColor,
                    position: "absolute",
                    height: 500,
                    bottom: -500,
                    left: 0,
                    right: 0,
                }}
            />
        </Fragment>
    );

    return (
        <View
            style={{
                flex: 1,
            }}>
            {/* Status Bar Background (when header not shown) */}
            {!navigationHeaderShown && (
                <View
                    style={{
                        backgroundColor: theme.color.black,
                        height: safeAreaInsets.top,
                    }}
                />
            )}
            {statusBarView}
            {keyboardAware ? (
                <KeyboardAwareScrollView {...containerProps}>
                    {containerChildren}
                </KeyboardAwareScrollView>
            ) : (
                <ScrollView {...containerProps}>{containerChildren}</ScrollView>
            )}
        </View>
    );
};
