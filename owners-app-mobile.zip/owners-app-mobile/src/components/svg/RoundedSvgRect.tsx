import React from "react";
import { Path, PathProps } from "react-native-svg";

interface RoundedSvgRectProps extends PathProps {
    width: number;
    height: number;
    rtl?: number;
    rtr?: number;
    rbl?: number;
    rbr?: number;
    r?: number;
}

export const RoundedSvgRect: React.FunctionComponent<RoundedSvgRectProps> = ({
    width,
    height,
    rtl,
    rtr,
    rbl,
    rbr,
    r: radius,
    ...pathProps
}) => {
    const topLeft = rtl ?? radius ?? 0;
    const topRight = rtr ?? radius ?? 0;
    const bottomLeft = rbl ?? radius ?? 0;
    const bottomRight = rbr ?? radius ?? 0;

    const pathCommands: string[] = [];

    // Move to top left
    pathCommands.push(`M ${topLeft},0`);
    // Horizontal line across top of box
    pathCommands.push(`h ${width - topLeft - topRight}`);

    if (topRight) {
        // Top right arc
        pathCommands.push(
            `a ${topRight},${topRight} 0 0 1 ${topRight},${topRight}`
        );
    }

    // Move to top right
    //pathCommands.push(`M ${width},${topRight}`);
    // Vertical line right side of box
    pathCommands.push(`v ${height - topRight - bottomRight}`);

    if (bottomRight) {
        // Bottom right arc
        pathCommands.push(
            `a ${bottomRight},${bottomRight} 0 0 1 -${bottomRight},${bottomRight}`
        );
    }

    // Move to bottom right
    //pathCommands.push(`M ${width - bottomRight},${height}`);
    // Horizontal line bottom of box
    pathCommands.push(`h -${width - bottomRight - bottomLeft}`);

    if (bottomLeft) {
        // Bottom left arc
        pathCommands.push(
            `a ${bottomLeft},${bottomLeft} 0 0 1 -${bottomLeft},-${bottomLeft}`
        );
    }

    // Vertical line left side of box
    pathCommands.push(`v -${height - bottomLeft - topLeft}`);

    if (topLeft) {
        // Top left arc
        pathCommands.push(
            `a ${topLeft},${topLeft} 0 0 1 ${topLeft},-${topLeft}`
        );
    }

    pathCommands.push("z");

    const path = pathCommands.join(" ");

    return <Path {...pathProps} d={path} />;
};
