import { observer } from "mobx-react-lite";
import React, { useEffect } from "react";
import { AddIcon, ErrorFillIcon, SubtractIcon } from "../../assets/icons";
import { SlideOut, SlideOutMode } from "../../models/domain/movables";
import StackView from "../StackView";
import { ControlProgressButton } from "../newButtons";
import {
    ControlSection,
    ControlSectionHeaderView,
    ControlSectionLoadingView,
} from "../smartVehicle";
import { useTheme } from "../../context";
import { useAppState } from "../../hooks";
import { useIsFocused } from "@react-navigation/native";

export const SlideOutControlSection: React.FunctionComponent<{
    slideOut: SlideOut;
    isOutOfBluetoothRange: boolean;
}> = observer(({ slideOut, isOutOfBluetoothRange }) => {
    const [theme] = useTheme();

    // When this component unmounts,
    // stop movement
    useEffect(() => {
        return () => {
            slideOut.stopMovement();
        };
    }, [slideOut]);

    const isFocused = useIsFocused();

    // When this screen is unfocused
    // stop movement
    useEffect(() => {
        if (!isFocused) {
            slideOut.stopMovement();
        }
    }, [slideOut, isFocused]);

    const { appState } = useAppState();

    // When app goes to inactive or background,
    // stop movement
    useEffect(() => {
        switch (appState) {
            case "inactive":
                slideOut.stopMovement();
                break;
            default:
                // Do nothing
                break;
        }
    }, [slideOut, appState]);

    let headerViews: React.ReactNode = null;

    if (slideOut.isParkBrakeIgnitionLockout) {
        headerViews = (
            <ControlSectionHeaderView
                title="Slide-Out Disabled"
                bodyText="Slide-out controls are disabled because the parking brake is not engaged or the ignition is not running."
                icon={(props) => (
                    <ErrorFillIcon
                        {...props}
                        fill={theme.color.yellow.warning}
                    />
                )}
            />
        );
    } else if (slideOut.isLockedOut) {
        headerViews = (
            <ControlSectionHeaderView
                title="Slide-Out Disabled"
                bodyText="Slide-out controls are disabled"
                icon={(props) => (
                    <ErrorFillIcon
                        {...props}
                        fill={theme.color.yellow.warning}
                    />
                )}
            />
        );
    }

    let modeText = "";

    switch (slideOut.mode) {
        case SlideOutMode.Extending:
            modeText = "Extending";
            break;
        case SlideOutMode.Retracting:
            modeText = "Retracting";
            break;
        case SlideOutMode.Extended:
        case SlideOutMode.Retracted:
        case SlideOutMode.Off:
        default:
            modeText = "";
            break;
    }

    return (
        <ControlSection
            title={slideOut.name}
            headerViews={headerViews}
            rightView={
                <ControlSectionLoadingView
                    text={modeText}
                    loading={
                        slideOut.mode === SlideOutMode.Extending ||
                        slideOut.mode === SlideOutMode.Retracting
                    }
                />
            }>
            <StackView
                spacing={8}
                style={{
                    flexDirection: "row",
                    padding: 12,
                }}>
                <ControlProgressButton
                    text="Retract"
                    icon={SubtractIcon}
                    disabled={isOutOfBluetoothRange || slideOut.isLockedOut}
                    onLongPressComplete={() => slideOut.startRetracting()}
                    onLongPressCancelled={() => slideOut.stopMovement()}
                    style={{
                        height: 100,
                        flex: 1,
                    }}
                />
                <ControlProgressButton
                    text="Extend"
                    icon={AddIcon}
                    disabled={isOutOfBluetoothRange || slideOut.isLockedOut}
                    onLongPressComplete={() => slideOut.startExtending()}
                    onLongPressCancelled={() => slideOut.stopMovement()}
                    style={{
                        height: 100,
                        flex: 1,
                    }}
                />
            </StackView>
        </ControlSection>
    );
});
