import { useIsFocused } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";
import {
    AddIcon,
    ClearFilledIcon,
    ErrorFillIcon,
    SignalTowerIcon,
    SubtractIcon,
    WLogoIcon,
} from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { useAppState } from "../../hooks";
import { Awning, AwningMode } from "../../models/domain/movables";
import { SystemLockoutOrWarning } from "../../models/domain/system";
import { TextStyles } from "../../styles";
import { MathUtils, StringUtils } from "../../utils";
import StackView from "../StackView";
import { AnimatedEllipsisText } from "../animated";
import {
    ControlButton,
    ControlProgressButton,
    GradientLoadingButton,
} from "../newButtons";
import { ControlSection, ControlSectionHeaderView } from "../smartVehicle";

const AUTO_BUTTON_HEIGHT = 128;

export const AwningControlSection: React.FunctionComponent<{
    awning: Awning;
    isOutOfBluetoothRange: boolean;
}> = observer(({ awning, isOutOfBluetoothRange }) => {
    const [theme] = useTheme();

    const [warningVisible, setWarningVisible] = useState(true);
    const [isSendingCommand, setIsSendingCommand] = useState(false);
    const [isManualButtonPressed, setIsManualButtonPressed] = useState(false);

    const container = useRootContainer();

    const featureFlagStore = container.stores.featureFlag;
    const manualMoveFlag = featureFlagStore.awningManaulMove;
    const manualMoveAllowed = Boolean(manualMoveFlag?.value);

    // When this component unmounts,
    // stop movement
    useEffect(() => {
        return () => {
            awning.stopSilent();
        };
    }, [awning]);

    const isFocused = useIsFocused();

    // When this screen is unfocused
    // stop movement
    useEffect(() => {
        if (!isFocused) {
            awning.stopSilent();
        }
    }, [awning, isFocused]);

    const { appState } = useAppState();

    // When app goes to inactive or background,
    // stop movement
    useEffect(() => {
        switch (appState) {
            case "inactive":
                awning.stopSilent();
                break;
            default:
                // Do nothing
                break;
        }
    }, [awning, appState]);

    const mode = awning.mode;
    const percentExtended = awning.percentExtended;
    const isFullyExtended =
        MathUtils.isNumber(percentExtended) && percentExtended >= 100;
    const isRetracted =
        mode === AwningMode.Retracted ||
        (MathUtils.isNumber(percentExtended) && percentExtended <= 0);

    const isMoving = awning.isMoving;
    const isManualMoving = awning.isManualMoving;
    const isAutoMoving = awning.isAutoMoving;

    const isManualMovingFromRv = isManualMoving && !isManualButtonPressed;

    const lockouts = awning.lockouts;
    const isLockedOut = awning.isLockedOut;

    const warnings = awning.warnings;
    const hasWarnings = awning.hasWarnings;

    const headerMessages: React.ReactElement[] = [];

    // Situations where awning is disabled
    if (isLockedOut) {
        // Handle lockouts

        lockouts.forEach((lk) => {
            let bodyText = "";

            switch (lk) {
                case SystemLockoutOrWarning.Ignition:
                    bodyText =
                        "Awning controls are disabled because the chassis ignition is on. Please turn off the ignition before use.";
                    break;
                default:
                    bodyText = `Awning controls are disabled because of a system lockout. (Code: ${lk})`;
                    break;
            }

            headerMessages.push(
                <ControlSectionHeaderView
                    key={`header_lockout_${lk}`}
                    title="Awning Disabled"
                    bodyText={bodyText}
                    icon={(props) => (
                        <ErrorFillIcon
                            {...props}
                            fill={theme.color.yellow.warning}
                        />
                    )}
                />
            );
        });
    }

    if (isOutOfBluetoothRange) {
        headerMessages.push(
            <ControlSectionHeaderView
                key="header_lockout_bluetooth"
                title="Out of Bluetooth Range"
                bodyText="You are out of Bluetooth range and certain awning features cannot be controlled while away from your RV."
                icon={(props) => (
                    <SignalTowerIcon {...props} fill={theme.color.blue.brand} />
                )}
            />
        );
    }

    if (warningVisible && hasWarnings) {
        // Determine which warnings are visible
        const isLowBatteryVoltageWarning = awning.isLowBatteryVoltageWarning;
        const isParkBrakeWarning = awning.isParkBrakeWarning;

        // Only one warning is visible at a time
        let warningText: string;

        if (isLowBatteryVoltageWarning && isParkBrakeWarning) {
            // Low battery and parking brake
            warningText =
                "It's recommended to make sure your battery is charged and your parking brake is engaged while using your awning.";
        } else if (isLowBatteryVoltageWarning) {
            // Low battery
            warningText =
                "Your RV battery is low. It's recommend to charge your house battery before using your awning.";
        } else if (isParkBrakeWarning) {
            // Parking brake
            warningText =
                "Your parking brake is released. Please consider engaging the parking brake before using your awning.";
        } else {
            const codes = warnings.join(", ");
            warningText = `Please check your owner's manual before using your awning. (Code: ${codes})`;
        }

        if (warningText) {
            headerMessages.push(
                <ControlSectionHeaderView
                    key="header_warning"
                    title="Helpful Tip!"
                    bodyText={warningText}
                    onClose={() => setWarningVisible(false)}
                    icon={(props) => (
                        <WLogoIcon {...props} fill={theme.color.blue.brand} />
                    )}
                />
            );
        }
    }

    return (
        <ControlSection
            title="Awning Position"
            rightView={
                <View
                    style={{
                        flexDirection: "row",
                    }}>
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {awning.modeText}
                    </Text>
                    <AnimatedEllipsisText
                        animating={isMoving}
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}
                    />
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {" "}
                        • {StringUtils.toValueString(percentExtended)}%
                    </Text>
                </View>
            }
            headerViews={
                headerMessages.length > 0 ? (
                    <StackView
                        spacing={1}
                        spacerColor={theme.color.dividers.gray1}>
                        {headerMessages}
                    </StackView>
                ) : null
            }>
            {/* Auto/Stop Buttons */}
            {isAutoMoving ? (
                <View
                    style={{
                        padding: 12,
                    }}>
                    <GradientLoadingButton
                        text="Stop"
                        style={{
                            height: AUTO_BUTTON_HEIGHT,
                        }}
                        icon={ClearFilledIcon}
                        disabled={isSendingCommand}
                        onPress={() => {
                            setIsSendingCommand(true);
                            awning
                                .sendStopCommand()
                                .catch(() => {
                                    // Do nothing
                                })
                                .finally(() => {
                                    setIsSendingCommand(false);
                                });
                        }}
                    />
                </View>
            ) : (
                <StackView
                    spacing={10}
                    style={{
                        flexDirection: "row",
                        padding: 12,
                    }}>
                    {/* Auto-Retract: always visible */}
                    <ControlProgressButton
                        text={`Auto\nRetract`}
                        icon={SubtractIcon}
                        disabled={
                            isManualMoving ||
                            isLockedOut ||
                            isSendingCommand ||
                            isRetracted
                        }
                        onLongPressComplete={() => {
                            setIsSendingCommand(true);
                            awning
                                .sendAutoRetractCommand()
                                .catch(() => {
                                    // Do nothing
                                })
                                .finally(() => {
                                    setIsSendingCommand(false);
                                });
                        }}
                        style={{
                            height: AUTO_BUTTON_HEIGHT,
                            flex: 1,
                        }}
                    />

                    {/* Auto-Extend: only visible when in bluetooth range */}
                    {!isOutOfBluetoothRange && (
                        <ControlProgressButton
                            text={`Auto\nExtend`}
                            icon={AddIcon}
                            disabled={
                                isManualMoving ||
                                isLockedOut ||
                                isSendingCommand ||
                                isFullyExtended
                            }
                            onLongPressComplete={() => {
                                setIsSendingCommand(true);
                                awning
                                    .sendAutoExtendCommand()
                                    .catch(() => {
                                        // Do nothing
                                    })
                                    .finally(() => {
                                        setIsSendingCommand(false);
                                    });
                            }}
                            style={{
                                height: AUTO_BUTTON_HEIGHT,
                                flex: 1,
                            }}
                        />
                    )}
                </StackView>
            )}

            {/*
                Manual extend and retract buttons: visible when within
                bluetooth range and not auto-moving
            */}
            {manualMoveAllowed && !isOutOfBluetoothRange && !isAutoMoving && (
                <StackView
                    spacing={1}
                    spacerColor={theme.color.dividers.gray1}
                    style={{
                        flexDirection: "row",
                    }}>
                    <ControlButton
                        onPressIn={() => {
                            setIsManualButtonPressed(true);
                        }}
                        onLongPress={() => awning.startRetracting()}
                        onPressOut={() => {
                            setIsManualButtonPressed(false);
                            setIsSendingCommand(true);
                            awning
                                .sendStopCommand()
                                .catch(() => {
                                    // Do nothing
                                })
                                .finally(() => {
                                    setIsSendingCommand(false);
                                });
                        }}
                        disabled={
                            isManualMovingFromRv ||
                            isLockedOut ||
                            isSendingCommand ||
                            isRetracted
                        }
                        icon={SubtractIcon}
                        style={{
                            flex: 1,
                            borderRadius: 0,
                            borderBottomLeftRadius: 8,
                        }}
                    />
                    <ControlButton
                        onPressIn={() => {
                            setIsManualButtonPressed(true);
                        }}
                        onLongPress={() => awning.startExtending()}
                        onPressOut={() => {
                            setIsManualButtonPressed(false);
                            setIsSendingCommand(true);
                            awning
                                .sendStopCommand()
                                .catch(() => {
                                    // Do nothing
                                })
                                .finally(() => {
                                    setIsSendingCommand(false);
                                });
                        }}
                        disabled={
                            isManualMovingFromRv ||
                            isLockedOut ||
                            isSendingCommand ||
                            isFullyExtended
                        }
                        icon={AddIcon}
                        style={{
                            flex: 1,
                            borderRadius: 0,
                            borderBottomRightRadius: 8,
                        }}
                    />
                </StackView>
            )}
        </ControlSection>
    );
});
