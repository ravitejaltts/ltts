import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import { Alert } from "react-native";
import { HeartIcon, HeartOutlineIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { ImageButton } from "../Buttons";

const VIEW_NAME = "FavoriteDealerButton";

const DealerFavoriteButton: React.FunctionComponent<{
    dealerLocationId: number;
    isFavoriteInitially?: boolean;
}> = observer(({ dealerLocationId }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const logger = container.services.logger;
    const dealerStore = container.stores.dealer;
    const favorites = dealerStore.favorites;

    const [isFavorite, setIsFavorite] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        setIsFavorite(
            favorites.some((l) => l.dealerLocationId === dealerLocationId)
        );
    }, [favorites, dealerLocationId]);

    function onPress() {
        if (isLoading) {
            // Don't respond to taps when between states
            return;
        }

        if (isFavorite) {
            // Prompt user to remove from favorites
            Alert.alert(
                "Remove From Favorites?",
                "Unfavorite service location and remove from your favorite locations list?",
                [
                    {
                        text: "Cancel",
                        style: "cancel",
                    },
                    {
                        text: "Remove",
                        style: "default",
                        onPress: () => unfavoriteDealerLocation(),
                    },
                ]
            );
        } else {
            favoriteDealerLocation();
        }
    }

    function favoriteDealerLocation() {
        // Immediately change the state
        setIsLoading(true);
        setIsFavorite(true);

        // Favorite this location
        dealerStore
            .favoriteDealerLocation(dealerLocationId)
            .catch((error) => {
                setIsFavorite(false);
                logger.error(VIEW_NAME, error);
            })
            .finally(() => setIsLoading(false));
    }

    function unfavoriteDealerLocation() {
        // Immediately change the state
        setIsLoading(true);
        setIsFavorite(false);

        dealerStore
            .unfavoriteDealerLocation(dealerLocationId)
            .catch((error) => {
                setIsFavorite(true);
                logger.error(VIEW_NAME, error);
            })
            .finally(() => setIsLoading(false));
    }

    return (
        <ImageButton
            onPress={onPress}
            image={(props) => {
                return isFavorite ? (
                    <HeartIcon
                        fill={theme.color.red.brand.toString()}
                        {...props}
                    />
                ) : (
                    <HeartOutlineIcon
                        fill={theme.color.text.main.toString()}
                        {...props}
                    />
                );
            }}
        />
    );
});

export default DealerFavoriteButton;
