import { observer } from "mobx-react-lite";
import React, { useCallback, useState } from "react";
import {
    ActivityIndicator,
    StyleProp,
    Text,
    View,
    ViewStyle,
} from "react-native";
import { HeartBrokenIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { useFocusedDependencyEffect, useLogger } from "../../hooks";
import { TextStyles } from "../../styles";
import { LinkButton, PrimaryButton } from "../Buttons";
import StackView from "../StackView";
import DealerFavoriteCard from "./DealerFavoriteCard";
import { FavoriteDealerLocation } from "../../models/domain/maintenance";

type DealerHelpCardProps = {
    onFindService: () => void;
    onSeeAllFavoriteLocations: () => void;
    navigateToFavorite: (favorite: FavoriteDealerLocation) => void;
    style?: StyleProp<ViewStyle>;
};

const DealerHelpCard: React.FunctionComponent<DealerHelpCardProps> = ({
    onFindService,
    onSeeAllFavoriteLocations,
    navigateToFavorite,
    style,
}) => {
    const [theme] = useTheme();

    const container = useRootContainer();

    const { logError } = useLogger("DealerHelpCard");

    const dealerStore = container.stores.dealer;
    const favorites = dealerStore.favorites.slice(0, 2);

    const vehicleStore = container.stores.vehicle;
    const hasVehicle = vehicleStore.hasVehicle;

    const [isLoading, setIsLoading] = useState(false);

    // Update favorites
    useFocusedDependencyEffect(
        useCallback(() => {
            if (!hasVehicle) {
                setIsLoading(false);
                return;
            }

            setIsLoading(true);

            dealerStore
                .updateFavoriteDealerLocations()
                .catch((error) => {
                    logError(error);
                })
                .finally(() => {
                    setIsLoading(false);
                });
        }, [hasVehicle, dealerStore, logError])
    );

    return (
        <View
            style={[
                {
                    paddingTop: 27,
                    paddingBottom: 24,
                    paddingHorizontal: 16,
                    backgroundColor: theme.color.background.elevation2,
                    borderRadius: 8,
                },
                style,
            ]}>
            <Text
                style={[
                    TextStyles.calloutTitle,
                    {
                        color: theme.color.text.main,
                        textAlign: "center",
                    },
                ]}>
                Dealer Help Center
            </Text>

            <Text
                style={[
                    TextStyles.body,
                    {
                        color: theme.color.text.main,
                        textAlign: "center",
                        marginTop: 12,
                        marginBottom: 24,
                    },
                ]}>
                Need some work done on your RV? {"\n"} Our network of dealers is
                here to help!
            </Text>

            <PrimaryButton text="Find a Dealer" onPress={onFindService} />

            <View>
                <View
                    style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "center",
                        paddingTop: 10,
                        paddingBottom: 2,
                    }}>
                    <Text
                        style={[
                            TextStyles.sectionBreak,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Favorite Dealers
                    </Text>

                    <LinkButton
                        text="See All"
                        onPress={onSeeAllFavoriteLocations}
                    />
                </View>

                {isLoading ? (
                    <View
                        style={{
                            justifyContent: "center",
                            alignItems: "center",
                            height: 400,
                        }}>
                        <ActivityIndicator
                            size="large"
                            animating={true}
                            color={theme.color.text.main}
                        />
                    </View>
                ) : favorites.length === 0 ? (
                    <View
                        style={{
                            flex: 1,
                            justifyContent: "center",
                            alignItems: "center",
                            height: 200,
                            borderRadius: 8,
                            padding: 20,
                            backgroundColor: theme.color.background.elevation3,
                        }}>
                        <HeartBrokenIcon
                            style={{
                                marginBottom: 4,
                            }}
                            fill={theme.color.red.brand.toString()}
                        />
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.main,
                                    marginBottom: 20,
                                },
                            ]}>
                            No Favorite Locations
                        </Text>

                        <Text
                            style={[
                                TextStyles.regular17,
                                {
                                    color: theme.color.text.main,
                                    textAlign: "center",
                                },
                            ]}>
                            Sorry, nothing to see here. Try adding some
                            locations you frequent or want to save for quick
                            access later
                        </Text>
                    </View>
                ) : (
                    <StackView spacing={20}>
                        {favorites.map((f) => (
                            <DealerFavoriteCard
                                key={f.dealerLocationId}
                                favoriteLocation={f}
                                navigateToFavorite={navigateToFavorite}
                            />
                        ))}
                    </StackView>
                )}
            </View>
        </View>
    );
};

export default observer(DealerHelpCard);
