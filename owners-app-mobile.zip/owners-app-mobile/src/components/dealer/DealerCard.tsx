import React from "react";
import { View, Text } from "react-native";
import { TextStyles, DarkTheme, LightTheme } from "../../styles";
import { useRootContainer, useTheme } from "../../context";
import { WLogoIcon } from "../../assets/icons";
import StackView from "../StackView";
import { SecondaryButton } from "../Buttons";
import { DealerLocation } from "../../models/domain/maintenance";
import DealerFavoriteButton from "./DealerFavoriteButton";
import { useDistance } from "../../hooks";
import { observer } from "mobx-react-lite";

const DealerCard: React.FunctionComponent<{
    location: DealerLocation;
    hasBorder: boolean;
    navigateToLocation: (location: DealerLocation) => void;
}> = observer(({ location, hasBorder, navigateToLocation }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const linkingService = container.services.linking;

    const fullAddress = `${location.address}\n${location.city}, ${location.stateProvince} ${location.postalCode}`;
    const distance = useDistance(location);
    const name =
        location.dealerName !== "Unknown"
            ? location.dealerName
            : location.locationName;

    function onCallPressed() {
        linkingService.call(location.phoneNumber);
    }

    function onDirectionsPressed() {
        linkingService.openDirections(location.latitude, location.longitude);
    }

    return (
        <View
            style={{
                backgroundColor: theme.color.background.elevation3,
                padding: 20,
                borderRadius: 8,
                borderWidth: hasBorder ? 1 : 0,
                borderColor: hasBorder
                    ? theme.color.background.elevation1
                    : undefined,
            }}>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                }}>
                <View
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    <Text
                        style={[
                            TextStyles.listEyebrow,
                            {
                                color: DarkTheme.color.dividers.gray2,
                            },
                        ]}>
                        {distance}
                    </Text>
                </View>

                {/* Favorite Button */}
                <DealerFavoriteButton
                    dealerLocationId={location.dealerLocationId}
                />
            </View>

            <Text
                style={[
                    TextStyles.listItemLarge,
                    {
                        color: theme.color.text.main,
                        textTransform: "capitalize",
                    },
                ]}>
                {name}
            </Text>

            {location.isFlyingW && (
                <View
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    <WLogoIcon fill={LightTheme.color.red.brand.toString()} />
                    <Text
                        style={[
                            TextStyles.listEyebrow,
                            {
                                color: LightTheme.color.text.deemphasized,
                                marginLeft: 6,
                            },
                        ]}>
                        Flying W Service Excellence Dealer
                    </Text>
                </View>
            )}
            <Text
                style={[
                    TextStyles.body,
                    {
                        color: theme.color.text.main,
                        marginBottom: 16,
                        textTransform: "capitalize",
                    },
                ]}>
                {fullAddress}
            </Text>
            <StackView
                spacing={8}
                style={{
                    flexDirection: "row",
                    justifyContent: "flex-start",
                    alignItems: "center",
                }}>
                <SecondaryButton
                    style={{
                        height: 40,
                        borderRadius: 20,
                        paddingHorizontal: 12,
                    }}
                    text="Call"
                    onPress={onCallPressed}
                />
                <SecondaryButton
                    style={{
                        height: 40,
                        borderRadius: 20,
                        paddingHorizontal: 12,
                    }}
                    text="Directions"
                    onPress={onDirectionsPressed}
                />
                <SecondaryButton
                    style={{
                        height: 40,
                        borderRadius: 20,
                        paddingHorizontal: 12,
                    }}
                    text="Details"
                    onPress={() => navigateToLocation(location)}
                />
            </StackView>
        </View>
    );
});

export default DealerCard;
