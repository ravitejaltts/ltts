import React from "react";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import { PrimaryButton } from "../Buttons";

const ContactDealerCard: React.FunctionComponent<{
    navigateToMap: () => void;
    style?: StyleProp<ViewStyle>;
}> = ({ navigateToMap, style }) => {
    const [theme] = useTheme();

    return (
        <View
            style={[
                {
                    backgroundColor: theme.color.background.elevation3,
                    paddingTop: 28,
                    paddingBottom: 24,
                    paddingHorizontal: 16,
                    borderRadius: 8,
                },
                style,
            ]}>
            <Text
                style={[
                    TextStyles.calloutTitle,
                    {
                        color: theme.color.text.main,
                        textAlign: "center",
                    },
                ]}>
                Having Issues?
            </Text>

            <Text
                style={[
                    TextStyles.largeButton,
                    {
                        color: theme.color.text.main,
                        textAlign: "center",
                        paddingTop: 12,
                        paddingBottom: 20,
                        paddingHorizontal: 24,
                    },
                ]}>
                A certified Winnebago dealer is ready to help!
            </Text>

            <PrimaryButton text="Contact a Dealer" onPress={navigateToMap} />
        </View>
    );
};

export default ContactDealerCard;
