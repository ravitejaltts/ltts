import React from "react";
import { LogoIcon } from "../../assets/icons";
import { useTheme } from "../../context";

const LogoTitleView: React.FunctionComponent = () => {
    const [theme] = useTheme();
    return (
        <LogoIcon
            width={148}
            height={24}
            fill={theme.color.red.brand.toString()}
        />
    );
};

export default LogoTitleView;
