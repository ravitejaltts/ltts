import React from "react";
import { Platform, View } from "react-native";
import { useTheme } from "../../context";

const NavigationHeaderView: React.FunctionComponent = () => {
    const [theme] = useTheme();

    if (Platform.OS === "android") {
        return null;
    }

    return (
        <View
            style={{
                backgroundColor: theme.color.black,
                height: 500,
                position: "absolute",
                top: -500,
                left: 0,
                right: 0,
            }}
        />
    );
};

export default NavigationHeaderView;
