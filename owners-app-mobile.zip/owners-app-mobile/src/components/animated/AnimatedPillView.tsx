import React from "react";
import { Animated, ViewStyle, StyleProp } from "react-native";
import { ColorValue } from "react-native-windows";
import { TextStyles } from "../../styles";

export type PillAnimationColors = {
    start: ColorValue;
    end: ColorValue;
};

export const AnimatedPillView: React.FunctionComponent<{
    style: StyleProp<ViewStyle>;
    text: string;
    value: Animated.Value;
    backgroundAnimationColors: PillAnimationColors;
    textAnimationColors: PillAnimationColors;
}> = ({
    style,
    text,
    backgroundAnimationColors,
    textAnimationColors,
    value,
}) => {
    const bgStyle = {
        backgroundColor: value.interpolate({
            inputRange: [0, 1],
            outputRange: [
                backgroundAnimationColors.start.toString(),
                backgroundAnimationColors.end.toString(),
            ],
        }),
    };

    const textStyle = {
        color: value.interpolate({
            inputRange: [0, 1],
            outputRange: [
                textAnimationColors.start.toString(),
                textAnimationColors.end.toString(),
            ],
        }),
    };

    return (
        <Animated.View style={[style, bgStyle]}>
            <Animated.Text style={[textStyle, TextStyles.semibold15]}>
                {text}
            </Animated.Text>
        </Animated.View>
    );
};
