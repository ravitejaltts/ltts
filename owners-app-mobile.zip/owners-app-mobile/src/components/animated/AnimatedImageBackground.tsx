import { Animated, ImageBackground } from "react-native";

export const AnimatedImageBackground =
    Animated.createAnimatedComponent(ImageBackground);
