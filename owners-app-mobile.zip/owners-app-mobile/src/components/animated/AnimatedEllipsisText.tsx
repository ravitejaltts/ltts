import React from "react";
import { Text, TextProps } from "react-native";
import { useEllipsisAnimation } from "../../hooks";

interface AnimatedEllipsisTextProps extends TextProps {
    animating: boolean;
    intervalMillis?: number;
}

export const AnimatedEllipsisText: React.FunctionComponent<
    AnimatedEllipsisTextProps
> = (props) => {
    const { animating, intervalMillis = 250, ...textProps } = props;

    const ellipsis = useEllipsisAnimation(animating, intervalMillis);

    return props.animating ? (
        <Text
            {...textProps}
            style={[
                {
                    width: 16,
                },
                props.style,
            ]}>
            {ellipsis}
        </Text>
    ) : null;
};
