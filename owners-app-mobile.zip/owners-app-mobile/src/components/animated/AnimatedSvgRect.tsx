import { Animated } from "react-native";
import { Rect } from "react-native-svg";

export const AnimatedSvgRect = Animated.createAnimatedComponent(Rect);
