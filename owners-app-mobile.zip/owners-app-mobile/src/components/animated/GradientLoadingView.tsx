import React, { useEffect, useRef, useState } from "react";
import {
    Animated,
    ColorValue,
    Easing,
    StyleProp,
    View,
    ViewStyle,
} from "react-native";
import Svg, { Defs, LinearGradient, Rect, Stop } from "react-native-svg";

const AnimatedStop = Animated.createAnimatedComponent(Stop);

export const GradientLoadingView: React.FunctionComponent<{
    animating: boolean;
    direction: "vertical" | "horizontal";
    duration: number;
    backgroundColor: ColorValue;
    highlightColor: ColorValue;
    style?: StyleProp<ViewStyle>;
    children?: React.ReactNode;
}> = ({
    animating,
    direction,
    duration,
    backgroundColor,
    highlightColor,
    style,
    children,
}) => {
    const [viewWidth, setViewWidth] = useState(100);
    const [viewHeight, setViewHeight] = useState(100);

    const animationRef = useRef<Animated.CompositeAnimation>();
    const progress = useRef(new Animated.Value(0));

    useEffect(() => {
        const stopAnimation = () => {
            animationRef.current?.stop();
            animationRef.current = undefined;
        };

        stopAnimation();

        if (animating) {
            const animation = Animated.loop(
                Animated.timing(progress.current, {
                    toValue: 1,
                    duration: duration,
                    useNativeDriver: false,
                    easing: Easing.linear,
                })
            );

            animationRef.current = animation;
            animation.start();
        } else {
            stopAnimation();
        }

        return stopAnimation;
    }, [animating, duration]);

    let x1 = 0;
    let y1 = 0;
    let x2 = 0;
    let y2 = 0;

    switch (direction) {
        case "horizontal":
            // Left-middle
            x1 = 0;
            y1 = 0.5;

            // Right-middle
            x2 = 1;
            y2 = 0.5;
            break;
        case "vertical":
            // Middle-top
            x1 = 0.5;
            y1 = 0;

            // Middle-bottom
            x2 = 0.5;
            y2 = 1;
            break;
        default:
            break;
    }

    return (
        <View
            style={style}
            onLayout={(e) => {
                const { width, height } = e.nativeEvent.layout;
                setViewWidth(width);
                setViewHeight(height);
            }}>
            <Svg
                width={viewWidth}
                height={viewHeight}
                style={{
                    position: "absolute",
                }}>
                <Defs>
                    <LinearGradient
                        id="gradient"
                        x1={x1}
                        y1={y1}
                        x2={x2}
                        y2={y2}>
                        <AnimatedStop
                            offset={progress.current.interpolate({
                                inputRange: [0, 1],
                                outputRange: [-1, 1],
                            })}
                            stopColor={backgroundColor}
                        />
                        <AnimatedStop
                            offset={progress.current.interpolate({
                                inputRange: [0, 1],
                                outputRange: [-0.5, 1.5],
                            })}
                            stopColor={highlightColor}
                        />
                        <AnimatedStop
                            offset={progress.current.interpolate({
                                inputRange: [0, 1],
                                outputRange: [0, 2],
                            })}
                            stopColor={backgroundColor}
                        />
                    </LinearGradient>
                </Defs>
                <Rect
                    x="0"
                    y="0"
                    width={viewWidth}
                    height={viewHeight}
                    fill={"url(#gradient)"}
                />
            </Svg>

            {children}
        </View>
    );
};
