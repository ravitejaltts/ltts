import React, { RefObject } from "react";
import {
    TextInput,
    StyleProp,
    ViewStyle,
    Text,
    Pressable,
    Platform,
} from "react-native";
import { MagnifyingGlassIcon } from "../../assets/icons";
import { TextStyles } from "../../styles";
import { useTheme } from "../../context";
import StackView from "../StackView";

type SearchBarProps = {
    placeholder?: string;
    isInput?: boolean;
    style?: StyleProp<ViewStyle>;
    ref?: RefObject<TextInput>;
    onChangeText?: (text: string) => void;
    onSubmit?: (text: string) => void;
    onFocus?: () => void;
};

const SearchBar = React.forwardRef<TextInput, SearchBarProps>((props, ref) => {
    const {
        placeholder,
        isInput = true,
        style,
        onChangeText,
        onSubmit,
        onFocus,
    } = props;

    const [theme] = useTheme();

    const view = (
        <StackView
            spacing={8}
            style={[
                {
                    flexDirection: "row",
                    alignItems: "center",
                    backgroundColor: theme.color.white,
                    height: 44,
                    borderRadius: 22,
                    paddingLeft: 20,
                    paddingRight: Platform.OS === "ios" ? 12 : 20,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                },
                style,
            ]}>
            <MagnifyingGlassIcon fill={theme.color.red.brand.toString()} />

            {isInput && (
                <TextInput
                    ref={ref}
                    placeholder={placeholder}
                    placeholderTextColor={theme.color.text.deemphasized}
                    onFocus={onFocus}
                    onChangeText={onChangeText}
                    autoCapitalize="none"
                    autoCorrect={false}
                    returnKeyType="search"
                    clearButtonMode="while-editing"
                    onSubmitEditing={(e) => {
                        onSubmit?.(e.nativeEvent.text);
                    }}
                    selectionColor={theme.color.blue.brand}
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.black,
                            flex: 1,
                        },
                    ]}
                />
            )}

            {!isInput && (
                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.text.deemphasized,
                            flex: 1,
                        },
                    ]}>
                    {placeholder}
                </Text>
            )}
        </StackView>
    );

    if (!isInput) {
        return (
            <Pressable
                style={{
                    flex: 1,
                }}
                onPress={onFocus}>
                {view}
            </Pressable>
        );
    }

    return view;
});

export default SearchBar;
