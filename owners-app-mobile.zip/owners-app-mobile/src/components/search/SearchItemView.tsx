import { useNavigation } from "@react-navigation/native";
import React, { memo } from "react";
import { Text, TouchableHighlight, View } from "react-native";
import { SvgProps } from "react-native-svg";
import * as CategoryData from "../../constants/CategoryData";
import * as ZoneData from "../../constants/ZoneData";
import {
    ContentCategory,
    GenericContentItem,
    isHowToItem,
} from "../../models/domain/content";
import { SupportScreenNavigationProp } from "../../screens/support";
import { TextStyles, Theme } from "../../styles";
import StackView from "../StackView";

const SearchItemView: React.FunctionComponent<{
    zoneId?: string;
    item: GenericContentItem;
    theme: Theme;
}> = ({ zoneId, item, theme }) => {
    const navigation = useNavigation<SupportScreenNavigationProp>();

    const category = item.category;
    let categoryName: string | undefined;
    let icon: React.FunctionComponent<SvgProps> | undefined;

    if (category) {
        categoryName = CategoryData.getName(category);
        icon = CategoryData.getIcon(category);
    }

    if (!zoneId && item.zones?.length) {
        zoneId = item.zones[0];
    }

    let zoneName: string | undefined;

    if (zoneId) {
        zoneName = ZoneData.getName(zoneId);
    }

    function onPress() {
        switch (category) {
            case ContentCategory.About:
                navigation.navigate("manual", {
                    zoneId: zoneId,
                    item: item,
                });
                break;
            case ContentCategory.HowTo:
                if (isHowToItem(item)) {
                    navigation.navigate("howToDetail", {
                        zoneId: zoneId,
                        item: item,
                    });
                }
                break;
            case ContentCategory.Maintenance:
            case ContentCategory.Supplement:
            case ContentCategory.Troubleshooting:
            default:
                // TODO: Navigate
                break;
        }
    }

    return (
        <TouchableHighlight
            style={{
                backgroundColor: theme.color.background.elevation3,
            }}
            underlayColor={theme.color.background.elevation1}
            onPress={onPress}>
            {/* Horizontal Stack */}
            <StackView
                spacing={16}
                style={{
                    flex: 1,
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: 20,
                    paddingVertical: 14,
                }}>
                {/* Icon */}
                {Boolean(icon) && (
                    <View
                        style={{
                            width: 60,
                            height: 60,
                            justifyContent: "center",
                            alignItems: "center",
                            borderRadius: 8,
                            backgroundColor: theme.color.background.elevation2,
                        }}>
                        {icon?.({
                            fill: theme.color.blue.brand,
                        })}
                    </View>
                )}

                {/* Vertically-Stacked Content */}
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                    }}>
                    <Text
                        style={[
                            TextStyles.contentEyebrow,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {categoryName}
                    </Text>

                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {item.item.title}
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {zoneName}
                    </Text>
                </StackView>
            </StackView>
        </TouchableHighlight>
    );
};

export default memo(SearchItemView);
