import React from "react";
import { ColorValue, StyleProp, View, ViewStyle } from "react-native";
import Svg, { Circle } from "react-native-svg";

type CircularProgressBarProps = {
    size?: number;
    barWidth?: number;
    backgroundColor: ColorValue;
    progressColor: ColorValue;
    progress: number;
    style?: StyleProp<ViewStyle>;
    children: React.ReactNode;
};

const DEFAULT_SIZE = 50;
const DEFAULT_BAR_WIDTH = 5;

const CircularProgressBar: React.FunctionComponent<
    CircularProgressBarProps
> = ({
    size = DEFAULT_SIZE,
    barWidth = DEFAULT_BAR_WIDTH,
    backgroundColor,
    progressColor,
    progress,
    style,
    children,
}) => {
    const centerPoint = size / 2;
    const radius = (size - barWidth) / 2;
    const circumfrence = radius * 2 * Math.PI;
    const dashOffset = circumfrence * (1 - progress);

    return (
        <View
            style={[
                style,
                {
                    width: size,
                    height: size,
                },
            ]}>
            <Svg width={size} height={size}>
                {/* Background Circle */}
                <Circle
                    cx={centerPoint}
                    cy={centerPoint}
                    r={radius}
                    fill="none"
                    stroke={backgroundColor.toString()}
                    strokeWidth={barWidth}
                />

                {/* Progress Circle */}
                <Circle
                    cx={centerPoint}
                    cy={centerPoint}
                    r={radius}
                    fill="none"
                    stroke={progressColor.toString()}
                    strokeWidth={barWidth}
                    strokeLinecap="round"
                    strokeDasharray={[
                        circumfrence, // Dash length
                        circumfrence, // Gap length
                    ]}
                    strokeDashoffset={dashOffset}
                    transform={`rotate(-180, ${centerPoint} ${centerPoint})`}
                />
            </Svg>

            <View
                style={{
                    position: "absolute",
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                {children}
            </View>
        </View>
    );
};

export default CircularProgressBar;
