import React, { useEffect, useState } from "react";
import {
    NativeScrollEvent,
    NativeSyntheticEvent,
    ScrollView,
    Text,
    useWindowDimensions,
    View,
} from "react-native";
import { TextStyles } from "../../styles";
import Modal from "react-native-modal";
import { useServices, useTheme } from "../../context";
import { HeaderSecondaryButton, PrimaryButton } from "../Buttons";
import { WarningOutlineIcon } from "../../assets/icons";
import StackView from "../StackView";

const SupplementWarningModal: React.FunctionComponent<{
    visible: boolean;
    onClose: () => void;
}> = ({ visible, onClose }) => {
    const [theme] = useTheme();
    const windowDimensions = useWindowDimensions();

    const [hasViewed, setHasViewed] = useState(false);
    const [scrollOffset, setScrollOffset] = useState(0);

    const services = useServices();
    const settingService = services.setting;

    useEffect(() => {
        try {
            const value = settingService.getHasViewedElectricalWarning();
            setHasViewed(value ?? false);
        } catch {
            // Do nothing
        }
    }, [settingService]);

    function onScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
        setScrollOffset(event.nativeEvent.contentOffset.y);
    }

    function onAccept() {
        try {
            settingService.setHasViewedElectricalWarning(true);
        } catch {
            // Do nothing
        } finally {
            onClose();
        }
    }

    return (
        <Modal
            isVisible={visible}
            animationIn="slideInUp"
            animationOut="slideOutDown"
            scrollOffset={scrollOffset}
            propagateSwipe
            style={{
                margin: 0,
                justifyContent: "flex-end",
            }}>
            <View
                style={{
                    borderRadius: 10,
                    maxHeight: windowDimensions.height - 100,
                    backgroundColor: theme.color.background.elevation3,
                }}>
                <HeaderSecondaryButton
                    text="Close"
                    onPress={onClose}
                    style={{
                        alignSelf: "flex-end",
                        paddingTop: 16,
                        paddingRight: 20,
                    }}
                />

                <ScrollView
                    onScroll={onScroll}
                    showsVerticalScrollIndicator={false}
                    scrollEventThrottle={16}
                    contentContainerStyle={{
                        flexGrow: 1,
                        paddingBottom: 40,
                        paddingHorizontal: 20,
                    }}>
                    {/* Title */}
                    <Text
                        style={[
                            TextStyles.mainTitle,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Electric Shock Warning
                    </Text>

                    {/* Danger Section */}
                    <StackView
                        spacing={8}
                        style={{
                            paddingTop: 32,
                            paddingBottom: 24,
                        }}>
                        <StackView
                            spacing={8}
                            style={{
                                flexDirection: "row",
                                alignItems: "center",
                            }}>
                            <WarningOutlineIcon
                                fill={theme.color.error.toString()}
                            />
                            <Text
                                style={[
                                    TextStyles.sectionBreak,
                                    {
                                        color: theme.color.error,
                                    },
                                ]}>
                                Danger
                            </Text>
                        </StackView>

                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            <Text
                                style={[
                                    TextStyles.listItemSmall,
                                    {
                                        color: theme.color.text.main,
                                        fontWeight: "bold",
                                    },
                                ]}>
                                Danger of electrical shock, burns or death.
                            </Text>
                            <Text
                                style={[
                                    TextStyles.body,
                                    {
                                        color: theme.color.text.main,
                                    },
                                ]}>
                                {" "}
                                Always remove all power sources before
                                attempting any repair, service or diagnostic
                                work. Power can be present from shore power,
                                generator, inverter or battery. All power
                                sources must be disabled and secured before
                                performing any service.
                            </Text>
                        </Text>
                    </StackView>

                    <StackView
                        spacing={8}
                        style={{
                            paddingBottom: 40,
                        }}>
                        <StackView
                            spacing={8}
                            style={{
                                flexDirection: "row",
                                alignItems: "center",
                            }}>
                            <WarningOutlineIcon
                                fill={theme.color.error.toString()}
                            />
                            <Text
                                style={[
                                    TextStyles.sectionBreak,
                                    {
                                        color: theme.color.error,
                                    },
                                ]}>
                                Caution
                            </Text>
                        </StackView>

                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            If you lack the skills, tools or equipment to
                            perform diagnostic or repair work leave such work to
                            an authorized Winnebago Industries dealer or other
                            qualified shop.
                        </Text>
                    </StackView>

                    {!hasViewed && (
                        <View>
                            <PrimaryButton
                                text="I Understand"
                                onPress={onAccept}
                                style={{
                                    width: "100%",
                                    marginBottom: 24,
                                }}
                            />
                            <Text
                                style={[
                                    TextStyles.regular13,
                                    {
                                        textAlign: "center",
                                        color: theme.color.text.main,
                                        paddingHorizontal: 20,
                                        paddingBottom: 40,
                                    },
                                ]}>
                                By clicking “I Understand” you agree that
                                Winnebago is not liable to any damages or harm
                                while interacting with Winnebago products.
                            </Text>
                        </View>
                    )}
                </ScrollView>
            </View>
        </Modal>
    );
};

export default SupplementWarningModal;
