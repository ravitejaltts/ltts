import { useNavigation } from "@react-navigation/native";
import React from "react";
import { ArticleIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { SupplementContentItem } from "../../models/domain/content";
import { TextStyles } from "../../styles";
import LabeledRow from "../LabeledRow";
import { SupportScreenNavigationProp } from "../../screens/support";

const SupplementRow: React.FunctionComponent<{
    item: SupplementContentItem;
    showIcon?: boolean;
}> = ({ item, showIcon = true }) => {
    const [theme] = useTheme();
    const navigation = useNavigation<SupportScreenNavigationProp>();

    return (
        <LabeledRow
            leftText={item.item.title}
            leftTextStyle={TextStyles.listItemSmall}
            leftView={
                showIcon ? (
                    <ArticleIcon fill={theme.color.blue.brand} />
                ) : undefined
            }
            onPress={() =>
                navigation.navigate("supplementDetail", {
                    item: item,
                })
            }
        />
    );
};

export default SupplementRow;
