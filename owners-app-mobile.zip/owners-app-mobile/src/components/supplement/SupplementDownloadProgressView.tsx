import { observer } from "mobx-react-lite";
import React, { useEffect } from "react";
import { useRootContainer } from "../../context";
import {
    DownloadState,
    SupplementContentItem,
} from "../../models/domain/content";
import DownloadProgressView from "../DownloadProgressView";

export const SupplementDownloadProgressView: React.FunctionComponent<{
    item: SupplementContentItem;
    isEditing?: boolean;
}> = observer(({ item, isEditing }) => {
    const container = useRootContainer();
    const contentStore = container.stores.content;
    const file = contentStore.supplements.findCachedFile(item);
    const fileState = file?.state ?? DownloadState.None;
    const fileProgress = file?.progress ?? 0;

    // Check download
    useEffect(() => {
        contentStore.supplements.loadDownload(item).catch(() => {
            // Do nothing
        });
    }, [contentStore, item]);

    return (
        <DownloadProgressView
            state={fileState}
            progress={fileProgress}
            isEditing={isEditing}
            onDownload={() => {
                contentStore.supplements.startDownload(item);
            }}
            onDelete={() => {
                contentStore.supplements
                    .deleteDownloadByItemId(item.id)
                    .catch(() => {
                        // Do nothing
                    });
            }}
            onCancel={() => {
                if (file) {
                    file.cancelDownload();
                }
            }}
        />
    );
});
