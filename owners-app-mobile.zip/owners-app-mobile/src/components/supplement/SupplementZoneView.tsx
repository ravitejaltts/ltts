import React from "react";
import { Text, View } from "react-native";
import { useTheme } from "../../context";
import { SupplementContentItem } from "../../models/domain/content";
import StackView from "../StackView";
import * as ZoneData from "../../constants/ZoneData";
import { TextStyles } from "../../styles";
import StackSection from "../StackSection";
import SupplementRow from "./SupplementRow";

const SupplementZoneView: React.FunctionComponent<{
    zoneId: string;
    items: SupplementContentItem[];
}> = ({ zoneId, items }) => {
    const [theme] = useTheme();

    const zoneName = ZoneData.getName(zoneId);
    const zoneIcon = ZoneData.getIcon(zoneId);

    return (
        <StackView
            spacing={16}
            style={{
                paddingVertical: 14,
            }}>
            {/* Zone Header */}
            <StackView
                spacing={12}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                {/* Zone Icon */}
                <View
                    style={{
                        width: 32,
                        height: 32,
                        backgroundColor: theme.color.background.elevation2,
                        borderRadius: 4,
                        justifyContent: "center",
                        alignItems: "center",
                    }}>
                    {zoneIcon({
                        fill: theme.color.blue.brand.toString(),
                        width: 24,
                        height: 24,
                    })}
                </View>

                {/* Zone Name */}
                <Text
                    style={[
                        TextStyles.listItemLarge,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {zoneName}
                </Text>
            </StackView>

            {/* Zone Supplements */}
            <StackSection hasBorder={true}>
                {items.map((i) => {
                    return (
                        <SupplementRow key={i.id} item={i} showIcon={false} />
                    );
                })}
            </StackSection>
        </StackView>
    );
};

export default SupplementZoneView;
