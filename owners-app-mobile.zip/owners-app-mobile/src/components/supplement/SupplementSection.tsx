import { useNavigation } from "@react-navigation/native";
import React from "react";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import SupplementRow from "./SupplementRow";
import { LinkButton } from "../Buttons";
import StackSection from "../StackSection";
import { SupplementContentItem } from "../../models/domain/content";
import LoadingView from "../LoadingView";
import ErrorView from "../ErrorView";
import { SupportScreenNavigationProp } from "../../screens/support";

const SupplementSection: React.FunctionComponent<{
    isLoading: boolean;
    items: SupplementContentItem[];
    seeAllVisible?: boolean;
    onRetryPressed?: () => void;
    style?: StyleProp<ViewStyle>;
}> = ({ isLoading, items, seeAllVisible = false, onRetryPressed, style }) => {
    const [theme] = useTheme();
    const navigation = useNavigation<SupportScreenNavigationProp>();

    function onSeeAll() {
        navigation.navigate("supplementLanding", {
            items: items,
        });
    }

    return (
        <View style={style}>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    paddingBottom: seeAllVisible ? 6 : 20,
                }}>
                <Text
                    style={[
                        TextStyles.sectionBreak,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    Additional Resources
                </Text>

                {seeAllVisible && (
                    <LinkButton
                        text="See All"
                        disabled={items.length === 0}
                        onPress={onSeeAll}
                    />
                )}
            </View>

            {isLoading && <LoadingView />}

            {!isLoading && items.length === 0 && (
                <ErrorView
                    text="No Additional Resources"
                    onButtonPressed={onRetryPressed}
                />
            )}

            {!isLoading && items.length > 0 && (
                <StackSection hasBorder={true}>
                    {items.slice(0, 4).map((i) => {
                        return <SupplementRow key={i.id} item={i} />;
                    })}
                </StackSection>
            )}
        </View>
    );
};

export default SupplementSection;
