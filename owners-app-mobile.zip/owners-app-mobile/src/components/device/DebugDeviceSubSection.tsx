import { observer } from "mobx-react-lite";
import React, { useRef, useState } from "react";
import { useRootContainer } from "../../context";
import {
    DevicePlanCode,
    DeviceSubscriptionStatus,
} from "../../models/domain/device";
import { DateUtil } from "../../utils";
import { ButtonRow } from "../ButtonRow";
import LabeledRow from "../LabeledRow";
import LabeledRowSelect from "../LabeledRowSelect";
import { PickerItem } from "../Picker";
import SettingSection from "../SettingSection";

enum SubscriptionScenario {
    TrialActive,
    TrialPaused,
    TrialExpired,
    TrialCancelled,
    PremiumActive,
    Premium10Active,
    Premium100Active,
}

export const DebugDeviceSubSection: React.FunctionComponent = observer(() => {
    const container = useRootContainer();
    const deviceStore = container.stores.device;
    const subscription = deviceStore.subscription;

    const [selectedScenario, setSelectedScenario] =
        useState<SubscriptionScenario>(SubscriptionScenario.PremiumActive);

    const scenarios: PickerItem[] = useRef<PickerItem[]>([
        {
            label: "Trial Active",
            value: SubscriptionScenario.TrialActive,
        },
        {
            label: "Trial Paused",
            value: SubscriptionScenario.TrialPaused,
        },
        {
            label: "Trial Expired",
            value: SubscriptionScenario.TrialExpired,
        },
        {
            label: "Trial Cancelled",
            value: SubscriptionScenario.TrialCancelled,
        },
        {
            label: "Premium Active",
            value: SubscriptionScenario.PremiumActive,
        },
        {
            label: "Premium Wifi 10 Active",
            value: SubscriptionScenario.Premium10Active,
        },
        {
            label: "Premium Wifi 100 Active",
            value: SubscriptionScenario.Premium100Active,
        },
    ]).current;

    const trialActive = () => {
        deviceStore.overrideSubscription(DevicePlanCode.PremiumTrial, {});
    };

    const trialPaused = () => {
        deviceStore.overrideSubscription(DevicePlanCode.PremiumTrial, {
            status: DeviceSubscriptionStatus.NonRenewing,
        });
    };

    const trialExpired = () => {
        const todayDate = DateUtil.todayMidnight();

        deviceStore.overrideSubscription(DevicePlanCode.PremiumTrial, {
            status: DeviceSubscriptionStatus.TrialExpired,
            trialEndsAt: todayDate.toISOString(), // Expired today
            cancelledAt: "",
            next_billing_at: "",
        });
    };

    const trialCancelled = () => {
        deviceStore.overrideSubscription(DevicePlanCode.PremiumTrial, {
            status: DeviceSubscriptionStatus.Cancelled,
        });
    };

    const premiumActive = () => {
        deviceStore.overrideSubscription(DevicePlanCode.PremiumPaid, {});
    };

    const premium10Active = () => {
        deviceStore.overrideSubscription(DevicePlanCode.PremiumWifi10, {});
    };

    const premium100Active = () => {
        deviceStore.overrideSubscription(DevicePlanCode.PremiumWifi100, {});
    };

    const overrideSubscription = () => {
        switch (selectedScenario) {
            case SubscriptionScenario.TrialActive:
                trialActive();
                break;
            case SubscriptionScenario.TrialPaused:
                trialPaused();
                break;
            case SubscriptionScenario.TrialExpired:
                trialExpired();
                break;
            case SubscriptionScenario.TrialCancelled:
                trialCancelled();
                break;
            case SubscriptionScenario.PremiumActive:
                premiumActive();
                break;
            case SubscriptionScenario.Premium10Active:
                premium10Active();
                break;
            case SubscriptionScenario.Premium100Active:
                premium100Active();
                break;
        }
    };

    const expireCard = () => {
        const planCode = subscription?.plan.planCode;
        const card = subscription?.card;

        if (!planCode || !card) {
            return;
        }

        // Last year
        const year = new Date().getFullYear() - 1;

        deviceStore.overrideSubscription(planCode, {
            ...subscription,
            card: {
                ...card,
                expiryYear: year.toFixed(0),
            },
        });
    };

    return (
        <SettingSection title="DEBUG">
            <LabeledRow
                leftText="Status"
                rightText={subscription?.status ?? "None"}
                rightIconVisible={false}
            />

            <LabeledRowSelect
                label="Select Plan"
                items={scenarios}
                value={selectedScenario}
                onValueChanged={(item) => {
                    setSelectedScenario(item.value);
                }}
            />
            <ButtonRow
                text="Override Subscription"
                onPress={overrideSubscription}
            />
            <ButtonRow
                text="Expire Card"
                isDestructive={true}
                onPress={expireCard}
            />
        </SettingSection>
    );
});
