import React, { useMemo } from "react";
import { FlatList, View, useWindowDimensions } from "react-native";
import { getDevicePlanFeatureData } from "../../constants";
import {
    DevicePlanFeatureCard,
    DevicePlanFeatureCardProps,
} from "./DevicePlanFeatureCard";

const FLATLIST_PADDING = 20;
const FEATURE_CARD_SPACING = 16;

export const DevicePlanFeatureCarousel: React.FunctionComponent = () => {
    const windowWidth = useWindowDimensions().width;

    const featureCardWidth = useMemo(
        () => windowWidth - FLATLIST_PADDING * 2 - FEATURE_CARD_SPACING,
        [windowWidth]
    );

    const featureCardProps = useMemo<DevicePlanFeatureCardProps[]>(
        () => getDevicePlanFeatureData(featureCardWidth),
        [featureCardWidth]
    );

    const featureCardOffsets = useMemo(() => {
        const offsets: number[] = [];

        for (let index = 0; index < featureCardProps.length; index++) {
            if (index === 0 || index === featureCardProps.length - 1) {
                // First and last card are automatically considered offsets
                // due to snapToStart and snapToEnd FlatList props defaults
                continue;
            }

            // Some middle card
            let offset =
                FLATLIST_PADDING +
                featureCardWidth * index +
                FEATURE_CARD_SPACING * (index - 1);

            // Card in middle, spacing on either side
            // Remaining width is divided by two between the two sides
            // This determines the overlap for middle cards
            offset -=
                (windowWidth - featureCardWidth - FEATURE_CARD_SPACING * 2) / 2;

            offsets.push(offset);
        }

        return offsets;
    }, [windowWidth, featureCardWidth, featureCardProps]);

    return (
        <FlatList
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            data={featureCardProps}
            decelerationRate="fast"
            bounces={false}
            snapToOffsets={featureCardOffsets}
            contentContainerStyle={{
                paddingTop: 20,
                paddingBottom: 24,
                paddingHorizontal: FLATLIST_PADDING,
            }}
            ItemSeparatorComponent={() => <View style={{ width: 16 }} />}
            renderItem={({ item }) => <DevicePlanFeatureCard {...item} />}
        />
    );
};
