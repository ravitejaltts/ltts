import React from "react";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import { useTheme } from "../../context";
import { DevicePlanIntervalUnit } from "../../models/domain/device";
import { TextStyles } from "../../styles";
import { DateUtil } from "../../utils";
import StackView from "../StackView";

const DEFAULT_PRICE_UNIT = "$";

export const DevicePlanView: React.FunctionComponent<{
    planName: string;
    price: number;
    priceUnit?: string;
    interval: number;
    intervalUnit: DevicePlanIntervalUnit;
    isTrial: boolean;
    trialEndDate?: Date;
    showRemainingTime: boolean;
    style?: StyleProp<ViewStyle>;
}> = ({
    planName,
    price,
    priceUnit = DEFAULT_PRICE_UNIT,
    interval,
    intervalUnit,
    isTrial,
    trialEndDate,
    showRemainingTime,
    style,
}) => {
    const [theme] = useTheme();

    let priceText = "";
    let trialPriceText = "";
    let trialEndText = "";
    let trialRemainingTimeText = "";

    if (isTrial) {
        priceText = "FREE";
        trialPriceText = price.toFixed(0);

        if (trialEndDate) {
            const nowDate = DateUtil.now();
            trialEndText = trialEndDate.toLocaleDateString("en-US", {
                month: "numeric",
                day: "numeric",
                year: "2-digit",
            });

            if (showRemainingTime) {
                // Zero if less than one month remaining
                const monthsRemaining = DateUtil.getMonthsDuration(
                    nowDate,
                    trialEndDate
                );

                if (monthsRemaining > 0) {
                    trialRemainingTimeText = `${monthsRemaining} months remaining`;
                } else {
                    // "X days"
                    const days = DateUtil.getDurationText(
                        trialEndDate.getTime() - nowDate.getTime(),
                        {
                            days: true,
                        }
                    );
                    trialRemainingTimeText = `${days} remaining`;
                }
            }
        } else {
            trialEndText = "trial ends";
        }
    } else {
        priceText = `${priceUnit}${price.toFixed(0)}`;
    }

    let intervalUnitText = "";

    if (interval > 1) {
        switch (intervalUnit) {
            case DevicePlanIntervalUnit.Months:
                intervalUnitText = "months";
                break;
            case DevicePlanIntervalUnit.Years:
                intervalUnitText = "years";
                break;
        }

        intervalUnitText = ` every ${interval} ${intervalUnitText}`;
    } else {
        switch (intervalUnit) {
            case DevicePlanIntervalUnit.Months:
                intervalUnitText = "/mo";
                break;
            case DevicePlanIntervalUnit.Years:
                intervalUnitText = "/yr";
                break;
        }
    }

    return (
        <StackView
            spacing={4}
            style={[
                {
                    flexDirection: "row",
                    alignItems: "center",
                },
                style,
            ]}>
            {/* Plan Name */}
            <Text
                style={[
                    TextStyles.bold16,
                    {
                        flex: 1,
                        color: theme.color.text.main,
                        textTransform: "uppercase",
                    },
                ]}>
                {planName}
            </Text>

            {/* Plan Details */}
            <View
                style={{
                    flex: isTrial ? 1 : 1, // Give more space for the trial text
                }}>
                <Text
                    style={{
                        color: theme.color.text.main,
                        textAlign: "right",
                    }}>
                    <Text
                        style={[
                            TextStyles.sectionBreak,
                            {
                                textTransform: "uppercase",
                            },
                        ]}>
                        {priceText}
                    </Text>
                    {!isTrial && (
                        <Text style={TextStyles.listItemSmall}>
                            {intervalUnitText}
                        </Text>
                    )}
                </Text>

                {Boolean(trialRemainingTimeText) && (
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.main,
                                textAlign: "right",
                            },
                        ]}>
                        {trialRemainingTimeText}
                    </Text>
                )}

                {/* Trial Description */}
                {isTrial && (
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.main,
                                textAlign: "right",
                            },
                        ]}>
                        {priceUnit}
                        {trialPriceText}
                        {intervalUnitText} after {trialEndText}
                    </Text>
                )}
            </View>
        </StackView>
    );
};
