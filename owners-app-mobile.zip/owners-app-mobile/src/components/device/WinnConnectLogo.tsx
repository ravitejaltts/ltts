import React from "react";
import FastImage from "react-native-fast-image";

export const WinnConnectLogo: React.FunctionComponent<{
    width: number;
    height: number;
    theme: "black" | "white";
}> = ({ theme, width, height }) => {
    return (
        <FastImage
            style={{
                width: width,
                height: height,
            }}
            resizeMode="contain"
            source={
                theme === "black"
                    ? require("../../assets/images/helpers/WinnConnectLogoBlack.png")
                    : require("../../assets/images/helpers/WinnConnectLogoWhite.png")
            }
        />
    );
};
