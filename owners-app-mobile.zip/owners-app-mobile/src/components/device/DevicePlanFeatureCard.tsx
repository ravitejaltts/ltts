import React from "react";
import { View, Text } from "react-native";
import { SvgProps } from "react-native-svg";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { useTheme } from "../../context";

export type DevicePlanFeatureCardProps = {
    title: string;
    body: string;
    icon: React.FunctionComponent<SvgProps>;
    width: number;
};

export const DevicePlanFeatureCard: React.FunctionComponent<
    DevicePlanFeatureCardProps
> = ({ title, body, icon, width }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={12}
            style={{
                flexDirection: "row",
                width: width,
                padding: 20,
                borderRadius: 8,
                backgroundColor: theme.color.background.elevation3,
            }}>
            <View
                style={{
                    width: 24,
                    height: 24,
                    borderRadius: 4,
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: theme.color.blue.brand,
                }}>
                {icon({
                    width: 18,
                    height: 18,
                    fill: theme.color.white,
                })}
            </View>

            <StackView
                spacing={4}
                style={{
                    flex: 1,
                }}>
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {title}
                </Text>

                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {body}
                </Text>
            </StackView>
        </StackView>
    );
};
