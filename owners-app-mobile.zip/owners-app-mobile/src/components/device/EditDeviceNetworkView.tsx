import React, { useState } from "react";
import { StyleProp, TextStyle } from "react-native";
import { useRootContainer } from "../../context";
import { useSmartVehicle } from "../../hooks";
import { EditNetworkForm } from "../../models/ui/form";
import FormTextInput from "../FormTextInput";
import PasswordFormTextInput from "../PasswordFormTextInput";
import StackView from "../StackView";

export const useEditNetwork = (form: EditNetworkForm, onSaved: () => void) => {
    const ssidField = form.ssidField;
    const passwordField = form.passwordField;
    const confirmPasswordField = form.confirmPasswordField;

    const [isSaving, setIsSaving] = useState(false);

    const canSave =
        !isSaving &&
        Boolean(ssidField.text) &&
        passwordField.hasEdit &&
        Boolean(passwordField.text) &&
        confirmPasswordField.hasEdit &&
        Boolean(confirmPasswordField.text);

    const smartVehicle = useSmartVehicle();
    const deviceId = smartVehicle?.deviceId;

    const container = useRootContainer();
    const deviceStore = container.stores.device;
    const activeSubscription = deviceStore.activeSubscription;

    const save = () => {
        if (!deviceId || !activeSubscription || !form.validate()) {
            return;
        }

        setIsSaving(true);

        deviceStore
            .updateNetworkConfig(deviceId, activeSubscription, {
                wifiSsid: form.ssidField.text,
                wifiPassword: form.passwordField.text,
            })
            .then(onSaved)
            .catch(() => {
                form.confirmPasswordField.invalidate(
                    "We encountered an issue updating your Wi-Fi configuration. Please try again later."
                );
            })
            .finally(() => {
                setIsSaving(false);
            });
    };

    return {
        canSave,
        isSaving,
        save,
    };
};

type EditDeviceNetworkViewProps = {
    form: EditNetworkForm;
    isSaving: boolean;
    save: () => void;
    nameStyle?: StyleProp<TextStyle>;
};

export const EditDeviceNetworkView: React.FunctionComponent<
    EditDeviceNetworkViewProps
> = ({ form, isSaving, save, nameStyle }) => {
    return (
        <StackView spacing={24}>
            <FormTextInput
                name="Network Name"
                placeholder="Network Name"
                nameStyle={nameStyle}
                field={form.ssidField}
                disabled={isSaving}
            />

            <PasswordFormTextInput
                name="New Password"
                placeholder="New Password"
                nameStyle={nameStyle}
                field={form.passwordField}
                maxLength={63}
                disabled={isSaving}
                helperText="Must be 8-63 characters in length."
            />

            <PasswordFormTextInput
                name="Confirm Password"
                placeholder="Confirm Password"
                nameStyle={nameStyle}
                field={form.confirmPasswordField}
                maxLength={63}
                disabled={isSaving}
                returnKeyType="go"
                onSubmitEditing={save}
            />
        </StackView>
    );
};
