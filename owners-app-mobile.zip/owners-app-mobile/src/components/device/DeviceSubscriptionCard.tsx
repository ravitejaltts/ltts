import React from "react";
import { useTheme } from "../../context";
import {
    DeviceSubscription,
    DeviceSubscriptionStatus,
} from "../../models/domain/device";
import { DevicePlanView } from "./DevicePlanView";

export const DeviceSubscriptionCard: React.FunctionComponent<{
    subscription: DeviceSubscription;
}> = ({ subscription }) => {
    const [theme] = useTheme();

    const { plan, status, amount, interval, intervalUnit, trialEndsAt } =
        subscription;

    let trialEndDate: Date | undefined;

    if (trialEndsAt) {
        trialEndDate = new Date(trialEndsAt);
    }

    let isTrial: boolean;

    switch (status) {
        case DeviceSubscriptionStatus.Trial:
        case DeviceSubscriptionStatus.TrialExpired:
            isTrial = true;
            break;
        default:
            isTrial = false;
            break;
    }

    return (
        <DevicePlanView
            planName={plan.name}
            price={amount}
            interval={interval}
            intervalUnit={intervalUnit}
            isTrial={isTrial}
            trialEndDate={trialEndDate}
            showRemainingTime={true}
            style={{
                minHeight: 78,
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8,
                backgroundColor: theme.color.background.elevation3,
            }}
        />
    );
};
