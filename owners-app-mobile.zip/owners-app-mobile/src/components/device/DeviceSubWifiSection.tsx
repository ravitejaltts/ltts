import React from "react";
import { ActivityIndicator, Text, TouchableHighlight } from "react-native";
import { ChevronRightIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import SettingSection from "../SettingSection";
import StackView from "../StackView";

export const DeviceSubWifiSection: React.FunctionComponent<{
    ssid: string;
    isLoading: boolean;
    onPress: () => void;
}> = ({ ssid, isLoading, onPress }) => {
    const [theme] = useTheme();

    return (
        <SettingSection title="WI-FI NETWORK">
            <TouchableHighlight
                disabled={isLoading}
                onPress={onPress}
                underlayColor={theme.color.background.labeledRowUnderlay}
                style={{
                    backgroundColor: theme.color.background.elevation3,
                    padding: 20,
                    borderRadius: 8,
                }}>
                <StackView
                    spacing={12}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                flex: 1,
                                color: theme.color.text.main,
                            },
                        ]}>
                        {ssid}
                    </Text>

                    {isLoading ? (
                        <ActivityIndicator color={theme.color.text.main} />
                    ) : (
                        <ChevronRightIcon
                            width={28}
                            height={28}
                            fill={theme.color.components.gray2}
                        />
                    )}
                </StackView>
            </TouchableHighlight>
        </SettingSection>
    );
};
