import React from "react";
import { TouchableHighlight } from "react-native";
import { ChevronRightIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { DevicePlan } from "../../models/domain/device";
import { DateUtil } from "../../utils";
import StackView from "../StackView";
import { DevicePlanView } from "./DevicePlanView";

export const ChangeDevicePlanCard: React.FunctionComponent<{
    plan: DevicePlan;
    disabled?: boolean;
    onPress: () => void;
}> = ({ plan, disabled, onPress }) => {
    const { name, recurringPrice, interval, intervalUnit, trialPeriodDays } =
        plan;

    const [theme] = useTheme();

    const recurringPriceNumber = Number.parseFloat(recurringPrice);

    const isTrial = trialPeriodDays > 0;
    const trialEndDate = DateUtil.nowAddDays(trialPeriodDays);

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.labeledRowUnderlay}
            disabled={disabled}
            onPress={onPress}
            style={{
                backgroundColor: theme.color.background.elevation3,
                padding: 20,
                borderRadius: 8,
                opacity: disabled ? 0.5 : 1,
            }}>
            <StackView
                spacing={16}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                <DevicePlanView
                    planName={name}
                    isTrial={isTrial}
                    trialEndDate={trialEndDate}
                    price={recurringPriceNumber}
                    interval={interval}
                    intervalUnit={intervalUnit}
                    showRemainingTime={false}
                    style={{
                        flex: 1,
                    }}
                />

                <ChevronRightIcon
                    width={28}
                    height={28}
                    fill={theme.color.components.gray2}
                />
            </StackView>
        </TouchableHighlight>
    );
};
