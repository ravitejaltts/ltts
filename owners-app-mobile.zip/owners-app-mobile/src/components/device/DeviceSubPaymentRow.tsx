import React from "react";
import { ActivityIndicator, Text, TouchableHighlight } from "react-native";
import { ChevronRightIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { DeviceSubscriptionCardData } from "../../models/domain/device";
import { TextStyles } from "../../styles";
import StackView from "../StackView";

export const DeviceSubPaymentRow: React.FunctionComponent<{
    card: DeviceSubscriptionCardData;
    isLoading: boolean;
    onPress: () => void;
}> = ({ card, isLoading, onPress }) => {
    const { lastFourDigits } = card;

    const [theme] = useTheme();

    const container = useRootContainer();
    const deviceStore = container.stores.device;

    const isExpired = deviceStore.isSubscriptionCardExpired(card);

    return (
        <TouchableHighlight
            disabled={isLoading}
            onPress={onPress}
            underlayColor={theme.color.background.labeledRowUnderlay}
            style={{
                backgroundColor: theme.color.background.elevation3,
                padding: 20,
                borderRadius: 8,
            }}>
            <StackView
                spacing={12}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Payment
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: isExpired
                                    ? theme.color.error
                                    : theme.color.text.deemphasized,
                            },
                        ]}>
                        Credit card ending in {lastFourDigits}
                    </Text>

                    {isExpired && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.error,
                                },
                            ]}>
                            Expired
                        </Text>
                    )}
                </StackView>

                {isLoading ? (
                    <ActivityIndicator color={theme.color.text.main} />
                ) : (
                    <ChevronRightIcon
                        width={28}
                        height={28}
                        fill={theme.color.components.gray2}
                    />
                )}
            </StackView>
        </TouchableHighlight>
    );
};
