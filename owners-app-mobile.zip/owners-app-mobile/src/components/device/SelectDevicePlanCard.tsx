import React from "react";
import { Pressable, View } from "react-native";
import { CheckMarkIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { DevicePlan } from "../../models/domain/device";
import { DateUtil } from "../../utils";
import StackView from "../StackView";
import { DevicePlanView } from "./DevicePlanView";

export const SelectDevicePlanCard: React.FunctionComponent<{
    plan: DevicePlan;
    disabled?: boolean;
    selected: boolean;
    onSelected: () => void;
}> = ({ plan, disabled = false, selected, onSelected }) => {
    const { name, recurringPrice, interval, intervalUnit, trialPeriodDays } =
        plan;

    const [theme] = useTheme();

    const recurringPriceNumber = Number.parseFloat(recurringPrice);

    const isTrial = trialPeriodDays > 0;
    const trialEndDate = DateUtil.nowAddDays(trialPeriodDays);

    const backgroundColor = theme.color.background.elevation3;

    return (
        <Pressable
            disabled={disabled}
            onPress={onSelected}
            style={{
                padding: 2,
                borderRadius: 8,
                backgroundColor: selected
                    ? theme.color.blue.brand
                    : backgroundColor,
                opacity: disabled ? 0.5 : 1,
            }}>
            <StackView
                spacing={12}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                    minHeight: 74,
                    paddingHorizontal: 16,
                    paddingVertical: 12,
                    borderRadius: 6,
                    backgroundColor: backgroundColor,
                }}>
                {/* Checkbox */}
                {selected ? (
                    <View
                        style={{
                            width: 24,
                            height: 24,
                            borderRadius: 12,
                            justifyContent: "center",
                            alignItems: "center",
                            backgroundColor: theme.color.blue.brand,
                        }}>
                        <CheckMarkIcon
                            width={20}
                            height={20}
                            fill={theme.color.white}
                        />
                    </View>
                ) : (
                    <View
                        style={{
                            width: 24,
                            height: 24,
                            borderRadius: 12,
                            borderWidth: 2,
                            borderColor: theme.color.components.gray2,
                        }}
                    />
                )}

                <DevicePlanView
                    planName={name}
                    isTrial={isTrial}
                    trialEndDate={trialEndDate}
                    price={recurringPriceNumber}
                    interval={interval}
                    intervalUnit={intervalUnit}
                    showRemainingTime={false}
                    style={{
                        flex: 1,
                    }}
                />
            </StackView>
        </Pressable>
    );
};
