import React, {
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import { View, ColorValue, Animated, PanResponder } from "react-native";
import { useTheme } from "../context";
import { MathUtils } from "../utils";
import { LightTheme } from "../styles";

type BarSliderProps = {
    disabled?: boolean;
    height?: number;
    progressColor?: ColorValue;
    backgroundColor?: ColorValue;
    progress: number;
    minProgress: number;
    maxProgress: number;
    onProgressChange?: (value: number) => void;
    onChangeStarted?: () => void;
    onChangeEnded?: (value: number) => void;
};

export const BarSlider: React.FunctionComponent<BarSliderProps> = ({
    disabled = false,
    height = 50,
    progressColor,
    backgroundColor,
    progress,
    minProgress,
    maxProgress,
    onProgressChange,
    onChangeStarted,
    onChangeEnded,
}) => {
    const [theme] = useTheme();

    if (!backgroundColor) {
        backgroundColor = theme.color.background.elevation2;
    }

    if (!progressColor) {
        progressColor = theme.color.components.gray2;
    }

    const [viewWidth, setViewWidth] = useState(100);

    const calculateBarWidth = useCallback(
        (prog: number) => {
            return MathUtils.clamp(prog * viewWidth, 0, viewWidth);
        },
        [viewWidth]
    );

    const isPanningRef = useRef(false);
    const barWidth = useRef(0);
    const animatedBarWidth = useRef(new Animated.Value(0)).current;

    const panEventRef = useRef(
        Animated.event(
            [
                {
                    width: animatedBarWidth,
                },
            ],
            {
                useNativeDriver: false,
            }
        )
    );

    const panResponder = useMemo(
        () =>
            PanResponder.create({
                onStartShouldSetPanResponder: () => !disabled,
                onStartShouldSetPanResponderCapture: () => !disabled,
                onMoveShouldSetPanResponder: () => !disabled,
                onMoveShouldSetPanResponderCapture: () => !disabled,
                onPanResponderGrant: () => {
                    // Start panning and notify listeners
                    isPanningRef.current = true;
                    onChangeStarted?.();
                },
                onPanResponderMove: (_, gestureState) => {
                    /*
                        New bar width is:
                        current bar width + how far the user has moved their
                        finger, clamped by the min and max width of the bar.

                        Do not commit this value yet or it will interfere with
                        calculations while moving.
                    */
                    const newBarWidth = MathUtils.clamp(
                        barWidth.current + gestureState.dx,
                        minProgress * viewWidth,
                        maxProgress * viewWidth
                    );

                    /*
                        New progress is the percentage of the bar width out of
                        total possible width
                    */
                    const newProgress = newBarWidth / viewWidth;

                    // Animate to this width
                    panEventRef.current({
                        width: newBarWidth,
                    });

                    // Notify listeners
                    onProgressChange?.(newProgress);
                },
                onPanResponderRelease: (_, gestureState) => {
                    const newBarWidth = MathUtils.clamp(
                        barWidth.current + gestureState.dx,
                        minProgress * viewWidth,
                        maxProgress * viewWidth
                    );
                    const newProgress = newBarWidth / viewWidth;

                    // Notify listeners
                    onChangeEnded?.(newProgress);

                    // Commit the new bar width
                    barWidth.current = newBarWidth;

                    // Stop panning
                    isPanningRef.current = false;
                },
            }),
        [
            viewWidth,
            disabled,
            minProgress,
            maxProgress,
            onChangeStarted,
            onChangeEnded,
            onProgressChange,
        ]
    );

    useEffect(() => {
        // Only update bar width when not panning
        if (!isPanningRef.current) {
            // Calculate the new bar width based on progress
            const newBarWidth = calculateBarWidth(progress);

            // Update the bar width value
            barWidth.current = newBarWidth;

            // Animate to this width
            panEventRef.current({
                width: newBarWidth,
            });
        }
    }, [progress, calculateBarWidth]);

    return (
        <View
            {...panResponder.panHandlers}
            onLayout={(e) => {
                setViewWidth(e.nativeEvent.layout.width);
            }}
            style={{
                height: height,
                backgroundColor: backgroundColor,
                borderRadius: 8,
            }}>
            {/* Progress Bar */}
            {!disabled && (
                <Animated.View
                    style={{
                        overflow: "hidden",
                        width: animatedBarWidth,
                        height: height,
                        backgroundColor: progressColor,
                        borderRadius: 8,
                        justifyContent: "center",
                        alignItems: "flex-end",
                    }}>
                    {/* Handle */}
                    <View
                        style={{
                            width: 4,
                            height: height / 2,
                            marginRight: 12,
                            backgroundColor: theme.color.white,
                            borderWidth: 1,
                            borderRadius: 4,
                            borderColor: LightTheme.color.dividers.gray2,
                        }}
                    />
                </Animated.View>
            )}
        </View>
    );
};
