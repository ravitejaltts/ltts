import React from "react";
import { StyleProp, Text, TextStyle, View, ViewStyle } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { LinkButton } from "./Buttons";

const ErrorView: React.FunctionComponent<{
    text?: string;
    textStyle?: StyleProp<TextStyle>;
    buttonText?: string;
    buttonStyle?: StyleProp<ViewStyle>;
    buttonTextStyle?: StyleProp<TextStyle>;
    onButtonPressed?: () => void;
    style?: StyleProp<ViewStyle>;
}> = ({
    text,
    textStyle,
    buttonText,
    buttonStyle,
    buttonTextStyle,
    onButtonPressed,
    style,
}) => {
    const [theme] = useTheme();

    return (
        <View
            style={[
                {
                    height: 100,
                    justifyContent: "center",
                },
                style,
            ]}>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: theme.color.text.main,
                        textAlign: "center",
                    },
                    textStyle,
                ]}>
                {text ?? "Error"}
            </Text>

            {onButtonPressed ? (
                <LinkButton
                    text={buttonText ?? "Retry"}
                    style={[
                        {
                            alignSelf: "center",
                            paddingHorizontal: 16,
                        },
                        buttonStyle,
                    ]}
                    textStyle={[
                        {
                            color: theme.color.text.deemphasized,
                        },
                        buttonTextStyle,
                    ]}
                    onPress={onButtonPressed}
                />
            ) : null}
        </View>
    );
};

export default ErrorView;
