import React, { useEffect } from "react";
import { View, Modal } from "react-native";
import Orientation from "react-native-orientation-locker";
import ImageView from "react-native-image-zoom-viewer";

type ImageViewerProps = {
    img: { url: string }[];
    onClose: () => void;
};

const ImageViewer: React.FunctionComponent<ImageViewerProps> = ({
    img,
    onClose,
}) => {
    useEffect(() => {
        Orientation.unlockAllOrientations();
    }, []);

    const onSwipeDown = () => {
        Orientation.lockToPortrait();
        onClose();
    };

    return (
        <Modal
            animationType="fade"
            transparent={false}
            supportedOrientations={["portrait", "landscape"]}>
            <ImageView
                enableSwipeDown
                renderIndicator={() => <View />}
                onSwipeDown={onSwipeDown}
                imageUrls={img}
            />
        </Modal>
    );
};

export default ImageViewer;
