import React from "react";
import { ColorValue, TouchableHighlight } from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";

export const ThermostatCircleButton: React.FunctionComponent<{
    size: number;
    icon: React.FunctionComponent<SvgProps>;
    iconFillColor: ColorValue;
    disabled?: boolean;
    onPress: () => void;
}> = ({ size, icon, iconFillColor, disabled = false, onPress }) => {
    const [theme] = useTheme();

    const iconSize = (36 / 60) * size;

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={onPress}
            disabled={disabled}
            style={{
                justifyContent: "center",
                alignItems: "center",
                width: size,
                height: size,
                borderRadius: size,
                borderWidth: 1,
                borderColor: theme.color.dividers.gray1,
                backgroundColor: theme.color.background.elevation3,
            }}>
            {icon({
                width: iconSize,
                height: iconSize,
                fill: disabled
                    ? theme.color.text.disabled.toString()
                    : iconFillColor.toString(),
            })}
        </TouchableHighlight>
    );
};
