import { observer } from "mobx-react-lite";
import React, { useRef, useState } from "react";
import { Text } from "react-native";
import { StackSection, StackView } from "..";
import { useTheme } from "../../context";
import {
    RoofVent,
    RoofVentDome,
    RoofVentFanSpeed,
} from "../../models/domain/climate";
import { TextStyles } from "../../styles";
import { CommandButton } from "../newButtons";

export const RoofVentSection: React.FunctionComponent<{
    roofVent: RoofVent;
}> = observer(({ roofVent }) => {
    const [theme] = useTheme();

    const [isSendingDome, setIsSendingDome] = useState(false);
    const [isSendingSpeed, setIsSendingSpeed] = useState(false);

    const name = roofVent.name;

    // Dome options generated from validDomes
    const domeOptions = useRef(
        roofVent.validDomes.reduce<
            {
                text: string;
                dome: RoofVentDome;
            }[]
        >((array, dome) => {
            switch (dome) {
                case RoofVentDome.Opened:
                    array.push({
                        text: "Open",
                        dome,
                    });
                    break;
                case RoofVentDome.Closed:
                    array.push({
                        text: "Close",
                        dome,
                    });
                    break;
            }

            return array;
        }, [])
    ).current;

    // Fan speed options generated from validFanSpeeds
    const fanSpeedOptions = useRef(
        roofVent.validFanSpeeds.reduce<
            {
                text: string;
                speed: RoofVentFanSpeed;
            }[]
        >((array, speed) => {
            switch (speed) {
                case RoofVentFanSpeed.High:
                    array.push({
                        text: "High",
                        speed,
                    });
                    break;
                case RoofVentFanSpeed.Medium:
                    array.push({
                        text: "Med",
                        speed,
                    });
                    break;
                case RoofVentFanSpeed.Low:
                    array.push({
                        text: "Low",
                        speed,
                    });
                    break;
                case RoofVentFanSpeed.Off:
                    array.push({
                        text: "Off",
                        speed,
                    });
                    break;
            }

            return array;
        }, [])
    ).current;

    const sendDomeCommand = async (dome: RoofVentDome) => {
        setIsSendingDome(true);

        try {
            await roofVent.sendDomeCommand(dome);
        } finally {
            setIsSendingDome(false);
        }
    };

    const sendSpeedCommand = async (speed: RoofVentFanSpeed) => {
        setIsSendingSpeed(true);

        try {
            await roofVent.sendSpeedCommand(speed);
        } finally {
            setIsSendingSpeed(false);
        }
    };

    return (
        <StackView spacing={12}>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: theme.color.text.main,
                    },
                ]}>
                {name}
            </Text>

            <StackSection hasBorder={true}>
                <StackView
                    spacing={12}
                    style={{
                        paddingTop: 16,
                        paddingBottom: 20,
                        paddingHorizontal: 20,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {name} Hatch
                    </Text>

                    <StackView
                        spacing={8}
                        style={{
                            flexDirection: "row",
                        }}>
                        {domeOptions.map(({ text, dome }) => (
                            <CommandButton
                                key={text}
                                text={text}
                                disabled={isSendingDome}
                                sendCommand={() => sendDomeCommand(dome)}
                                style={{
                                    flex: 1,
                                }}
                            />
                        ))}
                    </StackView>
                </StackView>

                {/* Fan Speed */}
                <StackView
                    spacing={12}
                    style={{
                        paddingTop: 16,
                        paddingBottom: 20,
                        paddingHorizontal: 20,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Fan Speed
                    </Text>

                    <StackView
                        spacing={4}
                        style={{
                            flexDirection: "row",
                        }}>
                        {fanSpeedOptions.map(({ text, speed }) => (
                            <CommandButton
                                key={text}
                                text={text}
                                disabled={isSendingSpeed}
                                sendCommand={() => sendSpeedCommand(speed)}
                                style={{
                                    flex: 1,
                                }}
                            />
                        ))}
                    </StackView>
                </StackView>
            </StackSection>
        </StackView>
    );
});
