import { observer } from "mobx-react-lite";
import React, { useState } from "react";
import { Text, View } from "react-native";
import { PillSelect, PillSelectSectionProps, StackView } from "..";
import { AddIcon, SubtractIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import {
    AirConditioner,
    Heater,
    Thermostat,
    ThermostatMode,
} from "../../models/domain/climate";
import { AirConditionerFanSpeed } from "../../models/domain/climate/AirConditioner";
import { SharedColors, TextStyles } from "../../styles";
import { TemperatureUtils } from "../../utils";
import { ControlSection, ControlSectionSwitchView } from "../smartVehicle";
import TemperatureModeCard from "./TemperatureModeCard";
import { ThermostatCircleButton } from "./ThermostatCircleButton";
import {
    AirConditionerFanButton,
    HeatSourceButton,
} from "./ThermostatSettingButton";

const MIN_CIRCLE_BUTTON_SIZE = 48;
const MAX_CIRCLE_BUTTON_SIZE = 60;

const THERMOSTAT_MODE_SECTIONS: PillSelectSectionProps<ThermostatMode>[] = [
    {
        label: "Auto",
        value: ThermostatMode.Auto,
    },
    {
        label: "Heat",
        value: ThermostatMode.Heat,
        selectedStyle: {
            backgroundColor: SharedColors.orange.light,
            textColor: SharedColors.orange.dark,
        },
    },
    {
        label: "Cool",
        value: ThermostatMode.Cool,
        selectedStyle: {
            backgroundColor: SharedColors.blue.light,
            textColor: SharedColors.blue.dark,
        },
    },
    {
        label: "Fan",
        value: ThermostatMode.Fan,
    },
];

export const ThermostatSection: React.FunctionComponent<{
    thermostat: Thermostat;
    airConditioner: AirConditioner | null;
    heater: Heater | null;
    fanSettingPressed: () => void;
    heatSourceSettingPressed: () => void;
}> = observer(
    ({
        thermostat,
        airConditioner,
        heater,
        fanSettingPressed,
        heatSourceSettingPressed,
    }) => {
        const [theme] = useTheme();

        const container = useRootContainer();
        const { preferredTemperatureUnit } = container.stores.setting;

        const isOn = thermostat.isOn;
        const desiredMode = thermostat.desiredMode;
        const heatTemp =
            TemperatureUtils.convertFromC(
                thermostat.heatTemp,
                preferredTemperatureUnit
            ) ?? 0;
        const coolTemp =
            TemperatureUtils.convertFromC(
                thermostat.coolTemp,
                preferredTemperatureUnit
            ) ?? 0;
        const currentTemp = thermostat.temp;
        const currentTempText =
            TemperatureUtils.convertFromC(
                currentTemp,
                preferredTemperatureUnit
            )?.toString() ?? "--";

        const isCooling = thermostat.currentMode === ThermostatMode.Cool;
        const isHeating = thermostat.currentMode === ThermostatMode.Heat;

        const heatSourceButtonVisible =
            desiredMode === ThermostatMode.Auto ||
            desiredMode === ThermostatMode.Heat;

        const tempControlVisible =
            desiredMode !== ThermostatMode.Fan &&
            desiredMode !== ThermostatMode.Off;

        const getTempMode = (
            mode: ThermostatMode
        ): ThermostatMode.Cool | ThermostatMode.Heat => {
            switch (mode) {
                case ThermostatMode.Auto:
                    if (currentTemp && currentTemp > coolTemp) {
                        return ThermostatMode.Cool;
                    } else {
                        return ThermostatMode.Heat;
                    }
                case ThermostatMode.Cool:
                    return ThermostatMode.Cool;
                case ThermostatMode.Heat:
                default:
                    return ThermostatMode.Heat;
            }
        };

        // Selection to control the mode of the increment/decrement buttons
        const [tempMode, setTempMode] = useState(getTempMode(desiredMode));

        const heatModeCardVisible =
            desiredMode === ThermostatMode.Auto ||
            desiredMode === ThermostatMode.Heat;
        const coolModeCardVisible =
            desiredMode === ThermostatMode.Auto ||
            desiredMode === ThermostatMode.Cool;

        // Shrink the circle buttons if the screen is small
        const [circleButtonSize, setCircleButtonSize] = useState(0);

        const circleButtonColor =
            tempMode === ThermostatMode.Cool
                ? theme.color.blue.dark
                : theme.color.orange.dark;

        const onDesiredModeChanged = (newDesiredMode: ThermostatMode) => {
            setTempMode(getTempMode(newDesiredMode));
            thermostat.setDesiredMode(newDesiredMode);

            if (airConditioner) {
                const fanSpeed = airConditioner.desiredFanSpeed;

                // Update fan speed when Thermostat is in "FanOnly" mode
                if (
                    newDesiredMode === ThermostatMode.Fan &&
                    fanSpeed === AirConditionerFanSpeed.Auto
                ) {
                    airConditioner.setFanSpeed(AirConditionerFanSpeed.Low);
                }
            }
        };

        const changeTempMode = (
            mode: ThermostatMode.Cool | ThermostatMode.Heat
        ) => {
            setTempMode(mode);
        };

        const updateTemperature = (increment: boolean) => {
            thermostat.updateTemperature(
                tempMode,
                increment,
                preferredTemperatureUnit
            );
        };

        const leftCircleButton = (size: number) => (
            <ThermostatCircleButton
                size={size}
                icon={SubtractIcon}
                iconFillColor={circleButtonColor}
                disabled={!isOn}
                onPress={() => updateTemperature(false)}
            />
        );

        const rightCircleButton = (size: number) => (
            <ThermostatCircleButton
                size={size}
                icon={AddIcon}
                iconFillColor={circleButtonColor}
                disabled={!isOn}
                onPress={() => updateTemperature(true)}
            />
        );

        return (
            <ControlSection
                title="Thermostat"
                rightView={
                    <ControlSectionSwitchView
                        text={isOn ? "On" : "Off"}
                        value={isOn}
                        onValueChange={(value) => thermostat.toggle(value)}
                    />
                }>
                {/* Thermostat Control */}
                <View
                    style={{
                        padding: 20,
                    }}>
                    {/* Desired Mode Select */}
                    <PillSelect
                        value={desiredMode}
                        onValueChanged={onDesiredModeChanged}
                        sections={THERMOSTAT_MODE_SECTIONS}
                        disabled={!isOn}
                    />

                    {/* Current Temperature */}
                    <Text
                        style={[
                            TextStyles.bold80,
                            {
                                color: theme.color.text.main,
                                paddingTop: 12,
                                alignSelf: "center",
                            },
                        ]}>
                        {currentTempText}
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            º{preferredTemperatureUnit}
                        </Text>
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                                alignSelf: "center",
                            },
                        ]}>
                        Current Indoor Temp
                    </Text>

                    {isCooling && (
                        <Text
                            style={[
                                TextStyles.semibold17,
                                {
                                    color: theme.color.blue.dark,
                                    alignSelf: "center",
                                    marginTop: 4,
                                },
                            ]}>
                            Cooling to{" "}
                            {TemperatureUtils.format(
                                coolTemp,
                                preferredTemperatureUnit
                            )}
                        </Text>
                    )}

                    {isHeating && (
                        <Text
                            style={[
                                TextStyles.semibold17,
                                {
                                    color: theme.color.orange.dark,
                                    alignSelf: "center",
                                    marginTop: 4,
                                },
                            ]}>
                            Heating to{" "}
                            {TemperatureUtils.format(
                                heatTemp,
                                preferredTemperatureUnit
                            )}
                        </Text>
                    )}

                    {/* Temperature Control */}
                    {tempControlVisible && (
                        <StackView
                            spacing={12}
                            style={{
                                paddingTop: 20,
                            }}>
                            <StackView
                                spacing={12}
                                style={{
                                    flexDirection: "row",
                                    alignItems: "center",
                                }}>
                                {/* Left Circle Button */}
                                <View
                                    style={{
                                        flex: 1,
                                        alignItems: "flex-start",
                                    }}
                                    onLayout={(e) => {
                                        const width =
                                            e.nativeEvent.layout.width;
                                        setCircleButtonSize(
                                            Math.min(
                                                MAX_CIRCLE_BUTTON_SIZE,
                                                width
                                            )
                                        );
                                    }}>
                                    {circleButtonSize >=
                                        MIN_CIRCLE_BUTTON_SIZE &&
                                        leftCircleButton(circleButtonSize)}
                                </View>

                                {/* Heat Mode Card */}
                                {heatModeCardVisible && (
                                    <TemperatureModeCard
                                        mode={ThermostatMode.Heat}
                                        temperature={heatTemp}
                                        unit={preferredTemperatureUnit}
                                        isOn={isOn}
                                        isSelected={
                                            tempMode === ThermostatMode.Heat
                                        }
                                        onPress={() =>
                                            changeTempMode(ThermostatMode.Heat)
                                        }
                                        isActive={isHeating}
                                    />
                                )}

                                {/* Cool Mode Card */}
                                {coolModeCardVisible && (
                                    <TemperatureModeCard
                                        mode={ThermostatMode.Cool}
                                        temperature={coolTemp}
                                        unit={preferredTemperatureUnit}
                                        isOn={isOn}
                                        isSelected={
                                            tempMode === ThermostatMode.Cool
                                        }
                                        onPress={() =>
                                            changeTempMode(ThermostatMode.Cool)
                                        }
                                        isActive={isCooling}
                                    />
                                )}

                                {/* Right Circle Button */}
                                <View
                                    style={{
                                        flex: 1,
                                        alignItems: "flex-end",
                                    }}>
                                    {circleButtonSize >=
                                        MIN_CIRCLE_BUTTON_SIZE &&
                                        rightCircleButton(circleButtonSize)}
                                </View>
                            </StackView>

                            {circleButtonSize < MIN_CIRCLE_BUTTON_SIZE && (
                                <StackView
                                    spacing={12}
                                    style={{
                                        flexDirection: "row",
                                        justifyContent: "center",
                                        alignItems: "center",
                                    }}>
                                    {leftCircleButton(MAX_CIRCLE_BUTTON_SIZE)}
                                    {rightCircleButton(MAX_CIRCLE_BUTTON_SIZE)}
                                </StackView>
                            )}
                        </StackView>
                    )}
                </View>

                {/* Settings Buttons */}
                <StackView
                    spacing={1}
                    spacerColor={theme.color.dividers.gray1}
                    style={{
                        flexDirection: "row",
                    }}>
                    {heater &&
                        heater.canSetHeatSource &&
                        heatSourceButtonVisible && (
                            <HeatSourceButton
                                heater={heater}
                                disabled={!isOn}
                                onPress={heatSourceSettingPressed}
                                style={{
                                    flex: 1,
                                }}
                            />
                        )}

                    {airConditioner && (
                        <AirConditionerFanButton
                            airConditioner={airConditioner}
                            disabled={!isOn}
                            onPress={fanSettingPressed}
                            style={{
                                flex: 1,
                            }}
                        />
                    )}
                </StackView>
            </ControlSection>
        );
    }
);
