import { observer } from "mobx-react-lite";
import React from "react";
import {
    ColorValue,
    StyleProp,
    Text,
    TextStyle,
    TouchableHighlight,
    ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { SnowFlakeIcon, ThermostatHeatIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { ThermostatMode } from "../../models/domain/climate";
import { TextStyles } from "../../styles";
import { StackView } from "..";
import { StringUtils } from "../../utils";

const TemperatureModeCard: React.FunctionComponent<{
    mode: ThermostatMode.Heat | ThermostatMode.Cool;
    title?: string;
    titleStyle?: StyleProp<TextStyle>;
    containerStyle?: StyleProp<ViewStyle>;
    showIcon?: boolean;
    temperature?: number | null;
    unit: string;
    isOn: boolean;
    isSelected: boolean;
    disabled?: boolean;
    onPress: () => void;
    isActive: boolean;
}> = observer(
    ({
        mode,
        title,
        titleStyle,
        containerStyle,
        showIcon = true,
        temperature,
        unit,
        isOn,
        isSelected,
        disabled,
        onPress,
        isActive = false,
    }) => {
        const [theme] = useTheme();

        const tempText = StringUtils.toValueString(temperature);

        let modeText: string;
        let modeColor: ColorValue;
        let modeBackgroundColor: ColorValue;
        let icon: React.FunctionComponent<SvgProps>;

        switch (mode) {
            case ThermostatMode.Heat:
                modeText = "Heat";
                modeColor = theme.color.orange.dark;
                modeBackgroundColor = theme.color.orange.light5;
                icon = ThermostatHeatIcon;
                break;
            default:
                modeText = "Cool";
                modeColor = theme.color.blue.dark;
                modeBackgroundColor = theme.color.blue.light10;
                icon = SnowFlakeIcon;
        }

        const maxBorderWidth = 2;

        // default state is on, inactive, and not selected
        let borderColor: ColorValue = theme.color.dividers.gray1;
        let textColor: ColorValue = modeColor;
        let borderWidth: number = 1;
        let backgroundColor: ColorValue = theme.color.background.elevation3;

        if (isActive || isSelected) {
            borderColor = modeColor;
            borderWidth = maxBorderWidth;

            if (isSelected) {
                backgroundColor = modeBackgroundColor;
            }
        } else if (!isOn) {
            borderColor = theme.color.text.disabled;
            textColor = theme.color.text.disabled;
        }

        return (
            <TouchableHighlight
                onPress={onPress}
                disabled={disabled}
                underlayColor={theme.color.background.elevation1}
                style={[
                    {
                        margin: maxBorderWidth - borderWidth, // this keeps the button in place when its border width changes
                        padding: 12,
                        borderRadius: 8,
                        borderWidth: borderWidth,
                        borderColor: borderColor,
                        backgroundColor: backgroundColor,
                    },
                    containerStyle,
                ]}>
                <StackView spacing={4}>
                    <StackView
                        spacing={4}
                        style={{
                            flexDirection: "row",
                        }}>
                        {showIcon &&
                            icon({
                                width: 20,
                                height: 20,
                                fill: textColor.toString(),
                            })}

                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: textColor,
                                },
                                titleStyle,
                            ]}>
                            {title ? title : modeText}
                        </Text>
                    </StackView>

                    {isOn ? (
                        <Text
                            style={[
                                TextStyles.calloutTitle,
                                {
                                    color: disabled
                                        ? theme.color.text.disabled
                                        : theme.color.text.main,
                                },
                            ]}>
                            {tempText}
                            <Text
                                style={[
                                    TextStyles.subheading,
                                    {
                                        color: disabled
                                            ? theme.color.text.disabled
                                            : theme.color.text.deemphasized,
                                    },
                                ]}>
                                ˚{unit}
                            </Text>
                        </Text>
                    ) : (
                        <Text
                            style={[
                                TextStyles.calloutTitle,
                                {
                                    color: theme.color.text.disabled,
                                },
                            ]}>
                            Off
                        </Text>
                    )}
                </StackView>
            </TouchableHighlight>
        );
    }
);

export default TemperatureModeCard;
