import React from "react";
import { observer } from "mobx-react-lite";
import { StyleProp, ViewStyle, Text, View } from "react-native";
import { useTheme } from "../../context";
import {
    AirConditioner,
    Heater,
    ThermostatMode,
} from "../../models/domain/climate";
import { AirConditionerFanSpeed } from "../../models/domain/climate/AirConditioner";
import { TextStyles } from "../../styles";
import { OpacityButton } from "../Buttons";
import StackView from "../StackView";
import { useSmartVehicle } from "../../hooks";

export const AirConditionerFanButton: React.FunctionComponent<{
    airConditioner: AirConditioner;
    disabled?: boolean;
    onPress: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(({ airConditioner, disabled, onPress, style }) => {
    let buttonText = "";

    const smartVehicle = useSmartVehicle();
    if (!smartVehicle) {
        return null;
    }

    const thermostat = smartVehicle.climate.thermostat;

    if (!thermostat) {
        return null;
    }

    switch (airConditioner.desiredFanSpeed) {
        case AirConditionerFanSpeed.Auto:
        case AirConditionerFanSpeed.Off:
            if (
                thermostat.desiredMode === ThermostatMode.Auto ||
                thermostat.desiredMode === ThermostatMode.Cool
            ) {
                buttonText = "Auto";
            } else {
                buttonText = "Off";
            }
            break;
        case AirConditionerFanSpeed.High:
            buttonText = "High";
            break;
        case AirConditionerFanSpeed.Medium:
            buttonText = "Medium";
            break;
        case AirConditionerFanSpeed.Low:
            buttonText = "Low";
            break;
    }

    return (
        <ThermostatSettingButton
            name="Fan"
            buttonText={buttonText}
            disabled={disabled}
            onPress={onPress}
            style={style}
        />
    );
});

export const HeatSourceButton: React.FunctionComponent<{
    heater: Heater;
    disabled?: boolean;
    onPress: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(({ heater, disabled, onPress, style }) => {
    const heatSource = heater.heatSource;
    let buttonText = heater.heatSourceToString(heatSource);

    if (!buttonText) {
        // Unknown heat source
        buttonText = "Unknown";
    }

    return (
        <ThermostatSettingButton
            name="Heat Source"
            buttonText={buttonText}
            disabled={disabled}
            onPress={onPress}
            style={style}
        />
    );
});

export const ThermostatSettingButton: React.FunctionComponent<{
    name: string;
    buttonText: string;
    style?: StyleProp<ViewStyle>;
    disabled?: boolean;
    onPress: () => void;
}> = observer(({ name, buttonText, style, disabled = false, onPress }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={12}
            style={[
                {
                    padding: 20,
                },
                style,
            ]}>
            <Text
                style={[
                    TextStyles.semibold17,
                    {
                        textAlign: "center",
                        color: disabled
                            ? theme.color.text.disabled
                            : theme.color.text.main,
                    },
                ]}>
                {name}
            </Text>
            <View style={{ alignItems: "center" }}>
                <OpacityButton
                    disabled={disabled}
                    text={buttonText}
                    onPress={onPress}
                    style={{
                        height: 40,
                        borderRadius: 8,
                        backgroundColor: disabled
                            ? theme.color.background.elevation3
                            : theme.color.text.main,
                        borderColor: disabled
                            ? theme.color.dividers.gray1
                            : theme.color.text.main,
                        borderWidth: 1,
                        width: "100%",
                        maxWidth: 140,
                    }}
                    textStyle={[
                        TextStyles.semibold17,
                        {
                            color: disabled
                                ? theme.color.text.disabled
                                : theme.color.text.mainInverted,
                        },
                    ]}
                />
            </View>
        </StackView>
    );
});
