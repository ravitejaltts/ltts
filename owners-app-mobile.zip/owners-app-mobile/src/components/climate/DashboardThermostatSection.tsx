import { observer } from "mobx-react-lite";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { Animated, Text, View } from "react-native";
import {
    AddIcon,
    ErrorFillIcon,
    SnowFlakeIcon,
    SubtractIcon,
    ThermostatAutoIcon,
    ThermostatFanIcon,
    ThermostatHeatIcon,
} from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import {
    AcFanSpeed,
    AirConditioner,
    Thermostat,
    ThermostatMode,
} from "../../models/domain/climate";
import { TextStyles } from "../../styles";
import { DateUtil, StringUtils, TemperatureUtils } from "../../utils";
import StackView from "../StackView";
import { AnimatedPillView, PillAnimationColors } from "../animated";
import { ThermostatCircleButton } from "./ThermostatCircleButton";
import { SmartVehicle } from "../../models/domain/vehicle";

export const DashboardThermostatSection: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
    thermostat: Thermostat;
    airConditioner: AirConditioner;
    disabled?: boolean;
}> = observer(
    ({ smartVehicle, thermostat, airConditioner, disabled = false }) => {
        const [theme] = useTheme();

        const container = useRootContainer();
        const { preferredTemperatureUnit } = container.stores.setting;

        const animationRef = useRef<Animated.CompositeAnimation>();
        const animationValueRef = useRef(new Animated.Value(0));

        const [animationBackgroundColors, setAnimationBackgroundColors] =
            useState<PillAnimationColors>({
                start: theme.color.background.elevation3,
                end: theme.color.background.elevation3,
            });

        const [animationTextColors, setAnimationTextColors] =
            useState<PillAnimationColors>({
                start: theme.color.text.deemphasized,
                end: theme.color.text.deemphasized,
            });

        const isCloudDeviceDisconnected =
            smartVehicle.isCloudDeviceDisconnected;
        const lastUpdatedDate = smartVehicle.lastUpdatedDate;

        const currentTemp = thermostat.temp;
        const currentTempText = StringUtils.toValueString(
            TemperatureUtils.convertFromC(currentTemp, preferredTemperatureUnit)
        );

        const isOn = thermostat.isOn;
        const currentMode = thermostat.currentMode;
        const desiredMode = thermostat.desiredMode;
        const heatTempText = TemperatureUtils.convertAndFormat(
            thermostat.heatTemp,
            preferredTemperatureUnit
        );
        const coolTempText = TemperatureUtils.convertAndFormat(
            thermostat.coolTemp,
            preferredTemperatureUnit
        );

        let setToText = "";

        if (isCloudDeviceDisconnected) {
            let dateTimeText = "";

            if (lastUpdatedDate) {
                if (DateUtil.isSameDay(Date.now(), lastUpdatedDate.getTime())) {
                    dateTimeText = ` at ${lastUpdatedDate.toLocaleTimeString(
                        "en-US",
                        {
                            hour: "numeric",
                            minute: "numeric",
                        }
                    )}`;
                } else {
                    dateTimeText = ` on ${lastUpdatedDate.toLocaleDateString(
                        "en-US",
                        {
                            month: "numeric",
                            day: "numeric",
                            year: "2-digit",
                        }
                    )}`;
                }
            }

            setToText = `Last Known Temp${dateTimeText}: ${currentTempText}˚${preferredTemperatureUnit}`;
        } else if (isOn) {
            let fanSpeed = "";

            if (airConditioner) {
                switch (airConditioner.desiredFanSpeed) {
                    case AcFanSpeed.Auto:
                        fanSpeed = "Auto";
                        break;
                    case AcFanSpeed.Low:
                        fanSpeed = "Low";
                        break;
                    case AcFanSpeed.High:
                        fanSpeed = "High";
                        break;
                    case AcFanSpeed.Off:
                    default:
                        fanSpeed = "Off";
                        break;
                }
            }

            switch (desiredMode) {
                case ThermostatMode.Auto:
                    setToText = `Set to ${heatTempText}- ${coolTempText} | Fan on ${fanSpeed}`;
                    break;
                case ThermostatMode.Cool:
                    switch (currentMode) {
                        case ThermostatMode.Cool:
                            // Actively cooling
                            setToText = `Cooling to ${coolTempText}`;
                            break;
                        default:
                            // Not actively cooling
                            setToText = `Set to ${coolTempText}`;
                            break;
                    }
                    break;
                case ThermostatMode.Heat:
                    switch (currentMode) {
                        case ThermostatMode.Heat:
                            // Actively heating
                            setToText = `Heating to ${heatTempText}`;
                            break;
                        default:
                            // Not actively heating
                            setToText = `Set to ${heatTempText}`;
                            break;
                    }
                    break;
                case ThermostatMode.Fan:
                    setToText = `Fan on ${fanSpeed}`;
                    break;
            }
        } else {
            setToText = "Off";
        }

        const startFadeAnimation = useCallback(() => {
            animationRef.current?.stop();
            animationValueRef.current.setValue(0);

            const animation = Animated.timing(animationValueRef.current, {
                toValue: 1,
                duration: 1000,
                useNativeDriver: false,
            });

            animationRef.current = animation;
            animation.start();
        }, []);

        const updateThermostat = (increment: boolean) => {
            // Only "Cool" and "Heat" have buttons
            switch (desiredMode) {
                case ThermostatMode.Cool:
                    thermostat.updateTemperature(
                        desiredMode,
                        increment,
                        preferredTemperatureUnit
                    );

                    // Animate background from light blue -> elevation3
                    setAnimationBackgroundColors({
                        start: theme.color.blue.light,
                        end: animationBackgroundColors.end,
                    });

                    // Animate text from black -> deemphasized
                    setAnimationTextColors({
                        start: theme.color.black,
                        end: animationTextColors.end,
                    });

                    startFadeAnimation();
                    break;
                case ThermostatMode.Heat:
                    thermostat.updateTemperature(
                        desiredMode,
                        increment,
                        preferredTemperatureUnit
                    );

                    // Animate background from light orange -> elevation3
                    setAnimationBackgroundColors({
                        start: theme.color.orange.light,
                        end: animationBackgroundColors.end,
                    });

                    // Animate text from black -> deemphasized
                    setAnimationTextColors({
                        start: theme.color.black,
                        end: animationTextColors.end,
                    });

                    startFadeAnimation();
                    break;
            }
        };

        // When current mode changes to running, start the fade animation
        useEffect(() => {
            switch (currentMode) {
                case ThermostatMode.Cool:
                    // Animate background from dark blue -> elevation2
                    setAnimationBackgroundColors({
                        start: theme.color.blue.dark,
                        end: theme.color.background.elevation3,
                    });

                    // Animate text from white -> dark blue
                    setAnimationTextColors({
                        start: theme.color.white,
                        end: theme.color.blue.dark,
                    });

                    startFadeAnimation();
                    break;
                case ThermostatMode.Heat:
                    // Animate background from dark orange to elevation2
                    setAnimationBackgroundColors({
                        start: theme.color.orange.dark,
                        end: theme.color.background.elevation3,
                    });

                    // Animate text from white -> dark orange
                    setAnimationTextColors({
                        start: theme.color.white,
                        end: theme.color.orange.dark,
                    });

                    startFadeAnimation();
                    break;
            }
        }, [currentMode, theme, startFadeAnimation]);

        return (
            <View
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: 20,
                    paddingTop: 12,
                    paddingBottom: 20,
                    backgroundColor: theme.color.background.elevation3,
                    borderColor: theme.color.dividers.gray1,
                    borderWidth: 0.5,
                    borderRadius: 8,
                }}>
                {/* Left Column */}
                <View
                    style={{
                        flex: 1,
                        justifyContent: "center",
                        alignItems: "flex-start",
                    }}>
                    {/* Subtract Circle: show if not disabled or in heat or cool modes */}
                    {!disabled &&
                    (desiredMode === ThermostatMode.Heat ||
                        desiredMode === ThermostatMode.Cool) ? (
                        <ThermostatCircleButton
                            size={60}
                            onPress={() => updateThermostat(false)}
                            icon={SubtractIcon}
                            iconFillColor={
                                desiredMode === ThermostatMode.Heat
                                    ? theme.color.orange.dark
                                    : theme.color.blue.dark
                            }
                        />
                    ) : null}
                </View>

                {/* Middle Column */}
                <View
                    style={{
                        alignItems: "center",
                    }}>
                    {/* Top Row */}
                    <StackView
                        spacing={4}
                        style={{
                            flexDirection: "row",
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        {isCloudDeviceDisconnected ? (
                            <ErrorFillIcon
                                width={24}
                                height={24}
                                fill={theme.color.yellow.warning}
                            />
                        ) : isOn && desiredMode === ThermostatMode.Auto ? (
                            <ThermostatAutoIcon />
                        ) : isOn && desiredMode === ThermostatMode.Cool ? (
                            <SnowFlakeIcon
                                fill={theme.color.blue.dark.toString()}
                            />
                        ) : isOn && desiredMode === ThermostatMode.Fan ? (
                            <ThermostatFanIcon
                                fill={theme.color.blue.dark.toString()}
                            />
                        ) : isOn && desiredMode === ThermostatMode.Heat ? (
                            <ThermostatHeatIcon
                                fill={theme.color.orange.dark.toString()}
                            />
                        ) : null}

                        <StackView
                            spacing={2}
                            style={{
                                flexDirection: "row",
                            }}>
                            <Text
                                style={{
                                    fontSize: 50,
                                    fontWeight: "bold",
                                    color: disabled
                                        ? theme.color.text.deemphasized
                                        : theme.color.text.main,
                                }}>
                                {isCloudDeviceDisconnected
                                    ? "--"
                                    : currentTempText}
                            </Text>
                            <Text
                                style={[
                                    TextStyles.body,
                                    {
                                        color: theme.color.text.deemphasized,
                                        alignSelf: "flex-end",
                                        paddingBottom: 8,
                                    },
                                ]}>
                                ˚{preferredTemperatureUnit}
                            </Text>
                        </StackView>
                    </StackView>

                    {/* Set To Text */}
                    {disabled ||
                    desiredMode === ThermostatMode.Fan ||
                    desiredMode === ThermostatMode.Auto ? (
                        <Text
                            style={[
                                TextStyles.listEyebrow,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {setToText}
                        </Text>
                    ) : (
                        <AnimatedPillView
                            value={animationValueRef.current}
                            backgroundAnimationColors={
                                animationBackgroundColors
                            }
                            textAnimationColors={animationTextColors}
                            text={setToText}
                            style={{
                                backgroundColor: theme.color.blue.dark,
                                paddingVertical: 2,
                                paddingHorizontal: 10,
                                borderRadius: 16,
                                opacity: 1,
                            }}
                        />
                    )}
                </View>

                {/* Right Column */}
                <View
                    style={{
                        flex: 1,
                        justifyContent: "center",
                        alignItems: "flex-end",
                    }}>
                    {/* Add Circle: show if not disabled or in heat or cool modes */}
                    {!disabled &&
                    (desiredMode === ThermostatMode.Heat ||
                        desiredMode === ThermostatMode.Cool) ? (
                        <ThermostatCircleButton
                            size={60}
                            onPress={() => updateThermostat(true)}
                            icon={AddIcon}
                            iconFillColor={
                                desiredMode === ThermostatMode.Heat
                                    ? theme.color.orange.dark
                                    : theme.color.blue.dark
                            }
                        />
                    ) : null}
                </View>
            </View>
        );
    }
);
