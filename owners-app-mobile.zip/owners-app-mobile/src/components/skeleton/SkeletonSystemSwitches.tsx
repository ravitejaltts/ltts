import React from "react";
import { Circle, Defs, G, GProps, Mask, Rect, Svg } from "react-native-svg";
import { useTheme } from "../../context";

const SWITCH_WIDTH = 88;
const SWITCH_HEIGHT = 158;

const SwitchMask: React.FunctionComponent<GProps> = (props) => {
    return (
        <G {...props}>
            <Rect
                width={SWITCH_WIDTH}
                height={SWITCH_HEIGHT}
                rx={8}
                stroke="black"
                fill="white"
            />

            <Circle x={44} y={46} r={30} fill="black" />

            <Rect x={20} y={98} width={48} height={8} fill="black" />
            <Rect x={20} y={114} width={48} height={8} fill="black" />
            <Rect x={28} y={130} width={30} height={8} fill="black" />
        </G>
    );
};

export const SkeletonSystemSwitches: React.FunctionComponent<{
    width: number;
    paddingHorizontal: number;
}> = ({ width, paddingHorizontal }) => {
    const [theme] = useTheme();
    const spacing = 8;

    const masks: React.ReactElement[] = [];

    for (let i = 0; i < 4; i++) {
        masks.push(
            <SwitchMask
                key={i}
                x={paddingHorizontal + spacing * i + SWITCH_WIDTH * i}
            />
        );
    }

    return (
        <Svg width={width} height={SWITCH_HEIGHT}>
            <Defs>
                <Mask id="mask">
                    <Rect width={width} height={SWITCH_HEIGHT} fill="white" />
                    {masks}
                </Mask>
            </Defs>

            <Rect
                width={width}
                height={SWITCH_HEIGHT}
                fill={theme.color.background.elevation3}
                mask="url(#mask)"
            />
        </Svg>
    );
};
