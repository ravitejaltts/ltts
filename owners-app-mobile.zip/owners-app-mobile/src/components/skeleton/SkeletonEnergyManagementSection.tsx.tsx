import React from "react";
import { Defs, G, GProps, Mask, Rect, Svg } from "react-native-svg";
import { useTheme } from "../../context";

const SECTION_HEIGHT = 441;
const SECTION_PADDING_HORIZONTAL = 16;
const CARD_SPACING = 8;

interface CardMaskProps extends GProps {
    width: number;
}

const UsageCardMask: React.FunctionComponent<CardMaskProps> = ({
    width,
    ...gProps
}) => {
    const horizontalPadding = 16;
    const fortyWidth = 0.4 * width;

    const barWidth = width - 2 * horizontalPadding;

    return (
        <G {...gProps}>
            {/* Left Text */}
            <Rect x={horizontalPadding} width={fortyWidth} y={14} height={24} />

            {/* Right Text */}
            <Rect
                x={width - fortyWidth - horizontalPadding}
                y={14}
                width={fortyWidth}
                height={24}
            />

            {/* Bar */}
            <Rect x={horizontalPadding} y={46} width={barWidth} height={12} />
        </G>
    );
};

const ShoreCardMask: React.FunctionComponent<CardMaskProps> = ({
    width,
    ...gProps
}) => {
    const horizontalPadding = 12;
    const contentWidth = width - 2 * horizontalPadding;
    const titleSpacing = 8;

    const iconSize = 24;

    const titleX = horizontalPadding + iconSize + titleSpacing;
    const titleWidth = width - titleX - horizontalPadding;

    return (
        <G {...gProps}>
            {/* Icon */}
            <Rect
                x={horizontalPadding}
                y={12}
                width={iconSize}
                height={iconSize}
            />

            {/* Title */}
            <Rect x={titleX} y={15} width={titleWidth} height={18} />

            {/* Power */}
            <Rect
                x={horizontalPadding}
                y={44}
                width={contentWidth * 0.4}
                height={26}
            />

            {/* Status */}
            <Rect
                x={horizontalPadding}
                y={72}
                width={contentWidth * 0.25}
                height={18}
            />
        </G>
    );
};

const GeneratorCardMask: React.FunctionComponent<CardMaskProps> = ({
    width,
    ...gProps
}) => {
    const horizontalPadding = 12;
    const contentWidth = width - 2 * horizontalPadding;
    const titleSpacing = 8;

    const iconSize = 24;

    const titleX = horizontalPadding + iconSize + titleSpacing;
    const titleWidth = 0.4 * width - titleX;

    const buttonX = 0.5 * width;
    const buttonWidth = width - buttonX - horizontalPadding;

    return (
        <G {...gProps}>
            {/* Icon */}
            <Rect
                x={horizontalPadding}
                y={12}
                width={iconSize}
                height={iconSize}
            />

            {/* Title */}
            <Rect x={titleX} y={15} width={titleWidth} height={18} />

            {/* Button */}
            <Rect x={buttonX} y={12} width={buttonWidth} height={62} />

            {/* Propane Level */}
            <Rect x={buttonX} y={82} width={buttonWidth} height={18} />

            {/* Power */}
            <Rect
                x={horizontalPadding}
                y={44}
                width={contentWidth * 0.4}
                height={26}
            />

            {/* Status */}
            <Rect
                x={horizontalPadding}
                y={72}
                width={contentWidth * 0.25}
                height={18}
            />

            {/* AGS */}
            <Rect
                x={horizontalPadding}
                y={124}
                width={contentWidth}
                height={32}
            />
        </G>
    );
};

export const SkeletonEnergyManagementSection: React.FunctionComponent<{
    width: number;
    paddingHorizontal: number;
}> = ({ width, paddingHorizontal }) => {
    const [theme] = useTheme();

    const sectionWidth = width - paddingHorizontal * 2;
    const cardRowWidth = sectionWidth - SECTION_PADDING_HORIZONTAL * 2;
    const cardWidth = (cardRowWidth - CARD_SPACING) / 2;

    const centerX = 0.5 * sectionWidth;
    const titleWidth = 0.5 * sectionWidth;
    const titleX = centerX - 0.5 * titleWidth;

    const usageCardX = SECTION_PADDING_HORIZONTAL;
    const usageCardY = 62;

    const shoreCardX = SECTION_PADDING_HORIZONTAL;
    const shoreCardY = 146;

    const batteryCardX = SECTION_PADDING_HORIZONTAL + cardWidth + CARD_SPACING;
    const batteryCardY = 146;

    const generatorCardX = SECTION_PADDING_HORIZONTAL;
    const generatorCardY = 256;

    return (
        <Svg width={width} height={SECTION_HEIGHT}>
            <Defs>
                <Mask id="mask">
                    <Rect width={width} height={SECTION_HEIGHT} fill="white" />

                    {/* Section Group */}
                    <G x={paddingHorizontal} fill="black">
                        <Rect x={titleX} y={20} width={centerX} height={26} />

                        <UsageCardMask
                            x={usageCardX}
                            y={usageCardY}
                            width={cardRowWidth}
                        />

                        <ShoreCardMask
                            x={shoreCardX}
                            y={shoreCardY}
                            width={cardWidth}
                        />

                        <ShoreCardMask
                            x={batteryCardX}
                            y={batteryCardY}
                            width={cardWidth}
                        />

                        <GeneratorCardMask
                            x={generatorCardX}
                            y={generatorCardY}
                            width={cardRowWidth}
                        />
                    </G>
                </Mask>
            </Defs>

            <G mask="url(#mask)">
                {/* Dashboard Background */}
                <Rect
                    width={width}
                    height={SECTION_HEIGHT}
                    fill={theme.color.background.elevation3}
                />

                {/* Section Group */}
                <G x={paddingHorizontal}>
                    {/* Section Background */}
                    <Rect
                        width={sectionWidth}
                        height={SECTION_HEIGHT}
                        rx={8}
                        fill={theme.color.background.elevation2}
                    />

                    {/* Energy Usage Card */}
                    <G x={usageCardX} y={usageCardY}>
                        <Rect
                            width={cardRowWidth}
                            height={76}
                            rx={8}
                            fill={theme.color.background.elevation3}
                        />
                    </G>

                    {/* Shore & Battery Cards */}
                    <G x={shoreCardX} y={shoreCardY}>
                        {/* Shore Card */}
                        <Rect
                            width={cardWidth}
                            height={102}
                            rx={8}
                            fill={theme.color.background.elevation3}
                        />
                    </G>

                    {/* Battery Card */}
                    <G x={batteryCardX} y={batteryCardY}>
                        <Rect
                            width={cardWidth}
                            height={102}
                            rx={8}
                            fill={theme.color.background.elevation3}
                        />
                    </G>

                    {/* Generator Card */}
                    <G x={generatorCardX} y={generatorCardY}>
                        <Rect
                            width={cardRowWidth}
                            height={169}
                            rx={8}
                            fill={theme.color.background.elevation3}
                        />
                    </G>
                </G>
            </G>
        </Svg>
    );
};
