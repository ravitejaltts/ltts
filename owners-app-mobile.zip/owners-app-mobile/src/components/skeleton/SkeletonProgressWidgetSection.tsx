import React from "react";
import Svg, { Defs, G, GProps, Mask, Rect } from "react-native-svg";
import { useTheme } from "../../context";

const PROGRESS_WIDGET_HEIGHT = 76;

interface ProgressWidgetMaskProps extends GProps {
    width: number;
}

const ProgressWidgetMask: React.FunctionComponent<ProgressWidgetMaskProps> = (
    props
) => {
    const { width, ...gProps } = props;
    const horizontalPadding = 16;
    const topPadding = 12;
    const widgetWidth = width - horizontalPadding * 2;

    return (
        <G {...gProps}>
            <Rect
                x={0}
                y={0}
                rx={8}
                width={width}
                height={PROGRESS_WIDGET_HEIGHT}
                fill="white"
                stroke="black"
            />
            <G x={horizontalPadding} y={topPadding} fill="black">
                {/* Bar */}
                <Rect x={0} y={0} width={6} height={52} rx={3} />
                <Rect x={18} y={0} width={16} height={16} />
                <Rect x={36} y={4} width={widgetWidth - 36} height={8} />
                <Rect
                    x={18}
                    y={24}
                    width={0.9 * (widgetWidth - 18)}
                    height={8}
                />
                <Rect
                    x={18}
                    y={40}
                    width={0.7 * (widgetWidth - 18)}
                    height={8}
                />
            </G>
        </G>
    );
};

export const SkeletonProgressWidgetSection: React.FunctionComponent<{
    width: number;
    paddingHorizontal: number;
}> = ({ width, paddingHorizontal }) => {
    const [theme] = useTheme();
    const sectionWidth = width - 2 * paddingHorizontal;
    const progressWidgetWidth = (sectionWidth - 12) / 2;

    return (
        <Svg width={width} height={252}>
            <Defs>
                <Mask id="mask">
                    <Rect width={width} height={252} fill="white" />

                    <G x={20}>
                        <ProgressWidgetMask width={progressWidgetWidth} />
                        <ProgressWidgetMask
                            x={progressWidgetWidth + 12}
                            width={progressWidgetWidth}
                        />
                        <ProgressWidgetMask
                            y={PROGRESS_WIDGET_HEIGHT + 12}
                            width={progressWidgetWidth}
                        />
                        <ProgressWidgetMask
                            x={progressWidgetWidth + 12}
                            y={PROGRESS_WIDGET_HEIGHT + 12}
                            width={progressWidgetWidth}
                        />
                        <ProgressWidgetMask
                            y={PROGRESS_WIDGET_HEIGHT * 2 + 24}
                            width={progressWidgetWidth}
                        />
                    </G>
                </Mask>
            </Defs>

            <Rect
                width={width}
                height={252}
                fill={theme.color.background.elevation3}
                mask="url(#mask)"
            />
        </Svg>
    );
};
