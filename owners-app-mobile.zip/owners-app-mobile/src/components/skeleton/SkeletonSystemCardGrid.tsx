import React from "react";
import { useWindowDimensions } from "react-native";
import { Defs, G, Mask, Rect, Svg } from "react-native-svg";
import { useTheme } from "../../context";
import GridView from "../GridView";
import { GradientLoadingView } from "../animated";

const CARD_HEIGHT = 129;
const CARD_PADDING = 12;

const CellSvg: React.FunctionComponent<{
    width: number;
    paddingLeft: number;
    paddingRight: number;
    paddingTop: number;
    paddingBottom: number;
}> = ({ width, paddingLeft, paddingRight, paddingTop, paddingBottom }) => {
    const [theme] = useTheme();

    // Fixes 1px line in-between cells
    width = Math.round(width);

    const cellHeight = CARD_HEIGHT + paddingTop + paddingBottom;
    const cardWidth = width - paddingLeft - paddingRight;
    const bottomTextY = CARD_HEIGHT - CARD_PADDING - 20;
    const topTextY = bottomTextY - 2 - 24;

    return (
        <Svg width={width} height={cellHeight}>
            <Defs>
                <Mask id="mask">
                    <Rect width={width} height={cellHeight} fill="white" />

                    {/* Card Group Mask */}
                    <G x={paddingLeft} y={paddingTop}>
                        <Rect
                            width={cardWidth}
                            height={CARD_HEIGHT}
                            rx={8}
                            fill="white"
                            stroke="black"
                            strokeWidth={1}
                        />

                        <Rect
                            x={CARD_PADDING}
                            y={CARD_PADDING}
                            width={24}
                            height={24}
                            fill="black"
                        />

                        <Rect
                            x={CARD_PADDING}
                            y={topTextY}
                            width={0.75 * cardWidth}
                            height={24}
                            fill="black"
                        />

                        <Rect
                            x={CARD_PADDING}
                            y={bottomTextY}
                            width={0.25 * cardWidth}
                            height={20}
                            fill="black"
                        />
                    </G>
                </Mask>
            </Defs>

            {/* Background */}
            <Rect
                width={width}
                height={cellHeight}
                fill={theme.color.background.elevation3}
                mask="url(#mask)"
            />
        </Svg>
    );
};

export const SkeletonSystemCardGrid: React.FunctionComponent = () => {
    const { width } = useWindowDimensions();
    const [theme] = useTheme();

    const columnWidth = width / 2;

    return (
        <GradientLoadingView
            animating={true}
            direction="vertical"
            duration={1500}
            backgroundColor={theme.color.background.elevation1}
            highlightColor={theme.color.background.elevation2}>
            <GridView columns={2} columnSpacing={0} rowSpacing={0}>
                <CellSvg
                    width={columnWidth}
                    paddingLeft={20}
                    paddingRight={6}
                    paddingTop={20}
                    paddingBottom={6}
                />
                <CellSvg
                    width={columnWidth}
                    paddingLeft={6}
                    paddingRight={20}
                    paddingTop={20}
                    paddingBottom={6}
                />

                <CellSvg
                    width={columnWidth}
                    paddingLeft={20}
                    paddingRight={6}
                    paddingTop={6}
                    paddingBottom={6}
                />
                <CellSvg
                    width={columnWidth}
                    paddingLeft={6}
                    paddingRight={20}
                    paddingTop={6}
                    paddingBottom={6}
                />

                <CellSvg
                    width={columnWidth}
                    paddingLeft={20}
                    paddingRight={6}
                    paddingTop={6}
                    paddingBottom={6}
                />
                <CellSvg
                    width={columnWidth}
                    paddingLeft={6}
                    paddingRight={20}
                    paddingTop={6}
                    paddingBottom={6}
                />

                <CellSvg
                    width={columnWidth}
                    paddingLeft={20}
                    paddingRight={6}
                    paddingTop={6}
                    paddingBottom={6}
                />
                <CellSvg
                    width={columnWidth}
                    paddingLeft={6}
                    paddingRight={20}
                    paddingTop={6}
                    paddingBottom={6}
                />

                <CellSvg
                    width={columnWidth}
                    paddingLeft={20}
                    paddingRight={6}
                    paddingTop={6}
                    paddingBottom={6}
                />
                <CellSvg
                    width={columnWidth}
                    paddingLeft={6}
                    paddingRight={20}
                    paddingTop={6}
                    paddingBottom={6}
                />
            </GridView>
        </GradientLoadingView>
    );
};
