import React from "react";
import { Text, View, useWindowDimensions } from "react-native";
import { Defs, G, Mask, Rect, Svg } from "react-native-svg";
import { ChevronRightIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { GradientLoadingView } from "../animated";
import { SkeletonDoorLockCard } from "./SkeletonDoorLockCard";
import { SkeletonEnergyManagementSection } from "./SkeletonEnergyManagementSection.tsx";
import { SkeletonProgressWidgetSection } from "./SkeletonProgressWidgetSection";
import { SkeletonSystemSwitches } from "./SkeletonSystemSwitches";
import { SkeletonThermostatCard } from "./SkeletonThermostatCard";

const SectionHeader: React.FunctionComponent<{
    title: string;
}> = ({ title }) => {
    const [theme] = useTheme();

    return (
        <View
            style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: theme.color.background.elevation3,
                paddingHorizontal: 20,
                paddingVertical: 12,
            }}>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: theme.color.text.disabled,
                        flex: 1,
                    },
                ]}>
                {title}
            </Text>
            <ChevronRightIcon
                width={28}
                height={28}
                fill={theme.color.text.disabled}
            />
        </View>
    );
};

export const SkeletonSmartDashboardView: React.FunctionComponent = () => {
    const [theme] = useTheme();
    const { width } = useWindowDimensions();
    const paddingHorizontal = 20;
    const sectionWidth = width - 2 * paddingHorizontal;

    return (
        <GradientLoadingView
            animating={true}
            direction="vertical"
            duration={1500}
            backgroundColor={theme.color.background.elevation1}
            highlightColor={theme.color.background.elevation2}
            style={{
                flex: 1,
            }}>
            {/* Header */}
            <Svg width={width} height={188}>
                <Defs>
                    <Mask id="mask">
                        {/* Background */}
                        <Rect
                            x={0}
                            y={0}
                            width={width}
                            height={188}
                            fill="white"
                        />

                        <G x={20} y={0} fill="black">
                            {/* Header Lines */}
                            <Rect y={0} width={sectionWidth * 0.6} height={8} />
                            <Rect
                                y={20}
                                width={sectionWidth * 0.7}
                                height={8}
                            />
                            <Rect
                                y={40}
                                width={sectionWidth * 0.6}
                                height={8}
                            />

                            {/* RV avatar */}
                            <Rect y={72} width={100} height={80} rx={8} />

                            {/* Text below avatar */}
                            <Rect
                                y={164}
                                width={sectionWidth * 0.6}
                                height={8}
                            />

                            {/* Pet Minder */}
                            <Rect
                                x={sectionWidth - 60}
                                y={108}
                                width={60}
                                height={24}
                                rx={12}
                            />
                        </G>
                    </Mask>
                </Defs>

                {/* Header Background */}
                <Rect
                    width={width}
                    height={92}
                    fill="black"
                    mask="url(#mask)"
                />

                {/* Body Background */}
                <Rect
                    x={0}
                    y={92}
                    width={width}
                    height={96}
                    fill={theme.color.background.elevation3}
                    mask="url(#mask)"
                />
            </Svg>

            <SkeletonProgressWidgetSection
                width={width}
                paddingHorizontal={paddingHorizontal}
            />

            <StackView
                spacing={16}
                spacerColor={theme.color.background.elevation3}>
                {/* Progress Widgets */}

                {/* Thermostat Section */}
                <View>
                    <SectionHeader title="Thermostat" />
                    <SkeletonThermostatCard width={width} />
                </View>

                {/* Door Lock Section */}
                <View>
                    <SectionHeader title="Door Locks" />

                    <SkeletonDoorLockCard width={width} />
                </View>

                {/* Systems Section */}
                <View>
                    <SectionHeader title="Systems" />

                    <SkeletonSystemSwitches
                        width={width}
                        paddingHorizontal={paddingHorizontal}
                    />
                </View>

                <SkeletonEnergyManagementSection
                    width={width}
                    paddingHorizontal={paddingHorizontal}
                />
            </StackView>
        </GradientLoadingView>
    );
};
