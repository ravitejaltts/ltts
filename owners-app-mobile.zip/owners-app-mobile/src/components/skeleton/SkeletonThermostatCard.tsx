import React from "react";
import Svg, { Circle, Defs, G, Mask, Rect } from "react-native-svg";
import { useTheme } from "../../context";

const CARD_HEIGHT = 120;

export const SkeletonThermostatCard: React.FunctionComponent<{
    width: number;
}> = ({ width }) => {
    const [theme] = useTheme();
    const horizontalPadding = 20;
    const cardWidth = width - horizontalPadding * 2;
    const center = 0.5 * cardWidth;
    const tempWidth = 0.2 * cardWidth;
    const subtitleWidth = 0.1 * cardWidth;

    return (
        <Svg width={width} height={CARD_HEIGHT}>
            <Defs>
                <Mask id="mask">
                    <Rect width={width} height={CARD_HEIGHT} fill="white" />

                    <G x={horizontalPadding}>
                        <Rect
                            width={cardWidth}
                            height={CARD_HEIGHT}
                            fill="white"
                            stroke="black"
                            rx={8}
                        />

                        <Circle x={50} y={60} r={30} fill="black" />
                        <Circle x={cardWidth - 50} y={60} r={30} fill="black" />

                        <Rect
                            x={center - tempWidth / 2}
                            y={30}
                            width={tempWidth}
                            height={40}
                        />

                        <Rect
                            x={center - subtitleWidth / 2}
                            y={80}
                            width={0.1 * cardWidth}
                            height={8}
                        />
                    </G>
                </Mask>
            </Defs>

            <Rect
                width={width}
                height={CARD_HEIGHT}
                fill={theme.color.background.elevation3}
                mask="url(#mask)"
            />
        </Svg>
    );
};
