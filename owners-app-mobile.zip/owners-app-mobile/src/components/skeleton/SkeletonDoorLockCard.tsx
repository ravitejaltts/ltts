import React from "react";
import Svg, { Defs, G, Mask, Rect } from "react-native-svg";
import { useTheme } from "../../context";

const CARD_HEIGHT = 104;

export const SkeletonDoorLockCard: React.FunctionComponent<{
    width: number;
}> = ({ width }) => {
    const [theme] = useTheme();
    const horizontalPadding = 20;
    const spacing = 12;

    const cardWidth = width - horizontalPadding * 2;
    const buttonWidth = (cardWidth - spacing * 3) / 2;

    return (
        <Svg width={width} height={CARD_HEIGHT}>
            <Defs>
                <Mask id="mask">
                    <Rect width={width} height={CARD_HEIGHT} fill="white" />

                    <G x={horizontalPadding} fill="black">
                        <Rect
                            width={cardWidth}
                            height={CARD_HEIGHT}
                            rx={8}
                            stroke="black"
                            fill="white"
                        />

                        <G x={spacing} y={spacing}>
                            <G>
                                <Rect
                                    x={buttonWidth / 2 - 12}
                                    y={16}
                                    width={24}
                                    height={24}
                                />
                                <Rect
                                    x={buttonWidth / 2 - 25}
                                    y={50}
                                    width={50}
                                    height={8}
                                />
                            </G>

                            <G x={buttonWidth + spacing}>
                                <Rect
                                    x={buttonWidth / 2 - 12}
                                    y={16}
                                    width={24}
                                    height={24}
                                />

                                <Rect
                                    x={buttonWidth / 2 - 25}
                                    y={50}
                                    width={50}
                                    height={8}
                                />
                            </G>
                        </G>
                    </G>
                </Mask>
            </Defs>

            <G mask="url(#mask)">
                <Rect
                    width={width}
                    height={CARD_HEIGHT}
                    fill={theme.color.background.elevation3}
                />
                <G x={horizontalPadding}>
                    <G x={spacing} y={spacing}>
                        <Rect
                            width={buttonWidth}
                            height={80}
                            rx={8}
                            fill={theme.color.background.elevation2}
                        />
                        <Rect
                            x={buttonWidth + spacing}
                            width={buttonWidth}
                            height={80}
                            rx={8}
                            fill={theme.color.background.elevation2}
                        />
                    </G>
                </G>
            </G>
        </Svg>
    );
};
