import React from "react";
import { View, TouchableOpacity, Alert, ColorValue } from "react-native";
import {
    PhoneCheckmarkIcon,
    DownloadIcon,
    RemoveCircleOutlineIcon,
} from "../assets/icons";
import { ImageButton } from "./Buttons";
import { useTheme } from "../context";
import CircularProgressBar from "./CircularProgressBar";
import { DownloadState } from "../models/domain/content";

type DownloadProgressProps = {
    state: DownloadState;
    progress: number;
    downloadIconFillColor?: ColorValue;
    progressBackgroundColor?: ColorValue;
    isEditing?: boolean;
    onDownload: () => void;
    onDelete: () => void;
    onCancel?: () => void;
};

const DownloadProgressView: React.FunctionComponent<DownloadProgressProps> = ({
    state,
    progress,
    onDownload,
    onDelete,
    onCancel,
    downloadIconFillColor,
    progressBackgroundColor,
    isEditing = false,
}) => {
    const [theme] = useTheme();

    function _onDelete() {
        Alert.alert(
            "Remove download?",
            "This will remove the downloaded file from your device.",
            [
                {
                    text: "Cancel",
                    style: "cancel",
                },
                {
                    text: "Remove",
                    style: "destructive",
                    onPress: onDelete,
                },
            ]
        );
    }

    if (isEditing) {
        return (
            <ImageButton
                image={RemoveCircleOutlineIcon}
                imageProps={{
                    fill: theme.color.error,
                }}
                onPress={_onDelete}
            />
        );
    }

    if (state === DownloadState.Complete) {
        return (
            <TouchableOpacity activeOpacity={0.5} onPress={_onDelete}>
                <PhoneCheckmarkIcon fill={theme.color.blue.brand} />
            </TouchableOpacity>
        );
    }

    if (state === DownloadState.InProgress) {
        return (
            <TouchableOpacity activeOpacity={0.5} onPress={onCancel}>
                <CircularProgressBar
                    size={30}
                    barWidth={2}
                    backgroundColor={
                        progressBackgroundColor ?? theme.color.white
                    }
                    progressColor={theme.color.blue.brand}
                    progress={progress}>
                    <View
                        style={{
                            width: 10,
                            height: 10,
                            backgroundColor: theme.color.blue.brand,
                        }}
                    />
                </CircularProgressBar>
            </TouchableOpacity>
        );
    }

    return (
        <ImageButton
            style={{
                width: 30,
                justifyContent: "center",
                alignItems: "center",
            }}
            image={DownloadIcon}
            imageProps={{
                fill: downloadIconFillColor ?? theme.color.white,
            }}
            onPress={onDownload}
        />
    );
};

export default DownloadProgressView;
