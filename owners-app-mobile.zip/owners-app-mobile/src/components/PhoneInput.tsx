import { observer } from "mobx-react-lite";
import React from "react";
import { TextInput } from "react-native";
import MaskInput, { MaskInputProps } from "react-native-mask-input";
import { FormFieldValidator } from "../models/ui/form/field";
import { StringUtils } from "../utils";

const SHORT_MASK = [
    "(",
    /\d/,
    /\d/,
    /\d/,
    ") ",
    /\d/,
    /\d/,
    /\d/,
    "-",
    /\d/,
    /\d/,
    /\d/,
    /\d/,
];

const LONG_MASK = [
    "+",
    /\d/,
    " ",
    "(",
    /\d/,
    /\d/,
    /\d/,
    ") ",
    /\d/,
    /\d/,
    /\d/,
    "-",
    /\d/,
    /\d/,
    /\d/,
    /\d/,
];

export interface PhoneInputProps extends MaskInputProps {
    field: FormFieldValidator;
}

export const PhoneInput = observer(
    React.forwardRef<TextInput, PhoneInputProps>((props, ref) => {
        const { field, ...maskInputProps } = props;

        const hasEdit = field.hasEdit;
        const value = field.text;

        return (
            <MaskInput
                ref={ref}
                value={value}
                keyboardType="phone-pad"
                placeholder="(###) ###-###"
                mask={(text) => {
                    if (!text) {
                        return [];
                    }

                    // Get length of just the numeric digits
                    if (StringUtils.stripPhoneNumber(text).length < 11) {
                        return SHORT_MASK;
                    }

                    return LONG_MASK;
                }}
                {...maskInputProps}
                onChangeText={(
                    masked: string,
                    unmasked: string,
                    obfuscated: string
                ) => {
                    maskInputProps.onChangeText?.(masked, unmasked, obfuscated);
                    field.setText(unmasked);
                }}
                onBlur={(e) => {
                    maskInputProps.onBlur?.(e);
                    if (hasEdit) {
                        field.validate();
                    }
                }}
            />
        );
    })
);
