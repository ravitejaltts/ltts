import React, { useEffect } from "react";
import { useRootContainer, useTheme } from "../../context";
import { View, Text } from "react-native";
import { TextStyles } from "../../styles";
import { SavedContentSmallView } from "./SavedContentSmallView";

export const SavedContentStackView: React.FunctionComponent = () => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const contentStore = container.stores.content;
    const storedItems = contentStore.storedItems;

    useEffect(() => {
        contentStore.loadStoredContent().catch(() => {
            // Do nothing
        });
    }, [contentStore]);

    return (
        <View>
            <Text
                style={[
                    TextStyles.bold22,
                    {
                        color: theme.color.text.main,
                        paddingHorizontal: 20,
                    },
                ]}>
                Saved Content
            </Text>
            {storedItems.length === 0 ? (
                <View
                    style={{
                        flex: 1,
                        justifyContent: "center",
                        alignItems: "center",
                        minHeight: 200,
                    }}>
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        No saved content available
                    </Text>
                </View>
            ) : (
                storedItems.map((content) => {
                    return (
                        <SavedContentSmallView
                            key={`${content.type}_${content.id}`}
                            item={content}
                        />
                    );
                })
            )}
        </View>
    );
};
