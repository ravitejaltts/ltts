import { observer } from "mobx-react-lite";
import React, { useEffect } from "react";
import { useRootContainer } from "../../context";
import { useLogger } from "../../hooks";
import {
    DownloadState,
    DynamicArticleContentItem,
} from "../../models/domain/content";
import { DynamicArticleDetails } from "../../services";
import DownloadProgressView from "../DownloadProgressView";

export const DynamicArticleDownloadProgressView: React.FunctionComponent<{
    item: DynamicArticleContentItem;
    details?: DynamicArticleDetails;
    isEditing?: boolean;
}> = observer(({ item, details, isEditing }) => {
    const { logError } = useLogger("DynamicArticleDownloadProgressView");
    const container = useRootContainer();
    const contentStore = container.stores.content;
    const file = contentStore.dynamicArticles.findCachedFile(item);
    const fileState = file?.state ?? DownloadState.None;
    const fileProgress = file?.progress ?? 0;

    // Check download
    useEffect(() => {
        contentStore.dynamicArticles.loadDownload(item);
    }, [contentStore, item]);

    if (fileState === DownloadState.None && !details) {
        // Display nothing if we're showing the download icon
        // but there is nothing to download
        return null;
    }

    return (
        <DownloadProgressView
            state={fileState}
            progress={fileProgress}
            isEditing={isEditing}
            onDownload={() => {
                if (!details) {
                    return;
                }
                contentStore.dynamicArticles.startDownload(details);
            }}
            onDelete={() => {
                contentStore.dynamicArticles
                    .deleteDownloadByItemId(item.id)
                    .catch(logError);
            }}
            onCancel={() => {
                file?.cancelDownload();
            }}
        />
    );
});
