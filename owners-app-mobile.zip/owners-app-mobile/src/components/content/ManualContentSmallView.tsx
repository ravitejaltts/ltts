import { useNavigation } from "@react-navigation/native";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import FastImage from "react-native-fast-image";
import * as ZoneData from "../../constants/ZoneData";
import { useRootContainer, useTheme } from "../../context";
import { useContentFileSize } from "../../hooks";
import {
    ContentFile,
    DynamicArticleContentItem,
    ManualContentItem,
    isDynamicArticleItem,
    isManualItem,
} from "../../models/domain/content";
import { ManualScreenNavigationProp } from "../../screens/support";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { DynamicArticleDownloadProgressView } from "./DynamicArticleDownloadProgressView";
import { ManualDownloadProgressView } from "./ManualDownloadProgressView";

const ManualContentSmallView: React.FunctionComponent<{
    zoneId: string;
    item: DynamicArticleContentItem | ManualContentItem;
    isEditing?: boolean;
}> = ({ zoneId, item, isEditing }) => {
    const [theme] = useTheme();
    const navigation = useNavigation<ManualScreenNavigationProp>();

    const zoneName = ZoneData.getName(zoneId);

    const ManualContentImage = require("../../assets/images/helpers/content/ManualContent.png");

    const container = useRootContainer();
    const contentStore = container.stores.content;

    let file: ContentFile | undefined;

    if (isDynamicArticleItem(item)) {
        file = contentStore.dynamicArticles.findCachedFile(item);
    } else if (isManualItem(item)) {
        file = contentStore.manuals.findCachedFile(item);
    }

    const fileSize = useContentFileSize(file);

    return (
        <TouchableOpacity
            activeOpacity={0.5}
            onPress={() => {
                navigation.navigate("manual", {
                    zoneId,
                    item: item,
                });
            }}>
            <View
                style={{
                    flex: 1,
                    flexDirection: "row",
                    paddingHorizontal: 20,
                    paddingVertical: 14,
                }}>
                <FastImage
                    style={{
                        width: 110,
                        height: 60,
                    }}
                    source={ManualContentImage}
                />
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                        paddingLeft: 12,
                        paddingRight: 8,
                    }}>
                    <Text
                        numberOfLines={2}
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {item.item.title}
                    </Text>

                    {zoneName && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {zoneName}
                        </Text>
                    )}

                    {Boolean(fileSize) && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {fileSize}
                        </Text>
                    )}
                </StackView>
                {isManualItem(item) ? (
                    <ManualDownloadProgressView
                        item={item}
                        isEditing={isEditing}
                    />
                ) : isDynamicArticleItem(item) ? (
                    <DynamicArticleDownloadProgressView
                        item={item}
                        isEditing={isEditing}
                    />
                ) : null}
            </View>
        </TouchableOpacity>
    );
};

export default ManualContentSmallView;
