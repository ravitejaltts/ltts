import { observer } from "mobx-react-lite";
import React, { useEffect } from "react";
import { useRootContainer } from "../../context";
import { DownloadState, ManualContentItem } from "../../models/domain/content";
import { ManualDetails } from "../../services";
import DownloadProgressView from "../DownloadProgressView";
import { useLogger } from "../../hooks";

export const ManualDownloadProgressView: React.FunctionComponent<{
    item: ManualContentItem;
    details?: ManualDetails;
    isEditing?: boolean;
}> = observer(({ item, details, isEditing }) => {
    const { logError } = useLogger("ManualDownloadProgressView");
    const container = useRootContainer();
    const contentStore = container.stores.content;
    const file = contentStore.manuals.findCachedFile(item);
    const fileState = file?.state ?? DownloadState.None;
    const fileProgress = file?.progress ?? 0;

    // Check download
    useEffect(() => {
        contentStore.manuals.loadDownload(item).catch(logError);
    }, [contentStore, item, logError]);

    if (fileState === DownloadState.None && !details) {
        // Display nothing if we're showing the download icon
        // but there is nothing to download
        return null;
    }

    return (
        <DownloadProgressView
            state={fileState}
            progress={fileProgress}
            isEditing={isEditing}
            onDownload={() => {
                if (!details) {
                    return;
                }
                contentStore.manuals.startDownload(details);
            }}
            onDelete={() => {
                contentStore.manuals
                    .deleteDownloadByItemId(item.id)
                    .catch(logError);
            }}
            onCancel={() => {
                file?.cancelDownload();
            }}
        />
    );
});
