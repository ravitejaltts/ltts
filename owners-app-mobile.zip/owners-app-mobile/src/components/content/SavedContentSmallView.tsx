import React from "react";
import { SmallHowToItemView } from "../howTo";
import {
    GenericContentItem,
    isDynamicArticleItem,
    isHowToItem,
    isManualItem,
    isSupplementItem,
} from "../../models/domain/content";
import ManualContentSmallView from "./ManualContentSmallView";
import SupplementContentSmallView from "./SupplementContentSmallView";

export const SavedContentSmallView: React.FunctionComponent<{
    item: GenericContentItem;
    isEditing?: boolean;
}> = ({ item, isEditing = false }) => {
    let zoneId = "";
    if (item.zones?.length) {
        zoneId = item.zones[0];
    }

    if (isHowToItem(item)) {
        return (
            <SmallHowToItemView
                zoneId={zoneId}
                item={item}
                isEditing={isEditing}
            />
        );
    }

    if (isSupplementItem(item)) {
        return (
            <SupplementContentSmallView
                zoneId={zoneId}
                item={item}
                isEditing={isEditing}
            />
        );
    }

    if (isManualItem(item) || isDynamicArticleItem(item)) {
        return (
            <ManualContentSmallView
                zoneId={zoneId}
                item={item}
                isEditing={isEditing}
            />
        );
    }

    return null;
};
