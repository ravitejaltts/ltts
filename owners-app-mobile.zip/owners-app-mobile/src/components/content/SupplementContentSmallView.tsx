import { useNavigation } from "@react-navigation/native";
import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import FastImage from "react-native-fast-image";
import * as ZoneData from "../../constants/ZoneData";
import { useRootContainer, useTheme } from "../../context";
import { useContentFileSize } from "../../hooks";
import { SupplementContentItem } from "../../models/domain/content";
import { SupplementDetailNavigationProp } from "../../screens/support";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { SupplementDownloadProgressView } from "../supplement/SupplementDownloadProgressView";

const SupplementContentSmallView: React.FunctionComponent<{
    zoneId: string;
    item: SupplementContentItem;
    isEditing?: boolean;
}> = ({ zoneId, item, isEditing }) => {
    const zoneName = ZoneData.getName(zoneId);

    const [theme] = useTheme();
    const navigation = useNavigation<SupplementDetailNavigationProp>();

    const container = useRootContainer();
    const contentStore = container.stores.content;

    const file = contentStore.supplements.findCachedFile(item);

    const fileSize = useContentFileSize(file);

    return (
        <TouchableOpacity
            activeOpacity={0.5}
            onPress={() => {
                navigation.navigate("supplementDetail", {
                    item: item,
                });
            }}>
            <View
                style={{
                    flex: 1,
                    flexDirection: "row",
                    paddingHorizontal: 20,
                    paddingVertical: 14,
                }}>
                <FastImage
                    style={{
                        width: 110,
                        height: 60,
                    }}
                    source={require("../../assets/images/helpers/content/PDFContent.png")}
                />
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                        paddingLeft: 12,
                        paddingRight: 8,
                    }}>
                    <Text
                        numberOfLines={2}
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {item.item.title}
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {zoneName}
                    </Text>

                    {Boolean(fileSize) && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {fileSize}
                        </Text>
                    )}
                </StackView>
                <SupplementDownloadProgressView
                    item={item}
                    isEditing={isEditing}
                />
            </View>
        </TouchableOpacity>
    );
};

export default SupplementContentSmallView;
