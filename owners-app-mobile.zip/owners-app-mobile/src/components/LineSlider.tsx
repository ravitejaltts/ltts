import React, {
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import {
    Animated,
    ColorValue,
    PanResponder,
    StyleProp,
    View,
    ViewStyle,
    Text,
    PanResponderGestureState,
} from "react-native";
import { useTheme } from "../context";
import { MathUtils } from "../utils";
import { TextStyles } from "../styles";

type SliderProps = {
    minValue?: number;
    maxValue?: number;
    stepCount?: number;
    value: number;
    onValueChange: (newValue: number) => void;
    onSlideStart?: () => void;
    onSlideEnd?: (newValue: number) => void;
    disabled?: boolean;
    fillColor?: ColorValue;
    barColor?: ColorValue;
    barHeight?: number;
    thumbSize?: number;
    stepWidth?: number;
    stepHeight?: number;
    stepLabelsVisible?: boolean;
    style?: StyleProp<ViewStyle>;
};

type StepData = {
    value: number;
    progress: number;
    pos: number;
};

// TODO: Add a threshold for sending value change events?
export const LineSlider: React.FunctionComponent<SliderProps> = ({
    minValue = 0,
    maxValue = 1,
    stepCount = 0,
    value,
    onValueChange,
    onSlideStart,
    onSlideEnd,
    disabled = false,
    fillColor,
    barColor,
    barHeight = 6,
    thumbSize = 40,
    stepWidth = 6,
    stepHeight = 16,
    stepLabelsVisible = false,
    style,
}) => {
    const [theme] = useTheme();

    if (!fillColor) {
        fillColor = theme.color.blue.brand;
    }

    if (!barColor) {
        barColor = theme.color.background.elevation1;
    }

    const [containerWidth, setContainerWidth] = useState(100);

    // Allow the thumb to center on the ends of the bar
    const barWidth = containerWidth - thumbSize;
    const halfThumbSize = thumbSize / 2;
    const minPos = halfThumbSize;
    const maxPos = barWidth + halfThumbSize;

    // Value to Progress
    const valueToProgress = useCallback(
        (newValue: number) => {
            return MathUtils.clamp(
                (newValue - minValue) / (maxValue - minValue),
                0,
                1
            );
        },
        [minValue, maxValue]
    );

    // Progress to Value
    const progressToValue = useCallback(
        (newProgress: number) => {
            return MathUtils.clamp(
                newProgress * (maxValue - minValue) + minValue,
                minValue,
                maxValue
            );
        },
        [minValue, maxValue]
    );

    const posToProgress = useCallback(
        (newPos: number) => {
            return MathUtils.clamp((newPos - halfThumbSize) / barWidth, 0, 1);
        },
        [halfThumbSize, barWidth]
    );

    const progressToPos = useCallback(
        (newProgress: number) => {
            return MathUtils.clamp(
                newProgress * barWidth + halfThumbSize,
                minPos,
                maxPos
            );
        },
        [barWidth, halfThumbSize, minPos, maxPos]
    );

    const stepData: StepData[] = useMemo(() => {
        const data: StepData[] = [];

        if (stepCount > 0) {
            const stepInterval = (maxValue - minValue) / (stepCount - 1);

            for (
                let stepValue = minValue;
                stepValue <= maxValue;
                stepValue += stepInterval
            ) {
                const stepProgress = valueToProgress(stepValue);
                const stepPos = progressToPos(stepProgress);

                data.push({
                    value: stepValue,
                    progress: stepProgress,
                    pos: stepPos,
                });
            }
        }

        return data;
    }, [stepCount, minValue, maxValue, valueToProgress, progressToPos]);

    const progress = valueToProgress(value);
    const fillPos = progressToPos(progress);

    // Both intentionally initialized to zero
    // Effect will assign them
    const fillPosRef = useRef(0);
    const animatedThumbPos = useRef(new Animated.Value(0)).current;

    const isPanningRef = useRef(false);

    const panEventRef = useRef(
        Animated.event(
            [
                {
                    pos: animatedThumbPos,
                },
            ],
            {
                useNativeDriver: false,
            }
        )
    );

    const panResponder = useMemo(() => {
        const onMove = (gestureState: PanResponderGestureState) => {
            // New pos is current pos + how far the user has panned
            let newPos = MathUtils.clamp(
                fillPosRef.current + gestureState.dx,
                minPos,
                maxPos
            );

            if (stepData.length > 0) {
                // Round between steps
                let closestStep = stepData[0];

                // Iterate to find the closest step
                for (const step of stepData) {
                    if (
                        Math.abs(newPos - step.pos) <
                        Math.abs(newPos - closestStep.pos)
                    ) {
                        closestStep = step;
                    }
                }

                newPos = closestStep.pos;
            }

            panEventRef.current({
                // Center thumb on newFillPos
                pos: newPos - thumbSize / 2,
            });

            const newProgress = posToProgress(newPos);
            const newValue = progressToValue(newProgress);

            // Notify value change
            onValueChange?.(newValue);

            return {
                value: newValue,
                progress: newProgress,
                pos: newPos,
            };
        };

        const onRelease = (gestureState: PanResponderGestureState) => {
            const { value: newValue, pos: newFillPos } = onMove(gestureState);

            fillPosRef.current = newFillPos;

            // Notify ended
            onSlideEnd?.(newValue);

            // Stop panning
            isPanningRef.current = false;
        };

        return PanResponder.create({
            onStartShouldSetPanResponder: () => !disabled,
            onStartShouldSetPanResponderCapture: () => !disabled,
            onMoveShouldSetPanResponder: () => !disabled,
            onMoveShouldSetPanResponderCapture: () => !disabled,
            onPanResponderGrant: () => {
                // Start panning and notify listeners
                isPanningRef.current = true;

                // Notify started
                onSlideStart?.();
            },
            onPanResponderMove: (_, gestureState) => onMove(gestureState),
            onPanResponderRelease: (_, gestureState) => onRelease(gestureState),
            onPanResponderTerminate: (_, gestureState) =>
                onRelease(gestureState),
        });
    }, [
        thumbSize,
        maxPos,
        minPos,
        disabled,
        stepData,
        onSlideStart,
        onSlideEnd,
        onValueChange,
        posToProgress,
        progressToValue,
    ]);

    // Listen for value changes
    useEffect(() => {
        // Only update progressLeft when not panning
        if (!isPanningRef.current) {
            const newProgress = valueToProgress(value);
            const newFillPos = progressToPos(newProgress);

            fillPosRef.current = newFillPos;

            panEventRef.current({
                // Center thumb on newFillPos
                pos: newFillPos - thumbSize / 2,
            });
        }
    }, [value, thumbSize, containerWidth, valueToProgress, progressToPos]);

    return (
        <View style={style}>
            {/* Slider Container */}
            <View
                {...panResponder.panHandlers}
                onLayout={(e) => {
                    setContainerWidth(e.nativeEvent.layout.width);
                }}
                style={{
                    height: thumbSize,
                }}>
                {/* Background Bar */}
                <View
                    style={{
                        position: "absolute",
                        top: halfThumbSize - barHeight / 2, // Center on thumb
                        left: halfThumbSize, // Allow thumb to center on ends of bar
                        width: barWidth,
                        height: barHeight,
                        backgroundColor: barColor,
                    }}
                />

                {/* Step Views */}
                {stepData.map(({ value: stepValue, pos: stepPos }) => {
                    const stepLeft = stepPos - stepWidth / 2;
                    const stepTop = halfThumbSize - stepHeight / 2;

                    const stepColor =
                        fillPos > stepLeft ? theme.color.blue.brand : barColor;

                    return (
                        <View
                            key={`step_view_${stepValue}`}
                            style={{
                                position: "absolute",
                                top: stepTop,
                                left: stepLeft,
                                width: stepWidth,
                                height: stepHeight,
                                backgroundColor: stepColor,
                            }}
                        />
                    );
                })}

                {/* Fill Bar */}
                <Animated.View
                    style={{
                        position: "absolute",
                        top: halfThumbSize - barHeight / 2, // Center on thumb
                        left: halfThumbSize, // Allow thumb to center on ends of bar
                        width: animatedThumbPos,
                        height: barHeight,
                        backgroundColor: fillColor,
                    }}
                />

                {/* Thumb */}
                <Animated.View
                    style={[
                        {
                            position: "absolute",
                            left: animatedThumbPos,
                            width: thumbSize,
                            height: thumbSize,
                            borderRadius: thumbSize,
                            backgroundColor: theme.color.background.elevation3,
                            shadowColor: theme.color.black,
                            shadowOpacity: 0.25,
                            shadowOffset: {
                                width: 0,
                                height: 2,
                            },
                        },
                        theme.name === "dark" && {
                            borderColor: theme.color.dividers.gray1,
                            borderWidth: 1,
                        },
                    ]}
                />
            </View>

            {/* Step Label Container */}
            {stepData.length > 0 && stepLabelsVisible && (
                <View
                    style={{
                        marginTop: 8,
                        height: 30,
                    }}>
                    {stepData.map(({ value: stepValue, pos: stepPos }) => {
                        const stepLabelWidth = containerWidth / (stepCount + 1);

                        return (
                            <Text
                                key={`step_label_${stepValue}`}
                                style={[
                                    TextStyles.body,
                                    {
                                        position: "absolute",
                                        left: stepPos - stepLabelWidth / 2,
                                        width: stepLabelWidth,
                                        color: theme.color.text.deemphasized,
                                        textAlign: "center",
                                    },
                                ]}>
                                {stepValue}
                            </Text>
                        );
                    })}
                </View>
            )}
        </View>
    );
};
