import React from "react";
import {
    View,
    Text,
    StyleProp,
    ViewStyle,
    TextStyle,
    TouchableHighlight,
    ActivityIndicator,
    ColorValue,
} from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { ChevronRightIcon } from "../assets/icons";
import StackView from "./StackView";
import { SvgProps } from "react-native-svg";

export type LabeledRowProps = {
    leftText: string;
    leftTextStyle?: StyleProp<TextStyle>;
    leftSubtext?: string;
    leftView?: React.ReactNode;

    rightText?: string;
    rightTextStyle?: StyleProp<TextStyle>;
    rightIconVisible?: boolean;
    rightIconProps?: SvgProps;

    loading?: boolean;
    disabled?: boolean;
    underlayColor?: ColorValue;
    style?: StyleProp<ViewStyle>;

    onPress?: () => void;
    onLongPress?: () => void;
};

const LabeledRow: React.FunctionComponent<LabeledRowProps> = ({
    leftText,
    leftTextStyle,
    leftSubtext,
    leftView,

    rightText,
    rightTextStyle,
    rightIconVisible = true,
    rightIconProps,

    loading = false,
    disabled = false,
    underlayColor,
    style,

    onPress,
    onLongPress,
}) => {
    const [theme] = useTheme();

    return (
        <TouchableHighlight
            disabled={disabled}
            underlayColor={
                underlayColor ?? theme.color.background.labeledRowUnderlay
            }
            style={[
                {
                    paddingVertical: 16,
                    paddingHorizontal: 20,
                    backgroundColor: theme.color.background.elevation3,
                },
                style,
            ]}
            onPress={onPress}
            onLongPress={onLongPress}>
            <View
                style={{
                    opacity: disabled ? 0.5 : 1,
                }}>
                <StackView
                    spacing={8}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    {/* Left Icon & Text */}
                    <StackView
                        spacing={12}
                        style={{
                            flexDirection: "row",
                            justifyContent: "flex-start",
                            alignItems: "center",
                            flex: rightText ? 0 : 1,
                        }}>
                        {Boolean(leftView) && leftView}
                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    color: theme.color.text.main,
                                    flexShrink: 1,
                                },
                                leftTextStyle,
                            ]}>
                            {leftText}
                        </Text>
                    </StackView>

                    {
                        // Right Text
                        Boolean(rightText) && (
                            <Text
                                numberOfLines={1}
                                style={[
                                    TextStyles.body,
                                    {
                                        flex: 1,
                                        color: theme.color.text.deemphasized,
                                        textAlign: "right",
                                    },
                                    rightTextStyle,
                                ]}>
                                {rightText}
                            </Text>
                        )
                    }

                    {rightIconVisible && !loading && (
                        <ChevronRightIcon
                            width={24}
                            height={24}
                            fill={theme.color.components.gray2}
                            {...rightIconProps}
                        />
                    )}

                    {loading && (
                        <ActivityIndicator
                            animating={true}
                            style={{
                                width: 24,
                                height: 24,
                            }}
                        />
                    )}
                </StackView>
                {Boolean(leftSubtext) && (
                    <Text
                        style={[
                            TextStyles.medium15,
                            { color: theme.color.text.deemphasized },
                        ]}>
                        {leftSubtext}
                    </Text>
                )}
            </View>
        </TouchableHighlight>
    );
};

export default LabeledRow;
