import React from "react";
import { Text, View } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";

export const LargeTitleHeaderView: React.FunctionComponent<{
    title: string;
    headerHeightRef: React.MutableRefObject<number>;
    titleHeaderView?: React.ReactNode;
    bodyHeaderView?: React.ReactNode;
}> = ({ title, headerHeightRef, titleHeaderView, bodyHeaderView }) => {
    const [theme] = useTheme();

    return (
        <View>
            {/* Title Header */}
            <View
                onLayout={(e) => {
                    headerHeightRef.current = e.nativeEvent.layout.height;
                }}>
                {
                    // Render custom title header
                    titleHeaderView ? (
                        <View
                            style={{
                                padding: 20,
                                backgroundColor: theme.color.black,
                            }}>
                            {titleHeaderView}
                        </View>
                    ) : title ? (
                        <View
                            style={{
                                padding: 20,
                                backgroundColor: theme.color.black,
                            }}>
                            <Text
                                style={[
                                    TextStyles.calloutTitle,
                                    {
                                        color: theme.color.white,
                                    },
                                ]}>
                                {title}
                            </Text>
                        </View>
                    ) : null
                }
            </View>
            {
                // Render body header below title header
                bodyHeaderView
            }
        </View>
    );
};
