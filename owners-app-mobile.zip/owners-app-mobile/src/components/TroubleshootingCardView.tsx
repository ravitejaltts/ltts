import React from "react";
import {
    GestureResponderEvent,
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../context/ThemeContext";
import { TextStyles } from "../styles";

export const CARD_HEIGHT = 187;

const TroubleshootingCardView: React.FunctionComponent<{
    zone: string;
    title: string;
    icon: React.FunctionComponent<SvgProps>;
    iconProps?: SvgProps;
    onPress: (event: GestureResponderEvent) => void;
    style?: StyleProp<ViewStyle>;
}> = ({ zone, title, icon, iconProps, onPress, style }) => {
    const [theme] = useTheme();

    return (
        <TouchableHighlight
            onPress={onPress}
            underlayColor={theme.color.background.elevation1}
            style={[
                {
                    flex: 0,
                    width: 140,
                    height: CARD_HEIGHT,
                    paddingTop: 12,
                    paddingHorizontal: 12,
                    paddingBottom: 16,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor:
                        theme.name === "light"
                            ? theme.color.dividers.gray1
                            : theme.color.dividers.gray2,
                    backgroundColor: theme.color.background.elevation2,
                },
                style,
            ]}>
            <View
                style={{
                    flex: 1,
                }}>
                <View
                    style={{
                        flex: 0,
                        height: 40,
                        width: 40,
                        borderRadius: 5,
                        backgroundColor: theme.color.blue.brand,
                        justifyContent: "center",
                        alignItems: "center",
                    }}>
                    {icon({
                        width: 24,
                        height: 24,
                        fill: theme.color.white.toString(),
                        ...iconProps,
                    })}
                </View>

                <View
                    style={{
                        flex: 1,
                        justifyContent: "flex-end",
                    }}>
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {zone}
                    </Text>

                    <Text
                        style={[
                            TextStyles.cardTitle,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {title}
                    </Text>
                </View>
            </View>
        </TouchableHighlight>
    );
};

export default TroubleshootingCardView;
