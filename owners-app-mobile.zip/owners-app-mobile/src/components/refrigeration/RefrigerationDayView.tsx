import React from "react";
import { StyleProp, Text, ViewStyle } from "react-native";
import { SvgProps } from "react-native-svg";
import {
    ErrorFillIcon,
    SnowFlakeIcon,
    ThermostatSystemIcon,
} from "../../assets/icons";
import { useTheme, useRootContainer } from "../../context";
import {
    RefrigerationCompartmentType,
    RefrigerationHistoryPoint,
} from "../../models/domain/climate";
import { TextStyles } from "../../styles";
import StackSection from "../StackSection";
import StackView from "../StackView";
import { TemperatureUtils } from "../../utils";

export const RefrigerationDayView: React.FunctionComponent<{
    name: string;
    type: RefrigerationCompartmentType;
    dayTimestampMillis: number;
    points: RefrigerationHistoryPoint[];
    style?: StyleProp<ViewStyle>;
}> = ({ name, type, dayTimestampMillis, points, style }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const { preferredTemperatureUnit } = container.stores.setting;

    const dayDate = new Date(dayTimestampMillis);

    let compartmentIcon: React.FunctionComponent<SvgProps>;

    switch (type) {
        case RefrigerationCompartmentType.Freezer:
            compartmentIcon = SnowFlakeIcon;
            break;
        case RefrigerationCompartmentType.Fridge:
        default:
            compartmentIcon = ThermostatSystemIcon;
            break;
    }

    return (
        <StackView spacing={8} style={style}>
            <Text
                style={[
                    TextStyles.contentEyebrow,
                    {
                        color: theme.color.text.deemphasized,
                    },
                ]}>
                {dayDate.toLocaleDateString("en-US", {
                    weekday: "long",
                    month: "long",
                    day: "numeric",
                })}
            </Text>

            <StackSection hasBorder={true}>
                {points.map((p) => {
                    const pointDate = new Date(p.timestampMillis);

                    return (
                        <StackView
                            key={p.timestampMillis}
                            spacing={8}
                            style={{
                                flexDirection: "row",
                                alignItems: "center",
                                paddingHorizontal: 20,
                                paddingVertical: 16,
                            }}>
                            {p.isWithinRange ? (
                                compartmentIcon({
                                    width: 24,
                                    height: 24,
                                    fill: theme.color.blue.dark,
                                })
                            ) : (
                                <ErrorFillIcon
                                    width={24}
                                    height={24}
                                    fill={theme.color.yellow.warning}
                                />
                            )}

                            <Text
                                style={[
                                    TextStyles.body,
                                    {
                                        color: theme.color.text.main,
                                        flex: 1,
                                    },
                                ]}>
                                {`${name} temp at ${TemperatureUtils.convertFromC(
                                    p.temp,
                                    preferredTemperatureUnit
                                )}˚`}
                            </Text>

                            <Text
                                style={[
                                    TextStyles.subheading,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {pointDate.toLocaleTimeString("en-US", {
                                    hour: "numeric",
                                    minute: "numeric",
                                })}
                            </Text>
                        </StackView>
                    );
                })}
            </StackSection>
        </StackView>
    );
};
