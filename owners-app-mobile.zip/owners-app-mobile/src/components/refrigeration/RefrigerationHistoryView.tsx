import { observer } from "mobx-react-lite";
import React, { useCallback, useState } from "react";
import { Text, View } from "react-native";
import { HistoryIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { useFirstFocusedEffect } from "../../hooks";
import { RefrigerationCompartment } from "../../models/domain/climate";
import { TextStyles } from "../../styles";
import { ArrayUtils } from "../../utils";
import { SecondaryButton } from "../Buttons";
import LoadingView from "../LoadingView";
import StackView from "../StackView";
import { RefrigerationDayView } from "./RefrigerationDayView";

const MAX_POINTS = 4;

export const RefrigerationHistoryView: React.FunctionComponent<{
    compartment: RefrigerationCompartment;
}> = observer(({ compartment }) => {
    const [theme] = useTheme();
    const [isLoading, setIsLoading] = useState(false);

    const displayName = compartment.displayName;
    const type = compartment.type;
    const historyPoints = compartment.historyPoints;
    const showHistoryButton = historyPoints.length > MAX_POINTS;

    // Most recent X points
    const recentPoints = historyPoints.slice(0, MAX_POINTS);

    const groupedPoints = ArrayUtils.groupBy(recentPoints, (p) => {
        const date = new Date(p.timestampMillis);
        date.setHours(0, 0, 0, 0);
        return date.getTime();
    });

    const dayViews: React.ReactNode[] = [];

    groupedPoints.forEach((points, timestampMillis) => {
        dayViews.push(
            <RefrigerationDayView
                key={timestampMillis}
                name={displayName}
                type={type}
                dayTimestampMillis={timestampMillis}
                points={points}
                style={{
                    paddingBottom: 16,
                }}
            />
        );
    });

    useFirstFocusedEffect(
        useCallback(() => {
            if (!recentPoints.length) {
                setIsLoading(true);

                compartment
                    .updateHistory()
                    .catch(() => {
                        // Do nothing
                    })
                    .finally(() => {
                        setIsLoading(false);
                    });
            }
        }, [recentPoints, compartment])
    );

    return (
        <View>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: theme.color.text.main,
                        paddingBottom: 8,
                    },
                ]}>
                {displayName}
            </Text>

            {dayViews.length ? (
                dayViews
            ) : isLoading ? (
                <LoadingView />
            ) : (
                <StackView
                    spacing={8}
                    style={{
                        height: 100,
                        justifyContent: "center",
                        alignItems: "center",
                    }}>
                    <HistoryIcon
                        width={50}
                        height={50}
                        fill={theme.color.text.deemphasized}
                    />
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        No history available
                    </Text>
                </StackView>
            )}

            {showHistoryButton && (
                <SecondaryButton
                    onPress={() => {
                        console.log("history pressed");
                    }}
                    text={`See ${displayName} History`}
                    textStyle={{
                        color: theme.color.blue.brand,
                    }}
                    leftView={
                        <HistoryIcon
                            width={20}
                            height={20}
                            fill={theme.color.blue.brand}
                        />
                    }
                />
            )}
        </View>
    );
});
