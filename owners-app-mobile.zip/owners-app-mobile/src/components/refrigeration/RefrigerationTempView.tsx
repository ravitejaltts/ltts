import React from "react";
import { ColorValue, Text, View } from "react-native";
import { SvgProps } from "react-native-svg";
import {
    ErrorFillIcon,
    ShieldCheckIcon,
    SnowFlakeIcon,
    ThermostatSystemIcon,
    WarningFillIcon,
} from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import {
    RefrigerationCompartment,
    RefrigerationCompartmentType,
} from "../../models/domain/climate";
import { TextStyles } from "../../styles";
import { StringUtils, TemperatureUtils } from "../../utils";
import StackView from "../StackView";
import { observer } from "mobx-react-lite";

export const RefrigerationTempView: React.FunctionComponent<{
    compartment: RefrigerationCompartment;
}> = observer(({ compartment }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const preferredTemperatureUnit =
        container.stores.setting.preferredTemperatureUnit;

    const displayName = compartment.displayName;
    const temp = TemperatureUtils.convertFromC(
        compartment.temp,
        preferredTemperatureUnit
    );

    const tempText = StringUtils.toValueString(temp);

    const isWithinRange = compartment.isWithinRange;

    let compartmentIcon: React.FunctionComponent<SvgProps>;

    switch (compartment.type) {
        case RefrigerationCompartmentType.Freezer:
            compartmentIcon = SnowFlakeIcon;
            break;
        case RefrigerationCompartmentType.Fridge:
        default:
            compartmentIcon = ThermostatSystemIcon;
            break;
    }

    let rangeText: string;
    let rangeIcon: React.FunctionComponent<SvgProps>;
    let rangeColor: ColorValue;

    if (isWithinRange === null) {
        rangeText = "Error";
        rangeIcon = WarningFillIcon;
        rangeColor = theme.color.error;
    } else if (isWithinRange) {
        rangeText = "Within Range";
        rangeIcon = ShieldCheckIcon;
        rangeColor = theme.color.green.light;
    } else {
        rangeText = "Outside Range";
        rangeIcon = ErrorFillIcon;
        rangeColor = theme.color.yellow.warning;
    }

    return (
        <View
            style={{
                flex: 1,
                paddingTop: 12,
                paddingBottom: 16,
                alignItems: "center",
            }}>
            {/* First Row */}
            <StackView
                spacing={4}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                {compartmentIcon({
                    width: 20,
                    height: 20,
                    fill: theme.color.blue.dark,
                })}
                <Text
                    style={[
                        TextStyles.contentEyebrow,
                        {
                            color: theme.color.blue.dark,
                        },
                    ]}>
                    {displayName}
                </Text>
            </StackView>

            {/* Second Row */}
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "center",
                }}>
                {/* Center Temperature View */}
                <Text
                    style={[
                        TextStyles.bold80,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {tempText}
                </Text>

                {/* Right Units View */}
                <View
                    style={{
                        justifyContent: "flex-end",
                        paddingBottom: 16,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        ˚{preferredTemperatureUnit}
                    </Text>
                </View>
            </View>

            {/* Third Row */}
            <StackView
                spacing={4}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                {rangeIcon({
                    width: 16,
                    height: 16,
                    fill: rangeColor,
                })}
                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: rangeColor,
                            textAlign: "center",
                        },
                    ]}>
                    {rangeText}
                </Text>
            </StackView>
        </View>
    );
});
