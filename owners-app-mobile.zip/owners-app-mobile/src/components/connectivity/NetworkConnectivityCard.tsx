import React from "react";
import { StyleProp, Text, ViewStyle } from "react-native";
import { WifiOffIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";

export const NetworkConnectivityCard: React.FunctionComponent<{
    style?: StyleProp<ViewStyle>;
}> = ({ style }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={4}
            style={[
                {
                    paddingTop: 20,
                    paddingBottom: 36,
                    paddingHorizontal: 20,
                    borderRadius: 8,
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: theme.color.background.elevation2,
                },
                style,
            ]}>
            <WifiOffIcon
                style={{
                    marginBottom: 12,
                }}
                fill={theme.color.background.defaultInverted}
            />
            <Text
                style={[
                    TextStyles.bold22,
                    {
                        color: theme.color.text.main,
                    },
                ]}>
                We Can't Connect
            </Text>
            <Text
                style={[
                    TextStyles.regular17,
                    {
                        color: theme.color.text.main,
                    },
                ]}>
                Please check your internet connection.
            </Text>
        </StackView>
    );
};
