import React from "react";
import {
    ColorValue,
    StyleProp,
    Text,
    TextStyle,
    TouchableHighlight,
    TouchableHighlightProps,
    TouchableOpacity,
    TouchableOpacityProps,
    View,
    ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { ForwardArrowIcon } from "../assets/icons";
import { useTheme } from "../context/ThemeContext";
import { DarkTheme, LightTheme, TextStyles, Theme } from "../styles";
import StackView from "./StackView";

interface OpacityButtonProps extends TouchableOpacityProps {
    text: string;
    textStyle?: StyleProp<TextStyle>;
}

export const OpacityButton: React.FunctionComponent<OpacityButtonProps> = (
    props
) => {
    const { text, textStyle, ...opacityProps } = props;
    return (
        <TouchableOpacity
            {...opacityProps}
            activeOpacity={opacityProps.activeOpacity ?? 0.5}
            style={[
                {
                    justifyContent: "center", // Center vertically
                },
                opacityProps.style,
            ]}>
            <Text
                style={[
                    {
                        textAlign: "center", // Center horizontally
                    },
                    textStyle,
                ]}>
                {text}
            </Text>
        </TouchableOpacity>
    );
};

interface HighlightButtonProps extends TouchableHighlightProps {
    text: string;
    textStyle?: StyleProp<TextStyle>;
    leftView?: React.ReactNode;
    overrideTheme?: Theme;
}

export const HighlightButton: React.FunctionComponent<HighlightButtonProps> = (
    props
) => {
    const { text, textStyle, leftView, ...highlightProps } = props;

    return (
        <TouchableHighlight
            {...highlightProps}
            style={[
                {
                    justifyContent: "center", // Center vertically
                },
                highlightProps.style,
            ]}>
            <StackView
                spacing={8}
                style={{
                    flexDirection: "row",
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                {leftView}
                <Text
                    style={[
                        {
                            textAlign: "center", // Center horizontally
                        },
                        textStyle,
                    ]}>
                    {text}
                </Text>
            </StackView>
        </TouchableHighlight>
    );
};

export const PrimaryButton: React.FunctionComponent<HighlightButtonProps> = (
    props
) => {
    const [theme] = useTheme();
    return (
        <HighlightButton
            underlayColor={theme.color.red.dark}
            {...props}
            style={[
                {
                    height: 48,
                    borderRadius: 24,
                    opacity: props.disabled ? 0.5 : 1,
                    backgroundColor: theme.color.red.brand,
                },
                props.style,
            ]}
            textStyle={[
                TextStyles.largeButton,
                {
                    color: theme.color.white,
                },
                props.textStyle,
            ]}
        />
    );
};

export const BlackPrimaryButton: React.FunctionComponent<
    HighlightButtonProps
> = (props) => {
    const { overrideTheme } = props;
    let [theme] = useTheme();
    if (overrideTheme) {
        theme = overrideTheme;
    }

    return (
        <HighlightButton
            underlayColor={
                theme.name === "light"
                    ? DarkTheme.color.background.elevation1
                    : LightTheme.color.background.elevation1
            }
            {...props}
            style={[
                {
                    height: 48,
                    borderRadius: 24,
                    opacity: props.disabled ? 0.5 : 1,
                    backgroundColor: theme.color.background.defaultInverted,
                },
                props.style,
            ]}
            textStyle={[
                TextStyles.largeButton,
                {
                    color: theme.color.text.mainInverted,
                },
                props.textStyle,
            ]}
        />
    );
};

export const SecondaryButton: React.FunctionComponent<HighlightButtonProps> = (
    props
) => {
    const [theme] = useTheme();
    return (
        <HighlightButton
            underlayColor={theme.color.background.elevation1}
            {...props}
            style={[
                {
                    height: 48,
                    borderRadius: 24,
                    borderWidth: 1,
                    opacity: props.disabled ? 0.5 : 1,
                    backgroundColor: theme.color.background.elevation3,
                    borderColor: theme.color.dividers.gray1,
                },
                props.style,
            ]}
            textStyle={[
                TextStyles.largeButton,
                {
                    color: theme.color.text.main,
                },
                props.textStyle,
            ]}
        />
    );
};

interface HeaderButtonProps extends OpacityButtonProps {
    color?: ColorValue;
    overrideTheme?: Theme;
}

export const HEADER_BUTTON_HEIGHT = 40;

const HeaderButton: React.FunctionComponent<HeaderButtonProps> = (props) => {
    const [theme] = useTheme();
    const { color, ...headerButtonProps } = props;
    return (
        <OpacityButton
            {...headerButtonProps}
            style={[
                {
                    height: HEADER_BUTTON_HEIGHT,
                    backgroundColor: theme.color.transparent,
                },
                props.style,
            ]}
            textStyle={[
                TextStyles.listItemSmall,
                {
                    color: props.disabled ? theme.color.text.disabled : color,
                },
                props.textStyle,
            ]}
        />
    );
};

export const HeaderPrimaryButton: React.FunctionComponent<HeaderButtonProps> = (
    props
) => {
    let [theme] = useTheme();

    if (props.overrideTheme) {
        theme = props.overrideTheme;
    }

    return <HeaderButton {...props} color={theme.color.blue.brand} />;
};

export const HeaderSecondaryButton: React.FunctionComponent<
    HeaderButtonProps
> = (props) => {
    let [theme] = useTheme();

    if (props.overrideTheme) {
        theme = props.overrideTheme;
    }

    return <HeaderButton {...props} color={theme.color.text.main} />;
};

export const LinkButton: React.FunctionComponent<OpacityButtonProps> = (
    props
) => {
    const [theme] = useTheme();

    return (
        <OpacityButton
            {...props}
            style={[
                {
                    height: 48,
                    backgroundColor: theme.color.transparent,
                },
                props.style,
            ]}
            textStyle={[
                TextStyles.linkButton,
                {
                    textDecorationLine: "underline",
                    color: props.disabled
                        ? theme.color.text.disabled
                        : theme.color.text.main,
                },
                props.textStyle,
            ]}
        />
    );
};

export interface ImageButtonProps extends TouchableOpacityProps {
    image: React.FunctionComponent<SvgProps>;
    imageProps?: SvgProps;
}

export const ImageButton: React.FunctionComponent<ImageButtonProps> = (
    props
) => {
    const { image, imageProps, ...touchableOpacityProps } = props;

    return (
        <TouchableOpacity
            {...touchableOpacityProps}
            activeOpacity={touchableOpacityProps.activeOpacity ?? 0.5}>
            {image(imageProps ?? {})}
        </TouchableOpacity>
    );
};

export interface CardButtonProps extends TouchableHighlightProps {
    text: string;
    textStyle?: StyleProp<TextStyle>;
    image: React.FunctionComponent<SvgProps>;
    imageProps?: SvgProps;
}

export const CardButton: React.FunctionComponent<CardButtonProps> = (props) => {
    const [theme] = useTheme();

    const { text, textStyle, image, imageProps, ...touchableOpacityProps } =
        props;

    return (
        <TouchableHighlight
            {...touchableOpacityProps}
            underlayColor={theme.color.background.elevation1}
            style={[
                {
                    backgroundColor: theme.color.background.elevation3,
                    paddingVertical: 16,
                    paddingHorizontal: 12,
                    borderRadius: 8,
                },
                touchableOpacityProps.style,
            ]}>
            <View
                style={{
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                {image(imageProps ?? {})}

                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.text.main,
                            paddingTop: 4,
                            textAlign: "center",
                        },
                        textStyle,
                    ]}>
                    {text}
                </Text>
            </View>
        </TouchableHighlight>
    );
};

export interface ArrowButtonProps extends TouchableOpacityProps {
    text: string;
    textStyle?: StyleProp<TextStyle>;
    buttonProps?: SvgProps;
}

export const ArrowButton: React.FunctionComponent<ArrowButtonProps> = (
    props
) => {
    const [theme] = useTheme();

    const { text, textStyle, buttonProps, ...touchableOpacityProps } = props;

    return (
        <TouchableOpacity
            {...touchableOpacityProps}
            activeOpacity={touchableOpacityProps.activeOpacity ?? 0.5}
            style={[
                {
                    flexDirection: "row",
                    height: 40,
                    justifyContent: "center", // Center vertically,
                    alignItems: "center", // Center horizontally
                },
                touchableOpacityProps.style,
            ]}>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: theme.color.text.main,
                        marginRight: 8,
                    },
                    textStyle,
                ]}>
                {text}
            </Text>
            <ForwardArrowIcon fill={theme.color.red.brand} {...buttonProps} />
        </TouchableOpacity>
    );
};

export const MapButton: React.FunctionComponent<{
    icon: React.FunctionComponent;
    onPress: () => void;
    style?: StyleProp<ViewStyle>;
    disabled?: boolean;
}> = ({ onPress, style, icon, disabled = false }) => {
    const [theme] = useTheme();

    return (
        <TouchableOpacity
            disabled={disabled}
            onPress={onPress}
            style={[
                {
                    flex: 1,
                    padding: 10,
                    borderRadius: 30,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: theme.color.background.elevation3,
                    shadowColor: theme.color.black,
                    shadowOffset: {
                        width: 0,
                        height: 2,
                    },
                    shadowOpacity: 0.25,
                    shadowRadius: 3.84,

                    elevation: 5,
                },
                style,
            ]}>
            {icon({})}
        </TouchableOpacity>
    );
};
