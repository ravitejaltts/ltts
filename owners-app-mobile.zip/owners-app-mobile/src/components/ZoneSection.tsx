import React, { useCallback, useEffect, useState } from "react";
import StackSection from "./StackSection";
import * as ZoneData from "../constants/ZoneData";
import LabeledRow from "./LabeledRow";
import { TextStyles } from "../styles";
import { useStores, useTheme } from "../context";
import LoadingView from "./LoadingView";
import ErrorView from "./ErrorView";
import { StyleProp, ViewStyle } from "react-native";
import { useIsFocused } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import { Vehicle } from "../models/domain/vehicle";

const DEFAULT_HEIGHT = 200;

const ZoneSection: React.FunctionComponent<{
    zoneTapped: (zoneId: string) => void;
    loadingStyle?: StyleProp<ViewStyle>;
    errorStyle?: StyleProp<ViewStyle>;
}> = observer(({ zoneTapped, loadingStyle, errorStyle }) => {
    const [theme] = useTheme();

    const isFocused = useIsFocused();

    const stores = useStores();
    const vehicleStore = stores.vehicle;
    const contentStore = stores.content;

    const vehicle = vehicleStore.associatedVehicle;
    const modelId = Vehicle.getModelIdOrDefault(vehicle);

    const [zones, setZones] = useState<string[]>([]);
    const [isLoadingZones, setIsLoadingZones] = useState(true);

    const updateZones = useCallback(() => {
        setIsLoadingZones(true);

        contentStore
            .getZones(modelId)
            .then((newZones) => {
                setIsLoadingZones(false);
                setZones(newZones);
            })
            .catch(() => {
                setIsLoadingZones(false);
            });
    }, [contentStore, modelId]);

    useEffect(() => {
        if (isFocused && modelId) {
            updateZones();
        }
    }, [isFocused, modelId, updateZones]);

    return isLoadingZones ? (
        <LoadingView
            style={[
                {
                    height: DEFAULT_HEIGHT,
                },
                loadingStyle,
            ]}
        />
    ) : zones.length === 0 ? (
        <ErrorView
            text="No Zones Available"
            onButtonPressed={updateZones}
            style={[
                {
                    height: DEFAULT_HEIGHT,
                },
                errorStyle,
            ]}
        />
    ) : (
        <StackSection hasBorder={true}>
            {zones.map((zoneId) => {
                const displayName = ZoneData.getName(zoneId);

                const icon = ZoneData.getIcon(zoneId);

                return (
                    <LabeledRow
                        key={zoneId}
                        leftText={displayName}
                        leftTextStyle={TextStyles.listItemSmall}
                        leftView={icon({
                            fill: theme.color.blue.brand,
                        })}
                        onPress={() => zoneTapped(zoneId)}
                    />
                );
            })}
        </StackSection>
    );
});

export default ZoneSection;
