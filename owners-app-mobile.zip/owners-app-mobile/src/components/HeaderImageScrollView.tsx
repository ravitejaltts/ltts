import React, { useMemo, useRef, useState } from "react";
import {
    Animated,
    ImageRequireSource,
    NativeScrollEvent,
    NativeSyntheticEvent,
    ScrollViewProps,
    useWindowDimensions,
    View,
    ViewStyle,
    Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "../context";
import AdaptiveStatusBar from "./AdaptiveStatusBar";
import { AnimatedImageBackground } from "./animated";

export interface HeaderImageScrollViewProps extends ScrollViewProps {
    imageSource?: ImageRequireSource;
    renderHeader: React.FunctionComponent;
    renderOverlay?: React.FunctionComponent;
}

const HeaderImageScrollView: React.FunctionComponent<
    HeaderImageScrollViewProps
> = (props) => {
    const { imageSource, renderHeader, renderOverlay, ...scrollViewProps } =
        props;

    const windowDimensions = useWindowDimensions();
    const safeAreaInsets = useSafeAreaInsets();
    const [theme] = useTheme();

    const [isStatusBarOpaque, setIsStatusBarOpaque] = useState(false);
    const [headerHeight, setHeaderHeight] = useState(0);

    const scrollY = useRef(new Animated.Value(0)).current;

    const animatedStyle = useMemo<Animated.AnimatedProps<ViewStyle>>(() => {
        return {
            transform: [
                {
                    // Center the image as it scales
                    translateY: scrollY.interpolate({
                        inputRange: [-headerHeight, 0, headerHeight],
                        outputRange: [-headerHeight / 2, 0, 0],
                    }),
                },
                {
                    // Scale the image up to twice its size
                    scale: scrollY.interpolate({
                        inputRange: [-headerHeight, 0, headerHeight],
                        outputRange: [2, 1, 1],
                    }),
                },
            ],
        };
    }, [headerHeight, scrollY]);

    function onScroll(e: NativeSyntheticEvent<NativeScrollEvent>) {
        // Forward event to props
        props.onScroll?.(e);

        const y = e.nativeEvent.contentOffset.y;

        if (!isStatusBarOpaque && y >= headerHeight - safeAreaInsets.top) {
            setIsStatusBarOpaque(true);
        }

        if (isStatusBarOpaque && y < headerHeight - safeAreaInsets.top) {
            setIsStatusBarOpaque(false);
        }
    }

    return (
        <View>
            <Animated.ScrollView
                {...scrollViewProps}
                scrollEventThrottle={10}
                onScroll={Animated.event(
                    [
                        {
                            nativeEvent: {
                                contentOffset: {
                                    y: scrollY,
                                },
                            },
                        },
                    ],
                    {
                        useNativeDriver: true,
                        listener: onScroll,
                    }
                )}>
                {imageSource && (
                    <AnimatedImageBackground
                        source={imageSource}
                        resizeMode="cover"
                        style={[
                            {
                                width: windowDimensions.width,
                                height: headerHeight,
                                position: "absolute",
                            },
                            animatedStyle,
                        ]}>
                        {renderOverlay?.({})}
                    </AnimatedImageBackground>
                )}
                {!imageSource && (
                    <View>
                        {
                            // Top overscroll background
                            Platform.OS === "ios" && (
                                <View
                                    style={{
                                        backgroundColor: theme.color.black,
                                        position: "absolute",
                                        height: 500,
                                        top: -500,
                                        left: 0,
                                        right: 0,
                                    }}
                                />
                            )
                        }
                        <View
                            style={{
                                width: windowDimensions.width,
                                height: headerHeight,
                                position: "absolute",
                                backgroundColor: theme.color.black,
                            }}
                        />
                    </View>
                )}

                <View
                    onLayout={(e) => {
                        setHeaderHeight(e.nativeEvent.layout.height);
                    }}>
                    {renderHeader({})}
                </View>

                {props.children}
            </Animated.ScrollView>

            <AdaptiveStatusBar isOpaque={isStatusBarOpaque} />
        </View>
    );
};

export default HeaderImageScrollView;
