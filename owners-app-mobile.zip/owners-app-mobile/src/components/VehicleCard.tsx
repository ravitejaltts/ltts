import { observer } from "mobx-react-lite";
import React from "react";
import { Text, TouchableHighlight, View } from "react-native";
import FastImage from "react-native-fast-image";
import StackView from "./StackView";
import { useStores, useTheme } from "../context";
import { TextStyles } from "../styles";
import { ArrowButton } from "./Buttons";

const VehicleCard: React.FunctionComponent<{
    navigateToSupport: () => void;
}> = observer(({ navigateToSupport }) => {
    const [theme] = useTheme();
    const vehicleStore = useStores().vehicle;
    const vehicle = vehicleStore.associatedVehicle;

    if (!vehicle) {
        return null;
    }

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={navigateToSupport}
            style={{
                borderRadius: 8,
                paddingTop: 20,
                paddingHorizontal: 20,
                paddingBottom: 6,
                backgroundColor: theme.color.background.elevation3,
            }}>
            <StackView
                spacing={5}
                style={{
                    flex: 1,
                    flexDirection: "row",
                }}>
                {/* Left Column */}
                <View
                    style={{
                        flex: 1,
                    }}>
                    <Text
                        style={[
                            TextStyles.contentEyebrow,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        QUICK START GUIDE
                    </Text>

                    {/* Header */}
                    <Text
                        style={[
                            TextStyles.calloutTitle,
                            {
                                color: theme.color.text.main,
                                marginVertical: 4,
                            },
                        ]}>
                        Get to Know Your {vehicle.seriesName}
                    </Text>

                    {/* CTA Button */}
                    <ArrowButton
                        text="Get Started"
                        onPress={navigateToSupport}
                        style={{
                            alignSelf: "flex-start",
                        }}
                    />
                </View>

                {/* Right Column */}
                {vehicle.avatar && (
                    <View
                        style={{
                            flex: 1,
                            justifyContent: "flex-end",
                            paddingBottom: 14,
                        }}>
                        <FastImage
                            source={{ uri: vehicle.avatar.url }}
                            style={{
                                height: 100,
                                width: undefined,
                            }}
                            resizeMode="contain"
                        />
                    </View>
                )}
            </StackView>
        </TouchableHighlight>
    );
});

export default VehicleCard;
