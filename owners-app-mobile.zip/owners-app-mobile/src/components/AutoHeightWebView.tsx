import React, { useEffect, useMemo, useRef, useState } from "react";
import { useWindowDimensions } from "react-native";
import WebView, { WebViewProps } from "react-native-webview";

// https://github.com/react-native-webview/react-native-webview/blob/master/docs/Reference.md#injectedjavascript
// https://github.com/scazzy/react-native-webview-autoheight/blob/master/index.js
const documentHeightJs = `
    // Wait for render
    // Timeout prevents ReactNativeWebView from being undefined
    setTimeout(() => {
        window.ReactNativeWebView.postMessage(
            JSON.stringify(
                Math.max(
                    document.documentElement.clientHeight,
                    document.documentElement.scrollHeight,
                    document.body.clientHeight,
                    document.body.scrollHeight
                )
            )
        );
    }, 500);
`;

const getStyleJs = (css: string) => {
    return `
        var styleTags = document.getElementsByTagName('style');
        if (styleTags.length > 0) {
            var style = styleTags.item(0)
            style.textContent = \`${css}\`;
        } else {
            var style = document.createElement('style');
            style.textContent = \`${css}\`;
            document.head.appendChild(style);
        }
    `;
};

interface AutoHeightWebViewProps extends WebViewProps {
    css?: string;
}

const AutoHeightWebView: React.FunctionComponent<AutoHeightWebViewProps> = (
    props
) => {
    const windowDimensions = useWindowDimensions();
    const [height, setHeight] = useState(windowDimensions.height);
    const webView = useRef<WebView | null>(null);

    const { css, ...webViewProps } = props;

    const injectedJavaScript = useMemo(() => {
        let js = "";

        if (css) {
            js += getStyleJs(css);
        }

        js += documentHeightJs;

        // Required to return a boolean on iOS
        js += "\ntrue;";

        return js;
    }, [css]);

    // Reload the WebView when the CSS changes
    useEffect(() => {
        webView.current?.injectJavaScript(injectedJavaScript);
    }, [injectedJavaScript]);

    return (
        <WebView
            {...webViewProps}
            ref={(ref) => {
                webView.current = ref;
            }}
            style={[
                {
                    height: height,
                },
                props.style,
            ]}
            scrollEnabled={false}
            nestedScrollEnabled={false}
            injectedJavaScript={injectedJavaScript}
            onMessage={(event) => {
                const data = event.nativeEvent.data;
                setHeight(parseInt(data));
            }}
        />
    );
};

export default AutoHeightWebView;
