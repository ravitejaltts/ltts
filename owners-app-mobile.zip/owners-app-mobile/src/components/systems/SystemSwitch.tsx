import React from "react";
import { ColorValue, Text, TouchableHighlight, View } from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { observer } from "mobx-react-lite";

export type SystemSwitchProps = {
    name: string;
    isOn: boolean;
    status?: string;
    disabled?: boolean;
    icon: React.FunctionComponent<SvgProps>;
    iconFillColor?: ColorValue;
    onPress?: () => void;
    onLongPress?: () => void;
    backgroundColorOverride?: ColorValue;
};

export const SystemSwitch: React.FunctionComponent<SystemSwitchProps> =
    observer(
        ({
            name,
            isOn,
            status,
            icon,
            iconFillColor,
            onPress,
            onLongPress,
            backgroundColorOverride,
            disabled = false,
        }) => {
            const [theme] = useTheme();

            return (
                <TouchableHighlight
                    underlayColor={theme.color.background.elevation1}
                    onPress={onPress}
                    onLongPress={onLongPress}
                    disabled={disabled}
                    style={{
                        width: 88,
                        paddingTop: 16,
                        paddingBottom: 12,
                        borderRadius: 8,
                        borderWidth: 1,
                        borderColor: theme.color.dividers.gray1,
                        backgroundColor: backgroundColorOverride
                            ? backgroundColorOverride
                            : theme.color.background.elevation3,
                    }}>
                    <StackView
                        spacing={8}
                        style={{
                            flex: 1,
                            alignItems: "center",
                            paddingHorizontal: 4,
                        }}>
                        {/* Icon */}
                        <View
                            style={{
                                justifyContent: "center",
                                alignItems: "center",
                                width: 60,
                                height: 60,
                                borderWidth: 1,
                                borderRadius: 60,
                                borderColor: theme.color.dividers.gray1,
                                backgroundColor: backgroundColorOverride
                                    ? backgroundColorOverride
                                    : isOn
                                    ? theme.color.background.elevation3
                                    : theme.color.background.elevation2,
                            }}>
                            {icon({
                                width: 32,
                                height: 32,
                                fill:
                                    !disabled && isOn
                                        ? iconFillColor
                                        : theme.color.components.gray1,
                            })}
                        </View>

                        <StackView
                            spacing={4}
                            style={{
                                flex: 1,
                                justifyContent: "space-between",
                                alignItems: "center",
                            }}>
                            {/* Name */}
                            <Text
                                numberOfLines={2}
                                style={[
                                    TextStyles.listItemSmall,
                                    {
                                        color:
                                            !disabled && isOn
                                                ? theme.color.text.main
                                                : theme.color.text.deemphasized,
                                        textAlign: "center",
                                        textAlignVertical: "center",
                                    },
                                ]}>
                                {name}
                            </Text>

                            <Text
                                style={[
                                    TextStyles.subheading,
                                    {
                                        color:
                                            !disabled && isOn
                                                ? theme.color.text.main
                                                : theme.color.text.deemphasized,
                                    },
                                ]}>
                                {status ? status : isOn ? "On" : "Off"}
                            </Text>
                        </StackView>
                    </StackView>
                </TouchableHighlight>
            );
        }
    );
