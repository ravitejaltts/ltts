import { useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React from "react";
import { ScrollView } from "react-native";
import { InverterIcon, LightBulbIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { SmartVehicle } from "../../models/domain/vehicle";
import { RvcWaterHeater } from "../../models/domain/water";
import { SmartVehicleDashboardScreenNavigationProp } from "../../screens/dashboard";
import StackView from "../StackView";
import { WaterSystemIcon } from "../water";
import { SystemSwitch, SystemSwitchProps } from "./SystemSwitch";

type SwitchData = SystemSwitchProps & {
    key: string;
};

export const SystemSwitchSection: React.FunctionComponent<{
    disabled?: boolean;
}> = observer(({ disabled = false }) => {
    const [theme] = useTheme();
    const navigation =
        useNavigation<SmartVehicleDashboardScreenNavigationProp>();

    const container = useRootContainer();
    const vehicleStore = container.stores.vehicle;
    const vehicle = vehicleStore.associatedVehicle;

    if (!(vehicle instanceof SmartVehicle)) {
        return null;
    }

    const lightingStore = vehicle.lighting;
    const smartLightingGroup = lightingStore.smartGroup;
    const lightingIsActive = Boolean(smartLightingGroup?.isActive);

    const waterStore = vehicle.water;
    const toggleableWaterSystems = [
        ...waterStore.pumps,
        ...waterStore.rvcHeaters,
    ];

    const energyStore = vehicle.energy;

    const switches: SwitchData[] = [];

    switches.push(
        ...toggleableWaterSystems.map((system) => {
            const isOn = system.isOn;
            let status: string | undefined;

            if (system instanceof RvcWaterHeater) {
                // Custom status message for RVC water heaters
                status = system.isBusy ? "Busy" : isOn ? "On" : "Off";
            }

            const data: SwitchData = {
                key: `${system.metadata.componentType}-${system.instance}`,
                name: system.name,
                status,
                isOn,
                disabled,
                icon: (props) => (
                    <WaterSystemIcon metadata={system.metadata} {...props} />
                ),
                onPress: () => {
                    system.toggle(!isOn);
                },
                onLongPress: () => {
                    navigation.navigate("water");
                },
            };

            return data;
        })
    );

    switches.push({
        key: "lighting",
        name: "Interior Lights",
        isOn: lightingIsActive,
        disabled,
        icon: LightBulbIcon,
        iconFillColor: theme.color.yellow.default,
        onPress: () => {
            smartLightingGroup?.toggle(!lightingIsActive);
        },
        onLongPress: () => {
            navigation.navigate("lighting");
        },
    });

    const inverter = energyStore.inverter;

    if (inverter) {
        switches.push({
            key: "inverter",
            name: "Inverter",
            isOn: inverter.isOn ?? false,
            disabled,
            icon: InverterIcon,
            iconFillColor: theme.color.green.light,
            onPress: () => {
                inverter.toggle(!inverter.isOn);
            },
            onLongPress: () => {
                navigation.navigate("energy");
            },
        });
    }

    return (
        <ScrollView
            contentContainerStyle={{
                paddingHorizontal: 20,
            }}
            showsHorizontalScrollIndicator={false}
            horizontal={true}>
            <StackView
                spacing={10}
                style={{
                    flexDirection: "row",
                }}>
                {switches.map((s) => {
                    return <SystemSwitch {...s} />;
                })}
            </StackView>
        </ScrollView>
    );
});
