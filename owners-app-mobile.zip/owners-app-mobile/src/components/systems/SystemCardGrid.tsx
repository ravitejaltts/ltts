import { CommonActions } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import pluralize from "pluralize";
import React from "react";
import { GridView } from "..";
import { getSystemCardData } from "../../constants/SystemCardData";
import { useRootContainer } from "../../context";
import { useSmartVehicle } from "../../hooks";
import {
    AcFanSpeed,
    RefrigerationCompartmentType,
    ThermostatMode,
} from "../../models/domain/climate";
import { AwningMode } from "../../models/domain/movables";
import {
    PoweredSystemComponent,
    SystemType,
    isPoweredComponent,
} from "../../models/domain/system";
import { SystemCardType } from "../../models/ui";
import { SystemsNavigatorParamList } from "../../navigators/SystemsNavigator";
import { SystemsScreenProps } from "../../screens/systems";
import { StringUtils, TemperatureUtils } from "../../utils";
import { SystemCard } from "./SystemCard";

export const SystemCardGrid: React.FunctionComponent<SystemsScreenProps> =
    observer(({ navigation }) => {
        const container = useRootContainer();
        const smartVehicle = useSmartVehicle();

        if (!smartVehicle) {
            return null;
        }

        const { preferredTemperatureUnit } = container.stores.setting;

        const deviceStore = container.stores.device;
        const activeSubscription = deviceStore.activeSubscription;

        const isGridDisabled =
            smartVehicle.isCloudDeviceDisconnected ||
            smartVehicle.isCloudInactiveSub;

        const availableSystems =
            smartVehicle.componentTemplates.availableSystems;

        const lightingStore = smartVehicle.lighting;
        const climateStore = smartVehicle.climate;
        const waterStore = smartVehicle.water;
        const energyStore = smartVehicle.energy;
        const movableStore = smartVehicle.movable;
        const vehicleSystemStore = smartVehicle.vehicleSystem;
        const featuresStore = smartVehicle.features;

        const systemCards: { system: SystemCardType; itemCount?: number }[] =
            [];

        if (availableSystems) {
            if (
                availableSystems.includes(SystemType.Lighting) &&
                lightingStore.hasComponents
            ) {
                systemCards.push({
                    system: SystemCardType.Lighting,
                    itemCount: lightingStore.zones.length,
                });
            }
            if (
                availableSystems.includes(SystemType.Climate) &&
                climateStore.hasComponents
            ) {
                systemCards.push({
                    system: SystemCardType.Climate,
                });
            }

            if (
                availableSystems.includes(SystemType.Water) &&
                waterStore.hasComponents
            ) {
                systemCards.push({
                    system: SystemCardType.Water,
                    itemCount: waterStore.getComponents().length,
                });
            }
            if (
                availableSystems.includes(SystemType.Energy) &&
                energyStore.hasComponents
            ) {
                systemCards.push({
                    system: SystemCardType.Energy,
                });
            }
            if (
                availableSystems.includes(SystemType.Climate) &&
                climateStore.hasComponents &&
                climateStore.refrigerationCompartments.length
            ) {
                systemCards.push({
                    system: SystemCardType.Refrigeration,
                });
            }

            if (
                availableSystems.includes(SystemType.Movables) &&
                movableStore.hasComponents
            ) {
                if (movableStore.awning) {
                    systemCards.push({
                        system: SystemCardType.Awning,
                        itemCount: 1, // awning is hard-coded as a single component
                    });
                }

                if (movableStore.slideOuts.length) {
                    systemCards.push({
                        system: SystemCardType.SlideOut,
                        itemCount: movableStore.slideOuts.length,
                    });
                }
            }
            if (
                availableSystems.includes(SystemType.Vehicle) &&
                vehicleSystemStore.hasComponents
            ) {
                if (vehicleSystemStore.doorLocks.length) {
                    systemCards.push({
                        system: SystemCardType.DoorLock,
                        itemCount: vehicleSystemStore.doorLocks.length,
                    });
                }
            }

            if (
                availableSystems.includes(SystemType.Features) &&
                featuresStore.petMinder &&
                Boolean(activeSubscription)
            ) {
                systemCards.push({ system: SystemCardType.Pet });
            }
        }

        const onSystemPress = (screen: keyof SystemsNavigatorParamList) => {
            navigation.dispatch(
                CommonActions.navigate({
                    name: screen,
                })
            );
        };

        const getSystemStatus = (systemCardType: SystemCardType) => {
            switch (systemCardType) {
                case SystemCardType.Lighting:
                    return lightingStore.statusText;
                case SystemCardType.Refrigeration:
                    let status = "";
                    let divider = "";

                    const fridge = climateStore.refrigerationCompartments.find(
                        (rf) => rf.type === RefrigerationCompartmentType.Fridge
                    );

                    if (fridge) {
                        status += TemperatureUtils.convertAndFormat(
                            fridge.temp,
                            preferredTemperatureUnit
                        );
                        divider = " | ";
                    }

                    const freezer = climateStore.refrigerationCompartments.find(
                        (rf) => rf.type === RefrigerationCompartmentType.Freezer
                    );

                    if (freezer) {
                        status += divider;
                        status += TemperatureUtils.convertAndFormat(
                            freezer.temp,
                            preferredTemperatureUnit
                        );
                    }

                    return status;
                case SystemCardType.Climate:
                    let statusText = "";

                    if (climateStore.thermostat?.isOn) {
                        const heatTempText = TemperatureUtils.convertAndFormat(
                            climateStore.thermostat.heatTemp,
                            preferredTemperatureUnit
                        );
                        const coolTempText = TemperatureUtils.convertAndFormat(
                            climateStore.thermostat.coolTemp,
                            preferredTemperatureUnit
                        );

                        if (
                            climateStore.thermostat.currentMode ===
                            ThermostatMode.Heat
                        ) {
                            statusText = `Heating to ${heatTempText}`;
                        } else if (
                            climateStore.thermostat.currentMode ===
                            ThermostatMode.Cool
                        ) {
                            statusText = `Cooling to ${coolTempText}`;
                        } else {
                            switch (climateStore.thermostat.desiredMode) {
                                case ThermostatMode.Auto:
                                    statusText = `Set to ${heatTempText}-${coolTempText}`;
                                    break;
                                case ThermostatMode.Cool:
                                    statusText = `Set to ${coolTempText}`;
                                    break;
                                case ThermostatMode.Heat:
                                    statusText = `Set to ${heatTempText}`;
                                    break;
                                case ThermostatMode.Fan:
                                    switch (
                                        climateStore.airConditioner
                                            ?.desiredFanSpeed
                                    ) {
                                        case AcFanSpeed.Auto:
                                            statusText = "Fan on Auto";
                                            break;
                                        case AcFanSpeed.Low:
                                            statusText = "Fan on Low";
                                            break;
                                        case AcFanSpeed.High:
                                            statusText = "Fan on High";
                                            break;
                                    }
                                    break;
                                default:
                                    statusText = "On";
                                    break;
                            }
                        }
                    } else {
                        statusText = "Off";
                    }

                    return statusText;
                case SystemCardType.Water:
                    const poweredWaterComponents = waterStore
                        .getComponents()
                        .filter((x) =>
                            isPoweredComponent(x)
                        ) as unknown as PoweredSystemComponent[];
                    const poweredOnWaterComponents =
                        poweredWaterComponents.filter((x) => x.isOn);

                    const numPoweredWaterComponents =
                        poweredWaterComponents.length;
                    const numPoweredOnWaterComponents =
                        poweredOnWaterComponents.length;

                    if (numPoweredOnWaterComponents == 0) {
                        return "All Systems Off";
                    }

                    if (
                        numPoweredOnWaterComponents ===
                        numPoweredWaterComponents
                    ) {
                        return "All Systems On";
                    }

                    return `${numPoweredOnWaterComponents} ${pluralize(
                        "Systems",
                        numPoweredOnWaterComponents
                    )} On`;
                case SystemCardType.Energy:
                    return `${energyStore.totalSourceWatts.toLocaleString()}W`;
                case SystemCardType.Pet:
                    return "";
                case SystemCardType.Generator:
                    return energyStore.generator?.modeText ?? "";
                case SystemCardType.Awning:
                    const awning = movableStore.awning;
                    if (awning) {
                        switch (movableStore.awning?.mode) {
                            case AwningMode.Retracted:
                                return "Retracted";
                            default:
                                const percentExtended =
                                    StringUtils.toValueString(
                                        awning.percentExtended
                                    );
                                return `${percentExtended}% Extended`;
                        }
                    } else {
                        return "";
                    }
                case SystemCardType.SlideOut:
                    return "";
                default:
                    return "";
            }
        };

        return (
            <GridView
                columns={2}
                rowSpacing={12}
                columnSpacing={12}
                style={{
                    padding: 20,
                }}>
                {systemCards.map(({ system, itemCount }) => {
                    const {
                        name,
                        icon,
                        iconFillColor,
                        iconStrokeColor,
                        screen,
                    } = getSystemCardData(system);

                    const status = getSystemStatus(system);

                    return (
                        <SystemCard
                            key={system.toString()}
                            name={pluralize(name, itemCount ?? 1)}
                            status={status}
                            onPress={() => onSystemPress(screen)}
                            icon={icon}
                            iconFillColor={iconFillColor}
                            iconStrokeColor={iconStrokeColor}
                            disabled={isGridDisabled}
                        />
                    );
                })}
            </GridView>
        );
    });
