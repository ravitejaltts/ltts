import React from "react";
import { ColorValue, Text, TouchableHighlight, View } from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";

const CARD_HEIGHT = 129;

export type SystemCardProps = {
    name: string;
    status?: string;
    icon: React.FunctionComponent<SvgProps>;
    iconFillColor: ColorValue;
    iconStrokeColor?: ColorValue;
    onPress?: () => void;
    disabled?: boolean;
};

export const SystemCard: React.FunctionComponent<SystemCardProps> = ({
    name,
    status,
    icon,
    iconFillColor,
    iconStrokeColor,
    onPress,
    disabled = false,
}) => {
    const [theme] = useTheme();

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={onPress}
            disabled={disabled}
            style={{
                padding: 12,
                height: CARD_HEIGHT,
                borderWidth: 1,
                borderRadius: 8,
                borderColor: theme.color.dividers.gray1,
                backgroundColor: theme.color.background.elevation3,
            }}>
            <View
                style={{
                    flex: 1,
                }}>
                <View
                    style={{
                        flex: 1,
                    }}>
                    {icon({
                        width: 24,
                        height: 24,
                        fill: disabled
                            ? theme.color.components.gray1
                            : iconFillColor,
                        stroke: disabled
                            ? theme.color.components.gray1
                            : iconStrokeColor,
                    })}
                </View>

                <View>
                    <Text
                        numberOfLines={2}
                        ellipsizeMode="tail"
                        style={[
                            TextStyles.listItemLarge,
                            {
                                color: disabled
                                    ? theme.color.text.deemphasized
                                    : theme.color.text.main,
                                marginTop: 10,
                                marginBottom: 2,
                            },
                        ]}>
                        {name}
                    </Text>

                    <Text
                        numberOfLines={1}
                        ellipsizeMode="tail"
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {status ?? ""}
                    </Text>
                </View>
            </View>
        </TouchableHighlight>
    );
};
