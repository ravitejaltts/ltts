import React from "react";
import { ColorValue, StyleSheet, View, ViewProps } from "react-native";

interface StackViewProps extends ViewProps {
    spacing: number;
    spacerColor?: ColorValue;
    children: React.ReactNode;
}

const StackView: React.FunctionComponent<StackViewProps> = ({
    children,
    spacing,
    spacerColor,
    style,
    onLayout,
}) => {
    const newChildren = React.Children.toArray(children);

    let isHorizontal = false;

    if (style) {
        const styleSheet = StyleSheet.flatten(style);
        isHorizontal =
            styleSheet.flexDirection === "row" ||
            styleSheet.flexDirection === "row-reverse";
    }

    for (let i = 1; i < newChildren.length; i += 2) {
        // Insert a spacer view between each child
        newChildren.splice(
            i,
            0,
            <View
                key={i}
                style={
                    isHorizontal
                        ? { width: spacing, backgroundColor: spacerColor }
                        : { height: spacing, backgroundColor: spacerColor }
                }
            />
        );
    }

    return (
        <View style={style} onLayout={onLayout}>
            {newChildren}
        </View>
    );
};

export default StackView;
