import { observer } from "mobx-react-lite";
import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { ElectricalServicesIcon } from "../../../assets/icons";
import { ShoreEnergySource } from "../../../models/domain/energy/sources";
import { EnergySourceView } from "./EnergySourceView";

export const ShoreSourceCard: React.FunctionComponent<{
    source: ShoreEnergySource;
    hasBorder?: boolean;
    disabled?: boolean;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(
    ({ source, hasBorder = false, disabled = false, onPress, style }) => {
        const watts = source.watts;
        const isActive = Boolean(source.isActive);
        const hasError = source.hasError;
        const hasWarning = source.hasWarning;

        return (
            <EnergySourceView
                name="SHORE POWER"
                status={isActive ? "Active" : "Inactive"}
                icon={ElectricalServicesIcon}
                isActive={isActive}
                error={hasError}
                warning={hasWarning}
                watts={watts}
                hasBorder={hasBorder}
                disabled={disabled}
                onPress={onPress}
                style={[
                    {
                        borderRadius: 8,
                    },
                    style,
                ]}
            />
        );
    }
);
