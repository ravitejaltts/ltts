import { observer } from "mobx-react-lite";
import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { VanIcon } from "../../../assets/icons";
import { ProEnergySource } from "../../../models/domain/energy/sources";
import { EnergySourceView } from "./EnergySourceView";

export const ProSourceCard: React.FunctionComponent<{
    source: ProEnergySource;
    hasBorder?: boolean;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(({ source, hasBorder = false, onPress, style }) => {
    const isActive = Boolean(source.isActive) && source.isOn;
    const hasError = source.hasError;
    const hasWarning = source.hasWarning;
    const watts = source.watts;

    return (
        <EnergySourceView
            name="PRO"
            status={isActive ? "Active" : "Inactive"}
            icon={VanIcon}
            isActive={isActive}
            error={hasError}
            warning={hasWarning}
            watts={watts}
            hasBorder={hasBorder}
            onPress={onPress}
            style={[
                {
                    borderRadius: 8,
                },
                style,
            ]}
        />
    );
});
