import { observer } from "mobx-react-lite";
import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { SolarIcon } from "../../../assets/icons";
import { SolarEnergySource } from "../../../models/domain/energy/sources";
import { EnergySourceView } from "./EnergySourceView";

export const SolarSourceCard: React.FunctionComponent<{
    source: SolarEnergySource;
    hasBorder?: boolean;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(({ source, hasBorder = false, onPress, style }) => {
    const isActive = Boolean(source.isActive);
    const hasError = source.hasError;
    const hasWarning = source.hasWarning;
    const watts = source.watts;

    return (
        <EnergySourceView
            name="SOLAR"
            status={isActive ? "Active" : "Inactive"}
            icon={SolarIcon}
            isActive={isActive}
            error={hasError}
            warning={hasWarning}
            watts={watts}
            hasBorder={hasBorder}
            onPress={onPress}
            style={[
                {
                    borderRadius: 8,
                },
                style,
            ]}
        />
    );
});
