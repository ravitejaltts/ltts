import React from "react";
import {
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { StackView } from "../..";
import {
    ChevronRightIcon,
    ErrorFillIcon,
    WarningFillIcon,
} from "../../../assets/icons";
import { useTheme } from "../../../context";
import { TextStyles } from "../../../styles";
import { StringUtils } from "../../../utils";
import { AnimatedEllipsisText } from "../../animated";

export const EnergySourceView: React.FunctionComponent<{
    name: string;
    status?: string;
    icon: React.FunctionComponent<SvgProps>;
    isActive: boolean;
    watts?: number | null;
    warning?: boolean;
    error?: boolean;
    rightView?: React.ReactNode;
    hasBorder?: boolean;
    disabled?: boolean;
    style?: StyleProp<ViewStyle>;
    onPress?: () => void;
}> = ({
    name,
    status,
    icon,
    isActive,
    watts,
    warning = false,
    error = false,
    rightView,
    hasBorder = false,
    disabled = false,
    style,
    onPress,
}) => {
    const [theme] = useTheme();

    let powerText: string;
    let unitText: string;

    if (error) {
        powerText = "Error";
        unitText = "";
    } else if (isActive) {
        powerText = StringUtils.toValueString(watts);
        unitText = "W";
    } else {
        powerText = "0";
        unitText = "W";
    }

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            disabled={disabled}
            onPress={onPress}
            style={[
                {
                    backgroundColor: theme.color.background.elevation3,
                },
                hasBorder
                    ? {
                          borderRadius: 8,
                          borderWidth: 1,
                          borderColor: theme.color.dividers.gray1,
                      }
                    : undefined,
                style,
            ]}>
            {/* Root Element */}
            <View
                style={{
                    flex: 1,
                    flexDirection: "row",
                    padding: 12,
                }}>
                {/* Name, Power, Status (Left Column) */}
                <StackView
                    spacing={16}
                    style={{
                        flex: rightView ? 0 : 1,
                    }}>
                    {/* Icon & Name */}
                    <StackView
                        spacing={8}
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                        }}>
                        <View
                            style={{
                                width: 24,
                                height: 24,
                                borderRadius: 4,
                                justifyContent: "center",
                                alignItems: "center",
                                backgroundColor: isActive
                                    ? theme.color.background.elevation2
                                    : theme.color.background.elevation1,
                            }}>
                            {error ? (
                                <WarningFillIcon
                                    width={18}
                                    height={18}
                                    fill={theme.color.error}
                                />
                            ) : warning ? (
                                <ErrorFillIcon
                                    width={18}
                                    height={18}
                                    fill={theme.color.yellow.warning}
                                />
                            ) : (
                                icon({
                                    width: 18,
                                    height: 18,
                                    fill:
                                        isActive && !disabled
                                            ? theme.color.green.light
                                            : theme.color.components.gray2,
                                })
                            )}
                        </View>

                        <Text
                            ellipsizeMode="tail"
                            style={[
                                TextStyles.contentEyebrow,
                                {
                                    flex: rightView ? 0 : 1,
                                    color:
                                        isActive && !disabled
                                            ? theme.color.text.main
                                            : theme.color.text.deemphasized,
                                },
                            ]}>
                            {name}
                        </Text>
                    </StackView>

                    <StackView spacing={8}>
                        {/* Power */}
                        <Text>
                            <Text
                                style={[
                                    TextStyles.sectionBreak,
                                    {
                                        color:
                                            isActive && !disabled
                                                ? theme.color.text.main
                                                : theme.color.text.deemphasized,
                                    },
                                ]}>
                                {powerText}
                            </Text>

                            <Text
                                style={[
                                    TextStyles.listItemSmall,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {" "}
                                {unitText}
                            </Text>
                        </Text>

                        {/* Status */}
                        {Boolean(status) && (
                            <View
                                style={{
                                    flexDirection: "row",
                                }}>
                                <Text
                                    style={[
                                        TextStyles.subheading,
                                        {
                                            color: theme.color.text
                                                .deemphasized,
                                        },
                                    ]}>
                                    {status}
                                </Text>
                                <AnimatedEllipsisText
                                    animating={status === "Starting"}
                                    style={[
                                        TextStyles.subheading,
                                        {
                                            color: theme.color.text
                                                .deemphasized,
                                        },
                                    ]}
                                />
                            </View>
                        )}
                    </StackView>
                </StackView>

                {/* Right View */}
                {rightView && (
                    <View
                        style={{
                            flex: 1,
                        }}>
                        {rightView}
                    </View>
                )}

                {/* Right Chevron */}
                {onPress && (
                    <ChevronRightIcon
                        width={24}
                        height={24}
                        fill={theme.color.components.gray2}
                    />
                )}
            </View>
        </TouchableHighlight>
    );
};
