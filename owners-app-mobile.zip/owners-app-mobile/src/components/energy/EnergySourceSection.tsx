import React from "react";
import { Text, View } from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import {
    ErrorFillIcon,
    LightningIcon,
    LightningStrikethroughIcon,
    WarningFillIcon,
} from "../../assets/icons";

type EnergySourceSectionProps = React.PropsWithChildren<{
    title: string;
    subtitle?: string;
    icon?: React.FunctionComponent<SvgProps>;
    isCharging?: boolean;
    error?: boolean;
    alert?: boolean;
}>;

const EnergySourceSection: React.FunctionComponent<
    EnergySourceSectionProps
> = ({ title, subtitle, icon, isCharging = false, error, alert, children }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={12}
            style={{
                paddingTop: 12,
                paddingBottom: 16,
                paddingHorizontal: 16,
                borderRadius: 8,
                backgroundColor: theme.color.background.elevation2,
            }}>
            <StackView
                spacing={4}
                style={{
                    flexDirection: "row",
                }}>
                {/* Left Column */}
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                    }}>
                    <View
                        style={{
                            flexDirection: "row",
                        }}>
                        {icon && (
                            <View style={{ marginRight: 4 }}>
                                {icon({
                                    fill: theme.color.text.deemphasized,
                                    width: 18,
                                    height: 18,
                                })}
                            </View>
                        )}
                        <Text
                            style={[
                                TextStyles.contentEyebrow,
                                { color: theme.color.text.deemphasized },
                            ]}>
                            {title}
                        </Text>
                    </View>
                    {Boolean(subtitle) && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                { color: theme.color.text.deemphasized },
                            ]}>
                            {subtitle}
                        </Text>
                    )}
                </StackView>

                {/* Right Column */}
                <View
                    style={{
                        width: 28,
                        height: 28,
                        borderRadius: 4,
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor:
                            error || alert || isCharging
                                ? theme.color.background.elevation3
                                : theme.color.background.elevation1,
                    }}>
                    {error ? (
                        <WarningFillIcon fill={theme.color.error} />
                    ) : alert ? (
                        <ErrorFillIcon fill={theme.color.yellow.warning} />
                    ) : isCharging ? (
                        <LightningIcon fill={theme.color.green.light} />
                    ) : (
                        <LightningStrikethroughIcon
                            fill={theme.color.dividers.gray2}
                        />
                    )}
                </View>
            </StackView>
            {children}
        </StackView>
    );
};

export default EnergySourceSection;
