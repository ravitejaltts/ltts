import { observer } from "mobx-react-lite";
import React from "react";
import { ColorValue, StyleProp, Text, View, ViewStyle } from "react-native";
import {
    BatteryAlertIcon,
    BatteryChargingIcon,
    BatteryIcon,
} from "../../../assets/icons";
import { useTheme } from "../../../context";
import { BatteryManager } from "../../../models/domain/energy";
import { TextStyles } from "../../../styles";
import { DateUtil, MathUtils } from "../../../utils";
import StackView from "../../StackView";
import { EnergySourceView } from "../source";
import { SvgProps } from "react-native-svg";

export const BatterySourceCard: React.FunctionComponent<{
    batteryManager: BatteryManager;
    hasBorder?: boolean;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(({ batteryManager, hasBorder = false, onPress, style }) => {
    const [theme] = useTheme();

    const watts = batteryManager.powerWatts;
    const isCharging = batteryManager.isCharging;
    const charge = batteryManager.charge;

    let chargeStatusText: string;

    if (charge === 1) {
        chargeStatusText = "Charged";
    } else if (isCharging) {
        chargeStatusText = "Charging";
    } else {
        chargeStatusText = "Discharging";
    }

    let icon: React.FunctionComponent<SvgProps>;

    if (isCharging) {
        icon = BatteryChargingIcon;
    } else if (
        MathUtils.isNumber(charge) &&
        charge < BatteryManager.LowCharge
    ) {
        icon = BatteryAlertIcon;
    } else {
        icon = BatteryIcon;
    }

    let iconColor: ColorValue;

    if (isCharging) {
        iconColor = theme.color.green.light;
    } else if (MathUtils.isNumber(charge)) {
        if (charge < BatteryManager.LowCharge) {
            iconColor = theme.color.error;
        } else if (charge < BatteryManager.MediumCharge) {
            iconColor = theme.color.yellow.warning;
        } else {
            iconColor = theme.color.green.light;
        }
    } else {
        iconColor = theme.color.components.gray2;
    }

    const timeTillMinutes = batteryManager.timeTillMinutes;

    let rightView: React.ReactNode;

    if (MathUtils.isNumber(timeTillMinutes)) {
        const timeTillMillis = DateUtil.minutesToMillis(timeTillMinutes);
        const duration = DateUtil.getDuration(timeTillMillis, {
            days: true,
            hours: true,
            minutes: true,
        });

        const daysRemaining = duration.days;
        const hoursRemaining = duration.hours;
        const minutesRemaining = duration.minutes;

        const remainingViews: React.ReactNode[] = [];

        if (daysRemaining) {
            let daysText: string;
            let daysUnit: string;

            if (charge === 1) {
                daysText = "--";
                daysUnit = " days";
            } else {
                daysText = daysRemaining.toString().padStart(2, "0");
                daysUnit = daysRemaining === 1 ? " day" : " days";
            }

            remainingViews.push(
                <Text key={"DAYS_REMAINING"}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {daysText}
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {daysUnit}
                    </Text>
                </Text>
            );
        }

        if (hoursRemaining) {
            let hoursText: string;
            let hoursUnit: string;

            if (charge === 1) {
                hoursText = "--";
                hoursUnit = " hours";
            } else {
                hoursText = hoursRemaining.toString().padStart(2, "0");
                hoursUnit = hoursRemaining === 1 ? " hour" : " hours";
            }

            remainingViews.push(
                <Text key={"HOURS_REMAINING"}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {hoursText}
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {hoursUnit}
                    </Text>
                </Text>
            );
        }

        if (minutesRemaining) {
            let minsText: string;
            let minsUnit: string;

            if (charge === 1) {
                minsText = "--";
                minsUnit = " mins";
            } else {
                minsText = minutesRemaining.toString().padStart(2, "0");
                minsUnit = minutesRemaining === 1 ? " min" : " mins";
            }

            remainingViews.push(
                <Text key={"MINUTES_REMAINING"}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {minsText}
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {minsUnit}
                    </Text>
                </Text>
            );
        }

        if (remainingViews.length) {
            rightView = (
                <View
                    style={{
                        flex: 1,
                        justifyContent: "flex-end",
                        alignItems: "flex-end",
                    }}>
                    <StackView spacing={4}>
                        <StackView
                            spacing={8}
                            style={{
                                flexDirection: "row",
                                alignItems: "center",
                            }}>
                            {remainingViews}
                        </StackView>

                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            Remaining
                        </Text>
                    </StackView>
                </View>
            );
        }
    }

    return (
        <EnergySourceView
            name="BATTERY"
            status={chargeStatusText}
            icon={(props) =>
                icon({
                    ...props,
                    fill: iconColor,
                })
            }
            isActive={true}
            watts={watts}
            hasBorder={hasBorder}
            rightView={rightView}
            onPress={onPress}
            style={[
                {
                    borderRadius: 8,
                },
                style,
            ]}
        />
    );
});
