import React from "react";
import { ColorValue, View } from "react-native";
import Svg, { Defs, G, Mask, Path, Use } from "react-native-svg";
import { useTheme } from "../../../context";
import { LightningIcon } from "../../../assets/icons";

type BatteryViewProps = {
    width: number;
    height: number;
    isCharging: boolean;
    charge: number;
    disabled?: boolean;
};

export const BatteryView: React.FunctionComponent<BatteryViewProps> = ({
    width,
    height,
    isCharging,
    charge,
    disabled = false,
}) => {
    const [theme] = useTheme();

    const viewBoxWidth = 84;
    const viewBoxHeight = 124;
    const innerBackgroundPathHeight = 100;
    const lightningIconSize = 39;

    const scaleX = width / viewBoxWidth;
    const scaleY = height / viewBoxHeight;
    const scaledLightningIconSize =
        Math.min(scaleX, scaleY) * lightningIconSize;

    const chargePathY =
        innerBackgroundPathHeight - charge * innerBackgroundPathHeight;

    let fillColor: ColorValue;

    if (disabled) {
        fillColor = theme.color.components.gray1;
    } else if (charge < 0.25) {
        fillColor = theme.color.orange.dark;
    } else if (charge < 0.5) {
        fillColor = theme.color.yellow.default;
    } else {
        fillColor = theme.color.green.light;
    }

    return (
        <View
            style={{
                width: width,
                height: height,
                justifyContent: "center",
                alignItems: "center",
            }}>
            <Svg
                width={width}
                height={height}
                viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`}
                style={{
                    position: "absolute",
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                }}>
                <Defs>
                    <Path
                        id="inner-background"
                        d="M0,8 C0,3.5817 3.58172,0 8,0 L65,0 C69.4183,0 73,3.5817 73,8 L73,92 C73,96.418 69.4183,100 65,100 L8,100 C3.58172,100 0,96.418 0,92 L0,8 Z"
                    />
                </Defs>

                {/* Background */}
                <Path
                    id="background"
                    d="M72.044,13.6 L58.183,13.6 L58.183,8.3 C58.183,3.735 54.448,0 49.883,0 L33.283,0 C28.718,0 24.983,3.735 24.983,8.3 L24.983,13.6 L11.122,13.6 C5.063,13.6 0.0829964,18.58 0.0829964,24.639 L0,112.878 C0,119.02 4.98,124 11.122,124 L71.878,124 C78.02,124 83,119.02 83,112.961 L83.083,24.639 C83.083,18.58 78.103,13.6 72.044,13.6 Z"
                    fill={theme.color.background.elevation2}
                />

                <G transform="translate(5, 19)">
                    <Mask id="mask" fill="white">
                        <Use href="#inner-background" />
                    </Mask>

                    {/* Inner Background */}
                    <Use
                        fill={theme.color.dividers.gray2}
                        fill-rule="nonzero"
                        opacity="0.5"
                        href="#inner-background"
                    />

                    {/* Charge Path */}
                    <Path
                        d={`M0,${chargePathY} L73,${chargePathY} L73,94.7733333 C73,97.65976 69.4183,100 65,100 L8,100 C3.58172,100 0,97.65976 0,94.7733333 L0,${chargePathY} Z`}
                        fill={fillColor}
                        fill-rule="nonzero"
                        mask="url(#mask)"
                    />
                </G>
            </Svg>

            {isCharging && (
                <LightningIcon
                    width={scaledLightningIconSize}
                    height={scaledLightningIconSize}
                    fill={theme.color.white}
                />
            )}
        </View>
    );
};
