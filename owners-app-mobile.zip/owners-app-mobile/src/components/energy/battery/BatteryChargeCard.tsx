import { observer } from "mobx-react-lite";
import React, { useState } from "react";
import { ColorValue, StyleProp, Text, View, ViewStyle } from "react-native";
import { Line, Svg } from "react-native-svg";
import { LeftTriangleIcon } from "../../../assets/icons";
import { useTheme } from "../../../context";
import { BatteryManager } from "../../../models/domain/energy";
import { TextStyles } from "../../../styles";
import { DateUtil, MathUtils, StringUtils } from "../../../utils";
import StackView from "../../StackView";
import { BatteryView } from "./BatteryView";

const BATTERY_WIDTH = 84;
const BATTERY_HEIGHT = 124;

// "Bump" on top of battery (above fill)
const BATTERY_PADDING_TOP = 19;

// Space below fill
const BATTERY_PADDING_BOTTOM = 5;

// Height of the battery fill
const BATTERY_FILL_HEIGHT =
    BATTERY_HEIGHT - BATTERY_PADDING_TOP - BATTERY_PADDING_BOTTOM;

const TRIANGLE_SIZE = 14;
const TEXT_HEIGHT = 48;

// TODO: Use real value when available
const DEBUG_MIN_CHARGE = 0.1;

export const BatteryChargeCard: React.FunctionComponent<{
    batteryManager: BatteryManager;
    style: StyleProp<ViewStyle>;
}> = observer(({ batteryManager, style }) => {
    const [theme] = useTheme();
    const [contentWidth, setContentWidth] = useState(1);

    const isCharging = batteryManager.isCharging;
    const charge = batteryManager.charge ?? 0;

    let chargeStateString = "Error";

    if (charge === 1) {
        chargeStateString = "Charged";
    } else {
        chargeStateString = isCharging ? "Charging" : "Discharging";
    }

    const chargePercentageString = StringUtils.toPercentageString(charge);
    const timeTillMinutes = batteryManager.timeTillMinutes;

    let daysRemaining = 0;
    let hoursRemaining = 0;
    let minutesRemaining = 0;

    if (MathUtils.isNumber(timeTillMinutes)) {
        const timeTillMillis = DateUtil.minutesToMillis(timeTillMinutes);
        const duration = DateUtil.getDuration(timeTillMillis, {
            days: true,
            hours: true,
            minutes: true,
        });

        daysRemaining = duration.days;
        hoursRemaining = duration.hours;
        minutesRemaining = duration.minutes;
    }

    const chargeOffset =
        BATTERY_PADDING_TOP + // Top padding
        (1 - charge) * // Distance from top is inverse of fill level
            BATTERY_FILL_HEIGHT; // The inner background height

    const chargeLineOffset =
        BATTERY_PADDING_TOP + (1 - DEBUG_MIN_CHARGE) * BATTERY_FILL_HEIGHT;

    // Center on the triangle point
    const triangleOffset = chargeOffset - 0.5 * TRIANGLE_SIZE;

    // Keep the text above the charge line
    const maxTextOffset = BATTERY_HEIGHT - TEXT_HEIGHT;

    // Center on text height
    let textOffset = chargeOffset - 0.5 * TEXT_HEIGHT;

    // Clamp between top of battery and above charge line
    textOffset = MathUtils.clamp(textOffset, 0, maxTextOffset);

    let triangleFillColor: ColorValue;

    if (charge < BatteryManager.LowCharge) {
        triangleFillColor = theme.color.orange.dark;
    } else if (charge < BatteryManager.MediumCharge) {
        triangleFillColor = theme.color.yellow.default;
    } else {
        triangleFillColor = theme.color.green.light;
    }

    return (
        <View
            style={[
                style,
                {
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    backgroundColor: theme.color.background.elevation3,
                },
            ]}>
            {/* Top Section */}
            <StackView
                spacing={8}
                style={{
                    paddingHorizontal: 20,
                    paddingTop: 16,
                    paddingBottom: 8,
                }}>
                {/* Battery and Percent Charged */}
                <View
                    onLayout={(e) => {
                        setContentWidth(e.nativeEvent.layout.width);
                    }}
                    style={{
                        flexDirection: "row",
                    }}>
                    {/* Dynamic Battery Icon */}
                    <BatteryView
                        width={BATTERY_WIDTH}
                        height={BATTERY_HEIGHT}
                        isCharging={isCharging ?? false}
                        charge={charge}
                    />

                    {/* Min Line */}
                    <Svg
                        width={BATTERY_WIDTH}
                        height={BATTERY_HEIGHT}
                        style={{
                            position: "absolute",
                        }}
                        viewBox={`0 0 ${BATTERY_WIDTH} ${BATTERY_HEIGHT}`}>
                        <Line
                            x1={0}
                            y1={chargeLineOffset}
                            x2={contentWidth}
                            y2={chargeLineOffset}
                            stroke={theme.color.dividers.gray2}
                            strokeWidth={1}
                            strokeDasharray={[10, 10]}
                        />
                    </Svg>

                    {/* Triangle & Charge Text */}
                    <View
                        style={{
                            flex: 1,
                        }}>
                        {/* Triangle */}
                        <LeftTriangleIcon
                            width={TRIANGLE_SIZE}
                            height={TRIANGLE_SIZE}
                            fill={triangleFillColor.toString()}
                            style={{
                                position: "absolute",
                                top: triangleOffset,
                            }}
                        />

                        {/* Charge Text */}
                        <StackView
                            spacing={2}
                            style={{
                                justifyContent: "center",
                                position: "absolute",
                                height: TEXT_HEIGHT,
                                left: TRIANGLE_SIZE + 8,
                                top: textOffset,
                            }}>
                            <Text
                                style={[
                                    TextStyles.subheading,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {chargeStateString}
                            </Text>

                            <Text
                                style={[
                                    TextStyles.listItemLarge,
                                    {
                                        color: theme.color.text.main,
                                    },
                                ]}>
                                {chargePercentageString} Charged
                            </Text>
                        </StackView>
                    </View>
                </View>

                {/* Min Charge Text */}
                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.text.deemphasized,
                        },
                    ]}>
                    {`Minimum Charge: ${StringUtils.toPercentageString(
                        DEBUG_MIN_CHARGE
                    )}`}
                </Text>
            </StackView>

            {/* Bottom Section */}
            <StackView
                spacing={16}
                style={{
                    flexDirection: "row",
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    borderBottomLeftRadius: 8,
                    borderBottomRightRadius: 8,
                    backgroundColor: theme.color.background.elevation2,
                }}>
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    Remaining:
                </Text>

                {Boolean(daysRemaining) && (
                    <Text>
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {charge === 1 ? "--" : daysRemaining}
                        </Text>

                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {daysRemaining === 1 && charge !== 1
                                ? " day"
                                : " days"}
                        </Text>
                    </Text>
                )}

                {Boolean(hoursRemaining) && (
                    <Text>
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {charge === 1 ? "--" : hoursRemaining}
                        </Text>

                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {hoursRemaining === 1 && charge !== 1
                                ? " hour"
                                : " hours"}
                        </Text>
                    </Text>
                )}

                {Boolean(minutesRemaining) && (
                    <Text>
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {charge === 1 ? "--" : minutesRemaining}
                        </Text>

                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {minutesRemaining === 1 && charge !== 1
                                ? " min"
                                : " mins"}
                        </Text>
                    </Text>
                )}
            </StackView>
        </View>
    );
});
