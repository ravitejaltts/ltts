import { observer } from "mobx-react-lite";
import React from "react";
import {
    ColorValue,
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import {
    BatteryAlertIcon,
    BatteryChargingIcon,
    BatteryIcon,
} from "../../../assets/icons";
import { useTheme } from "../../../context";
import { BatteryManager } from "../../../models/domain/energy";
import { TextStyles } from "../../../styles";
import { MathUtils, StringUtils } from "../../../utils";
import StackView from "../../StackView";
import { SvgProps } from "react-native-svg";

export const CompactBatteryChargeCard: React.FunctionComponent<{
    batteryManager: BatteryManager;
    hasBorder?: boolean;
    disabled?: boolean;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(
    ({ batteryManager, hasBorder, disabled = false, onPress, style }) => {
        const [theme] = useTheme();

        const isCharging = batteryManager.isCharging;
        const charge = batteryManager.charge;
        let chargeStatusText: string;

        if (charge === 1) {
            chargeStatusText = "Charged";
        } else if (isCharging) {
            chargeStatusText = "Charging";
        } else {
            chargeStatusText = "Discharging";
        }

        let icon: React.FunctionComponent<SvgProps>;

        if (isCharging) {
            icon = BatteryChargingIcon;
        } else if (
            MathUtils.isNumber(charge) &&
            charge < BatteryManager.LowCharge
        ) {
            icon = BatteryAlertIcon;
        } else {
            icon = BatteryIcon;
        }

        let iconColor: ColorValue;

        if (disabled) {
            iconColor = theme.color.components.gray2;
        } else if (isCharging) {
            iconColor = theme.color.green.light;
        } else if (MathUtils.isNumber(charge)) {
            if (charge < BatteryManager.LowCharge) {
                iconColor = theme.color.error;
            } else if (charge < BatteryManager.MediumCharge) {
                iconColor = theme.color.yellow.warning;
            } else {
                iconColor = theme.color.green.light;
            }
        } else {
            iconColor = theme.color.components.gray2;
        }

        return (
            <TouchableHighlight
                underlayColor={theme.color.background.elevation1}
                onPress={onPress}
                style={[
                    {
                        backgroundColor: theme.color.background.elevation3,
                        borderRadius: 8,
                    },
                    hasBorder
                        ? {
                              borderWidth: 1,
                              borderColor: theme.color.dividers.gray1,
                          }
                        : undefined,
                    style,
                ]}>
                {/* Root View */}
                <StackView
                    spacing={16}
                    style={{
                        flex: 1,
                        padding: 12,
                    }}>
                    {/* Icon & Name */}
                    <StackView
                        spacing={8}
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                        }}>
                        <View
                            style={{
                                width: 24,
                                height: 24,
                                borderRadius: 4,
                                justifyContent: "center",
                                alignItems: "center",
                                backgroundColor:
                                    theme.color.background.elevation2,
                            }}>
                            {icon({
                                width: 18,
                                height: 18,
                                fill: iconColor,
                            })}
                        </View>

                        <Text
                            ellipsizeMode="tail"
                            style={[
                                TextStyles.contentEyebrow,
                                {
                                    color:
                                        isCharging && !disabled
                                            ? theme.color.text.main
                                            : theme.color.text.deemphasized,
                                },
                            ]}>
                            BATTERY
                        </Text>
                    </StackView>

                    <StackView
                        spacing={8}
                        style={{
                            flex: 1,
                            justifyContent: "flex-end",
                        }}>
                        <Text
                            style={[
                                TextStyles.sectionBreak,
                                {
                                    color: disabled
                                        ? theme.color.text.deemphasized
                                        : theme.color.text.main,
                                },
                            ]}>
                            {StringUtils.toPercentageString(charge)}
                        </Text>
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {chargeStatusText}
                        </Text>
                    </StackView>
                </StackView>
            </TouchableHighlight>
        );
    }
);
