import { observer } from "mobx-react-lite";
import pluralize from "pluralize";
import React, { useState } from "react";
import {
    ScrollView,
    StyleProp,
    Text,
    TouchableOpacity,
    View,
    ViewStyle,
} from "react-native";
import { useRootContainer, useTheme } from "../../../context";
import { Battery, BatteryManager } from "../../../models/domain/energy";
import { SystemTemperatureUnit } from "../../../models/domain/system";
import { TextStyles } from "../../../styles";
import { MathUtils, StringUtils, TemperatureUtils } from "../../../utils";
import GridView from "../../GridView";
import StackView from "../../StackView";
import { EnergyStatCard, EnergyStatCardProps } from "../EnergyStatCard";

type PackStats = EnergyStatCardProps[];

export const BatteryStatSection: React.FunctionComponent<{
    batteryManager: BatteryManager;
    batteries: Battery[];
    style?: StyleProp<ViewStyle>;
}> = observer(({ batteryManager, batteries, style }) => {
    const [theme] = useTheme();
    const container = useRootContainer();
    const preferredTemperatureUnit =
        container.stores.setting.preferredTemperatureUnit;
    const tempUnitText =
        preferredTemperatureUnit == SystemTemperatureUnit.Fahrenheit
            ? "Fahrenheit"
            : "Celsius";

    const isCharging = batteryManager.isCharging;
    const charge = batteryManager.charge;
    const numBatteries = batteries.length;

    const tabNames: string[] = [
        "All Packs",
        ...batteries.map((_, index) => `Pack ${index + 1}`),
    ];

    const toValueString = (value: number | null | undefined) => {
        if (isCharging) {
            return StringUtils.toValueString(value);
        }

        return "0";
    };

    const [selectedIndex, setSelectedIndex] = useState(0);

    const packStats: PackStats = [];

    if (selectedIndex === 0) {
        // All Packs
        packStats.push(
            {
                name: "Power",
                value: toValueString(batteryManager.powerWatts),
                valueDescription: "Watts",
            },
            {
                name: "Voltage",
                value: toValueString(batteryManager.voltage),
                valueDescription: "Volts",
            },
            {
                name: "Current",
                value: toValueString(batteryManager.current),
                valueDescription: "Amps",
            },
            {
                name: "BMS Temp",
                value: `${toValueString(
                    TemperatureUtils.convertFromC(
                        batteryManager.temperature,
                        preferredTemperatureUnit
                    )
                )}˚`,
                valueDescription: tempUnitText,
            }
        );

        if (batteries.length === 1) {
            const battery = batteries[0];
            const capacity = battery.capacity;

            let totalConsumedText = "--";

            if (MathUtils.isNumber(charge) && MathUtils.isNumber(capacity)) {
                totalConsumedText = StringUtils.toValueString(
                    (1 - charge) * capacity
                );
            }

            packStats.push(
                {
                    name: "Battery Temp",
                    value: `${toValueString(
                        TemperatureUtils.convertFromC(
                            battery.temp,
                            preferredTemperatureUnit
                        )
                    )}˚`,
                    valueDescription: tempUnitText,
                },
                {
                    name: "Total Consumed",
                    value: totalConsumedText,
                    valueDescription: "Amp Hours",
                }
            );
        }
    } else if (selectedIndex <= numBatteries) {
        const battery = batteries[selectedIndex - 1];
        const capacity = battery.capacity;

        packStats.push(
            {
                name: "Temp",
                value: `${toValueString(
                    TemperatureUtils.convertFromC(
                        battery.temp,
                        preferredTemperatureUnit
                    )
                )}˚`,
                valueDescription: tempUnitText,
            },
            {
                name: "Capacity",
                value: StringUtils.toValueString(capacity),
                valueDescription: "Amp Hours",
            }
        );
    }

    return numBatteries === 1 ? (
        // Single battery pack
        // No tabs
        <GridView columns={2} rowSpacing={12} columnSpacing={12} style={style}>
            {packStats.map((s, index) => (
                <EnergyStatCard
                    key={index}
                    border={true}
                    disabled={!isCharging}
                    {...s}
                />
            ))}
        </GridView>
    ) : (
        // Multiple battery packs
        // Render tabs

        // Container View
        <View
            style={[
                {
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    backgroundColor: theme.color.background.elevation2,
                },
                style,
            ]}>
            {/* Tabs */}
            <View
                style={{
                    height: 56,
                }}>
                <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    style={{
                        borderBottomWidth: 1,
                        borderColor: theme.color.dividers.gray1,
                    }}
                    contentContainerStyle={{
                        flexDirection: "row",
                    }}>
                    {tabNames.map((text, index) => {
                        const isFocused = index === selectedIndex;

                        return (
                            <TouchableOpacity
                                key={index}
                                activeOpacity={0.5}
                                onPress={() => setSelectedIndex(index)}
                                style={{
                                    height: 56,
                                    justifyContent: "center",
                                    paddingHorizontal: 20,
                                    borderBottomWidth: 2,
                                    borderColor: isFocused
                                        ? theme.color.components.gray2
                                        : theme.color.transparent,
                                }}>
                                <Text
                                    style={[
                                        TextStyles.listItemSmall,
                                        {
                                            color: theme.color.text.main,
                                        },
                                    ]}>
                                    {text}
                                </Text>
                            </TouchableOpacity>
                        );
                    })}
                </ScrollView>
            </View>

            {/* Stats */}
            <StackView
                spacing={12}
                style={{
                    padding: 16,
                }}>
                {selectedIndex === 0 && (
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {`${numBatteries} lithium ion battery ${pluralize(
                            "pack",
                            numBatteries
                        )}`}
                    </Text>
                )}

                {packStats.length > 0 ? (
                    <GridView columns={2} rowSpacing={12} columnSpacing={12}>
                        {packStats.map((s, index) => (
                            <EnergyStatCard
                                key={index}
                                disabled={!isCharging}
                                {...s}
                            />
                        ))}
                    </GridView>
                ) : (
                    <View
                        style={{
                            flex: 1,
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        <Text
                            style={[
                                TextStyles.listItemLarge,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            No Stats Available
                        </Text>
                    </View>
                )}
            </StackView>
        </View>
    );
});
