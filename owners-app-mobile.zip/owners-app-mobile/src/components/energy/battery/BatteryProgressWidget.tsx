import { observer } from "mobx-react-lite";
import React from "react";
import { BatteryIcon } from "../../../assets/icons";
import { BatteryManager } from "../../../models/domain/energy";
import { DateUtil, MathUtils, StringUtils } from "../../../utils";
import { ProgressWidget } from "../../smartVehicle";

export const BatteryProgressWidget: React.FunctionComponent<{
    batteryManager: BatteryManager;
    disabled?: boolean;
}> = observer(({ batteryManager, disabled = false }) => {
    const charge = batteryManager.charge;
    const batteryPercentageString = StringUtils.toPercentageString(charge);

    const timeTillMinutes = batteryManager.timeTillMinutes;

    let remainingText = "";

    if (MathUtils.isNumber(timeTillMinutes)) {
        const timeTillMillis = DateUtil.minutesToMillis(timeTillMinutes);
        const { days, hours, minutes } = DateUtil.getDuration(timeTillMillis, {
            days: true,
            hours: true,
            minutes: true,
        });

        if (days) {
            remainingText += `${days}d `;
        }

        if (hours) {
            remainingText += `${hours}h `;
        }

        if (minutes) {
            remainingText += `${minutes}m`;
        }
    }

    return (
        <ProgressWidget
            name="House Battery"
            title={`${batteryPercentageString} Charged`}
            subtitle={remainingText}
            progress={charge ?? 0}
            progressDirection="down"
            icon={BatteryIcon}
            disabled={disabled}
        />
    );
});
