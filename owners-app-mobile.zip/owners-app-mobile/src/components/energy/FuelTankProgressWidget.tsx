import { observer } from "mobx-react-lite";
import React from "react";
import { PropaneTankFilledIcon } from "../../assets/icons";
import { FuelTank } from "../../models/domain/energy";
import { ProgressWidget } from "../smartVehicle";

export const FuelTankProgressWidget: React.FunctionComponent<{
    fuelTank: FuelTank;
}> = observer(({ fuelTank }) => {
    let progressFraction = 0;

    if (fuelTank?.level) {
        progressFraction = fuelTank.level / 100;
    }

    return (
        <ProgressWidget
            name="Propane Tank"
            subtitle={`${fuelTank.capacity} ${fuelTank.unit}`}
            title={`${fuelTank?.level ?? 0}% Full`}
            progress={progressFraction}
            progressDirection="down"
            icon={PropaneTankFilledIcon}
        />
    );
});
