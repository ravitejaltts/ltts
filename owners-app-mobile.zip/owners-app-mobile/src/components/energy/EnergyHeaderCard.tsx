import React from "react";
import {
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";

const EnergyHeaderCard: React.FunctionComponent<{
    topText: string;
    middleText: string;
    bottomText: string;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = ({ topText, middleText, bottomText, onPress, style }) => {
    const [theme] = useTheme();

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={onPress}
            style={[
                style,
                {
                    justifyContent: "center",
                    paddingVertical: 15,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    backgroundColor: theme.color.background.elevation3,
                },
            ]}>
            <View>
                <Text
                    style={[
                        TextStyles.listEyebrow,
                        {
                            color: theme.color.text.deemphasized,
                            textAlign: "center",
                        },
                    ]}>
                    {topText}
                </Text>

                <Text
                    style={[
                        TextStyles.calloutTitle,
                        {
                            color: theme.color.text.main,
                            textAlign: "center",
                            paddingTop: 8,
                            paddingBottom: 4,
                        },
                    ]}>
                    {middleText}
                </Text>

                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.deemphasized,
                            textAlign: "center",
                        },
                    ]}>
                    {bottomText}
                </Text>
            </View>
        </TouchableHighlight>
    );
};

export default EnergyHeaderCard;
