import React, { useState } from "react";
import StackSection from "../StackSection";
import StackView from "../StackView";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import { TextStyles } from "../../styles";
import { useTheme } from "../../context";
import { SmartVehicle } from "../../models/domain/vehicle";
import { observer } from "mobx-react-lite";
import { MathUtils, StringUtils } from "../../utils";

const BAR_HEIGHT = 12;

export const EnergyUsageCard: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
    hasBorder?: boolean;
    showDraw?: boolean;
    disabled?: boolean;
    style?: StyleProp<ViewStyle>;
}> = observer(
    ({
        smartVehicle,
        hasBorder,
        showDraw = false,
        disabled = false,
        style,
    }) => {
        const [theme] = useTheme();

        const energyStore = smartVehicle.energy;

        const totalSourceWatts = energyStore.totalSourceWatts;
        const totalConsumerWatts = energyStore.totalConsumerWatts;
        const totalACOutputWatts = energyStore.totalACOutputWatts;
        const totalDcOutputWatts = energyStore.totalDcOutputWatts;

        const barBorderRadius = BAR_HEIGHT / 2;

        const [barWidth, setBarWidth] = useState(100);

        let progressWidth = 0;
        let progressColor = theme.color.green.light;

        if (barWidth > 0 && totalSourceWatts > 0) {
            const progress = totalConsumerWatts / totalSourceWatts;
            progressWidth = MathUtils.clamp(
                progress * barWidth,
                BAR_HEIGHT,
                barWidth
            );

            if (disabled) {
                progressColor = theme.color.components.gray2;
            } else if (progress < 0.75) {
                progressColor = theme.color.green.light;
            } else if (progress < 0.85) {
                progressColor = theme.color.yellow.default;
            } else {
                progressColor = theme.color.error;
            }
        }

        return (
            <StackSection hasBorder={hasBorder} style={style}>
                {/* Top Section */}
                <StackView
                    spacing={8}
                    style={{
                        paddingTop: 16,
                        paddingBottom: showDraw ? 20 : 16,
                        paddingHorizontal: 16,
                    }}>
                    {/* Use vs Power */}
                    <View
                        style={{
                            flexDirection: "row",
                            alignItems: "flex-end",
                        }}>
                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    flex: 1,
                                    textAlign: "left",
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {"Energy Use: "}
                            <Text
                                style={[
                                    TextStyles.listItemSmall,
                                    {
                                        color: disabled
                                            ? theme.color.text.deemphasized
                                            : theme.color.text.main,
                                    },
                                ]}>
                                {StringUtils.toValueString(totalConsumerWatts)}
                            </Text>
                            {"W"}
                        </Text>

                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    flex: 1,
                                    textAlign: "right",
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {"Total Power: "}
                            <Text
                                style={[
                                    TextStyles.listItemSmall,
                                    {
                                        color: disabled
                                            ? theme.color.text.deemphasized
                                            : theme.color.text.main,
                                    },
                                ]}>
                                {StringUtils.toValueString(totalSourceWatts)}
                            </Text>
                            {"W"}
                        </Text>
                    </View>

                    {/* Progress Bar Background */}
                    <View
                        onLayout={(e) => {
                            setBarWidth(e.nativeEvent.layout.width);
                        }}
                        style={{
                            height: BAR_HEIGHT,
                            borderRadius: barBorderRadius,
                            backgroundColor: theme.color.background.elevation1,
                        }}>
                        {/* Progress */}
                        <View
                            style={{
                                width: progressWidth,
                                height: BAR_HEIGHT,
                                borderRadius: barBorderRadius,
                                backgroundColor: progressColor,
                            }}
                        />
                    </View>
                </StackView>

                {/* AC/DC */}
                {showDraw && (
                    <StackSection
                        style={{
                            flexDirection: "row",
                        }}>
                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    flex: 1,
                                    paddingVertical: 12,
                                    textAlign: "center",
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {"AC Draw: "}
                            <Text style={TextStyles.listItemSmall}>
                                {StringUtils.toValueString(totalACOutputWatts)}
                            </Text>
                            {"W"}
                        </Text>

                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    flex: 1,
                                    paddingVertical: 12,
                                    textAlign: "center",
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {"DC Draw: "}
                            <Text style={TextStyles.listItemSmall}>
                                {StringUtils.toValueString(totalDcOutputWatts)}
                            </Text>
                            {"W"}
                        </Text>
                    </StackSection>
                )}
            </StackSection>
        );
    }
);
