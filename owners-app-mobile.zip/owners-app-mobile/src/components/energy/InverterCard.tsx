import React, { useState } from "react";
import { View, Text } from "react-native";
import StackView from "../StackView";
import { TextStyles } from "../../styles";
import ThemedSwitch from "../ThemedSwitch";
import { useTheme } from "../../context";
import { Inverter } from "../../models/domain/energy";
import { InverterIcon } from "../../assets/icons";
import { MathUtils, StringUtils } from "../../utils";
import { observer } from "mobx-react-lite";

const BAR_HEIGHT = 12;

export const InverterCard: React.FunctionComponent<{
    inverter: Inverter;
}> = observer(({ inverter }) => {
    const [theme] = useTheme();

    const isOn = Boolean(inverter.isOn);

    const [barWidth, setBarWidth] = useState(100);

    const load = inverter.load;
    const maxLoad = inverter.maxLoad;

    let loadProgress = 0;

    if (maxLoad > 0) {
        loadProgress = load / maxLoad;
    }

    const progressWidth =
        loadProgress > 0
            ? MathUtils.clamp(
                  barWidth * loadProgress,
                  BAR_HEIGHT, // Min visible bar
                  barWidth // Max full width
              )
            : 0;

    let currentWattsColor = theme.color.text.main;
    let barColor = theme.color.green.light;

    if (loadProgress > 1) {
        currentWattsColor = theme.color.error;
        barColor = theme.color.error;
    } else if (loadProgress > 0.75) {
        currentWattsColor = theme.color.yellow.default;
        barColor = theme.color.yellow.default;
    } else if (loadProgress > 0) {
        currentWattsColor = theme.color.green.light;
    }

    return (
        <StackView
            spacing={12}
            style={{
                paddingHorizontal: 20,
                paddingVertical: 16,
                backgroundColor: theme.color.background.elevation3,
                borderRadius: 8,
                borderWidth: 1,
                borderColor: theme.color.dividers.gray1,
            }}>
            {/* Top Row */}
            <StackView
                spacing={8}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                <InverterIcon
                    width={24}
                    height={24}
                    fill={
                        isOn
                            ? theme.color.green.light
                            : theme.color.components.gray1
                    }
                />
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    Inverter
                </Text>
                <View
                    style={{
                        flex: 1,
                        alignItems: "flex-end",
                    }}>
                    <ThemedSwitch
                        value={isOn}
                        onValueChange={(value) => {
                            inverter?.toggle(value);
                        }}
                    />
                </View>
            </StackView>

            {/* Bar & Text */}
            <StackView spacing={4}>
                {/* Bar Row */}
                <View
                    onLayout={(e) => {
                        setBarWidth(e.nativeEvent.layout.width);
                    }}
                    style={{
                        backgroundColor: theme.color.background.elevation1,
                        height: BAR_HEIGHT,
                        borderRadius: BAR_HEIGHT / 2,
                    }}>
                    <View
                        style={{
                            backgroundColor: barColor,
                            height: BAR_HEIGHT,
                            borderRadius: BAR_HEIGHT / 2,
                            width: progressWidth,
                        }}
                    />
                </View>

                {/* Text Row */}
                <View
                    style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                    }}>
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: currentWattsColor,
                                },
                            ]}>
                            {StringUtils.toValueString(load)}
                        </Text>
                        W
                    </Text>

                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        of {StringUtils.toValueString(maxLoad)}W
                    </Text>
                </View>
            </StackView>
        </StackView>
    );
});
