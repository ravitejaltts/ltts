import React from "react";
import { Text, View } from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";

export type EnergyStatCardProps = {
    name?: string;
    value?: string;
    valueDescription?: string;
    disabled?: boolean;
    error?: boolean;
    border?: boolean;
};

export const EnergyStatCard: React.FunctionComponent<EnergyStatCardProps> = ({
    name,
    value,
    valueDescription,
    disabled = false,
    error = false,
    border = false,
}) => {
    const [theme] = useTheme();

    const valueString = error ? "Error" : value;
    const valueDescriptionString = error ? undefined : valueDescription;

    return (
        <StackView
            spacing={18}
            style={{
                height: 110,
                paddingVertical: 12,
                paddingHorizontal: 16,
                borderRadius: 8,
                borderWidth: border ? 1 : undefined,
                borderColor: border ? theme.color.dividers.gray1 : undefined,
                backgroundColor: theme.color.background.elevation3,
            }}>
            {Boolean(name) && (
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.deemphasized,
                        },
                    ]}>
                    {name}
                </Text>
            )}
            <View>
                {Boolean(value) && (
                    <Text
                        style={[
                            TextStyles.calloutTitle,
                            {
                                color: disabled
                                    ? theme.color.text.deemphasized
                                    : theme.color.text.main,
                            },
                        ]}>
                        {valueString}
                    </Text>
                )}
                {Boolean(valueDescription) && (
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {valueDescriptionString}
                    </Text>
                )}
            </View>
        </StackView>
    );
};
