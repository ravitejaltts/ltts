import React from "react";
import { useTheme } from "../../../context";
import { Generator } from "../../../models/domain/energy";
import { LabeledRowSwitch } from "../..";
import { TextStyles } from "../../../styles";

export const QuietHoursRowSwitch: React.FunctionComponent<{
    generator: Generator;
    onPress: () => void;
}> = ({ generator, onPress }) => {
    const [theme] = useTheme();

    const quietHoursEnabled = generator.quietHoursEnabled;
    const qhStartTimeText = generator.qhStartTimeText;
    const qhStopTimeText = generator.qhStopTimeText;

    return (
        <LabeledRowSwitch
            value={quietHoursEnabled}
            onValueChanged={(value) => {
                generator.toggleQuietHours(value);
            }}
            onPress={onPress}
            rightIcon={true}
            leftText="Quiet Hours"
            leftTextStyle={TextStyles.listItemSmall}
            leftSubtext={
                quietHoursEnabled
                    ? `${qhStartTimeText}-${qhStopTimeText}`
                    : "Off"
            }
            style={{
                paddingVertical: 16,
                borderRadius: 8,
                borderWidth: 1,
                borderColor: theme.color.dividers.stackSection,
            }}
        />
    );
};
