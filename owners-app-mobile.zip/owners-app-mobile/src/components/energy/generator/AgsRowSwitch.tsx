import { observer } from "mobx-react-lite";
import React from "react";
import { Alert } from "react-native";
import { LabeledRowSwitch } from "../..";
import { useTheme } from "../../../context";
import { Generator } from "../../../models/domain/energy";
import { TextStyles } from "../../../styles";

export const AgsRowSwitch: React.FunctionComponent<{
    generator: Generator;
}> = observer(({ generator }) => {
    const [theme] = useTheme();

    const ags = generator.ags;
    const ignitionOn = generator.isIgnitionOn;

    const disabled = ignitionOn;

    const toggleAgs = (value: boolean) => {
        if (value) {
            Alert.alert(
                "Is the RV in a Well-Ventilated Space?",
                "Enabling Auto Generator Start in a closed space is dangerous. Only use the generator in spaces where carbon monoxide can’t accumulate.",
                [
                    {
                        text: "Enable",
                        onPress: () => {
                            generator.toggleAgs(value);
                        },
                        style: "default",
                        isPreferred: true,
                    },
                    {
                        text: "Cancel",
                        style: "cancel",
                    },
                ]
            );
        } else {
            generator.toggleAgs(value);
        }
    };

    return (
        <LabeledRowSwitch
            value={ags}
            onValueChanged={toggleAgs}
            disabled={disabled}
            leftText="Auto Generator Start"
            leftTextStyle={[
                TextStyles.listItemSmall,
                {
                    color: disabled
                        ? theme.color.text.deemphasized
                        : theme.color.text.main,
                },
            ]}
            rightText={disabled ? "Disabled" : ags ? "Ready" : "Off"}
            rightTextStyle={TextStyles.body}
            style={{
                paddingHorizontal: 20,
                paddingVertical: 10,
            }}
        />
    );
});
