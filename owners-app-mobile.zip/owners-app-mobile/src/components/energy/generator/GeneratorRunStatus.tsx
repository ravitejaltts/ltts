import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React, { useCallback, useState } from "react";
import { Text, TouchableOpacity } from "react-native";
import { StackView } from "../..";
import { InfoOutlineIcon } from "../../../assets/icons";
import { useTheme } from "../../../context";
import { Generator, GeneratorMode } from "../../../models/domain/energy";
import { GeneratorScreenNavigationProp } from "../../../screens/energy/generator/GeneratorScreen";
import { TextStyles } from "../../../styles";
import { DateUtil } from "../../../utils";

export const GeneratorRunStatus: React.FunctionComponent<{
    generator: Generator;
}> = observer(({ generator }) => {
    const [theme] = useTheme();
    const navigation = useNavigation<GeneratorScreenNavigationProp>();

    const mode = generator.mode;
    const runReminder = generator.runReminder;
    const startTime = generator.startTime;
    const lastRun = generator.lastRun;

    const lastRunMoreThan30DaysAgo =
        DateUtil.millisToDays(Date.now() - lastRun) > 30;

    const [currentRunText, setCurrentRunText] = useState("");

    useFocusEffect(
        useCallback(() => {
            setCurrentRunText(
                DateUtil.getDurationText(
                    DateUtil.nowTimestampMilliseconds() - startTime,
                    {
                        hours: true,
                        minutes: true,
                    }
                )
            );
        }, [startTime])
    );

    const [lastRunText, setLastRunText] = useState("");

    useFocusEffect(
        useCallback(() => {
            setLastRunText(DateUtil.timeAgo(lastRun));
        }, [lastRun])
    );

    return (
        <StackView
            spacing={5}
            style={{
                flexDirection: "row",
                alignItems: "center",
            }}>
            {mode === GeneratorMode.Run && startTime ? (
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.white,
                        },
                    ]}>
                    Current Run: {currentRunText}
                </Text>
            ) : lastRun ? (
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.white,
                        },
                    ]}>
                    Last Ran:
                    <Text
                        style={{
                            color:
                                lastRunMoreThan30DaysAgo && runReminder
                                    ? theme.color.orange.default
                                    : theme.color.white,
                        }}>
                        {` ${lastRunText}`}
                    </Text>
                </Text>
            ) : null}

            {/* Info Icon */}
            <TouchableOpacity
                onPress={() => navigation.navigate("generatorExerciseTracker")}>
                <InfoOutlineIcon
                    height={16}
                    width={16}
                    fill={theme.color.blue.brand.toString()}
                />
            </TouchableOpacity>
        </StackView>
    );
});
