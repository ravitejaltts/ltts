import { observer } from "mobx-react-lite";
import React from "react";
import { useTheme } from "../../../context";
import { GeneratorEnergySource } from "../../../models/domain/energy/sources";
import { StringUtils } from "../../../utils";
import GridView from "../../GridView";
import { EnergyStatCard } from "../EnergyStatCard";

export const GeneratorStatSection: React.FunctionComponent<{
    source: GeneratorEnergySource;
}> = observer(({ source }) => {
    const [theme] = useTheme();

    const isActive = source.isActive;

    const toValueString = (value: number | null) => {
        if (isActive) {
            return StringUtils.toValueString(value);
        }

        return "000";
    };

    return (
        <GridView
            style={{
                padding: 16,
                backgroundColor: theme.color.background.elevation2,
                borderRadius: 8,
            }}
            columns={2}
            rowSpacing={12}
            columnSpacing={12}>
            <EnergyStatCard
                name="Power"
                value={toValueString(source.watts)}
                valueDescription="Watts"
                disabled={!isActive}
            />
            <EnergyStatCard
                name="Voltage"
                value={toValueString(source.voltage)}
                valueDescription="Volts"
                disabled={!isActive}
            />
            <EnergyStatCard
                name="Current"
                value={toValueString(source.current)}
                valueDescription="Amps"
                disabled={!isActive}
            />
        </GridView>
    );
});
