import React, { useRef, useState } from "react";
import { Animated, Easing, Text, View } from "react-native";
import { useRootContainer, useTheme } from "../../../context";
import { Generator, GeneratorMode } from "../../../models/domain/energy";
import { TextStyles } from "../../../styles";
import { ProgressButton } from "../../newButtons";
import { SystemComponentType } from "../../../models/domain/system";

const PROGRESS_VALUE_MIN = 0;
const PROGRESS_VALUE_MAX = 100;

const TIMEOUT_SECONDS = 30;

export const GeneratorPrimeButton: React.FunctionComponent<{
    generator: Generator;
}> = ({ generator }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const toastStore = container.stores.toast;
    const toastRef = useRef("");

    const timeoutRef = useRef<NodeJS.Timeout>();
    const [isPrimeTimeout, setIsPrimeTimeout] = useState(false);

    const animationRef = useRef<Animated.CompositeAnimation>();
    const progressValue = useRef(
        new Animated.Value(PROGRESS_VALUE_MIN)
    ).current;

    const disabled =
        isPrimeTimeout ||
        Boolean(generator.lockouts.length) ||
        (generator.mode !== GeneratorMode.Prime &&
            generator.mode !== GeneratorMode.Off);

    const startPriming = () => {
        generator.startPriming();

        timeoutRef.current = setTimeout(() => {
            // Stop priming after 30 seconds
            generator.stopPriming();

            // Enter timeout state
            setIsPrimeTimeout(true);

            // Start animating
            const animation = Animated.loop(
                Animated.timing(progressValue, {
                    toValue: PROGRESS_VALUE_MAX,
                    duration: 5000,
                    useNativeDriver: false,
                    easing: Easing.linear,
                })
            );

            animationRef.current = animation;
            animation.start();

            // Show prime timeout toast
            toastRef.current = toastStore.showSystemComponentToast({
                type: SystemComponentType.Generator,
                text: `Priming control has timed out. Don't exceed ${TIMEOUT_SECONDS} seconds.`,
            });
        }, TIMEOUT_SECONDS * 1000);
    };

    const stopPriming = () => {
        generator.stopPriming();

        // Stop waiting for user to lift finger
        clearTimeout(timeoutRef.current);

        if (isPrimeTimeout) {
            // Timeout state has started
            // Stop animation and hide toast
            animationRef.current?.stop();
            animationRef.current = undefined;
            progressValue.setValue(PROGRESS_VALUE_MIN);
            toastStore.hideById(toastRef.current);
            toastRef.current = "";

            setIsPrimeTimeout(false);
        }
    };

    return (
        <ProgressButton
            disabled={disabled}
            backgroundColor={
                disabled
                    ? theme.color.background.elevation2
                    : theme.color.background.elevation1
            }
            borderColor={theme.color.dividers.gray2}
            onLongPressComplete={startPriming}
            onLongPressCanceled={stopPriming}
            style={{
                height: 60,
            }}>
            {/* Progress */}
            <Animated.View
                style={{
                    position: "absolute",
                    height: 60,
                    width: progressValue.interpolate({
                        inputRange: [PROGRESS_VALUE_MIN, PROGRESS_VALUE_MAX],
                        outputRange: ["0%", "100%"],
                    }),
                    backgroundColor: theme.color.background.elevation1,
                    borderRadius: 8,
                }}
            />
            {/* Content */}
            <View
                style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: disabled
                                ? theme.color.text.disabled
                                : theme.color.text.main,
                        },
                    ]}>
                    Prime Generator
                </Text>
            </View>
        </ProgressButton>
    );
};
