import React from "react";
import { useTheme } from "../../../context";
import { ControlSectionHeaderView } from "../../smartVehicle";
import { TimelapseIcon } from "../../../assets/icons";
import { Generator } from "../../../models/domain/energy";
import { observer } from "mobx-react-lite";

export const QuietHoursHeaderView: React.FunctionComponent<{
    generator: Generator;
}> = observer(({ generator }) => {
    const [theme] = useTheme();

    const qhStopTimeText = generator.qhStopTimeText;

    return (
        <ControlSectionHeaderView
            title={`Quiet Hours in Effect Until ${qhStopTimeText}`}
            icon={() => <TimelapseIcon fill={theme.color.blue.brand} />}
        />
    );
});
