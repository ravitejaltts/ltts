import React from "react";
import { StyleProp, Text, ViewStyle } from "react-native";
import { useTheme } from "../../../context";
import { TextStyles } from "../../../styles";
import StackSection from "../../StackSection";
import StackView from "../../StackView";
import { GeneratorHistoryPoint } from "../../../models/domain/energy";
import { ArrayUtils, DateUtil } from "../../../utils";

export type GeneratorHistoryDayViewProps = {
    dayTimestampMillis: number;
    points: GeneratorHistoryPoint[];
    style?: StyleProp<ViewStyle>;
};

export const GeneratorHistoryDayView: React.FunctionComponent<
    GeneratorHistoryDayViewProps
> = ({ dayTimestampMillis, points, style }) => {
    const [theme] = useTheme();

    const dayDate = new Date(dayTimestampMillis);

    const totalDuration = ArrayUtils.sum(
        points,
        (p) => p.endTimestampMillis - p.startTimestampMillis
    );
    const totalDurationText = DateUtil.getDurationText(totalDuration, {
        hours: true,
        minutes: true,
    });

    return (
        <StackView spacing={12} style={style}>
            <Text
                style={[
                    TextStyles.contentEyebrow,
                    {
                        color: theme.color.text.deemphasized,
                        paddingTop: 20,
                    },
                ]}>
                {dayDate.toLocaleDateString("en-US", {
                    weekday: "long",
                    month: "long",
                    day: "numeric",
                })}
            </Text>

            <StackSection hasBorder={true}>
                {points.map((p) => {
                    const pointDate = new Date(p.startTimestampMillis);
                    const timeText = pointDate.toLocaleTimeString("en-US", {
                        hour: "numeric",
                        minute: "numeric",
                    });
                    const durationText = DateUtil.getDurationText(
                        Math.abs(p.endTimestampMillis - p.startTimestampMillis),
                        {
                            hours: true,
                            minutes: true,
                        }
                    );

                    return (
                        <StackView
                            key={p.startTimestampMillis}
                            spacing={16}
                            style={{
                                flexDirection: "row",
                                paddingHorizontal: 20,
                                paddingVertical: 16,
                            }}>
                            <StackView
                                spacing={2}
                                style={{
                                    flex: 1,
                                }}>
                                <Text
                                    style={[
                                        TextStyles.listItemSmall,
                                        {
                                            color: theme.color.text.main,
                                        },
                                    ]}>
                                    Run Time: {durationText}
                                </Text>
                            </StackView>

                            <Text
                                style={[
                                    TextStyles.body,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {timeText}
                            </Text>
                        </StackView>
                    );
                })}

                <StackView
                    spacing={16}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                        paddingHorizontal: 20,
                        paddingVertical: 16,
                        backgroundColor: theme.color.background.elevation2,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                                flex: 1,
                            },
                        ]}>
                        Total Duration
                    </Text>

                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {totalDurationText}
                    </Text>
                </StackView>
            </StackSection>
        </StackView>
    );
};
