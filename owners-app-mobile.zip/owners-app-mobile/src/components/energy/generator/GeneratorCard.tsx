import { observer } from "mobx-react-lite";
import React from "react";
import { ColorValue, Text, View } from "react-native";
import { GeneratorToastIcon } from "../../../assets/icons";
import { useTheme } from "../../../context";
import {
    useFeatureFlag,
    useGeneratorQuietHoursOverrideToast,
    useGeneratorTimedLockoutToast,
    useQuietHoursInEffect,
    useSmartVehicle,
} from "../../../hooks";
import { FuelTank, Generator } from "../../../models/domain/energy";
import { FeatureFlagKey } from "../../../models/domain/featureFlag";
import { SystemLockoutOrWarning } from "../../../models/domain/system";
import { TextStyles } from "../../../styles";
import { MathUtils, StringUtils } from "../../../utils";
import StackSection from "../../StackSection";
import StackView from "../../StackView";
import { EnergySourceView } from "../source/EnergySourceView";
import { AgsRowSwitch } from "./AgsRowSwitch";
import { GeneratorControlButton } from "./GeneratorControlButton";
import { QuietHoursHeaderView } from "./QuietHoursHeaderView";

export const GeneratorCard: React.FunctionComponent<{
    generator: Generator;
    propaneTank?: FuelTank;
    hasBorder?: boolean;
    disabled?: boolean;
    onPress?: () => void;
}> = observer(
    ({
        generator,
        propaneTank,
        hasBorder = false,
        disabled = false,
        onPress,
    }) => {
        const [theme] = useTheme();

        // Quiet Hours Override Toast
        useGeneratorQuietHoursOverrideToast();

        // Wait Lockout Toast
        useGeneratorTimedLockoutToast(SystemLockoutOrWarning.GeneratorWait);

        // Cooldown Lockout Toast
        useGeneratorTimedLockoutToast(SystemLockoutOrWarning.GeneratorCooldown);

        const qhFlagEnabled = useFeatureFlag(
            FeatureFlagKey.GeneratorQuietHours
        );
        const agsFlagEnabled = useFeatureFlag(
            FeatureFlagKey.AutoGeneratorStart
        );

        const qhInEffect = useQuietHoursInEffect();

        const smartVehicle = useSmartVehicle();

        let watts: number | null | undefined;

        if (smartVehicle) {
            // Get related energy source
            const energyStore = smartVehicle.energy;
            const relatedSources = energyStore.getRelatedEnergySources(
                generator.metadata
            );

            if (relatedSources.length) {
                watts = relatedSources[0].watts;
            }
        }

        const isRunning = generator.isRunning;
        const hasError = generator.hasError;
        const hasLockout = Boolean(generator.lockouts.length);
        const hasWarning = Boolean(generator.warnings.length);
        const modeText = generator.modeText;

        const propaneLevel = propaneTank?.level;
        const propaneText = StringUtils.toValueString(propaneLevel);
        let propaneBackgroundColor: ColorValue | undefined;
        let propaneBorderColor: ColorValue | undefined;

        if (disabled) {
            propaneBackgroundColor = theme.color.components.gray2;
        } else if (MathUtils.isNumber(propaneLevel)) {
            if (propaneLevel <= 10) {
                propaneBackgroundColor = theme.color.error;
            } else if (propaneLevel <= 55) {
                propaneBackgroundColor = theme.color.yellow.default;
            } else {
                propaneBackgroundColor = theme.color.green.light;
            }
        } else {
            propaneBorderColor = theme.color.components.gray1;
        }

        return (
            <StackSection hasBorder={hasBorder && agsFlagEnabled}>
                {qhFlagEnabled && qhInEffect && (
                    <QuietHoursHeaderView generator={generator} />
                )}

                <EnergySourceView
                    name="GENERATOR"
                    status={modeText}
                    icon={GeneratorToastIcon}
                    isActive={!hasLockout && isRunning}
                    watts={watts}
                    error={!hasLockout && hasError}
                    warning={hasWarning}
                    hasBorder={hasBorder && !agsFlagEnabled}
                    disabled={disabled}
                    onPress={onPress}
                    rightView={
                        <StackView
                            spacing={8}
                            style={{
                                paddingHorizontal: 8,
                                flex: 1,
                            }}>
                            <GeneratorControlButton
                                generator={generator}
                                disabled={disabled}
                                style={{
                                    height: undefined,
                                    flex: 1,
                                }}
                            />

                            {/* Propane Level */}
                            <StackView
                                spacing={8}
                                style={{
                                    flexDirection: "row",
                                    alignItems: "center",
                                    alignSelf: "center",
                                }}>
                                <View
                                    style={{
                                        width: 12,
                                        height: 12,
                                        backgroundColor: propaneBackgroundColor,
                                        borderRadius: 6,
                                        borderWidth: propaneBorderColor ? 1 : 0,
                                        borderColor: propaneBorderColor,
                                    }}
                                />

                                <Text style={TextStyles.listEyebrow}>
                                    <Text
                                        style={{
                                            color: theme.color.text
                                                .deemphasized,
                                        }}>
                                        Propane Tank{" "}
                                    </Text>

                                    <Text
                                        style={{
                                            color: disabled
                                                ? theme.color.text.deemphasized
                                                : theme.color.text.main,
                                        }}>
                                        {propaneText}%
                                    </Text>
                                </Text>
                            </StackView>
                        </StackView>
                    }
                />

                {/* AGS */}
                {agsFlagEnabled && <AgsRowSwitch generator={generator} />}
            </StackSection>
        );
    }
);
