import { observer } from "mobx-react-lite";
import React, { useState } from "react";
import { StyleProp, StyleSheet, Text, View, ViewStyle } from "react-native";
import { PowerSettingsIcon } from "../../../assets/icons";
import { useTheme } from "../../../context";
import { useLogger, useTimedLockout } from "../../../hooks";
import {
    Generator,
    GeneratorMode,
    GeneratorState,
} from "../../../models/domain/energy";
import { SystemLockoutOrWarning } from "../../../models/domain/system";
import { TextStyles } from "../../../styles";
import { ButtonOverlay, ProgressButton } from "../../newButtons";

const BUTTON_HEIGHT = 120;

export const GeneratorControlButton: React.FunctionComponent<{
    generator: Generator;
    disabled?: boolean;
    style?: StyleProp<ViewStyle>;
}> = observer(({ generator, disabled = false, style }) => {
    const [theme] = useTheme();
    const { logError } = useLogger("GeneratorControlButton");
    const [overlay, setOverlay] = useState(false);
    const [isSendingCommand, setIsSendingCommand] = useState(false);

    const mode = generator.mode;

    const cooldownLockout = useTimedLockout(
        SystemLockoutOrWarning.GeneratorCooldown
    );

    let fillProgress = 0;

    if (cooldownLockout) {
        const remainingSeconds = cooldownLockout.remainingSeconds;
        const durationSeconds = cooldownLockout.durationSeconds;

        fillProgress = (1 - remainingSeconds / durationSeconds) * 100;
    }

    const sendCommand = () => {
        let command: Promise<GeneratorState>;

        setIsSendingCommand(true);

        switch (mode) {
            case GeneratorMode.Off:
                command = generator.sendStartCommand();
                break;
            default:
            case GeneratorMode.Run:
                command = generator.sendStopCommand();
                break;
        }

        command
            .catch((error) => {
                logError(error);
            })
            .finally(() => {
                setIsSendingCommand(false);
            });
    };

    const buttonDisabled =
        disabled ||
        isSendingCommand ||
        mode === GeneratorMode.Error ||
        mode === GeneratorMode.Starting ||
        mode === GeneratorMode.Reset ||
        Boolean(generator.lockouts.length);

    const backgroundColor = buttonDisabled
        ? theme.color.background.elevation2
        : mode === GeneratorMode.Run
        ? theme.color.orange.dark20
        : theme.color.green.light20;

    const borderColor = buttonDisabled
        ? theme.color.background.elevation1
        : mode === GeneratorMode.Run
        ? theme.color.orange.dark
        : theme.color.green.light;

    const text = mode === GeneratorMode.Run ? "Stop" : "Start";

    const defaultHeightStyle: ViewStyle = {
        height: BUTTON_HEIGHT,
    };

    let flatStyle = defaultHeightStyle;

    if (style) {
        flatStyle = StyleSheet.flatten([defaultHeightStyle, style]);
    }

    const buttonHeight = flatStyle.height;

    return (
        <ProgressButton
            onLongPressComplete={sendCommand}
            onPress={() => {
                setOverlay(true);
            }}
            backgroundColor={backgroundColor}
            borderColor={borderColor}
            disabled={buttonDisabled}
            style={flatStyle}>
            <View style={{ flex: 1 }}>
                {/* Progress Bar */}
                <View
                    style={{
                        position: "absolute",
                        width: `${fillProgress}%`,
                        height: buttonHeight,
                        borderRadius: 8,
                        backgroundColor: theme.color.green.light20,
                    }}
                />

                {/* Icon & Text */}
                <View
                    style={{
                        flex: 1,
                        justifyContent: "center",
                        alignItems: "center",
                    }}>
                    <PowerSettingsIcon
                        width={28}
                        height={28}
                        fill={
                            buttonDisabled
                                ? theme.color.text.disabled
                                : borderColor
                        }
                    />
                    <Text
                        style={[
                            TextStyles.listItemLarge,
                            {
                                color: buttonDisabled
                                    ? theme.color.text.disabled
                                    : borderColor,
                                textAlign: "center",
                            },
                        ]}>
                        {text}
                    </Text>
                </View>

                {/* Overlay */}
                <ButtonOverlay
                    visible={overlay}
                    onAnimationFinish={() => setOverlay(false)}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                textAlign: "center",
                                color: theme.color.white,
                                width: "100%",
                            },
                        ]}>
                        Press and Hold
                    </Text>
                </ButtonOverlay>
            </View>
        </ProgressButton>
    );
});
