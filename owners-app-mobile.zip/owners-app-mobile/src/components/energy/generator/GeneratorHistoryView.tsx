import React, { useCallback, useState } from "react";
import { Text, View } from "react-native";
import { HistoryIcon } from "../../../assets/icons";
import { useTheme } from "../../../context";
import { useFirstFocusedEffect } from "../../../hooks";
import { Generator } from "../../../models/domain/energy";
import { TextStyles } from "../../../styles";
import { ArrayUtils, StringUtils } from "../../../utils";
import { LargeTitleFlatList } from "../../LargeTitleFlatList";
import LoadingView from "../../LoadingView";
import StackView from "../../StackView";
import {
    GeneratorHistoryDayView,
    GeneratorHistoryDayViewProps,
} from "./GeneratorHistoryDayView";

export const GeneratorHistoryView: React.FunctionComponent<{
    generator: Generator;
}> = ({ generator }) => {
    const [theme] = useTheme();
    const [isLoading, setIsLoading] = useState(true);

    const historyPoints = generator.historyPoints;
    const groupedPoints = ArrayUtils.groupBy(historyPoints, (p) => {
        const date = new Date(p.startTimestampMillis);
        date.setHours(0, 0, 0, 0);
        return date.getTime();
    });

    const listData: GeneratorHistoryDayViewProps[] = [];

    for (const group of groupedPoints) {
        const dateMillis = group[0];
        const points = group[1];

        listData.push({
            dayTimestampMillis: dateMillis,
            points,
        });
    }

    const totalRunTimeHours = generator.totalRunTimeHours;
    const hoursText = StringUtils.toValueString(totalRunTimeHours);

    useFirstFocusedEffect(
        useCallback(() => {
            if (historyPoints.length) {
                setIsLoading(false);
                return;
            }

            setIsLoading(true);

            generator
                .updateHistory()
                .catch(() => {
                    // Do nothing
                })
                .finally(() => {
                    setIsLoading(false);
                });
        }, [generator, historyPoints])
    );

    return (
        <LargeTitleFlatList
            title="Generator History"
            data={listData}
            renderItem={({ item: props }) => (
                <GeneratorHistoryDayView
                    {...props}
                    style={{
                        paddingHorizontal: 20,
                    }}
                />
            )}
            bodyHeaderView={
                <View
                    style={{
                        backgroundColor: theme.color.black,
                        paddingHorizontal: 20,
                        paddingBottom: 20,
                    }}>
                    <View
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                            backgroundColor: theme.color.background.elevation3,
                            borderRadius: 8,
                            paddingHorizontal: 20,
                            paddingVertical: 16,
                        }}>
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.main,
                                    flex: 1,
                                },
                            ]}>
                            Total Lifetime Run
                        </Text>

                        <Text style={TextStyles.body}>
                            <Text
                                style={{
                                    color: theme.color.text.main,
                                }}>
                                {hoursText}
                            </Text>

                            <Text
                                style={{
                                    color: theme.color.text.deemphasized,
                                }}>
                                {" Hours"}
                            </Text>
                        </Text>
                    </View>
                </View>
            }
            ListEmptyComponent={
                <View
                    style={{
                        flex: 1,
                        justifyContent: "center",
                    }}>
                    {isLoading ? (
                        <LoadingView />
                    ) : (
                        <StackView
                            spacing={8}
                            style={{
                                height: 100,
                                justifyContent: "center",
                                alignItems: "center",
                            }}>
                            <HistoryIcon
                                width={50}
                                height={50}
                                fill={theme.color.text.deemphasized}
                            />
                            <Text
                                style={[
                                    TextStyles.body,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                No history available
                            </Text>
                        </StackView>
                    )}
                </View>
            }
        />
    );
};
