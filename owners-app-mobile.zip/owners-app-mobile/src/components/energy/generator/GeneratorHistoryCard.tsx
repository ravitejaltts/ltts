import React from "react";
import { StyleProp, Text, ViewStyle } from "react-native";
import { useTheme } from "../../../context";
import StackView from "../../StackView";
import { TextStyles } from "../../../styles";
import { SecondaryButton } from "../../Buttons";
import { HistoryIcon } from "../../../assets/icons";
import { Generator } from "../../../models/domain/energy";
import { StringUtils } from "../../../utils";
import { observer } from "mobx-react-lite";

export const GeneratorHistoryCard: React.FunctionComponent<{
    generator: Generator;
    onHistoryPress: () => void;
    style?: StyleProp<ViewStyle>;
}> = observer(({ generator, onHistoryPress, style }) => {
    const [theme] = useTheme();

    const totalRunTimeHours = generator.totalRunTimeHours;
    const hoursText = StringUtils.toValueString(totalRunTimeHours);

    return (
        <StackView
            spacing={12}
            style={[
                {
                    backgroundColor: theme.color.background.elevation2,
                    padding: 16,
                    borderRadius: 8,
                },
                style,
            ]}>
            <StackView
                spacing={16}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                    borderRadius: 8,
                    paddingHorizontal: 20,
                    paddingVertical: 16,
                    backgroundColor: theme.color.background.elevation3,
                }}>
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                            flex: 1,
                        },
                    ]}>
                    Total Lifetime Run
                </Text>

                <Text style={TextStyles.body}>
                    <Text
                        style={{
                            color: theme.color.text.main,
                        }}>
                        {hoursText}
                    </Text>
                    <Text
                        style={{
                            color: theme.color.text.deemphasized,
                        }}>
                        {" hours"}
                    </Text>
                </Text>
            </StackView>

            <SecondaryButton
                onPress={onHistoryPress}
                text="See History"
                textStyle={{
                    color: theme.color.blue.brand,
                }}
                leftView={
                    <HistoryIcon
                        width={20}
                        height={20}
                        fill={theme.color.blue.brand}
                    />
                }
            />
        </StackView>
    );
});
