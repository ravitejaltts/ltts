import { observer } from "mobx-react-lite";
import React from "react";
import { Text } from "react-native";
import { useTheme } from "../../context";
import { useSmartVehicle } from "../../hooks";
import { FuelTank } from "../../models/domain/energy";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { EnergyUsageCard } from "./EnergyUsageCard";
import { CompactBatteryChargeCard } from "./battery";
import { GeneratorCard } from "./generator";
import { ShoreSourceCard } from "./source";

export const DashboardEnergySection: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
    disabled?: boolean;
}> = observer(({ disabled = false }) => {
    const [theme] = useTheme();

    const smartVehicle = useSmartVehicle();

    if (!smartVehicle) {
        return;
    }

    const energyStore = smartVehicle.energy;

    const shoreSource = energyStore.shoreSource;
    const batteryManager = energyStore.batteryManager;
    const generator = energyStore.generator;
    let propaneTank: FuelTank | undefined;

    if (generator) {
        // Get first related fuel tank
        propaneTank = energyStore
            .getRelatedFuelTanks(generator.metadata)
            .find(() => true);
    }

    return (
        <StackView
            spacing={16}
            style={{
                paddingTop: 20,
                paddingBottom: 16,
                paddingHorizontal: 16,
                borderRadius: 8,
                backgroundColor: theme.color.background.elevation2,
            }}>
            {/* Title */}
            <Text
                style={[
                    TextStyles.sectionBreak,
                    {
                        textAlign: "center",
                        color: theme.color.text.main,
                    },
                ]}>
                Energy Management
            </Text>

            <StackView spacing={8}>
                <EnergyUsageCard
                    disabled={disabled}
                    smartVehicle={smartVehicle}
                />

                <StackView
                    spacing={8}
                    style={{
                        flexDirection: "row",
                        alignItems: "stretch",
                    }}>
                    {shoreSource && (
                        <ShoreSourceCard
                            source={shoreSource}
                            disabled={disabled}
                            style={{
                                flex: 1,
                            }}
                        />
                    )}
                    {batteryManager && (
                        <CompactBatteryChargeCard
                            batteryManager={batteryManager}
                            disabled={disabled}
                            style={{
                                flex: 1,
                            }}
                        />
                    )}
                </StackView>

                {generator && (
                    <GeneratorCard
                        generator={generator}
                        propaneTank={propaneTank}
                        disabled={disabled}
                    />
                )}
            </StackView>
        </StackView>
    );
});
