import moment from "moment";
import React, { useRef, useState } from "react";
import {
    ColorValue,
    LayoutChangeEvent,
    ScrollView,
    Text,
    View,
    ViewProps,
} from "react-native";
import {
    BackArrowIcon,
    ForwardArrowIcon,
    LightningIcon,
} from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import { ImageButton } from "../Buttons";
import StackView from "../StackView";

export type BarGraphData = {
    value: number;
    timestamp: string;
    isCharging?: boolean;
};

interface BarGraphParams extends ViewProps {
    title: string;
    data: BarGraphData[][]; // [0][x] = today, [1][x] = yesterday, [2][x] = the day before yesterday, etc... The second dimension is the hour.
    yAxisLabels: string[] | number[];
    yAxisSuffix?: string;
    maxValue: number;
    batteryLayout?: boolean;
    onPage?: (pageIndex: number) => void; // 0 = today, 1 = yesterday, 2 = the day before yesterday, etc...
}

interface BarParams {
    height: number;
    paddingBottom: number;
    percentOfHeight: number;
    xAxisLabel: string;
    isCharging?: boolean;
    isChargingStartPiece?: boolean;
    isChargingEndPiece?: boolean;
    lightningMarginTop: number;
    lightningMarginBottom: number;
    lightningHeight: number;
}

const Bar: React.FunctionComponent<BarParams> = ({
    height,
    paddingBottom,
    percentOfHeight,
    xAxisLabel,
    isCharging,
    isChargingStartPiece,
    isChargingEndPiece,

    lightningMarginTop,
    lightningMarginBottom,
    lightningHeight,
}) => {
    const [theme] = useTheme();

    const adjustedBarHeight =
        height -
        lightningMarginTop -
        lightningHeight -
        lightningMarginTop -
        paddingBottom;

    const getBarColor = (percent: number): ColorValue => {
        if (percent < 0.25) {
            return theme.color.error;
        } else if (percent <= 0.5) {
            return theme.color.yellow.default;
        } else if (percent < 0.75) {
            return theme.color.green.light;
        }

        return theme.color.green.light;
    };

    return (
        <StackView spacing={6}>
            <View
                style={{
                    borderBottomLeftRadius: isChargingStartPiece ? 8 : 0,
                    borderTopLeftRadius: isChargingStartPiece ? 8 : 0,
                    borderBottomRightRadius: isChargingEndPiece ? 8 : 0,
                    borderTopRightRadius: isChargingEndPiece ? 8 : 0,
                    paddingBottom: paddingBottom,
                    width: 40,
                    alignItems: "center",
                    height: height,
                    backgroundColor:
                        (isCharging && theme.color.green.opaqueGreen) ||
                        undefined,
                }}>
                {isCharging && (
                    <LightningIcon
                        style={{
                            marginTop: lightningMarginTop,
                            marginBottom: lightningMarginBottom,
                        }}
                        fill={theme.color.green.light}
                        width={14}
                        height={lightningHeight}
                    />
                )}
                {/* Background */}
                <View
                    style={{
                        width: 8,
                        marginTop: !isCharging
                            ? lightningMarginTop +
                              lightningHeight +
                              lightningMarginBottom
                            : 0,
                        height: adjustedBarHeight,
                        overflow: "hidden",
                        borderRadius: 4,
                        backgroundColor: theme.color.dividers.gray1,
                        justifyContent: "flex-end",
                    }}>
                    {/* Progress */}
                    <View
                        style={{
                            position: "relative",
                            top: adjustedBarHeight * (1.0 - percentOfHeight),
                            width: 8,
                            height: adjustedBarHeight,
                            borderRadius: 4,
                            backgroundColor: getBarColor(percentOfHeight),
                        }}
                    />
                </View>
            </View>
            <Text
                style={[
                    TextStyles.regular12,
                    { color: theme.color.text.deemphasized },
                ]}>
                {xAxisLabel}
            </Text>
        </StackView>
    );
};

const BarGraph: React.FunctionComponent<BarGraphParams> = ({
    title,
    data,
    yAxisLabels,
    yAxisSuffix = "",
    style,
    maxValue,
    batteryLayout = false,
    onPage,
}) => {
    const scrollViewRef = useRef<ScrollView>(null);

    const [dayIndex, setDayIndex] = useState<number>(0);
    const [dayData, setDayData] = useState<BarGraphData[]>(data[dayIndex]);

    const [theme] = useTheme();

    const graphHeightPercentOfParent = "56%";
    const yAxisWidthFlex = 1;
    const graphWidthFlex = 6;

    const [barHeight, setBarHeight] = useState<number>(0);
    const [scrollViewWidth, setScrollViewWidth] = useState<number>(0);
    const [controllerRightMargin, setControllerRightMargin] =
        useState<number>(0);
    const lightningMarginTop = batteryLayout ? 4 : 0;
    const lightningHeight = batteryLayout ? 15 : 0;
    const lightningMarginBottom = batteryLayout ? 6.5 : 0;
    const barBottomPadding = batteryLayout ? 6 : 0;

    const barParams: BarParams[] = [];

    if (batteryLayout) {
        let chargingBlockFound = false;
        for (let i = 0; i < dayData.length; ++i) {
            const bp: BarParams = {
                height: barHeight,
                paddingBottom: barBottomPadding,
                percentOfHeight: dayData[i].value / maxValue,
                xAxisLabel: dayData[i].timestamp,
                isCharging: dayData[i].isCharging,
                isChargingStartPiece: false,
                isChargingEndPiece: false,
                lightningMarginTop,
                lightningMarginBottom,
                lightningHeight,
            };
            if (!chargingBlockFound && dayData[i].isCharging) {
                bp.isChargingStartPiece = true;
                chargingBlockFound = true;
            }
            if (
                chargingBlockFound &&
                i < dayData.length - 1 &&
                dayData[i].isCharging &&
                !dayData[i + 1].isCharging
            ) {
                bp.isChargingEndPiece = true;
                chargingBlockFound = false;
            }

            barParams.push(bp);
        }
    } else {
        for (let i = 0; i < dayData.length; ++i) {
            const bp: BarParams = {
                height: barHeight,
                paddingBottom: barBottomPadding,
                percentOfHeight: dayData[i].value / maxValue,
                xAxisLabel: dayData[i].timestamp,
                lightningMarginTop,
                lightningMarginBottom,
                lightningHeight,
            };

            barParams.push(bp);
        }
    }

    const pageBarGraph = (delta: number) => {
        if (
            (delta < 0 && dayIndex + delta >= 0) ||
            (delta > 0 && dayIndex + delta < data.length)
        ) {
            setDayData(data[dayIndex + delta]);
            setDayIndex(dayIndex + delta);
            scrollViewRef.current?.scrollTo({
                x: 0,
                animated: true,
            });
            if (onPage) {
                onPage(dayIndex + delta);
            }
        }
    };

    const onGraphLayout = (e: LayoutChangeEvent) => {
        const { width, height } = e.nativeEvent.layout;
        const sW = width * (graphWidthFlex / (yAxisWidthFlex + graphWidthFlex));
        setBarHeight(height * 0.86);
        setScrollViewWidth(sW);
    };

    const onControllerLayout = (e: LayoutChangeEvent) => {
        const { width } = e.nativeEvent.layout;
        setControllerRightMargin((scrollViewWidth - width) / 2);
    };

    return (
        <View
            style={[
                {
                    backgroundColor: theme.color.background.elevation3,
                    paddingTop: 16,
                    paddingLeft: 16,
                    borderRadius: 8,
                    minHeight: 250,
                },
                style,
            ]}>
            <Text
                style={[
                    TextStyles.semibold17,
                    {
                        color: theme.color.text.main,
                        marginBottom: 20,
                    },
                ]}>
                {title}
            </Text>
            {/* Y-Axis & Graph Container */}
            <StackView
                spacing={0}
                style={{
                    height: graphHeightPercentOfParent,
                    flexDirection: "row",
                }}
                onLayout={onGraphLayout}>
                <StackView
                    spacing={0}
                    style={{ flex: yAxisWidthFlex, marginRight: 18 }}>
                    <StackView
                        spacing={0}
                        style={{
                            justifyContent: "space-between",
                            marginTop:
                                lightningMarginTop +
                                lightningHeight +
                                lightningMarginBottom,
                            height:
                                barHeight -
                                lightningMarginTop -
                                lightningHeight -
                                lightningMarginTop -
                                barBottomPadding,
                        }}>
                        {yAxisLabels.map((item, index) => {
                            return (
                                <Text
                                    style={[
                                        TextStyles.regular12,
                                        { color: theme.color.text.main },
                                    ]}
                                    key={index}>
                                    {item}
                                    {yAxisSuffix}
                                </Text>
                            );
                        })}
                    </StackView>
                </StackView>
                {/* Graph Bars & X-Axis Labels */}
                <StackView
                    spacing={0}
                    style={{
                        flex: graphWidthFlex,
                        alignItems: "center",
                    }}>
                    <ScrollView
                        ref={scrollViewRef}
                        style={{
                            alignSelf: "stretch",
                        }}
                        horizontal
                        showsHorizontalScrollIndicator={false}>
                        <StackView
                            spacing={0}
                            style={{
                                flex: 1,
                                flexDirection: "row",
                            }}>
                            {barParams.map((item, index) => {
                                return <Bar key={index} {...item} />;
                            })}
                        </StackView>
                    </ScrollView>
                </StackView>
            </StackView>

            <View
                style={{
                    marginTop: 17,
                    marginRight: controllerRightMargin,
                    marginBottom: 25,
                    alignItems: "center",
                    alignSelf: "flex-end",
                }}>
                <StackView
                    spacing={16}
                    style={{ flexDirection: "row" }}
                    onLayout={onControllerLayout}>
                    <ImageButton
                        image={BackArrowIcon}
                        imageProps={{
                            fill:
                                dayIndex + 1 < data.length
                                    ? theme.color.blue.brand
                                    : theme.color.components.gray1,
                        }}
                        onPress={() => {
                            pageBarGraph(1);
                        }}
                    />
                    <Text
                        style={[
                            TextStyles.regular15,
                            { color: theme.color.text.deemphasized },
                        ]}>
                        {moment()
                            .subtract(dayIndex, "days")
                            .format("MMMM DD, YYYY")}
                    </Text>
                    <ImageButton
                        image={ForwardArrowIcon}
                        imageProps={{
                            fill:
                                dayIndex > 0
                                    ? theme.color.blue.brand
                                    : theme.color.components.gray1,
                        }}
                        onPress={() => {
                            pageBarGraph(-1);
                        }}
                    />
                </StackView>
                <Text
                    style={[
                        TextStyles.regular15,
                        { color: theme.color.text.deemphasized, marginTop: -2 },
                    ]}>
                    {dayIndex === 0
                        ? "Today"
                        : dayIndex === 1
                        ? "Yesterday"
                        : ""}
                </Text>
            </View>
        </View>
    );
};

export default BarGraph;
