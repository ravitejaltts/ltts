import { observer } from "mobx-react-lite";
import React, { useEffect } from "react";
import { ColorValue } from "react-native";
import { useRootContainer } from "../../context";
import { DownloadState, HowToContentItem } from "../../models/domain/content";
import DownloadProgressView from "../DownloadProgressView";

export const HowToDownloadProgressView: React.FunctionComponent<{
    item: HowToContentItem;
    isEditing?: boolean;
    downloadIconFillColor?: ColorValue;
    progressBackgroundColor?: ColorValue;
}> = observer(
    ({ item, downloadIconFillColor, progressBackgroundColor, isEditing }) => {
        const container = useRootContainer();
        const contentStore = container.stores.content;
        const canDownload = contentStore.howTos.canDownload(item);

        useEffect(() => {
            if (canDownload) {
                contentStore.howTos.loadDownload(item).catch(() => {
                    // Do nothing
                });
            }
        }, [contentStore, canDownload, item]);

        if (!canDownload) {
            return null;
        }

        const file = contentStore.howTos.findCachedFile(item);
        const fileState = file?.state ?? DownloadState.None;
        const fileProgress = file?.progress ?? 0;

        return (
            <DownloadProgressView
                state={fileState}
                progress={fileProgress}
                isEditing={isEditing}
                downloadIconFillColor={downloadIconFillColor}
                progressBackgroundColor={progressBackgroundColor}
                onDownload={() => {
                    contentStore.howTos.startDownload(item);
                }}
                onDelete={() => {
                    contentStore.howTos
                        .deleteDownloadByItemId(item.id)
                        .catch(() => {
                            // Do nothing
                        });
                }}
                onCancel={() => {
                    if (file) {
                        file.cancelDownload();
                    }
                }}
            />
        );
    }
);
