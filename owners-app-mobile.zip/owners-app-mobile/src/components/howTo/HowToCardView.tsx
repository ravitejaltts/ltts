import React, { useState } from "react";
import {
    StyleProp,
    Text,
    TouchableOpacity,
    View,
    ViewStyle,
} from "react-native";
import FastImage from "react-native-fast-image";
import * as ZoneData from "../../constants/ZoneData";
import { useTheme } from "../../context/ThemeContext";
import { HowToContentItem } from "../../models/domain/content";
import { LightTheme, TextStyles } from "../../styles";

export const CARD_HEIGHT = 178;
export const CARD_WIDTH = 140;

const HowToCardView: React.FunctionComponent<{
    zoneId?: string;
    item: HowToContentItem;
    style?: StyleProp<ViewStyle>;
    onPress?: () => void;
}> = ({ zoneId, item, style, onPress }) => {
    const [theme] = useTheme();
    const [validImageResponse, setValidImageResponse] = useState(true);

    if (!zoneId && item.zones?.length) {
        zoneId = item.zones[0];
    }

    let zoneName: string | undefined;

    if (zoneId) {
        zoneName = ZoneData.getName(zoneId);
    }

    let thumbnailUrl = item.item.thumbnailUrl;
    let thumbnailWidth = CARD_WIDTH;

    if (!thumbnailUrl || !validImageResponse) {
        thumbnailUrl = `https://img.youtube.com/vi/${item.item.videoId}/hqdefault.jpg`;
        thumbnailWidth = CARD_HEIGHT * (16 / 9);
    }

    return (
        <TouchableOpacity
            onPress={onPress}
            activeOpacity={0.5}
            style={[
                {
                    flex: 0,
                    width: CARD_WIDTH,
                    height: CARD_HEIGHT,
                    borderRadius: 8,
                    overflow: "hidden",
                    backgroundColor: theme.color.background.elevation1,
                },
                style,
            ]}>
            <View
                style={{
                    flex: 1,
                }}>
                <FastImage
                    resizeMode="cover"
                    style={{
                        width: thumbnailWidth,
                        height: CARD_HEIGHT,
                    }}
                    source={{
                        uri: thumbnailUrl,
                    }}
                    onError={() => {
                        setValidImageResponse(false);
                    }}
                />
                <View
                    style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        paddingVertical: 16,
                        paddingHorizontal: 10,
                        justifyContent: "flex-end",
                        backgroundColor: theme.color.background.alert,
                    }}>
                    {Boolean(zoneName) && (
                        <Text
                            numberOfLines={2}
                            style={[
                                TextStyles.subheading,
                                {
                                    color: LightTheme.color.background
                                        .elevation3,
                                },
                            ]}>
                            {zoneName}
                        </Text>
                    )}

                    <Text
                        numberOfLines={3}
                        style={[
                            TextStyles.cardTitle,
                            {
                                color: theme.color.white,
                            },
                        ]}>
                        {item.item.title}
                    </Text>
                </View>
            </View>
        </TouchableOpacity>
    );
};

export default HowToCardView;
