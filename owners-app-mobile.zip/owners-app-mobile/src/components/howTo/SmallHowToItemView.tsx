import React from "react";
import { Text, TouchableHighlight, View } from "react-native";
import { useRootContainer, useTheme } from "../../context";
import { HowToContentItem } from "../../models/domain/content";
import { TextStyles } from "../../styles";
import * as ZoneData from "../../constants/ZoneData";
import FastImage from "react-native-fast-image";
import { useNavigation } from "@react-navigation/native";
import { HowToDownloadProgressView } from "./HowToDownloadProgressView";
import { HowToZoneScreenNavigationProp } from "../../screens/support";
import { useContentFileSize } from "../../hooks";
import StackView from "../StackView";

const SmallHowToItemView: React.FunctionComponent<{
    zoneId: string;
    item: HowToContentItem;
    isEditing?: boolean;
}> = ({ zoneId, item, isEditing = false }) => {
    const navigation = useNavigation<HowToZoneScreenNavigationProp>();
    const [theme] = useTheme();

    const container = useRootContainer();
    const contentStore = container.stores.content;

    const zoneName = ZoneData.getName(zoneId);

    function onDetails() {
        navigation.navigate("howToDetail", {
            zoneId: zoneId,
            item: item,
        });
    }

    // 16/9 = width / height -> width = height * 16/9
    const thumbnailHeight = 75;
    const thumbnailWidth = (thumbnailHeight * 16) / 9;

    const thumbnailUrl = `https://img.youtube.com/vi/${item.item.videoId}/hqdefault.jpg`;

    const file = contentStore.howTos.findCachedFile(item);
    const fileSize = useContentFileSize(file);

    return (
        <TouchableHighlight
            activeOpacity={0.5}
            underlayColor={theme.color.background.elevation1}
            onPress={onDetails}>
            <View
                style={{
                    flexDirection: "row",
                    paddingVertical: 14,
                    paddingHorizontal: 20,
                }}>
                {/* Thumbnail */}
                <View
                    style={{
                        width: thumbnailWidth,
                        height: thumbnailHeight,
                        borderRadius: 8,
                        backgroundColor: theme.color.background.elevation3,
                        overflow: "hidden",
                    }}>
                    <FastImage
                        style={{
                            width: thumbnailWidth,
                            height: thumbnailHeight,
                        }}
                        source={{
                            uri: thumbnailUrl,
                        }}
                    />
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                position: "absolute",
                                right: 0,
                                bottom: 0,
                                backgroundColor: theme.color.background.alert,
                                color: theme.color.white,
                                padding: 2,
                            },
                        ]}>
                        {item.item.duration}
                    </Text>
                </View>

                {/* Center Content */}
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                        paddingLeft: 12,
                        paddingRight: 8,
                    }}>
                    <Text
                        numberOfLines={2}
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {item.item.title}
                    </Text>

                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {zoneName}
                    </Text>

                    {Boolean(fileSize) && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {fileSize}
                        </Text>
                    )}
                </StackView>

                <View
                    style={{
                        alignSelf: "flex-start",
                    }}>
                    <HowToDownloadProgressView
                        item={item}
                        isEditing={isEditing}
                        downloadIconFillColor={theme.color.blue.brand}
                        progressBackgroundColor={
                            theme.color.background.elevation3
                        }
                    />
                </View>
            </View>
        </TouchableHighlight>
    );
};

export default SmallHowToItemView;
