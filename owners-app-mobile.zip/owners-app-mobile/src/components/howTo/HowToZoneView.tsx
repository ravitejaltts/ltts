import React from "react";
import {
    ScrollView,
    Text,
    TouchableHighlight,
    TouchableOpacity,
    View,
} from "react-native";
import { ChevronRightIcon, ForwardArrowIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { HowToContentItem } from "../../models/domain/content";
import { FontWeight, TextStyles } from "../../styles";
import StackView from "../StackView";
import HowToCardView, { CARD_HEIGHT, CARD_WIDTH } from "./HowToCardView";
import * as ZoneData from "../../constants/ZoneData";

const HowToZoneView: React.FunctionComponent<{
    zoneId: string;
    items: HowToContentItem[];
    navigateToItemDetail: (item: HowToContentItem) => void;
    navigateToZone: (zoneId: string, items: HowToContentItem[]) => void;
}> = ({ zoneId, items, navigateToItemDetail, navigateToZone }) => {
    const [theme] = useTheme();

    const zoneName = ZoneData.getName(zoneId);
    const zoneIcon = ZoneData.getIcon(zoneId);
    const description = ZoneData.getDescription(zoneId);

    const cards: JSX.Element[] = [];

    for (let i = 0; i < items.length; i++) {
        const item = items[i];

        cards.push(
            <HowToCardView
                key={item.id}
                zoneId={zoneId}
                item={item}
                onPress={() => navigateToItemDetail(item)}
            />
        );

        if (i === 2) {
            break;
        }
    }

    if (items.length > 3) {
        cards.push(
            <TouchableOpacity
                key={`see_all_${zoneId}`}
                activeOpacity={0.5}
                onPress={() => navigateToZone(zoneId, items)}>
                <View
                    style={{
                        width: CARD_WIDTH,
                        height: CARD_HEIGHT,
                        backgroundColor: theme.color.background.elevation3,
                        padding: 16,
                        borderRadius: 8,
                    }}>
                    <ForwardArrowIcon fill={theme.color.red.brand.toString()} />

                    <Text
                        style={{
                            color: theme.color.text.main,
                            fontSize: 16,
                            fontWeight: FontWeight.Semibold,
                            letterSpacing: -0.34,
                        }}>
                        See All {zoneName} Videos
                    </Text>
                </View>
            </TouchableOpacity>
        );
    }

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={() => navigateToZone(zoneId, items)}>
            <View
                style={{
                    paddingVertical: 14,
                }}>
                {/* Header Section */}
                <StackView
                    spacing={4}
                    style={{
                        paddingHorizontal: 20,
                    }}>
                    {/* Top Row: Icon, Zone Name, Chevron */}
                    <View
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                            marginBottom: 4,
                        }}>
                        {/* Zone Icon */}
                        <View
                            style={{
                                width: 32,
                                height: 32,
                                backgroundColor:
                                    theme.color.background.elevation2,
                                borderRadius: 4,
                                justifyContent: "center",
                                alignItems: "center",
                            }}>
                            {zoneIcon({
                                fill: theme.color.blue.brand.toString(),
                                width: 24,
                                height: 24,
                            })}
                        </View>

                        {/* Zone Name */}
                        <Text
                            style={[
                                TextStyles.listItemLarge,
                                {
                                    flex: 1,
                                    paddingLeft: 12,
                                    paddingRight: 8,
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {zoneName}
                        </Text>

                        <ChevronRightIcon
                            fill={theme.color.text.main.toString()}
                        />
                    </View>

                    {
                        // Description
                        Boolean(description) && (
                            <Text
                                style={[
                                    TextStyles.subheading,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {description}
                            </Text>
                        )
                    }

                    {/* Video Count */}
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {items.length} Videos
                    </Text>
                </StackView>

                <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={{
                        paddingVertical: 12,
                        paddingHorizontal: 20,
                    }}>
                    <StackView
                        spacing={12}
                        style={{
                            flexDirection: "row",
                        }}>
                        {cards}
                    </StackView>
                </ScrollView>
            </View>
        </TouchableHighlight>
    );
};

export default HowToZoneView;
