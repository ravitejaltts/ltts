import React, { useCallback, useState } from "react";
import { ListRenderItemInfo, StyleProp, ViewStyle } from "react-native";
import { useRootContainer, useTheme } from "../../context";
import { useFocusedDependencyEffect, useLogger } from "../../hooks";
import { HowToContentItem } from "../../models/domain/content";
import { Vehicle } from "../../models/domain/vehicle";
import ErrorView from "../ErrorView";
import HorizontalFlatListSection from "../HorizontalFlatListSection";
import LoadingView from "../LoadingView";
import HowToCardView, { CARD_HEIGHT, CARD_WIDTH } from "./HowToCardView";

const HowToSection: React.FunctionComponent<{
    zoneId?: string;
    onItemPressed: (item: HowToContentItem) => void;
    onSeeAllPressed?: (items: HowToContentItem[]) => void;
    style?: StyleProp<ViewStyle>;
}> = ({ zoneId, onItemPressed, onSeeAllPressed, style }) => {
    const container = useRootContainer();

    const [theme] = useTheme();

    const { logError } = useLogger("HowToSection");

    const vehicleStore = container.stores.vehicle;
    const vehicle = vehicleStore.associatedVehicle;
    const modelId = Vehicle.getModelIdOrDefault(vehicle);

    const contentStore = container.stores.content;

    const [isLoading, setIsLoading] = useState(true);
    const [contentItems, setContentItems] = useState<HowToContentItem[]>([]);
    const [error, setError] = useState(false);

    const updateHowToItems = useCallback(() => {
        setIsLoading(true);
        setError(false);

        contentStore
            .getHowToItems(modelId, zoneId)
            .then((items) => {
                setContentItems(items);
            })
            .catch((e) => {
                logError(e);
                setError(true);
            })
            .finally(() => {
                setIsLoading(false);
            });
    }, [contentStore, modelId, zoneId, logError]);

    useFocusedDependencyEffect(updateHowToItems);

    function renderLoading() {
        return (
            <LoadingView
                style={{
                    height: CARD_HEIGHT,
                }}
            />
        );
    }

    function renderItem(info: ListRenderItemInfo<HowToContentItem>) {
        const item = info.item;

        return (
            <HowToCardView
                zoneId={zoneId}
                item={item}
                onPress={() => onItemPressed(item)}
            />
        );
    }

    return error ? (
        <ErrorView
            text="No How To's Available"
            onButtonPressed={updateHowToItems}
            style={[
                {
                    height: CARD_HEIGHT,
                },
                style,
            ]}
        />
    ) : contentItems.length > 0 ? (
        <HorizontalFlatListSection
            headerText="How To's"
            data={contentItems}
            isLoading={isLoading}
            renderLoading={renderLoading}
            renderItem={renderItem}
            onSeeAllPressed={() => onSeeAllPressed?.(contentItems)}
            style={[
                { backgroundColor: theme.color.background.elevation3 },
                style,
            ]}
            getItemLayout={(data, index) => ({
                length: CARD_WIDTH,
                offset: CARD_WIDTH * index,
                index,
            })}
        />
    ) : null;
};

export default HowToSection;
