import React from "react";
import {
    Text,
    TouchableHighlight,
    useWindowDimensions,
    View,
} from "react-native";
import FastImage from "react-native-fast-image";
import * as ZoneData from "../../constants/ZoneData";
import { useTheme } from "../../context";
import { HowToContentItem } from "../../models/domain/content";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { HowToDownloadProgressView } from "./HowToDownloadProgressView";

const PADDING_HORIZONTAL = 20;

const LargeHowToItemView: React.FunctionComponent<{
    item: HowToContentItem;
    navigateToItemDetail: (item: HowToContentItem) => void;
}> = ({ item, navigateToItemDetail }) => {
    const [theme] = useTheme();
    const windowDimensions = useWindowDimensions();

    const zoneId = item.zones?.length ? item.zones[0] : undefined;

    let zoneName: string | undefined;

    if (zoneId) {
        zoneName = ZoneData.getName(zoneId);
    }

    let zoneDurationText = zoneName ? `${zoneName} • ` : "";
    zoneDurationText += `${item.item.duration} min`;

    // 16/9 = width / height -> height = width * 9/16
    const thumbnailWidth = windowDimensions.width - 2 * PADDING_HORIZONTAL;
    const thumbnailHeight = (thumbnailWidth * 9) / 16;

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            style={{
                paddingVertical: 14,
                paddingHorizontal: PADDING_HORIZONTAL,
            }}
            onPress={() => navigateToItemDetail(item)}>
            <View>
                {/* Thumbnail */}
                <View
                    style={{
                        width: thumbnailWidth,
                        height: thumbnailHeight,
                        backgroundColor: theme.color.background.elevation2,
                        borderRadius: 8,
                        marginBottom: 16,
                    }}>
                    {item.item.thumbnailUrl && (
                        <FastImage
                            style={{
                                width: thumbnailWidth,
                                height: thumbnailHeight,
                                borderRadius: 8,
                            }}
                            source={{
                                uri: item.item.thumbnailUrl,
                            }}
                        />
                    )}
                </View>

                {/* Content Below Thumbnail */}
                <StackView
                    spacing={8}
                    style={{
                        flex: 1,
                    }}>
                    {/* Top Row */}
                    <View
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                        }}>
                        {/* Title */}
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                {
                                    color: theme.color.text.main,
                                    flex: 1,
                                },
                            ]}>
                            {item.item.title}
                        </Text>

                        <HowToDownloadProgressView
                            item={item}
                            downloadIconFillColor={theme.color.text.main}
                            progressBackgroundColor={
                                theme.color.background.elevation2
                            }
                        />
                    </View>

                    {/* Description */}
                    <Text
                        numberOfLines={2}
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {item.item.description}
                    </Text>

                    {/* Zone and Duration */}
                    <Text
                        style={[
                            TextStyles.subheading,
                            { color: theme.color.text.deemphasized },
                        ]}>
                        {zoneDurationText}
                    </Text>
                </StackView>
            </View>
        </TouchableHighlight>
    );
};

export default LargeHowToItemView;
