import { observer } from "mobx-react-lite";
import React from "react";
import { Platform, Text, TextInput } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import FormTextInput, { FormTextInputProps } from "./FormTextInput";

export const FormVinInput = observer(
    React.forwardRef<TextInput, FormTextInputProps>((props, ref) => {
        const [theme] = useTheme();

        const field = props.field;

        const rightView = (
            <Text
                style={[
                    TextStyles.body,
                    {
                        alignSelf: "center",
                        paddingRight: 10,
                        color:
                            field.text.length < 17
                                ? theme.color.text.deemphasized
                                : theme.color.green.brand,
                        fontFamily:
                            Platform.OS == "ios" ? "Menlo" : "monospace",
                    },
                ]}>
                {`${field.text.length}/17`}
            </Text>
        );

        return (
            <FormTextInput
                ref={ref}
                name="Winnebago VIN"
                placeholder="_________________"
                helperText="17 characters A-Z, 0-9."
                isMonospaced={true}
                autoCapitalize="characters"
                maxLength={17}
                rightView={rightView}
                {...props}
            />
        );
    })
);
