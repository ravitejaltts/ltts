import React, { MutableRefObject, useEffect, useRef, useState } from "react";
import {
    ColorValue,
    NativeSyntheticEvent,
    Text,
    TextInput,
    TextInputKeyPressEventData,
    View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useRootContainer, useTheme } from "../../context";
import { InvalidMfaCodeError, MfaCodeRecentlySentError } from "../../errors";
import { useLogger } from "../../hooks";
import { OktaFactor, OktaFactorType } from "../../models/domain/auth";
import { FontWeight, TextStyles } from "../../styles";
import { delay } from "../../utils";
import { LinkButton } from "../Buttons";
import StackView from "../StackView";

const CODE_LENGTH = 6;

type CodeTextInputProps = {
    value: string;
    isValid: boolean;
    disabled: boolean;
    factorType: OktaFactorType;
    onChangeValue: (text: string) => void;
    onTextPasted: (text: string) => void;
    onFocus: () => void;
    prevRef?: React.RefObject<TextInput>;
    nextRef?: React.RefObject<TextInput>;
};

const CodeTextInput = React.forwardRef<TextInput | null, CodeTextInputProps>(
    (
        {
            value,
            isValid,
            disabled,
            factorType,
            onChangeValue,
            onTextPasted,
            onFocus,
            prevRef,
            nextRef,
        },
        ref
    ) => {
        const innerRef = useRef<TextInput | null>(null);

        const [theme] = useTheme();

        const [isFocused, setIsFocused] = useState(false);

        const _onChangeText = (text: string) => {
            if (text.length > 1) {
                onTextPasted(text);
                innerRef.current?.blur();
                return;
            }

            onChangeValue(text);

            if (text) {
                if (nextRef?.current) {
                    // Focus next input
                    nextRef.current.focus();
                } else {
                    // Unfocus this input
                    innerRef.current?.blur();
                }
            }
        };

        const _onFocus = () => {
            // Clear the value and set the outline color
            onChangeValue("");
            setIsFocused(true);

            // Forward the event
            onFocus();
        };

        const _onBlur = () => {
            // Set the outline color
            setIsFocused(false);
        };

        const onKeyPress = (
            e: NativeSyntheticEvent<TextInputKeyPressEventData>
        ) => {
            const key = e.nativeEvent.key;

            if (key === "Backspace") {
                // Clear the value
                onChangeValue("");

                if (prevRef?.current) {
                    // Focus the previous input
                    prevRef.current.focus();
                } else {
                    // Unfocus if first input
                    innerRef.current?.blur();
                }
            }
        };

        return (
            <TextInput
                ref={(textInput) => {
                    // Set the inner ref
                    innerRef.current = textInput;

                    // Find out the type of forwarded ref and set it
                    if (typeof ref === "function") {
                        ref(textInput);
                    } else if (ref) {
                        (ref as MutableRefObject<TextInput | null>).current =
                            textInput;
                    }
                }}
                value={value}
                keyboardType="number-pad"
                editable={!disabled}
                textContentType={
                    factorType === OktaFactorType.Sms
                        ? "oneTimeCode"
                        : undefined
                }
                onChangeText={_onChangeText}
                onFocus={_onFocus}
                onBlur={_onBlur}
                onKeyPress={onKeyPress}
                selectionColor={theme.color.blue.brand}
                style={[
                    TextStyles.calloutTitle,
                    {
                        flex: 1,
                        backgroundColor: theme.color.background.default,
                        color: theme.color.text.main,
                        height: 60,
                        borderWidth: 1,
                        borderRadius: 8,
                        borderColor: isValid
                            ? isFocused
                                ? theme.color.text.main
                                : theme.color.dividers.gray1
                            : theme.color.error,
                        textAlign: "center",
                        opacity: disabled ? 0.5 : 1,
                    },
                ]}
            />
        );
    }
);

export const EnterMfaCodeView: React.FunctionComponent<{
    factor: OktaFactor;
    onConfirm: (code: string) => Promise<void>;
    onResend: () => Promise<void>;
    backgroundColor?: ColorValue;
}> = ({ factor, onConfirm, onResend, backgroundColor }) => {
    const [theme] = useTheme();

    const { logMessage, logError } = useLogger("EnterMfaCodeView");
    const container = useRootContainer();
    const authStore = container.stores.auth;
    const user = authStore.user;

    const factorType = factor.factorType;
    let factorValue: string | undefined;

    switch (factor.factorType) {
        case OktaFactorType.Sms:
            factorValue = factor.profile?.phoneNumber;
            if (factorValue && factorValue.length > 2) {
                // Obscure phone number
                factorValue = `(***) ***-**${factorValue.slice(
                    factorValue.length - 2
                )}`;
            }
            break;
        case OktaFactorType.Email:
            factorValue = factor.profile?.email ?? user?.email;
            break;
        default:
            factorValue = "Unsupported factor";
            break;
    }

    const [validationText, setValidationText] = useState("");
    const isValid = !validationText;

    const [isLoading, setIsLoading] = useState(false);

    const getEmptyCodeStrings = () => {
        const codeStrings: string[] = [];
        for (let i = 0; i < CODE_LENGTH; i++) {
            codeStrings.push("");
        }
        return codeStrings;
    };

    const [codeStrings, setCodeStrings] = useState<string[]>(
        getEmptyCodeStrings()
    );

    const inputRefs = useRef<React.RefObject<TextInput>[]>([
        useRef<TextInput>(null),
        useRef<TextInput>(null),
        useRef<TextInput>(null),
        useRef<TextInput>(null),
        useRef<TextInput>(null),
        useRef<TextInput>(null),
    ]).current;

    // Auto-confirm when the code array matches the code length
    useEffect(() => {
        const code = codeStrings.join("");

        logMessage(`Code: '${code}'`);

        if (code.length === CODE_LENGTH) {
            logMessage("Auto-confirm");

            setIsLoading(true);

            onConfirm(code).catch((error) => {
                setIsLoading(false);
                if (error instanceof InvalidMfaCodeError) {
                    setValidationText(
                        "Incorrect code was entered. Please try entering again or resend the code."
                    );
                } else {
                    logError(error);
                    setValidationText(
                        "An error occurred while validating the entered code. Please try entering again or resend the code."
                    );
                }
            });
        }
    }, [codeStrings, logMessage, logError, onConfirm]);

    // Focus the first input after a delay
    useEffect(() => {
        delay(500).then(() => {
            const firstInputRef = inputRefs[0];
            firstInputRef.current?.focus();
        });
    }, [inputRefs]);

    const onTextPasted = (text: string, index: number) => {
        let inputIndex = index;
        for (let textIndex = 0; textIndex < text.length; textIndex++) {
            // Iterate through the text

            if (inputIndex > codeStrings.length - 1) {
                // We've reached the end of the available inputs
                break;
            }

            const value = text[textIndex];

            codeStrings[inputIndex] = value;

            inputIndex++;
        }

        setCodeStrings([...codeStrings]);
    };

    const onFocus = () => {
        // Clear the validation state when focusing
        if (!isValid) {
            clearValidation();
        }
    };

    const clearValidation = () => {
        setCodeStrings(getEmptyCodeStrings());
        setValidationText("");
    };

    const _onResend = () => {
        setIsLoading(true);
        clearValidation();

        onResend()
            .then(() => {
                setIsLoading(false);
            })
            .catch((error) => {
                setIsLoading(false);

                if (error instanceof MfaCodeRecentlySentError) {
                    setValidationText(error.message);
                } else {
                    logError(error);
                    setValidationText(
                        "An error occurred while resending the code. Please try again."
                    );
                }
            });
    };

    const codeTextInputs: React.ReactNode[] = [];

    for (let index = 0; index < CODE_LENGTH; index++) {
        const ref = inputRefs[index];

        let nextRef;
        if (index < inputRefs.length - 1) {
            nextRef = inputRefs[index + 1];
        }

        let prevRef;
        if (index > 0) {
            prevRef = inputRefs[index - 1];
        }

        const value = codeStrings[index];

        codeTextInputs.push(
            <CodeTextInput
                key={index}
                prevRef={prevRef}
                ref={ref}
                nextRef={nextRef}
                isValid={isValid}
                disabled={isLoading}
                factorType={factorType}
                value={value}
                onChangeValue={(text) => {
                    codeStrings[index] = text;
                    setCodeStrings([...codeStrings]);
                }}
                onTextPasted={(text) => onTextPasted(text, index)}
                onFocus={onFocus}
            />
        );
    }

    return (
        <KeyboardAwareScrollView
            keyboardDismissMode="on-drag"
            keyboardShouldPersistTaps="never"
            style={{
                backgroundColor:
                    backgroundColor ?? theme.color.background.default,
            }}
            contentContainerStyle={{
                flexGrow: 1,
                paddingTop: 36,
                paddingBottom: 40,
                paddingHorizontal: 20,
            }}>
            <StackView spacing={12}>
                <Text
                    style={[
                        TextStyles.calloutTitle,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    Enter Security Code
                </Text>

                <View>
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Please enter the {CODE_LENGTH}-digit code sent to:
                    </Text>
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                fontWeight: FontWeight.Semibold,
                                color: theme.color.text.main,
                            },
                        ]}>
                        {factorValue}
                    </Text>
                </View>

                <StackView
                    spacing={10}
                    style={{
                        flexDirection: "row",
                        paddingTop: 16,
                    }}>
                    {codeTextInputs}
                </StackView>

                {!isValid && (
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.error,
                            },
                        ]}>
                        {validationText}
                    </Text>
                )}
            </StackView>

            <View style={{ flex: 1 }} />

            <View>
                <Text
                    style={[
                        TextStyles.body,
                        {
                            color: theme.color.text.main,
                            textAlign: "center",
                        },
                    ]}>
                    Didn't receive a code?
                </Text>
                <LinkButton
                    text="Resend Code"
                    disabled={isLoading}
                    onPress={_onResend}
                />
            </View>

            <View style={{ flex: 3 }} />
        </KeyboardAwareScrollView>
    );
};
