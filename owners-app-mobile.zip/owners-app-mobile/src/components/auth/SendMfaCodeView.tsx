import React, { useState } from "react";
import { Pressable, ScrollView, Text } from "react-native";
import { PrimaryButton, StackView } from "..";
import { useTheme } from "../../context";
import { useLogger, useStatusBar } from "../../hooks";
import { OktaFactor, OktaFactorType } from "../../models/domain/auth";
import { TextStyles } from "../../styles";
import { RadioButton } from "../newButtons";

export const SendMfaCodeView: React.FunctionComponent<{
    factors: OktaFactor[];
    selectedFactor?: OktaFactor;
    onSelectionChanged: (factor: OktaFactor) => void;
    sendCode: () => Promise<void>;
}> = ({ factors, selectedFactor, onSelectionChanged, sendCode }) => {
    const [theme] = useTheme();
    useStatusBar();
    const { logError } = useLogger("SendMfaCodeView");

    const [isSendingCode, setIsSendingCode] = useState(false);
    const [errorText, setErrorText] = useState("");

    const next = () => {
        setErrorText("");
        setIsSendingCode(true);

        sendCode()
            .catch((error) => {
                setErrorText(
                    "We encountered an error while sending the code. Please try again."
                );
                logError(error);
            })
            .finally(() => {
                setIsSendingCode(false);
            });
    };

    return (
        <ScrollView
            style={{
                backgroundColor: theme.color.background.elevation3,
            }}
            contentContainerStyle={{
                flexGrow: 1,
                paddingTop: 40,
                paddingBottom: 40,
                paddingHorizontal: 20,
            }}>
            <StackView
                spacing={40}
                style={{
                    flex: 1,
                }}>
                <StackView spacing={16}>
                    <Text
                        style={[
                            TextStyles.sectionBreak,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Select how you'd like to receive your authentication
                        code.
                    </Text>

                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        Using two-factor authentication makes your account more
                        secure by requiring you to enter a code when you log in
                        on a new device.
                    </Text>
                </StackView>

                <StackView spacing={20}>
                    {factors.map((factor) => {
                        const { id, factorType, profile } = factor;
                        const isSelected = factor === selectedFactor;

                        let name: string;
                        let description: string | undefined;

                        switch (factorType) {
                            case OktaFactorType.Sms:
                                name = "Text Message (SMS)";

                                let phoneNumber = profile?.phoneNumber;

                                if (phoneNumber && phoneNumber.length > 1) {
                                    phoneNumber = `(***) ***-**${phoneNumber.slice(
                                        phoneNumber.length - 2
                                    )}`;
                                    description = `We'll send a text message to\n${phoneNumber}`;
                                }
                                break;
                            case OktaFactorType.Email:
                                name = "Email";
                                description =
                                    "We'll send a code to your account email.";
                                break;
                            default:
                                name = "Unsupported Factor";
                                description = "This factor is unsupported.";
                                break;
                        }

                        return (
                            <Pressable
                                key={id}
                                disabled={isSendingCode}
                                onPress={() => onSelectionChanged(factor)}>
                                <StackView
                                    spacing={8}
                                    style={{
                                        flexDirection: "row",
                                    }}>
                                    <RadioButton
                                        size={24}
                                        isSelected={isSelected}
                                        disabled={isSendingCode}
                                    />

                                    <StackView
                                        spacing={8}
                                        style={{
                                            flex: 1,
                                        }}>
                                        <Text
                                            style={[
                                                TextStyles.listItemSmall,
                                                {
                                                    color: isSendingCode
                                                        ? theme.color.text
                                                              .deemphasized
                                                        : theme.color.text.main,
                                                },
                                            ]}>
                                            {name}
                                        </Text>

                                        {Boolean(description) && (
                                            <Text
                                                style={[
                                                    TextStyles.body,
                                                    {
                                                        color: isSendingCode
                                                            ? theme.color.text
                                                                  .deemphasized
                                                            : theme.color.text
                                                                  .main,
                                                    },
                                                ]}>
                                                {description}
                                            </Text>
                                        )}
                                    </StackView>
                                </StackView>
                            </Pressable>
                        );
                    })}
                </StackView>

                <StackView
                    spacing={12}
                    style={{
                        flex: 1,
                        justifyContent: "flex-end",
                    }}>
                    <Text
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.error,
                            },
                        ]}>
                        {errorText}
                    </Text>
                    <PrimaryButton
                        text="Next"
                        disabled={isSendingCode}
                        onPress={next}
                    />
                </StackView>
            </StackView>
        </ScrollView>
    );
};
