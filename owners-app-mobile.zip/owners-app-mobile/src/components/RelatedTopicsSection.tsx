import React from "react";
import { Text, View } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { LinkButton } from "./Buttons";
import LabeledRow from "./LabeledRow";
import StackSection from "./StackSection";

const RelatedTopicsSection: React.FunctionComponent<{
    header: string;
    data: { title: string }[];
}> = ({ header, data }) => {
    const [theme] = useTheme();

    return (
        <View>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    paddingBottom: 3,
                }}>
                <Text
                    style={[
                        TextStyles.contentEyebrow,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {header}
                </Text>
                <LinkButton
                    text="See All"
                    onPress={() => {
                        console.log("See all pressed");
                    }}
                />
            </View>

            <StackSection>
                {data.map((row, index) => (
                    <LabeledRow
                        key={index.toString()}
                        style={{
                            backgroundColor: theme.color.background.elevation2,
                        }}
                        leftText={row.title}
                        leftTextStyle={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.main,
                            },
                        ]}
                        onPress={() => {
                            console.log(`Topic pressed: ${row.title}`);
                        }}
                    />
                ))}
            </StackSection>
        </View>
    );
};

export default RelatedTopicsSection;
