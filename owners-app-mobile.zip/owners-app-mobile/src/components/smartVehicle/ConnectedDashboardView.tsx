import { useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React from "react";
import { View } from "react-native";
import { useTheme } from "../../context";
import { useFeatureFlag } from "../../hooks";
import { FeatureFlagKey } from "../../models/domain/featureFlag";
import { SmartVehicle } from "../../models/domain/vehicle";
import { SmartVehicleDashboardScreenNavigationProp } from "../../screens/dashboard";
import GridView from "../GridView";
import RoutePlannerCard from "../RoutePlannerCard";
import StackView from "../StackView";
import { DashboardThermostatSection } from "../climate";
import { DashboardEnergySection } from "../energy";
import { BatteryProgressWidget } from "../energy/battery";
import { SystemSwitchSection } from "../systems";
import { WaterTankProgressWidget } from "../water";
import SmartVehicleSectionHeader from "./SmartVehicleSectionHeader";
import { VehicleConnectionState } from "../../models/domain/connection";

export const ConnectedDashboardView: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
}> = observer(({ smartVehicle }) => {
    const [theme] = useTheme();
    const navigation =
        useNavigation<SmartVehicleDashboardScreenNavigationProp>();

    const eRv2PilotFlagEnabled = useFeatureFlag(FeatureFlagKey.Erv2Pilot);

    const isDashboardDisabled =
        smartVehicle.connectionState !== VehicleConnectionState.Connected ||
        smartVehicle.isCloudDeviceDisconnected ||
        smartVehicle.isCloudInactiveSub;

    const isPilotProgram = smartVehicle.isPilotProgram;

    const waterStore = smartVehicle.water;
    const waterTanks = waterStore.tanks;

    const climateStore = smartVehicle.climate;
    const thermostat = climateStore.thermostat;
    const airConditioner = climateStore.airConditioner;

    const energyStore = smartVehicle.energy;
    const batteryManager = energyStore.batteryManager;

    return (
        <View>
            {/* eRV2 Pilot Program */}
            {eRv2PilotFlagEnabled && isPilotProgram && (
                <View style={{ paddingHorizontal: 20 }}>
                    <RoutePlannerCard
                        style={{
                            marginBottom: 32,
                            borderWidth: 1,
                            borderColor: theme.color.dividers.gray1,
                        }}
                        onPress={() => {
                            navigation.navigate("routePlanningTools");
                        }}
                    />
                </View>
            )}
            <StackView spacing={32}>
                {/* Progress Widgets */}
                <GridView
                    columns={2}
                    rowSpacing={12}
                    columnSpacing={12}
                    style={{
                        paddingHorizontal: 20,
                    }}>
                    {batteryManager && (
                        <BatteryProgressWidget
                            batteryManager={batteryManager}
                            disabled={isDashboardDisabled}
                        />
                    )}

                    {waterTanks.map((system) => (
                        <WaterTankProgressWidget
                            key={system.instance}
                            tank={system}
                            disabled={isDashboardDisabled}
                        />
                    ))}
                </GridView>

                {/* Thermostat Section */}
                {thermostat && airConditioner && (
                    <StackView
                        spacing={12}
                        style={{
                            paddingHorizontal: 20,
                        }}>
                        <SmartVehicleSectionHeader
                            title="Thermostat"
                            disabled={isDashboardDisabled}
                            onPress={() => {
                                navigation.navigate("climate");
                            }}
                        />

                        <DashboardThermostatSection
                            smartVehicle={smartVehicle}
                            thermostat={thermostat}
                            airConditioner={airConditioner}
                            disabled={isDashboardDisabled}
                        />
                    </StackView>
                )}

                {/* Systems Section */}
                <StackView spacing={12}>
                    <SmartVehicleSectionHeader
                        title="Systems"
                        disabled={isDashboardDisabled}
                        onPress={() => {
                            navigation.navigate("systems");
                        }}
                        style={{
                            paddingHorizontal: 20,
                        }}
                    />

                    <SystemSwitchSection disabled={isDashboardDisabled} />
                </StackView>

                {/* Energy Management Section */}
                <View
                    style={{
                        paddingHorizontal: 20,
                    }}>
                    <DashboardEnergySection
                        smartVehicle={smartVehicle}
                        disabled={isDashboardDisabled}
                    />
                </View>
            </StackView>
        </View>
    );
});
