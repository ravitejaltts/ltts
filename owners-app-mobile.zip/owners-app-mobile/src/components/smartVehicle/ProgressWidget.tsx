import React from "react";
import {
    ColorValue,
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { WarningFillIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import { MathUtils } from "../../utils";
import StackView from "../StackView";

type ProgressWidgetProps = {
    name: string;
    title: string;
    subtitle: string;
    progress: number;
    barProgress?: number;
    // Determines progress bar color at certain intervals.
    // As the resource is used, which direction does the progress bar move?
    progressDirection: "up" | "down";
    icon: React.FunctionComponent<SvgProps>;
    onPress?: () => void;
    error?: boolean;
    disabled?: boolean;
    style?: StyleProp<ViewStyle>;
};

const ProgressWidget: React.FunctionComponent<ProgressWidgetProps> = ({
    name,
    subtitle,
    title,
    progress,
    barProgress = progress,
    progressDirection,
    icon,
    onPress,
    error = false,
    disabled = false,
    style,
}) => {
    const [theme] = useTheme();

    let progressBarColor: ColorValue;
    const progressEval = progressDirection === "down" ? 1 - progress : progress;

    if (disabled) {
        progressBarColor = theme.color.components.gray1;
    } else if (progressEval < 0.75) {
        progressBarColor = theme.color.green.light;
    } else if (progressEval < 0.9) {
        progressBarColor = theme.color.yellow.default;
    } else {
        progressBarColor = theme.color.error;
    }

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={onPress}
            disabled={disabled}
            style={[
                {
                    paddingVertical: 12,
                    paddingLeft: error ? 12 : 16,
                    paddingRight: 16,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    backgroundColor: theme.color.background.elevation3,
                },
                style,
            ]}>
            <StackView
                spacing={error ? 8 : 12}
                style={{
                    flexDirection: "row",
                }}>
                {/* Progress Bar Column */}
                {error ? (
                    <View
                        style={{
                            height: 24,
                            width: 24,
                            justifyContent: "center",
                            alignItems: "center",
                            borderRadius: 4,
                            backgroundColor: theme.color.background.elevation2,
                        }}>
                        <WarningFillIcon
                            width={18}
                            height={18}
                            fill={
                                disabled
                                    ? theme.color.text.deemphasized
                                    : theme.color.error
                            }
                        />
                    </View>
                ) : (
                    <View
                        style={{
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        {/* Background */}
                        <View
                            style={{
                                width: 6,
                                height: 52,
                                borderRadius: 3,
                                backgroundColor:
                                    theme.color.background.elevation1,
                                justifyContent: "flex-end",
                            }}>
                            {/* Progress */}
                            <View
                                style={{
                                    width: 6,
                                    height: MathUtils.clamp(
                                        barProgress * 52,
                                        6,
                                        52
                                    ),
                                    borderRadius: 3,
                                    backgroundColor: progressBarColor,
                                }}
                            />
                        </View>
                    </View>
                )}

                {/* Data Column */}
                <View
                    style={{
                        flex: 1,
                    }}>
                    {/* Icon and Name */}
                    <StackView
                        spacing={2}
                        style={{
                            flexDirection: "row",
                            paddingBottom: 2,
                        }}>
                        {icon({
                            width: 16,
                            height: 16,
                            fill: theme.color.text.deemphasized,
                        })}

                        <Text
                            numberOfLines={1}
                            style={[
                                TextStyles.semibold13,
                                {
                                    flexShrink: 1, // Fixes text out of bounds
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {name.toUpperCase()}
                        </Text>
                    </StackView>

                    {/* Title */}
                    <Text
                        numberOfLines={1}
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: disabled
                                    ? theme.color.text.deemphasized
                                    : theme.color.text.main,
                            },
                        ]}>
                        {error ? "Error" : title}
                    </Text>

                    {/* Subtitle */}
                    <Text
                        numberOfLines={1}
                        style={[
                            TextStyles.subheading,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {error ? "Unknown" : subtitle}
                    </Text>
                </View>
            </StackView>
        </TouchableHighlight>
    );
};

export default ProgressWidget;
