import React, { ReactNode } from "react";
import { Text, View } from "react-native";
import { TextStyles } from "../../styles";
import { AnimatedEllipsisText } from "../animated";
import { useTheme } from "../../context";

export const ControlSectionLoadingView: React.FunctionComponent<{
    text: string;
    loading: boolean;
    children?: ReactNode;
}> = ({ text, loading, children }) => {
    const [theme] = useTheme();

    return (
        <View
            style={{
                flexDirection: "row",
            }}>
            <Text
                style={[
                    TextStyles.body,
                    {
                        color: theme.color.text.deemphasized,
                    },
                ]}>
                {text}
            </Text>
            <AnimatedEllipsisText
                animating={loading}
                style={[
                    TextStyles.body,
                    {
                        color: theme.color.text.deemphasized,
                    },
                ]}
            />
            {children}
        </View>
    );
};
