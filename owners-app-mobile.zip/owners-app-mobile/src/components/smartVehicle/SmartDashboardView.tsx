import { observer } from "mobx-react-lite";
import React from "react";
import { View } from "react-native";
import {
    CloudVehicleConnection,
    VehicleConnectionState,
} from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { SkeletonSmartDashboardView } from "../skeleton";
import { ConnectedDashboardView } from "./ConnectedDashboardView";
import { DisconnectedDashboardView } from "./DisconnectedDashboardView";
import { SmartDashboardHeaderView } from "./SmartDashboardHeaderView";
import { SmartDashboardTitleView } from "./SmartDashboardTitleView";
import { useTheme } from "../../context";

export const SmartDashboardView: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
}> = observer(({ smartVehicle }) => {
    const [theme] = useTheme();
    const hasStoredState = smartVehicle.hasStoredState;
    const connection = smartVehicle.connection;
    const connectionState = smartVehicle.connectionState;

    let isSkeleton =
        !hasStoredState &&
        connectionState === VehicleConnectionState.Connecting;

    if (connection instanceof CloudVehicleConnection) {
        isSkeleton = isSkeleton || !connection.isNetworkConnected;
    }

    return isSkeleton ? (
        <View>
            <SmartDashboardTitleView
                smartVehicle={smartVehicle}
                style={{
                    backgroundColor: theme.color.black,
                    paddingHorizontal: 20,
                    paddingTop: 12,
                    paddingBottom: 20,
                }}
            />
            <SkeletonSmartDashboardView />
        </View>
    ) : (
        <View>
            {/* Dashboard Header */}
            <SmartDashboardHeaderView smartVehicle={smartVehicle} />

            {
                // Disconnected/Error State or Connecting/Connected State
                connectionState === VehicleConnectionState.Unpaired ||
                connectionState === VehicleConnectionState.Disconnected ? (
                    <DisconnectedDashboardView smartVehicle={smartVehicle} />
                ) : (
                    <ConnectedDashboardView smartVehicle={smartVehicle} />
                )
            }
        </View>
    );
});
