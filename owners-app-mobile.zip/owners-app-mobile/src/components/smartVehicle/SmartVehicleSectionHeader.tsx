import React from "react";
import { StyleProp, Text, TouchableOpacity, ViewStyle } from "react-native";
import { StackView } from "..";
import { ChevronRightIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";

const SmartVehicleSectionHeader: React.FunctionComponent<{
    title: string;
    subtitle?: string;
    rightText?: string;
    disabled?: boolean;
    onPress?: () => void;
    style?: StyleProp<ViewStyle>;
}> = ({ title, subtitle, rightText, disabled, onPress, style }) => {
    const [theme] = useTheme();

    return (
        <TouchableOpacity
            activeOpacity={0.5}
            onPress={onPress}
            disabled={disabled || !onPress}
            style={style}>
            <StackView
                spacing={12}
                style={{
                    flexDirection: "row",
                    alignItems: subtitle ? "flex-start" : "center",
                }}>
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: disabled
                                    ? theme.color.text.deemphasized
                                    : theme.color.text.main,
                            },
                        ]}>
                        {title}
                    </Text>

                    {Boolean(subtitle) && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {subtitle}
                        </Text>
                    )}
                </StackView>

                {rightText && (
                    <Text
                        style={[
                            TextStyles.subheading,
                            { color: theme.color.text.deemphasized },
                        ]}>
                        {rightText}
                    </Text>
                )}

                {onPress && (
                    <ChevronRightIcon
                        fill={
                            disabled
                                ? theme.color.text.deemphasized
                                : theme.color.text.main
                        }
                    />
                )}
            </StackView>
        </TouchableOpacity>
    );
};

export default SmartVehicleSectionHeader;
