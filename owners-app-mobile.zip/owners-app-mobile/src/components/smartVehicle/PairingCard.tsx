import { observer } from "mobx-react-lite";
import React, { useEffect, useState } from "react";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import { BluetoothDetailIcon, CloseIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { VehicleConnectionState } from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";
import { ArrowButton, ImageButton } from "../Buttons";

type PairingCardProps = {
    pairVehicle: () => void;
    style?: StyleProp<ViewStyle>;
};

const PairingCard: React.FunctionComponent<PairingCardProps> = ({
    pairVehicle,
    style,
}) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const vehicleStore = container.stores.vehicle;
    const vehicle = vehicleStore.associatedVehicle;
    const isUnpaired =
        vehicle instanceof SmartVehicle &&
        vehicle.connectionState === VehicleConnectionState.Unpaired;

    const [isVisible, setIsVisible] = useState(isUnpaired);

    useEffect(() => {
        setIsVisible(isUnpaired);
    }, [isUnpaired]);

    function close() {
        setIsVisible(false);
    }

    return isVisible ? (
        <View
            style={[
                {
                    paddingHorizontal: 20,
                    paddingTop: 20,
                    paddingBottom: 8,
                    borderRadius: 8,
                    backgroundColor: theme.color.background.elevation2,
                },
                style,
            ]}>
            <BluetoothDetailIcon
                fill={theme.color.background.elevation1}
                width={100}
                height={100}
                style={{
                    position: "absolute",
                    right: 12,
                    top: 24,
                }}
            />

            <View
                style={{
                    flexDirection: "row",
                }}>
                <Text
                    style={[
                        TextStyles.calloutTitle,
                        {
                            color: theme.color.text.main,
                            flex: 1,
                        },
                    ]}>
                    Connect to Your RV
                </Text>

                <ImageButton
                    image={() => (
                        <CloseIcon
                            fill={theme.color.text.main}
                            width={24}
                            height={24}
                        />
                    )}
                    onPress={close}
                />
            </View>

            <Text
                style={[
                    TextStyles.subheading,
                    {
                        color: theme.color.text.deemphasized,
                        marginTop: 4,
                        marginBottom: 18,
                    },
                ]}>
                Pair your app to access Winnebago Connect
            </Text>

            <ArrowButton
                text="Start Pairing"
                onPress={pairVehicle}
                style={{
                    alignSelf: "flex-start",
                }}
            />
        </View>
    ) : null;
};

export default observer(PairingCard);
