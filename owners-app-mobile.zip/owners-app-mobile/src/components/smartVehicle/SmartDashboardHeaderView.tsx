import { observer } from "mobx-react-lite";
import React, { useEffect, useRef, useState } from "react";
import {
    Animated,
    Easing,
    Text,
    View,
    useWindowDimensions,
} from "react-native";
import FastImage from "react-native-fast-image";
import { Defs, LinearGradient, Rect, Stop, Svg } from "react-native-svg";
import { useRootContainer, useTheme } from "../../context";
import { usePetMinderDashboardHeaderProps } from "../../hooks";
import { VehicleConnectionState } from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { DeviceConnectionButton } from "../newButtons";
import { PetMinderButton, PetMinderDashboardHeaderView } from "../pet";
import { SmartDashboardTitleView } from "./SmartDashboardTitleView";

const AVATAR_HEIGHT = 80;
const AVATAR_OVERLAP = 0.4 * AVATAR_HEIGHT;

export const SmartDashboardHeaderView: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
}> = observer(({ smartVehicle }) => {
    const [theme] = useTheme();
    const { width: screenWidth } = useWindowDimensions();

    const [headerHeight, setHeaderHeight] = useState(100);
    const [contentHeight, setContentHeight] = useState(0);

    const contentFadeRef = useRef(new Animated.Value(0));
    const animatedHeightRef = useRef(new Animated.Value(0));

    const container = useRootContainer();

    const deviceStore = container.stores.device;
    const activeSubscription = deviceStore.activeSubscription;

    const isCloudDeviceDisconnected = smartVehicle.isCloudDeviceDisconnected;

    const vehicleAvatar = smartVehicle.avatar;
    let validAvatarUrl = false;

    if (vehicleAvatar) {
        validAvatarUrl = vehicleAvatar.url.includes("http");
    }

    let avatarWidth = vehicleAvatar?.width;

    if (avatarWidth) {
        avatarWidth = Math.min(screenWidth * 0.4, avatarWidth);
    }

    const isConnected =
        smartVehicle.connectionState === VehicleConnectionState.Connected;

    const features = smartVehicle.features;
    const petMinder = features.petMinder;

    const isPetMinderEngaged = Boolean(petMinder?.isEngaged);
    const isPetMinderOn = Boolean(petMinder?.isOn);

    const isPetMinderVisible =
        isPetMinderOn && // ON
        isConnected && // Connected
        Boolean(activeSubscription); // There is an active subscription

    // Pet minder must be visible and engaged
    const isPetMinderBackgroundVisible =
        isPetMinderVisible && isPetMinderEngaged;

    const alertProps = usePetMinderDashboardHeaderProps();

    useEffect(() => {
        if (contentHeight <= 0) {
            return;
        }

        if (isPetMinderEngaged) {
            Animated.parallel([
                Animated.timing(animatedHeightRef.current, {
                    toValue: contentHeight,
                    duration: 200,
                    easing: Easing.linear,
                    useNativeDriver: false,
                }),
                Animated.timing(contentFadeRef.current, {
                    toValue: 1,
                    duration: 500,
                    easing: Easing.linear,
                    useNativeDriver: false,
                }),
            ]).start();
        } else {
            Animated.parallel([
                Animated.timing(animatedHeightRef.current, {
                    toValue: 0,
                    duration: 200,
                    easing: Easing.linear,
                    useNativeDriver: false,
                }),
                Animated.timing(contentFadeRef.current, {
                    toValue: 0,
                    duration: 100,
                    easing: Easing.linear,
                    useNativeDriver: false,
                }),
            ]).start();
        }
    }, [isPetMinderEngaged, contentHeight]);

    return (
        <View>
            {/* Header Content */}
            <View
                style={{
                    overflow: "hidden",
                    paddingBottom: validAvatarUrl ? AVATAR_OVERLAP : 0,
                }}
                onLayout={(e) => {
                    const { height } = e.nativeEvent.layout;
                    setHeaderHeight(height);
                }}>
                {/* Background */}
                {isPetMinderBackgroundVisible ? (
                    <Svg
                        width={screenWidth}
                        height={headerHeight}
                        style={{
                            position: "absolute",
                        }}>
                        <Defs>
                            <LinearGradient
                                id="gradient"
                                x1={0.25}
                                y1={0.5}
                                x2={0.5}
                                y2={contentHeight < 100 ? 2.9 : 2.35}>
                                <Stop
                                    offset={0}
                                    stopColor={theme.color.black}
                                />
                                <Stop
                                    offset={1}
                                    stopColor={alertProps.color}
                                    stopOpacity={1}
                                />
                            </LinearGradient>
                        </Defs>

                        <Rect
                            x={0}
                            y={0}
                            width={screenWidth}
                            height={headerHeight}
                            fill={"url(#gradient)"}
                        />
                    </Svg>
                ) : (
                    <View
                        style={{
                            position: "absolute",
                            width: screenWidth,
                            height: headerHeight,
                            backgroundColor: theme.color.black,
                        }}
                    />
                )}

                {/* Content */}
                <View
                    style={{
                        paddingTop: 12,
                        paddingBottom: 16,
                        paddingHorizontal: 20,
                    }}>
                    {/* Logo & Notifications Row */}
                    <SmartDashboardTitleView smartVehicle={smartVehicle} />

                    {/* Pet Minder Content */}
                    {isPetMinderVisible && (
                        <View>
                            <Animated.View
                                style={{
                                    height: animatedHeightRef.current,
                                }}
                            />

                            <Animated.View
                                style={{
                                    position: "absolute",
                                    width: screenWidth - 40,
                                    opacity: contentFadeRef.current,
                                }}>
                                <PetMinderDashboardHeaderView
                                    {...alertProps}
                                    style={{
                                        paddingTop: 16,
                                    }}
                                    onLayout={(e) => {
                                        const { height } = e.nativeEvent.layout;
                                        setContentHeight(height);
                                    }}
                                />
                            </Animated.View>
                        </View>
                    )}
                </View>
            </View>

            {/* Everything Below Header */}
            <View
                style={{
                    flexDirection: "row",
                    paddingHorizontal: 20,
                    paddingBottom: 16,
                }}>
                {/* Avatar Image */}
                {validAvatarUrl && (
                    <FastImage
                        resizeMode="contain"
                        source={{ uri: vehicleAvatar?.url }}
                        style={{
                            position: "absolute",
                            height: AVATAR_HEIGHT,
                            width: avatarWidth,
                            top: -AVATAR_OVERLAP,
                        }}
                    />
                )}

                {/* Avatar & Vehicle Name (Left Column) */}
                <View
                    style={{
                        flex: 1,
                        paddingTop: validAvatarUrl ? 0 : 16,
                    }}>
                    {/* Avatar Filler */}
                    {validAvatarUrl && (
                        <View
                            style={{
                                flex: 1,
                                height: AVATAR_HEIGHT - AVATAR_OVERLAP,
                            }}
                        />
                    )}

                    {/* Vehicle Name and Connection Status */}
                    <StackView
                        spacing={12}
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                        }}>
                        {/* Vehicle Name */}
                        <Text
                            style={[
                                TextStyles.calloutTitle,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {`${smartVehicle.year} ${
                                smartVehicle.seriesName
                            } ${smartVehicle.floorPlan.substring(3)}`}
                        </Text>

                        {/* Connection Status */}
                        <DeviceConnectionButton smartVehicle={smartVehicle} />
                    </StackView>
                </View>

                {/* Pet Minder Button (Right Column) */}
                {isPetMinderVisible && (
                    <View
                        style={{
                            paddingTop: 16,
                        }}>
                        <PetMinderButton disabled={isCloudDeviceDisconnected} />
                    </View>
                )}
            </View>
        </View>
    );
});
