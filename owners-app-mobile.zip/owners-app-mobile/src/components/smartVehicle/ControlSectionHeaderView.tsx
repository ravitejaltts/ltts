import React from "react";
import { Text } from "react-native";
import { TextStyles } from "../../styles";
import { useTheme } from "../../context";
import { ImageButton, StackView } from "..";
import { CloseIcon, InfoOutlineIcon } from "../../assets/icons";
import { SvgProps } from "react-native-svg";

export const ControlSectionHeaderView: React.FunctionComponent<{
    title: string;
    icon: React.FunctionComponent<SvgProps>;
    bodyText?: string;
    bodyView?: React.ReactNode;
    onInfo?: () => void;
    onClose?: () => void;
}> = ({ title, bodyText, icon, bodyView, onInfo, onClose }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={10}
            style={{
                padding: 16,
            }}>
            <StackView
                spacing={8}
                style={{
                    flexDirection: "row",
                }}>
                {icon({
                    width: 20,
                    height: 20,
                })}
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            flex: onInfo ? 0 : 1,
                            color: theme.color.text.main,
                        },
                    ]}>
                    {title}
                </Text>
                {onInfo && (
                    <ImageButton
                        onPress={onInfo}
                        image={InfoOutlineIcon}
                        imageProps={{
                            width: 20,
                            height: 20,
                            fill: theme.color.blue.brand,
                        }}
                    />
                )}
                {onClose ? (
                    <ImageButton
                        onPress={onClose}
                        image={() => <CloseIcon fill={theme.color.text.main} />}
                    />
                ) : null}
            </StackView>
            {bodyView ? (
                bodyView
            ) : bodyText ? (
                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.text.deemphasized,
                        },
                    ]}>
                    {bodyText}
                </Text>
            ) : null}
        </StackView>
    );
};
