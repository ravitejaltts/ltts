import { NetInfoStateType, useNetInfo } from "@react-native-community/netinfo";
import { observer } from "mobx-react-lite";
import React from "react";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import { SvgProps } from "react-native-svg";
import { BluetoothOffIcon, WifiOffIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import {
    UnexpectedBleManagerStateError,
    VehicleDiscoveryFailedError,
} from "../../errors";
import { useLogger } from "../../hooks";
import { VehicleConnectionType } from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";
import { LinkButton, PrimaryButton } from "../Buttons";
import StackView from "../StackView";

export const ConnectionErrorCard: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
    style?: StyleProp<ViewStyle>;
}> = observer(({ smartVehicle, style }) => {
    const [theme] = useTheme();
    const { logError } = useLogger("ConnectionErrorCard");
    const networkState = useNetInfo();
    const networkType = networkState.type;

    const error = smartVehicle.connectionError;

    let errorTitle: string;

    if (error) {
        errorTitle = "Connection Unsuccessful";
    } else {
        errorTitle = "Connect to your Coach";
    }

    let errorDescription: string;

    if (error instanceof UnexpectedBleManagerStateError) {
        errorDescription =
            "Please go to your phone's settings and enable Bluetooth.";
    } else if (error instanceof VehicleDiscoveryFailedError) {
        errorDescription =
            "It looks like you're out of Bluetooth range, and we can't connect.";
    } else if (error) {
        errorDescription = "We're unable to connect. Please try again.";
    } else {
        errorDescription = "Let's get you reconnected to your coach.";
    }

    let icon: React.FunctionComponent<SvgProps>;
    let canTryAgain: boolean;
    let changeConnectionText: string | undefined;
    let changeConnectionType: VehicleConnectionType | undefined;

    // Based on the last attempted connection type...
    switch (smartVehicle.storedConnectionType) {
        case VehicleConnectionType.Bluetooth:
            icon = BluetoothOffIcon;
            canTryAgain = true;

            // If the user can connect via cloud to a paired device,
            // suggest it
            if (smartVehicle.isDevicePaired) {
                switch (networkType) {
                    case NetInfoStateType.cellular:
                        changeConnectionText = "Connect via Cellular Network";
                        changeConnectionType = VehicleConnectionType.Cloud;
                        break;
                    case NetInfoStateType.wifi:
                        changeConnectionText = "Connect via WiFi";
                        changeConnectionType = VehicleConnectionType.Cloud;
                        break;
                    default:
                        // Do not offer a button to change the connection type
                        break;
                }
            }
            break;
        case VehicleConnectionType.Cloud:
            icon = WifiOffIcon;

            // Can only try again if we are paired to device
            // and the phone is not in airplane mode
            canTryAgain =
                smartVehicle.isDevicePaired &&
                networkType !== NetInfoStateType.none;

            changeConnectionText = "Connect via Bluetooth";
            changeConnectionType = VehicleConnectionType.Bluetooth;
            break;
        case VehicleConnectionType.Mock:
        case VehicleConnectionType.Local:
        default:
            icon = WifiOffIcon;
            canTryAgain = true;
            break;
    }

    let changeConnectionButton: React.ReactNode;

    if (changeConnectionText && changeConnectionType) {
        const changeConnection = () => {
            if (!changeConnectionType) {
                return;
            }
            smartVehicle.connect(changeConnectionType, true).catch((e) => {
                logError(e);
            });
        };

        if (canTryAgain) {
            changeConnectionButton = (
                <LinkButton
                    text={changeConnectionText}
                    onPress={changeConnection}
                />
            );
        } else {
            changeConnectionButton = (
                <PrimaryButton
                    text={changeConnectionText}
                    onPress={changeConnection}
                />
            );
        }
    }

    return (
        <View
            style={[
                {
                    backgroundColor: theme.color.background.elevation2,
                    padding: 20,
                    borderRadius: 8,
                },
                style,
            ]}>
            {icon({
                width: 24,
                height: 24,
                fill: theme.color.text.main,
                style: {
                    alignSelf: "center",
                    marginBottom: 16,
                },
            })}

            <Text
                style={[
                    TextStyles.sectionBreak,
                    {
                        color: theme.color.text.main,
                        textAlign: "center",
                    },
                ]}>
                {errorTitle}
            </Text>

            <StackView
                spacing={12}
                style={{
                    paddingTop: 4,
                }}>
                <Text
                    style={[
                        TextStyles.body,
                        {
                            color: theme.color.text.main,
                            textAlign: "center",
                        },
                    ]}>
                    {errorDescription}
                </Text>

                {canTryAgain && (
                    <PrimaryButton
                        text={error ? "Try Again" : "Reconnect"}
                        onPress={() => {
                            // Attempt the connection again with the same connection type
                            smartVehicle
                                .connect(
                                    smartVehicle.storedConnectionType,
                                    true
                                )
                                .catch((e) => {
                                    logError(e);
                                });
                        }}
                    />
                )}

                {changeConnectionButton}
            </StackView>
        </View>
    );
});
