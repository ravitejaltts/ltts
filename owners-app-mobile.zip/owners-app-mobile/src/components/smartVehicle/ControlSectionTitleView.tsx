import React, { ReactNode } from "react";
import { Text, View } from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";

export const ControlSectionTitleView: React.FunctionComponent<{
    title: string;
    subtitle?: string;
    rightView?: ReactNode;
    icon?: ReactNode;
}> = ({ title, subtitle, rightView, icon }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={8}
            style={{
                flexDirection: "row",
                alignItems: "center",
                paddingVertical: 16,
                paddingHorizontal: 20,
            }}>
            {Boolean(icon) && (
                <View
                    style={{
                        alignSelf: "flex-start",
                    }}>
                    {icon}
                </View>
            )}
            <View
                style={{
                    flex: 1,
                }}>
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                            lineHeight: 24, // Fixes UI resizing issue when using the ControlSectionLoadingView
                        },
                    ]}>
                    {title}
                </Text>
                {subtitle ? (
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {subtitle}
                    </Text>
                ) : null}
            </View>

            {rightView}
        </StackView>
    );
};
