import { observer } from "mobx-react-lite";
import React from "react";
import { Text, View } from "react-native";
import { ErrorFillIcon, RefreshIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";
import { DateUtil } from "../../utils";
import { ArrowButton, ImageButton } from "../Buttons";
import StackView from "../StackView";

export const SmartDashboardStatusBarView: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
    isRefreshing: boolean;
    onRefresh: () => void;
    onEssentialsPress: () => void;
}> = observer(
    ({ smartVehicle, isRefreshing, onRefresh, onEssentialsPress }) => {
        const [theme] = useTheme();

        const container = useRootContainer();
        const deviceStore = container.stores.device;
        const subscription = deviceStore.subscription;

        let planText: string;
        if (subscription) {
            planText = "Inactive";
        } else {
            planText = "Essentials";
        }

        const isCloudDeviceDisconnected =
            smartVehicle.isCloudDeviceDisconnected;
        const isCloudEssentials = smartVehicle.isCloudInactiveSub;

        if (!isCloudDeviceDisconnected && !isCloudEssentials) {
            // Cloud device connected
            // Cloud device has active subscription
            return null;
        }

        let displayText = "";

        const lastUpdatedDate = smartVehicle.lastUpdatedDate;

        if (lastUpdatedDate) {
            if (!DateUtil.isSameDay(Date.now(), lastUpdatedDate.getTime())) {
                const dateText = lastUpdatedDate.toLocaleDateString("en-US", {
                    day: "numeric",
                    month: "numeric",
                    year: "2-digit",
                    hour: "numeric",
                    minute: "numeric",
                });

                displayText = `Last Updated ${dateText}`;
            } else {
                const timeText = lastUpdatedDate.toLocaleTimeString("en-US", {
                    hour: "numeric",
                    minute: "numeric",
                });

                displayText = `Last Updated at ${timeText}`;
            }
        } else if (isCloudDeviceDisconnected) {
            displayText = "RV disconnected";
        } else {
            displayText = "RV data not up to date";
        }

        return (
            <StackView
                spacing={4}
                style={{
                    paddingHorizontal: 20,
                    paddingVertical: 14,
                    backgroundColor: theme.color.black,
                }}>
                <StackView
                    spacing={8}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    {isCloudDeviceDisconnected && (
                        <ErrorFillIcon
                            width={24}
                            height={24}
                            fill={theme.color.white}
                        />
                    )}

                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.white,
                                flex: 1,
                            },
                        ]}>
                        {displayText}
                    </Text>

                    {isCloudDeviceDisconnected && (
                        <ImageButton
                            disabled={isRefreshing}
                            onPress={onRefresh}
                            image={RefreshIcon}
                            imageProps={{
                                width: 24,
                                height: 24,
                                fill: theme.color.white,
                            }}
                        />
                    )}
                </StackView>

                {isCloudEssentials && (
                    <View>
                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    color: theme.color.white,
                                },
                            ]}>
                            Limited Far Field Access with {planText} Plan
                        </Text>
                        <ArrowButton
                            text="Subscribe Now"
                            onPress={onEssentialsPress}
                            textStyle={{
                                color: theme.color.white,
                            }}
                            buttonProps={{
                                fill: theme.color.white,
                            }}
                            style={{
                                alignSelf: "flex-start",
                            }}
                        />
                    </View>
                )}
            </StackView>
        );
    }
);
