import { useNavigation } from "@react-navigation/native";
import React from "react";
import { View } from "react-native";
import { useIsInternetConnected } from "../../hooks";
import { VehicleConnectionState } from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { SmartVehicleDashboardScreenNavigationProp } from "../../screens/dashboard";
import StackView from "../StackView";
import { NetworkConnectivityCard } from "../connectivity";
import { SavedContentStackView } from "../content";
import { DealerHelpCard } from "../dealer";
import { HowToSection } from "../howTo";
import { ConnectionErrorCard } from "./ConnectionErrorCard";
import PairingCard from "./PairingCard";

export const DisconnectedDashboardView: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
}> = ({ smartVehicle }) => {
    const navigation =
        useNavigation<SmartVehicleDashboardScreenNavigationProp>();

    const connectionState = smartVehicle.connectionState;

    const isInternetConnected = useIsInternetConnected();

    return (
        <View>
            <StackView
                spacing={16}
                style={{
                    paddingHorizontal: 20,
                    paddingBottom: 16,
                }}>
                {!isInternetConnected && <NetworkConnectivityCard />}

                {connectionState === VehicleConnectionState.Unpaired && (
                    <PairingCard
                        pairVehicle={() => {
                            navigation.navigate("addVehicle", {
                                screen: "pairingPermission",
                            });
                        }}
                    />
                )}

                {connectionState === VehicleConnectionState.Disconnected && (
                    <ConnectionErrorCard smartVehicle={smartVehicle} />
                )}
            </StackView>

            {isInternetConnected ? (
                <StackView spacing={16}>
                    <HowToSection
                        onItemPressed={(item) => {
                            navigation.navigate("howToDetail", {
                                item,
                            });
                        }}
                        onSeeAllPressed={(items) => {
                            navigation.navigate("howToLanding", {
                                items,
                            });
                        }}
                    />

                    <DealerHelpCard
                        style={{
                            marginHorizontal: 20,
                            marginTop: 16,
                        }}
                        onFindService={() => {
                            navigation.navigate("map");
                        }}
                        onSeeAllFavoriteLocations={() => {
                            navigation.navigate("favoriteLocations");
                        }}
                        navigateToFavorite={(favorite) => {
                            navigation.navigate("dealerLocation", {
                                dealerLocationId: favorite.dealerLocationId,
                            });
                        }}
                    />
                </StackView>
            ) : (
                <SavedContentStackView />
            )}
        </View>
    );
};
