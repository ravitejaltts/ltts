import React from "react";
import { Text } from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import ThemedSwitch from "../ThemedSwitch";

export const ControlSectionSwitchView: React.FunctionComponent<{
    text?: string;
    disabled?: boolean;
    value: boolean;
    onValueChange: (value: boolean) => void;
}> = ({ text, disabled = false, value, onValueChange }) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={16}
            style={{
                flexDirection: "row",
                alignItems: "center",
            }}>
            {Boolean(text) && (
                <Text
                    style={[
                        TextStyles.body,
                        {
                            color: disabled
                                ? theme.color.text.disabled
                                : theme.color.text.deemphasized,
                        },
                    ]}>
                    {text}
                </Text>
            )}
            <ThemedSwitch
                disabled={disabled}
                value={value}
                onValueChange={onValueChange}
            />
        </StackView>
    );
};
