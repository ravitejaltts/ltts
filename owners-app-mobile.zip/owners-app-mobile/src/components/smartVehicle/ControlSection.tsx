import React, { ReactNode } from "react";
import { StyleProp, ViewStyle } from "react-native";
import { useTheme } from "../../context";
import StackView from "../StackView";
import { ControlSectionTitleView } from "./ControlSectionTitleView";

export const ControlSection: React.FunctionComponent<{
    title?: string;
    subtitle?: string;
    rightView?: ReactNode;
    icon?: ReactNode;

    titleView?: ReactNode;
    headerViews?: ReactNode;

    style?: StyleProp<ViewStyle>;
    children?: ReactNode;
}> = ({
    title,
    subtitle,
    rightView,
    icon,
    titleView,
    headerViews,
    style,
    children,
}) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={1}
            spacerColor={theme.color.dividers.gray1}
            style={[
                {
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    borderRadius: 8,
                },
                style,
            ]}>
            {headerViews}

            {titleView ? (
                titleView
            ) : title ? (
                <ControlSectionTitleView
                    title={title}
                    subtitle={subtitle}
                    rightView={rightView}
                    icon={icon}
                />
            ) : null}

            {children}
        </StackView>
    );
};
