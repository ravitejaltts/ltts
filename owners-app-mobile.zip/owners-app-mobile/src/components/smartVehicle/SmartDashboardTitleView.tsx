import { useNavigation } from "@react-navigation/native";
import React from "react";
import { StyleProp, View, ViewStyle } from "react-native";
import { LogoIcon, NotificationFillIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { SmartVehicle } from "../../models/domain/vehicle";
import { SmartVehicleDashboardScreenNavigationProp } from "../../screens/dashboard";
import { ImageButton } from "../Buttons";
import { MobileConnectionButton } from "../newButtons";
import StackView from "../StackView";

export const SmartDashboardTitleView: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
    style?: StyleProp<ViewStyle>;
}> = ({ smartVehicle, style }) => {
    const navigation =
        useNavigation<SmartVehicleDashboardScreenNavigationProp>();
    const [theme] = useTheme();

    const container = useRootContainer();

    const authStore = container.stores.auth;
    const isAuthenticated = authStore.isAuthenticated;

    return (
        <View
            style={[
                {
                    flexDirection: "row",
                    alignItems: "center",
                },
                style,
            ]}>
            <View
                style={{
                    flex: 1,
                }}>
                <LogoIcon fill={theme.color.white} />
            </View>
            <StackView
                spacing={16}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                <MobileConnectionButton smartVehicle={smartVehicle} />
                {isAuthenticated && (
                    <ImageButton
                        image={NotificationFillIcon}
                        imageProps={{
                            fill: theme.color.white,
                            width: 34,
                            height: 34,
                        }}
                        onPress={() => {
                            navigation.navigate("notificationCenter");
                        }}
                    />
                )}
            </StackView>
        </View>
    );
};
