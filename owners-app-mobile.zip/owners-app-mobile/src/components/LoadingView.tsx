import React from "react";
import {
    ActivityIndicator,
    StyleProp,
    Text,
    TextStyle,
    View,
    ViewStyle,
} from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";

const LoadingView: React.FunctionComponent<{
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
}> = ({ style, textStyle }) => {
    const [theme] = useTheme();

    return (
        <View
            style={[
                {
                    height: 100,
                    justifyContent: "center",
                },
                style,
            ]}>
            <Text
                style={[
                    TextStyles.subheading,
                    {
                        color: theme.color.text.deemphasized,
                        textAlign: "center",
                        paddingBottom: 8,
                    },
                    textStyle,
                ]}>
                Loading
            </Text>
            <ActivityIndicator
                animating={true}
                color={theme.color.text.deemphasized}
            />
        </View>
    );
};

export default LoadingView;
