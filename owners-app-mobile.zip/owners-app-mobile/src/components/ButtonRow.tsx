import React, { useState } from "react";
import { ActivityIndicator, Text, TouchableHighlight } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import StackView from "./StackView";

export const ButtonRow: React.FunctionComponent<{
    text: string;
    onPress?: () => void;
    onLongPress?: () => void;
    onPressIn?: () => void;
    onPressOut?: () => void;
    action?: () => Promise<void>;
    isDestructive?: boolean;
    isBusy?: boolean;
    disabled?: boolean;
}> = ({
    text,
    isBusy = false,
    isDestructive = false,
    disabled = false,
    onPress,
    onLongPress,
    onPressIn,
    onPressOut,
    action,
}) => {
    const [theme] = useTheme();

    const [isRunningAction, setIsRunningAction] = useState(false);

    const isDisabled = disabled || isBusy || isRunningAction;

    const _onPress = () => {
        if (onPress) {
            onPress();
        }

        if (action) {
            setIsRunningAction(true);

            action()
                .catch(() => {
                    // Do nothing
                })
                .finally(() => {
                    setIsRunningAction(false);
                });
        }
    };

    return (
        <TouchableHighlight
            disabled={isDisabled}
            underlayColor={theme.color.background.elevation2}
            onPress={_onPress}
            onPressIn={onPressIn}
            onPressOut={onPressOut}
            onLongPress={onLongPress}
            style={{
                backgroundColor: theme.color.background.elevation3,
                paddingVertical: 16,
                paddingHorizontal: 20,
            }}>
            <StackView
                spacing={24}
                style={{
                    opacity: isDisabled ? 0.5 : 1,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                }}>
                <Text
                    style={[
                        TextStyles.body,
                        {
                            flex: 1,
                            color: isDestructive
                                ? theme.color.error
                                : theme.color.blue.brand,
                        },
                    ]}>
                    {text}
                </Text>

                <ActivityIndicator
                    animating={isBusy || isRunningAction}
                    style={{
                        width: 24,
                        height: 24,
                    }}
                />
            </StackView>
        </TouchableHighlight>
    );
};
