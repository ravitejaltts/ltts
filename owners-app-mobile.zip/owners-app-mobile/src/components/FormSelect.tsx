import { observer } from "mobx-react-lite";
import React, { useState } from "react";
import { ColorValue, LayoutChangeEvent, Text, View } from "react-native";
import { useTheme } from "../context";
import { FormFieldValidator } from "../models/ui/form/field";
import { TextStyles } from "../styles";
import Picker, { PickerItem } from "./Picker";

export type FormSelectProps = {
    label?: string;
    placeholder?: string;
    items: PickerItem[];
    field: FormFieldValidator;
    disabled?: boolean;
    onOpen?: () => void;
    onClose?: () => void;
    onLayout?: (event: LayoutChangeEvent) => void;
};

const FormSelect: React.FunctionComponent<FormSelectProps> = observer(
    ({
        label,
        placeholder,
        items,
        field,
        disabled,
        onOpen,
        onClose,
        onLayout,
    }) => {
        const [theme] = useTheme();

        const [isOpen, setIsOpen] = useState(false);

        const isValid = field.isValid;
        const validationText = field.validationText;
        const text = field.text;

        let borderColor: ColorValue;
        if (isValid) {
            borderColor = isOpen
                ? theme.color.text.main
                : theme.color.dividers.gray1;
        } else {
            borderColor = theme.color.error;
        }

        function onChange(newValue: PickerItem) {
            const strValue =
                typeof newValue.value === "string"
                    ? (newValue.value as string)
                    : (newValue.value as number).toString(10);
            field.setText(strValue);
        }

        function onOpenInternal() {
            setIsOpen(true);
            onOpen?.();
        }

        function onCloseInternal() {
            setIsOpen(false);
            field.validate();
            onClose?.();
        }

        return (
            <View onLayout={onLayout}>
                {Boolean(label) && (
                    <Text
                        style={[
                            TextStyles.listEyebrow,
                            {
                                marginBottom: 4,
                                color: theme.color.text.main,
                            },
                        ]}>
                        {label}
                    </Text>
                )}

                <Picker
                    placeholder={placeholder}
                    items={items}
                    value={text}
                    onValueChanged={onChange}
                    onOpen={onOpenInternal}
                    onClose={onCloseInternal}
                    disabled={disabled}
                    chevronVisible={true}
                    containerStyle={{
                        height: 48,
                        paddingLeft: 24,
                        paddingRight: 20,
                        borderWidth: 1,
                        borderRadius: 10,
                        borderColor: borderColor,
                        backgroundColor: theme.color.background.default,
                        opacity: disabled ? 0.5 : 1,
                    }}
                    textStyle={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                        },
                    ]}
                />

                {
                    // Validation Text
                    !isValid && validationText ? (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.error,
                                    marginTop: 8,
                                },
                            ]}>
                            {validationText}
                        </Text>
                    ) : null
                }
            </View>
        );
    }
);

export default FormSelect;
