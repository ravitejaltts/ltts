import React, { useState } from "react";
import {
    ColorValue,
    KeyboardTypeOptions,
    Platform,
    ReturnKeyTypeOptions,
    StyleProp,
    Text,
    TextInput,
    TextStyle,
    View,
    ViewStyle,
} from "react-native";
import { useTheme } from "../context/ThemeContext";
import { FormFieldValidator } from "../models/ui/form/field";
import { TextStyles } from "../styles";
import { observer } from "mobx-react-lite";

export type FormTextInputProps = {
    name?: string;
    nameStyle?: StyleProp<TextStyle>;
    disabled?: boolean;
    field: FormFieldValidator;
    placeholder?: string;
    helperText?: string;
    keyboardType?: KeyboardTypeOptions;
    autoCapitalize?: "none" | "sentences" | "words" | "characters";
    autoFocus?: boolean;
    secureTextEntry?: boolean;
    isMonospaced?: boolean;
    maxLength?: number;
    returnKeyType?: ReturnKeyTypeOptions;
    nextRef?: React.RefObject<TextInput>;
    multiline?: boolean;
    containerStyle?: StyleProp<ViewStyle>;
    inputStyle?: StyleProp<TextStyle>;
    rightView?: React.ReactNode;
    textContentType?: "username" | "password" | "newPassword";
    onSubmitEditing?: () => void;
};

const FormTextInput = observer(
    React.forwardRef<TextInput, FormTextInputProps>((props, ref) => {
        const [theme] = useTheme();
        const [isFocused, setIsFocused] = useState(false);

        const field = props.field;
        const isValid = field.isValid;
        const text = field.text;

        let borderColor: ColorValue;
        if (isValid) {
            borderColor = isFocused
                ? theme.color.text.main
                : theme.color.dividers.gray1;
        } else {
            borderColor = theme.color.error;
        }

        const fontFamily = props.isMonospaced
            ? Platform.OS == "ios"
                ? "Menlo"
                : "monospace"
            : undefined;

        return (
            <View>
                {/* Input Name */}
                <Text
                    style={[
                        TextStyles.listEyebrow,
                        {
                            color: isValid
                                ? theme.color.text.main
                                : theme.color.error,
                        },
                        props.nameStyle,
                    ]}>
                    {props.name}
                </Text>

                {/* Container */}
                <View
                    style={[
                        {
                            flexDirection: "row",
                            backgroundColor: theme.color.background.default,
                            borderColor: borderColor,
                            borderWidth: 1,
                            borderRadius: 8,
                            marginTop: 4,
                            opacity: props.disabled ? 0.5 : 1,
                        },
                        props.containerStyle,
                    ]}>
                    {/* TextInput */}
                    <TextInput
                        ref={ref}
                        multiline={props.multiline}
                        autoCorrect={false}
                        autoCapitalize={props.autoCapitalize}
                        autoFocus={props.autoFocus}
                        secureTextEntry={props.secureTextEntry}
                        maxLength={props.maxLength}
                        value={text}
                        placeholder={props.placeholder}
                        keyboardType={props.keyboardType}
                        editable={!props.disabled}
                        textContentType={props.textContentType}
                        returnKeyType={
                            props.returnKeyType
                                ? props.returnKeyType
                                : props.nextRef
                                ? "next"
                                : undefined
                        }
                        selectionColor={theme.color.blue.brand}
                        style={[
                            {
                                flex: 1,
                                color: theme.color.text.main,
                                fontSize: 17,
                                paddingLeft: 20,
                                paddingRight: props.rightView ? 0 : 20,
                                paddingTop: 12,
                                paddingBottom: 12,
                                fontFamily: fontFamily,
                                letterSpacing: props.isMonospaced ? 2 : 0,
                            },
                            props.inputStyle,
                        ]}
                        onChangeText={(newText: string) => {
                            field.setText(newText);
                        }}
                        onFocus={() => {
                            setIsFocused(true);
                        }}
                        onBlur={() => {
                            setIsFocused(false);
                            if (field.hasEdit) {
                                field.validate();
                            }
                        }}
                        onSubmitEditing={() => {
                            props.nextRef?.current?.focus();
                            props.onSubmitEditing?.();
                        }}
                        placeholderTextColor={theme.color.text.deemphasized}
                    />
                    {props.rightView}
                </View>

                {
                    // Validation Text
                    !isValid && props.field.validationText ? (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.error,
                                    marginTop: 8,
                                },
                            ]}>
                            {props.field.validationText}
                        </Text>
                    ) : null
                }

                {
                    // Helper Text
                    isValid && Boolean(props.helperText) && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                    marginTop: 8,
                                },
                            ]}>
                            {props.helperText}
                        </Text>
                    )
                }
            </View>
        );
    })
);

export default FormTextInput;
