import React, { useRef } from "react";
import { Pressable, Text, TextInput, TextInputProps } from "react-native";
import StackView from "./StackView";
import { useTheme } from "../context";
import { TextStyles } from "../styles";

interface LabeledRowInputProps {
    label: string;
    leftFlex?: number;
    rightFlex?: number;
    rightView?: React.FunctionComponent;
    disabled?: boolean;
    textInputProps?: TextInputProps;
}

const LabeledRowInput: React.FunctionComponent<LabeledRowInputProps> = ({
    label,
    leftFlex = 1,
    rightFlex = 2,
    rightView,
    disabled = false,
    textInputProps,
}) => {
    const [theme] = useTheme();
    const inputRef = useRef<TextInput>(null);

    return (
        <Pressable
            onPress={() => {
                inputRef.current?.focus();
            }}>
            <StackView
                spacing={4}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                    paddingHorizontal: 20,
                    height: 56,
                    backgroundColor: theme.color.background.elevation3,
                    opacity: disabled ? 0.5 : 1,
                }}>
                <Text
                    numberOfLines={1}
                    style={[
                        TextStyles.body,
                        {
                            flex: leftFlex,
                            color: theme.color.text.main,
                        },
                    ]}>
                    {label}
                </Text>

                <TextInput
                    ref={inputRef}
                    placeholderTextColor={theme.color.text.deemphasized}
                    editable={!disabled}
                    {...textInputProps}
                    selectionColor={theme.color.blue.brand}
                    style={[
                        TextStyles.regular17,
                        {
                            flex: rightFlex,
                            color: theme.color.text.main,
                        },
                        textInputProps?.style,
                    ]}
                />

                {rightView?.({})}
            </StackView>
        </Pressable>
    );
};

export default LabeledRowInput;
