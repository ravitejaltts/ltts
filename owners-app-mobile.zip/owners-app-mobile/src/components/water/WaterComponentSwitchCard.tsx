import { observer } from "mobx-react-lite";
import React from "react";
import { Text, View } from "react-native";
import { useTheme } from "../../context";
import {
    SimpleWaterHeater,
    TankPadWaterHeater,
    WaterPump,
} from "../../models/domain/water";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import ThemedSwitch from "../ThemedSwitch";
import { WaterSystemIcon } from "./WaterSystemIcon";

export const WaterComponentSwitchCard: React.FunctionComponent<{
    component: WaterPump | SimpleWaterHeater | TankPadWaterHeater;
}> = observer(({ component }) => {
    const [theme] = useTheme();

    const name = component.name;
    const isOn = component.isOn;

    const text = isOn
        ? component instanceof TankPadWaterHeater
            ? "Ready"
            : "On"
        : "Off";

    return (
        <View>
            {/* Water system switch card */}
            <StackView
                spacing={4}
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    borderWidth: 1,
                    paddingVertical: 16,
                    paddingHorizontal: 20,
                    borderColor: theme.color.dividers.gray1,
                    borderRadius: 8,
                }}>
                <StackView
                    spacing={8}
                    style={{
                        flexDirection: "row",
                        alignItems: "flex-start",
                    }}>
                    <WaterSystemIcon
                        width={24}
                        height={24}
                        metadata={component.metadata}
                        fill={
                            isOn
                                ? undefined // Use icon color when "on"
                                : theme.color.text.disabled.toString()
                        }
                    />

                    <StackView spacing={4}>
                        <Text
                            numberOfLines={1}
                            ellipsizeMode="middle"
                            style={[
                                TextStyles.semibold17,
                                {
                                    color: isOn
                                        ? theme.color.text.main
                                        : theme.color.text.deemphasized,
                                },
                            ]}>
                            {name}
                        </Text>
                        <Text
                            style={[
                                TextStyles.regular15,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {text}
                        </Text>
                    </StackView>
                </StackView>

                <ThemedSwitch
                    value={isOn}
                    onValueChange={(value) => {
                        component.toggle(value);
                    }}
                />
            </StackView>
        </View>
    );
});
