import { ColorValue } from "react-native";
import { SvgProps } from "react-native-svg";
import {
    BlackTankIcon,
    ShowerHeadIcon,
    TankHeatingPadIcon,
    WaterDropArrowUpIcon,
    WaterDropIcon,
    WaterHeaterIcon,
} from "../../assets/icons";
import { useTheme } from "../../context";
import {
    SystemComponentMetadata,
    SystemComponentType,
} from "../../models/domain/system";
import {
    TankPadWaterHeater,
    WaterPump,
    WaterPumpType,
    WaterTank,
    WaterTankType,
} from "../../models/domain/water";
import { DarkTheme } from "../../styles";

interface WaterSystemIconProps extends SvgProps {
    metadata: SystemComponentMetadata;
}

export const WaterSystemIcon: React.FunctionComponent<WaterSystemIconProps> = ({
    metadata,
    fill,
    ...svgProps
}) => {
    const [theme] = useTheme();

    let icon: React.FunctionComponent<SvgProps> = WaterDropIcon;
    let fillColor: ColorValue = theme.color.blue.dark;

    if (WaterPump.isMatch(metadata)) {
        switch (metadata.attributes.type) {
            case WaterPumpType.Fresh:
                icon = WaterDropArrowUpIcon;
                break;
            case WaterPumpType.Grey:
                icon = ShowerHeadIcon;
                fillColor = theme.color.components.gray1;
                break;
        }
    }

    if (metadata.componentType === SystemComponentType.WaterHeater) {
        icon = WaterHeaterIcon;
        fillColor = theme.color.orange.dark;
    }

    if (TankPadWaterHeater.isMatch(metadata)) {
        icon = TankHeatingPadIcon;
        fillColor = theme.color.orange.dark;
    }

    if (WaterTank.isMatch(metadata)) {
        switch (metadata.attributes.type) {
            case WaterTankType.Fresh:
                icon = WaterDropIcon;
                fillColor = DarkTheme.color.text.deemphasized;
                break;
            case WaterTankType.Grey:
                icon = ShowerHeadIcon;
                fillColor = DarkTheme.color.text.deemphasized;
                break;
            case WaterTankType.Black:
                icon = BlackTankIcon;
                fillColor = DarkTheme.color.text.deemphasized;
                break;
            default:
                icon = WaterDropIcon;
                fillColor = DarkTheme.color.text.deemphasized;
                break;
        }
    }

    return icon({
        fill: fill ?? fillColor.toString(),
        ...svgProps,
    });
};
