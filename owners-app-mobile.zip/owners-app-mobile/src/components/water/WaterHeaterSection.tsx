import { useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React, { ReactNode } from "react";
import { Text, TouchableOpacity, View } from "react-native";
import {
    ErrorFillIcon,
    InfoOutlineIcon,
    WaterHeaterIcon,
} from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { RvcWaterHeater, RvcWaterHeaterMode } from "../../models/domain/water";
import { WaterSystemsScreenNavigationProp } from "../../screens/water/WaterSystemsScreen";
import { TextStyles } from "../../styles";
import { ArrayUtils, StringUtils, TemperatureUtils } from "../../utils";
import PillSelect from "../PillSelect";
import {
    ControlSection,
    ControlSectionHeaderView,
    ControlSectionSwitchView,
} from "../smartVehicle";
import { useSmartVehicle } from "../../hooks";

const WATER_HEATER_MODE = [
    {
        label: "Comfort",
        value: RvcWaterHeaterMode.Comfort,
    },
    { label: "Eco", value: RvcWaterHeaterMode.Eco },
];

export const WaterHeaterSection: React.FunctionComponent<{
    heater: RvcWaterHeater;
}> = observer(({ heater }) => {
    const [theme] = useTheme();
    const navigation = useNavigation<WaterSystemsScreenNavigationProp>();
    const isOn = heater.isOn;

    const container = useRootContainer();
    const settingStore = container.stores.setting;
    const preferredTemperatureUnit = settingStore.preferredTemperatureUnit;

    const smartVehicle = useSmartVehicle();

    if (!smartVehicle) {
        return;
    }

    const energyStore = smartVehicle.energy;
    const generator = energyStore.generator;

    let remainingFuelText = "";

    if (generator) {
        // Get first related fuel tank
        const fuelTank = ArrayUtils.first(
            energyStore.getRelatedFuelTanks(generator.metadata)
        );

        // Convert to progress value
        const fuelLevel = fuelTank?.level;
        const fuelProgress =
            fuelLevel || fuelLevel === 0 ? fuelLevel / 100 : null;

        // To percentage string
        const fuelLevelText = StringUtils.toPercentageString(fuelProgress);
        remainingFuelText = `• Propane ${fuelLevelText}`;
    }

    const mode = heater.mode;
    const setTemp = heater.setTemp;
    const isBusy = heater.isBusy;
    const isDecalcifying = heater.isDecalcifying;
    const isDisabled = heater.isDisabled;

    const formattedSetTemp = TemperatureUtils.convertAndFormat(
        setTemp,
        preferredTemperatureUnit
    );

    const title = heater.name;

    let subtitle;

    if (isBusy) {
        subtitle = "Busy";
    } else if (isDecalcifying) {
        subtitle = "Decalcification";
    } else if (isOn) {
        subtitle = `On • Set to ${formattedSetTemp} ${remainingFuelText}`;
    } else {
        subtitle = `Off ${remainingFuelText}`;
    }

    let headerView: ReactNode;

    if (isBusy) {
        headerView = (
            <ControlSectionHeaderView
                title="Water Heater Disabled"
                bodyText="Water heater is disabled because system is busy, please check back in a few minutes."
                icon={(props) => (
                    <ErrorFillIcon
                        {...props}
                        fill={theme.color.yellow.warning}
                    />
                )}
            />
        );
    } else if (isDecalcifying) {
        headerView = (
            <ControlSectionHeaderView
                title="Decalcification In Progress"
                bodyText="Water Heater is disabled while the decalcification process is running. Decalcification will be done in about 3 hours."
                onInfo={() => {
                    navigation.navigate("decalcificationInfo");
                }}
                icon={(props) => (
                    <ErrorFillIcon
                        {...props}
                        fill={theme.color.yellow.warning}
                    />
                )}
            />
        );
    }

    return (
        <ControlSection
            title={title}
            subtitle={subtitle}
            headerViews={headerView}
            icon={
                <WaterHeaterIcon
                    width={24}
                    height={24}
                    fill={
                        isOn && !isDisabled
                            ? theme.color.orange.dark
                            : theme.color.text.disabled
                    }
                />
            }
            rightView={
                <ControlSectionSwitchView
                    disabled={isDisabled}
                    value={isOn}
                    onValueChange={(value) => {
                        heater.toggle(value);
                    }}
                />
            }>
            <View
                style={{
                    flex: 1,
                    paddingHorizontal: 20,
                    paddingVertical: 16,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                }}>
                <View
                    style={{
                        flexDirection: "row",
                        justifyContent: "center",
                        alignItems: "center",
                        marginRight: 12,
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color:
                                    isDisabled || !isOn
                                        ? theme.color.text.deemphasized
                                        : theme.color.text.main,
                                marginRight: 4,
                            },
                        ]}>
                        Mode
                    </Text>
                    <TouchableOpacity
                        disabled={isDisabled || !isOn}
                        onPress={() =>
                            navigation.navigate("waterHeaterModeInfo")
                        }>
                        <InfoOutlineIcon
                            width={16}
                            fill={
                                isDisabled || !isOn
                                    ? theme.color.text.deemphasized
                                    : theme.color.blue.brand
                            }
                        />
                    </TouchableOpacity>
                </View>
                <PillSelect
                    disabled={isDisabled || !isOn}
                    value={mode}
                    style={{ flex: 1 }}
                    onValueChanged={(newMode) => {
                        heater.updateMode(newMode);
                    }}
                    sections={WATER_HEATER_MODE}
                />
            </View>
        </ControlSection>
    );
});
