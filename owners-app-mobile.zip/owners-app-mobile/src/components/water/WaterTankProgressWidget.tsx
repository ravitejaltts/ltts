import { observer } from "mobx-react-lite";
import React from "react";
import { WaterTank, WaterTankType } from "../../models/domain/water";
import { StringUtils } from "../../utils";
import { ProgressWidget } from "../smartVehicle";
import { WaterSystemIcon } from "./WaterSystemIcon";

export const WaterTankProgressWidget: React.FunctionComponent<{
    tank: WaterTank;
    disabled?: boolean;
}> = observer(({ tank, disabled = false }) => {
    const name = tank.name;
    const subType = tank.subType;
    const level = tank.level;
    const capacity = tank.capacity;
    const capacityUnit = tank.unit;

    let isError = false;
    let levelFraction = 0;
    let progressFraction = 0;
    let title: string;
    let subtitle: string;

    let levelSuffix = "Left";
    let progressDirection: "up" | "down" = "down";

    switch (subType) {
        case WaterTankType.Grey:
        case WaterTankType.Black:
            levelSuffix = "Full";
            progressDirection = "up";
            break;
        case WaterTankType.Fresh:
        default:
            levelSuffix = "Left";
            progressDirection = "down";
    }

    if (level !== null && level > -1) {
        levelFraction = level / 100;
        if (levelFraction <= 0.05) {
            progressFraction = 0;
        } else if (levelFraction < 0.95) {
            progressFraction = Math.ceil(levelFraction * 10) / 10;
        } else {
            progressFraction = 1;
        }

        const levelText = StringUtils.toValueString(level, 0);
        title = `${levelText}% ${levelSuffix}`;
    } else {
        title = `--% ${levelSuffix}`;
        isError = true;
    }

    if (capacity !== undefined) {
        let capacityLevel = levelFraction * capacity;

        switch (subType) {
            case WaterTankType.Fresh:
                capacityLevel = Math.floor(capacityLevel);
                break;
            case WaterTankType.Grey:
            case WaterTankType.Black:
                capacityLevel = Math.ceil(capacityLevel);
                break;
            default:
                break;
        }
        subtitle = `${capacityLevel} ${capacityUnit}`;
    } else {
        subtitle = `-- ${capacityUnit}`;
        isError = true;
    }

    return (
        <ProgressWidget
            name={name}
            title={title}
            subtitle={subtitle}
            progress={levelFraction}
            barProgress={progressFraction}
            progressDirection={progressDirection}
            icon={(props) => (
                <WaterSystemIcon metadata={tank.metadata} {...props} />
            )}
            error={isError}
            disabled={disabled}
        />
    );
});
