import React from "react";
import { useFocusEffect } from "@react-navigation/native";
import {
    Text,
    Platform,
    View,
    BackHandler,
    TouchableOpacity,
} from "react-native";
import { TextStyles } from "../styles";
import { BackArrowIcon, ChevronLeftRoundedIcon } from "../assets/icons";
import { useTheme } from "../context";
import { ImageButton } from "./Buttons";

export type BackProps = {
    text: string;
    onPress: () => void;
    textColor?: string;
};

const HeaderBackButton: React.FunctionComponent<BackProps> = ({
    text,
    onPress,
    textColor,
}) => {
    const [theme] = useTheme();

    useFocusEffect(
        React.useCallback(() => {
            const onBackPress = () => {
                onPress();
                return true;
            };

            BackHandler.addEventListener("hardwareBackPress", onBackPress);

            return () =>
                BackHandler.removeEventListener(
                    "hardwareBackPress",
                    onBackPress
                );
        }, [onPress])
    );

    return (
        <View>
            {Platform.OS === "ios" ? (
                <TouchableOpacity
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                        right: 12,
                    }}
                    onPress={onPress}>
                    <ChevronLeftRoundedIcon fill="none" />
                    <Text
                        style={[
                            TextStyles.linkButton,
                            {
                                color:
                                    textColor ||
                                    theme.color.text.main.toString(),
                                marginLeft: 2,
                            },
                        ]}>
                        {text}
                    </Text>
                </TouchableOpacity>
            ) : (
                <ImageButton
                    image={BackArrowIcon}
                    imageProps={{
                        fill: textColor || theme.color.text.main.toString(),
                    }}
                    onPress={onPress}
                />
            )}
        </View>
    );
};

export default HeaderBackButton;
