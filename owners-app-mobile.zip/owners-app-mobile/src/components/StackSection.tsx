import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { useTheme } from "../context";
import StackView from "./StackView";

export type StackSectionProps = {
    headerView?: React.FunctionComponent;
    hasBorder?: boolean;
    style?: StyleProp<ViewStyle>;
    children: React.ReactNode;
};

const StackSection: React.FunctionComponent<StackSectionProps> = ({
    headerView,
    hasBorder = false,
    style,
    children,
}) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={1}
            spacerColor={theme.color.dividers.stackSection}
            style={[
                {
                    borderRadius: 8,
                    backgroundColor: theme.color.background.elevation3,
                    overflow: "hidden",
                },
                hasBorder && {
                    borderWidth: 1,
                    borderColor: theme.color.dividers.stackSection,
                },
                style,
            ]}>
            {headerView && headerView({})}
            {children}
        </StackView>
    );
};

export default StackSection;
