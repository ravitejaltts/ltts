import { observer } from "mobx-react-lite";
import React, { useEffect, useRef, useState } from "react";
import { Animated, Easing, Platform, useWindowDimensions } from "react-native";
import { useRootContainer } from "../../context";
import { WgoToastType } from "../../models/ui";
import { ErrorToast } from "./ErrorToast";
import { GeneratorLockoutToast } from "./GeneratorLockoutToast";
import { GeneratorQuietHoursOverrideToast } from "./GeneratorQuietHoursOverrideToast";
import { LoadingToast } from "./LoadingToast";
import { SystemComponentToast } from "./SystemComponentToast";
import { WgoToast } from "./WgoToast";
import { IconToast } from "./IconToast";

const ANIMATION_DURATION_MILLIS = 400;
const PADDING_BOTTOM = Platform.OS === "ios" ? 100 : 50;

export const ToastContainer: React.FunctionComponent = observer(() => {
    const { width: screenWidth, height: screenHeight } = useWindowDimensions();

    const [toastHeight, setToastHeight] = useState(0);

    const animationRef = useRef<Animated.CompositeAnimation | null>(null);
    const translateYRef = useRef(new Animated.Value(screenHeight));
    const autoHideTimeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

    const container = useRootContainer();
    const toastStore = container.stores.toast;
    const isVisible = toastStore.isVisible;
    const toastData = toastStore.toastData;
    const type = toastData?.type;
    const props = toastData?.props;

    // Show or hide
    useEffect(() => {
        if (!toastData || toastHeight <= PADDING_BOTTOM) {
            // Wait until toast height is > 0
            return;
        }

        // Stop any current animation
        animationRef.current?.stop();
        animationRef.current = null;

        if (isVisible) {
            // Show toast
            const animation = Animated.timing(translateYRef.current, {
                toValue: screenHeight - toastHeight,
                duration: ANIMATION_DURATION_MILLIS,
                useNativeDriver: true,
                easing: Easing.out(Easing.back(1)),
            });

            animationRef.current = animation;

            animation.start(({ finished }) => {
                if (!finished) {
                    return;
                }

                // Reset animation ref
                animationRef.current = null;

                // Auto-hide after duration
                if (toastData.autoHide && toastData.duration) {
                    autoHideTimeoutRef.current = setTimeout(() => {
                        toastStore.hideVisible();
                        autoHideTimeoutRef.current = undefined;
                    }, toastData.duration);
                }

                // Otherwise, must be hidden by calling hide() on the ToastStore
            });
        } else {
            // Stop auto-hide
            clearTimeout(autoHideTimeoutRef.current);

            // Hide toast
            const animation = Animated.timing(translateYRef.current, {
                toValue: screenHeight,
                duration: ANIMATION_DURATION_MILLIS,
                useNativeDriver: true,
                easing: Easing.in(Easing.back(1)),
            });

            animationRef.current = animation;

            animation.start(({ finished }) => {
                if (!finished) {
                    return;
                }

                // Reset animation ref and toast height
                animationRef.current = null;

                // Tell the store the toast has been hidden
                toastStore.onToastHidden();
            });
        }
    }, [toastData, isVisible, toastHeight, screenHeight, toastStore]);

    let toastView: React.ReactNode;

    switch (type) {
        case WgoToastType.Generic:
            toastView = <WgoToast {...props} />;
            break;
        case WgoToastType.Loading:
            toastView = <LoadingToast {...props} />;
            break;
        case WgoToastType.Error:
            toastView = <ErrorToast {...props} />;
            break;
        case WgoToastType.Icon:
            toastView = <IconToast {...props} />;
            break;
        case WgoToastType.GeneratorLockout:
            toastView = <GeneratorLockoutToast {...props} />;
            break;
        case WgoToastType.GeneratorQuietHoursOverride:
            toastView = <GeneratorQuietHoursOverrideToast {...props} />;
            break;
        case WgoToastType.SystemComponent:
            toastView = <SystemComponentToast {...props} />;
            break;
        default:
            toastView = null;
            break;
    }

    return (
        <Animated.View
            pointerEvents="box-none"
            onLayout={(e) => {
                const layout = e.nativeEvent.layout;
                setToastHeight(layout.height);
            }}
            style={{
                position: "absolute",
                width: screenWidth,
                paddingBottom: PADDING_BOTTOM,
                paddingHorizontal: 20,
                transform: [
                    {
                        translateY: translateYRef.current,
                    },
                ],
            }}>
            {toastView}
        </Animated.View>
    );
});
