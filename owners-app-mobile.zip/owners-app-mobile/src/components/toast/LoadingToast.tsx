import React from "react";
import { ActivityIndicator } from "react-native";
import { useTheme } from "../../context";
import { WgoToast } from "./WgoToast";

export type LoadingToastProps = {
    text: string;
    onPress?: () => void;
};

export const LoadingToast: React.FunctionComponent<LoadingToastProps> = ({
    text,
    onPress,
}) => {
    const [theme] = useTheme();

    return (
        <WgoToast
            text={text}
            onPress={onPress}
            leftView={
                <ActivityIndicator
                    color={theme.color.text.mainInverted}
                    animating={true}
                />
            }
        />
    );
};
