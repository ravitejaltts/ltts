import { observer } from "mobx-react-lite";
import React from "react";
import { Pressable, Text } from "react-native";
import { useStores, useTheme } from "../../context";
import { TextStyles } from "../../styles";
import StackView from "../StackView";

export type WgoToastProps = {
    text: string;
    onPress?: () => void;
    leftView?: React.ReactNode;
    rightView?: React.ReactNode;
};

export const WgoToast: React.FunctionComponent<WgoToastProps> = observer(
    ({ text, onPress, leftView, rightView }) => {
        const [theme] = useTheme();
        const stores = useStores();
        const toastStore = stores.toast;
        const toastData = toastStore.toastData;

        return (
            <Pressable
                onPress={() => {
                    onPress?.();

                    if (toastData?.autoHide) {
                        // Not persistent
                        // Hide when tapped
                        toastStore.hideVisible();
                    }
                }}
                style={{
                    backgroundColor: theme.color.background.defaultInverted,
                    paddingHorizontal: 12,
                    paddingVertical: 14,
                    borderRadius: 8,
                }}>
                <StackView
                    spacing={8}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    {leftView}
                    <Text
                        style={[
                            TextStyles.semibold15,
                            {
                                flex: 1,
                                color: theme.color.text.mainInverted,
                            },
                        ]}>
                        {text}
                    </Text>
                    {rightView}
                </StackView>
            </Pressable>
        );
    }
);
