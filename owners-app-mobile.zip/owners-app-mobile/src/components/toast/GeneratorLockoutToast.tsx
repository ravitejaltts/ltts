import { observer } from "mobx-react-lite";
import React from "react";
import { useTimedLockout } from "../../hooks";
import {
    SystemComponentType,
    SystemLockoutOrWarning,
} from "../../models/domain/system";
import { SystemComponentToast } from "./SystemComponentToast";

export type GeneratorLockoutToastProps = {
    lockoutInstance: SystemLockoutOrWarning;
    onPress?: () => void;
};

export const GeneratorLockoutToast: React.FunctionComponent<GeneratorLockoutToastProps> =
    observer(({ lockoutInstance, onPress }) => {
        const lockout = useTimedLockout(lockoutInstance);
        const durationSeconds = lockout.durationSeconds;
        let timeRemainingText = lockout.timeRemainingText;

        if (durationSeconds > 59) {
            timeRemainingText += " minutes";
        } else {
            timeRemainingText += " seconds";
        }

        let text: string;

        switch (lockoutInstance) {
            case SystemLockoutOrWarning.GeneratorCooldown:
                text = `Generator is cooling down. System will turn off within ${timeRemainingText}.`;
                break;
            case SystemLockoutOrWarning.GeneratorWait:
                text = `Please wait. Generator will be available in ${timeRemainingText}.`;
                break;
            default:
                text = "";
        }

        return (
            <SystemComponentToast
                type={SystemComponentType.Generator}
                text={text}
                onPress={onPress}
            />
        );
    });
