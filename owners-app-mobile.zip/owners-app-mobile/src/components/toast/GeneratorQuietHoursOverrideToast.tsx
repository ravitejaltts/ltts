import React from "react";
import { TimelapseIcon } from "../../assets/icons";
import { IconToast } from "./IconToast";

export const GeneratorQuietHoursOverrideToast: React.FunctionComponent = () => {
    return <IconToast text={"Quiet Hours Overridden"} icon={TimelapseIcon} />;
};
