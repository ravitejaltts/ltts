import React from "react";
import { ErrorFillIcon } from "../../assets/icons";
import { IconToast } from "./IconToast";

export type ErrorToastProps = {
    text: string;
    onPress?: () => void;
};

export const ErrorToast: React.FunctionComponent<ErrorToastProps> = ({
    text,
    onPress,
}) => {
    return <IconToast text={text} onPress={onPress} icon={ErrorFillIcon} />;
};
