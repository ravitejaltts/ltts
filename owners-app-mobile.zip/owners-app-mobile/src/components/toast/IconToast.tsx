import React from "react";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import { WgoToast } from "./WgoToast";

export type IconToastProps = {
    text: string;
    icon: React.FunctionComponent<SvgProps>;
    onPress?: () => void;
};

export const IconToast: React.FunctionComponent<IconToastProps> = ({
    text,
    icon,
    onPress,
}) => {
    const [theme] = useTheme();

    return (
        <WgoToast
            text={text}
            onPress={onPress}
            leftView={icon({
                width: 24,
                height: 24,
                fill: theme.color.text.mainInverted,
                stroke: theme.color.text.mainInverted,
            })}
        />
    );
};
