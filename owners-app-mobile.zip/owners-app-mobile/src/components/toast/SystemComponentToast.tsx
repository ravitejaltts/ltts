import React from "react";
import { SvgProps } from "react-native-svg";
import {
    BatteryIcon,
    DoorLockIcon,
    FurnaceIcon,
    GeneratorToastIcon,
    LightBulbIcon,
    LockedIcon,
    OpenAwningIcon,
    OpenSlideOutIcon,
    PawIcon,
    PropaneTankFilledIcon,
    RefrigeratorFilledIcon,
    RoofVentIcon,
    SnowFlakeIcon,
    ThermostatHeatIcon,
    WLogoIcon,
    WaterDropArrowUpIcon,
    WaterDropIcon,
    WaterHeaterIcon,
} from "../../assets/icons";
import { SystemComponentType } from "../../models/domain/system";
import { IconToast } from "./IconToast";

export type SystemComponentToastProps = {
    type: SystemComponentType;
    text: string;
    onPress?: () => void;
};

export const SystemComponentToast: React.FunctionComponent<
    SystemComponentToastProps
> = ({ type, text, onPress }) => {
    let icon: React.FunctionComponent<SvgProps>;

    switch (type) {
        case SystemComponentType.AirConditioner:
            icon = SnowFlakeIcon;
            break;

        case SystemComponentType.Awning:
            icon = OpenAwningIcon;
            break;

        case SystemComponentType.AwningLight:
        case SystemComponentType.LightingGroup:
        case SystemComponentType.LightingZone:
            icon = LightBulbIcon;
            break;

        case SystemComponentType.Battery:
        case SystemComponentType.BatteryManager:
        case SystemComponentType.EnergyConsumer:
        case SystemComponentType.EnergyInverter:
        case SystemComponentType.EnergyManager:
        case SystemComponentType.EnergySource:
            icon = BatteryIcon;
            break;

        case SystemComponentType.DoorLock:
            icon = DoorLockIcon;
            break;

        case SystemComponentType.FuelTank:
            icon = PropaneTankFilledIcon;
            break;

        case SystemComponentType.Generator:
            icon = GeneratorToastIcon;
            break;

        case SystemComponentType.Heater:
            icon = FurnaceIcon;
            break;

        case SystemComponentType.Lockout:
            icon = LockedIcon;
            break;

        case SystemComponentType.PetMinder:
            icon = PawIcon;
            break;

        case SystemComponentType.Refrigeration:
            icon = RefrigeratorFilledIcon;
            break;

        case SystemComponentType.RoofVent:
            icon = RoofVentIcon;
            break;

        case SystemComponentType.SlideOut:
            icon = OpenSlideOutIcon;
            break;

        case SystemComponentType.Thermostat:
            icon = ThermostatHeatIcon;
            break;

        case SystemComponentType.WaterHeater:
            icon = WaterHeaterIcon;
            break;

        case SystemComponentType.WaterPump:
            icon = WaterDropArrowUpIcon;
            break;

        case SystemComponentType.WaterTank:
            icon = WaterDropIcon;
            break;

        default:
            icon = WLogoIcon;
            break;
    }

    return <IconToast text={text} onPress={onPress} icon={icon} />;
};
