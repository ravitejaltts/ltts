import {
    CommonActions,
    StackActions,
    useNavigation,
} from "@react-navigation/native";
import React, { useEffect, useLayoutEffect, useState } from "react";
import { Platform, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRootContainer, useTheme } from "../../context";
import { useModalStatusBar } from "../../hooks";
import { WgoSetting } from "../../services";
import { TextStyles } from "../../styles";
import { HeaderSecondaryButton, PrimaryButton } from "../Buttons";
import StackView from "../StackView";

const CONTENT_PADDING_BOTTOM = 28;

export const SafetyAgreementView: React.FunctionComponent<{
    title: string;
    showAgreeButton: boolean;
    timestampKey: WgoSetting;
    children?: React.ReactNode;
}> = ({ title, showAgreeButton, timestampKey, children }) => {
    useModalStatusBar();
    const navigation = useNavigation();
    const safeAreaInsets = useSafeAreaInsets();
    const [theme] = useTheme();

    useLayoutEffect(() => {
        navigation.setOptions({
            // Don't allow the user to close out with gestures if this is an agreement
            gestureEnabled: !showAgreeButton,
        });
    }, [navigation, showAgreeButton]);

    const [contentHeight, setContentHeight] = useState(0);
    const [scrollViewHeight, setScrollViewHeight] = useState(0);
    const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);
    const [isScrolledToBottom, setIsScrolledToBottom] = useState(false);

    useEffect(() => {
        if (
            scrollViewHeight &&
            contentHeight &&
            scrollViewHeight > contentHeight
        ) {
            setHasScrolledToBottom(true);
            setIsScrolledToBottom(true);
        }
    }, [contentHeight, scrollViewHeight]);

    const container = useRootContainer();
    const settingService = container.services.setting;

    const agree = () => {
        settingService.setValue(timestampKey, Date.now());
        navigation.dispatch(CommonActions.goBack());
    };

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: theme.color.background.elevation3,
                marginTop: Platform.OS === "android" ? safeAreaInsets.top : 0,
            }}>
            <HeaderSecondaryButton
                text="Close"
                onPress={() => {
                    if (showAgreeButton) {
                        navigation.dispatch(StackActions.popToTop());
                    } else {
                        navigation.dispatch(CommonActions.goBack());
                    }
                }}
                style={{
                    alignSelf: "flex-end",
                    paddingHorizontal: 24,
                    height: 52,
                }}
            />
            {/* Title & Children */}
            <StackView
                spacing={28}
                style={{
                    flex: 1,
                }}>
                {/* Title */}
                <Text
                    style={[
                        TextStyles.mainTitle,
                        { color: theme.color.text.main, paddingHorizontal: 20 },
                    ]}>
                    {title}
                </Text>

                {/* Scrollable Content */}
                <ScrollView
                    style={{
                        backgroundColor: theme.color.background.elevation3,
                    }}
                    contentContainerStyle={{
                        flexGrow: 1,
                        paddingHorizontal: 20,
                        paddingBottom: showAgreeButton
                            ? CONTENT_PADDING_BOTTOM
                            : safeAreaInsets.bottom + CONTENT_PADDING_BOTTOM,
                    }}
                    scrollEventThrottle={16}
                    onLayout={(e) => {
                        setScrollViewHeight(e.nativeEvent.layout.height);
                    }}
                    onScroll={(e) => {
                        const y = e.nativeEvent.contentOffset.y;

                        // contentHeight - scrollViewHeight
                        // is the position where the scroll view window shows the bottom of the content.
                        // Subtract y to find out if we are above or below this threshold
                        // Zero at threshold, postive above, negative below
                        if (contentHeight - scrollViewHeight - y <= 0) {
                            setHasScrolledToBottom(true);
                            setIsScrolledToBottom(true);
                        } else {
                            setIsScrolledToBottom(false);
                        }
                    }}>
                    {/* Content Children */}
                    <View
                        onLayout={(e) => {
                            setContentHeight(e.nativeEvent.layout.height);
                        }}>
                        {children}
                    </View>
                </ScrollView>
            </StackView>

            {showAgreeButton && (
                <StackView
                    spacing={24}
                    style={{
                        backgroundColor: theme.color.background.elevation3,
                        paddingHorizontal: 20,
                        paddingTop: 24,
                        paddingBottom:
                            safeAreaInsets.bottom + CONTENT_PADDING_BOTTOM,
                        shadowColor: theme.color.black,
                        shadowOffset: {
                            width: 0,
                            height: -4,
                        },
                        shadowOpacity: isScrolledToBottom ? 0 : 0.15,
                        shadowRadius: 6,
                    }}>
                    <PrimaryButton
                        text="I Understand"
                        disabled={!hasScrolledToBottom}
                        onPress={agree}
                    />
                    <Text
                        style={[
                            TextStyles.regular13,
                            {
                                color: theme.color.text.main,
                                textAlign: "center",
                                paddingHorizontal: 20,
                            },
                        ]}>
                        By clicking "I Understand" you agree to that Winnebago
                        is not liable to any damages or harm while interacting
                        with Winnebago product.
                    </Text>
                </StackView>
            )}
        </View>
    );
};
