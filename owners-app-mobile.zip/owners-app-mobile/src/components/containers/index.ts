export { SafetyAgreementView } from "./SafetyAgreementView";
