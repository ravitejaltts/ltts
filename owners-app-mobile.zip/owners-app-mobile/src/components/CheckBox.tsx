import React from "react";
import {
    ColorValue,
    Pressable,
    StyleProp,
    View,
    ViewStyle,
} from "react-native";
import { CheckMarkIcon } from "../assets/icons";
import { useTheme } from "../context";

const CheckBox: React.FunctionComponent<{
    isChecked: boolean;
    onToggleChecked?: () => void;
    fillColor?: ColorValue;
    style?: StyleProp<ViewStyle>;
    size?: "small" | "large";
    disabled?: boolean;
}> = ({
    isChecked,
    onToggleChecked,
    fillColor,
    style,
    size = "large",
    disabled = false,
}) => {
    const [theme] = useTheme();

    let backgroundColor: ColorValue;
    let borderColor: ColorValue;

    if (isChecked) {
        backgroundColor = fillColor ?? theme.color.components.gray2;
        borderColor = backgroundColor;
    } else {
        backgroundColor = theme.color.background.default;
        borderColor = theme.color.components.gray2;
    }

    const onPress = () => {
        if (!disabled && onToggleChecked) {
            onToggleChecked();
        }
    };

    return (
        <Pressable
            style={[
                {
                    width: size === "small" ? 18 : 24,
                    height: size === "small" ? 18 : 24,
                    backgroundColor: backgroundColor,
                    borderColor: disabled
                        ? theme.color.text.disabled
                        : borderColor,
                    borderWidth: 2,
                    borderRadius: 2,
                },
                style,
            ]}
            onPress={onPress}>
            <View
                style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                {isChecked && (
                    <CheckMarkIcon
                        fill={theme.color.white.toString()}
                        width={size === "small" ? 18 : 20}
                        height={size === "small" ? 18 : 20}
                    />
                )}
            </View>
        </Pressable>
    );
};

export default CheckBox;
