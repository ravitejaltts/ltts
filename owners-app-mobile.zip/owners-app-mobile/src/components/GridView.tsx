import React from "react";
import { StyleProp, View, ViewStyle } from "react-native";

export type GridViewProps = {
    columns?: number;
    rowSpacing?: number;
    columnSpacing?: number;
    style?: StyleProp<ViewStyle>;
    children: React.ReactNode;
};

const GridView: React.FunctionComponent<GridViewProps> = ({
    columns = 1,
    rowSpacing = 0,
    columnSpacing = 0,
    style,
    children,
}) => {
    const newChildren = React.Children.toArray(children);
    const rowViews: JSX.Element[] = [];

    let rowNumber = 1;
    let colNumber = 1;
    let colViews: JSX.Element[] = [];

    // Number of children + number of empty cells to add to fill the last row
    const cellRemainder = newChildren.length % columns;
    const totalCellCount =
        cellRemainder > 0
            ? newChildren.length + columns - cellRemainder
            : newChildren.length;

    for (let cellIndex = 0; cellIndex < totalCellCount; cellIndex++) {
        const isLastCell = cellIndex === totalCellCount - 1;

        // Child or empty cell
        const cellChild =
            cellIndex < newChildren.length ? newChildren[cellIndex] : null;

        // Add cell
        colViews.push(
            <View
                key={`row-${rowNumber}-col-${colNumber}`}
                style={{
                    flex: 1,
                }}>
                {cellChild}
            </View>
        );

        if (colNumber === columns) {
            // We've reached the end of the columns in this row

            // Add the row
            rowViews.push(
                <View
                    key={`row-${rowNumber}`}
                    style={{
                        flexDirection: "row",
                    }}>
                    {colViews}
                </View>
            );

            // Add the row spacer (only between rows)
            if (!isLastCell && rowSpacing > 0) {
                rowViews.push(
                    <View
                        key={`row-${rowNumber}-spacer`}
                        style={{
                            height: rowSpacing,
                        }}
                    />
                );
            }

            colNumber = 1;
            rowNumber++;
            colViews = [];
        } else {
            // Continue to next column in same row

            // Add the column spacer (only between columns)
            if (columnSpacing > 0) {
                colViews.push(
                    <View
                        key={`row-${rowNumber}-col-${colNumber}-spacer`}
                        style={{
                            width: rowSpacing,
                        }}
                    />
                );
            }

            colNumber++;
        }
    }

    return <View style={style}>{rowViews}</View>;
};

export default GridView;
