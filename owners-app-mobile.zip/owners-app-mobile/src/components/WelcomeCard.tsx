import React from "react";
import {
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { ArrowButton } from "./Buttons";

const WelcomeCard: React.FunctionComponent<{
    icon: React.FunctionComponent<SvgProps>;
    headerText: string;
    subheaderText: string;
    buttonText: string;
    onPress: () => void;
    style?: StyleProp<ViewStyle>;
}> = (props) => {
    const [theme] = useTheme();
    const { style } = props;

    return (
        <TouchableHighlight
            underlayColor={theme.color.background.elevation1}
            onPress={props.onPress}
            style={[
                {
                    backgroundColor: theme.color.background.elevation3,
                    borderRadius: 8,
                    paddingTop: 20,
                    paddingHorizontal: 20,
                    paddingBottom: 8,
                },
                style,
            ]}>
            <View>
                {/* Icon */}
                <View
                    style={{
                        alignSelf: "flex-start",
                        backgroundColor: theme.color.red.brand,
                        borderRadius: 4,
                        padding: 10,
                    }}>
                    {props.icon({
                        fill: theme.color.white.toString(),
                        width: 28,
                        height: 28,
                    })}
                </View>

                {/* Header */}
                <Text
                    adjustsFontSizeToFit={true}
                    style={[
                        TextStyles.calloutTitle,
                        {
                            color: theme.color.text.main,
                            marginTop: 24,
                            marginBottom: 8,
                        },
                    ]}>
                    {props.headerText}
                </Text>

                {/* Subheader */}
                <Text
                    style={[
                        TextStyles.subheading,
                        {
                            color: theme.color.text.deemphasized,
                        },
                    ]}>
                    {props.subheaderText}
                </Text>

                {/* CTA Button */}
                <ArrowButton
                    text={props.buttonText}
                    onPress={props.onPress}
                    style={{
                        alignSelf: "flex-start",
                    }}
                />
            </View>
        </TouchableHighlight>
    );
};

export default WelcomeCard;
