import { useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React, { useCallback, useMemo, useState } from "react";
import { View } from "react-native";
import { ListIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { useFocusedDependencyEffect, useLogger } from "../../hooks";
import {
    MAINTENANCE_CHECKLISTS,
    MaintenanceTaskFrequency,
} from "../../models/domain/maintenance";
import { ServiceScreenNavigationProp } from "../../screens/service";
import { TextStyles } from "../../styles";
import ErrorView from "../ErrorView";
import LabeledRow from "../LabeledRow";
import LoadingView from "../LoadingView";
import StackSection from "../StackSection";

type Checklist = {
    title: string;
    frequencies: MaintenanceTaskFrequency[];
    onPress: () => void;
};

const MaintenanceChecklistRows: React.FunctionComponent = observer(() => {
    const navigation = useNavigation<ServiceScreenNavigationProp>();
    const [theme] = useTheme();

    const { logError } = useLogger("MaintenanceChecklistRows");

    const [isLoading, setIsLoading] = useState(true);

    const container = useRootContainer();
    const authStore = container.stores.auth;
    const isAuthenticated = authStore.isAuthenticated;

    const vehicleStore = container.stores.vehicle;
    const vehicle = vehicleStore.associatedVehicle;

    const maintenanceStore = container.stores.maintenance;
    const maintenanceTasks = maintenanceStore.tasks;

    const updateMaintenanceTasks = useCallback(() => {
        if (!isAuthenticated || !vehicle) {
            // Unauthenticated
            // OR
            // We've already loaded the maintenance tasks
            return;
        }

        const modelId = vehicle.modelId;

        maintenanceStore.loadStoredPretripChecklist(modelId);

        setIsLoading(true);

        maintenanceStore
            .updateMaintenanceTasks(modelId)
            .catch((error) => {
                logError(error);
            })
            .finally(() => {
                setIsLoading(false);
            });
    }, [isAuthenticated, vehicle, maintenanceStore, logError]);

    useFocusedDependencyEffect(updateMaintenanceTasks);

    const maintenanceChecklists = useMemo<Checklist[]>(
        () => [
            {
                title: MAINTENANCE_CHECKLISTS.preTrip.displayName,
                frequencies: MAINTENANCE_CHECKLISTS.preTrip.frequencies,
                onPress: () => {
                    navigation.navigate("pretripChecklist");
                },
            },
            {
                title: MAINTENANCE_CHECKLISTS.monthly.displayName,
                frequencies: MAINTENANCE_CHECKLISTS.monthly.frequencies,
                onPress: () => {
                    navigation.navigate("scheduledChecklist", {
                        title: MAINTENANCE_CHECKLISTS.monthly.displayName,
                        frequencies: MAINTENANCE_CHECKLISTS.monthly.frequencies,
                    });
                },
            },
            {
                title: MAINTENANCE_CHECKLISTS.threeToSixMonths.displayName,
                frequencies:
                    MAINTENANCE_CHECKLISTS.threeToSixMonths.frequencies,
                onPress: () => {
                    navigation.navigate("scheduledChecklist", {
                        title: MAINTENANCE_CHECKLISTS.threeToSixMonths
                            .displayName,
                        frequencies:
                            MAINTENANCE_CHECKLISTS.threeToSixMonths.frequencies,
                    });
                },
            },
            {
                title: MAINTENANCE_CHECKLISTS.yearly.displayName,
                frequencies: MAINTENANCE_CHECKLISTS.yearly.frequencies,
                onPress: () => {
                    navigation.navigate("scheduledChecklist", {
                        title: MAINTENANCE_CHECKLISTS.yearly.displayName,
                        frequencies: MAINTENANCE_CHECKLISTS.yearly.frequencies,
                    });
                },
            },
            {
                title: MAINTENANCE_CHECKLISTS.recommended.displayName,
                frequencies: MAINTENANCE_CHECKLISTS.recommended.frequencies,
                onPress: () => {
                    navigation.navigate("scheduledChecklist", {
                        title: MAINTENANCE_CHECKLISTS.recommended.displayName,
                        frequencies:
                            MAINTENANCE_CHECKLISTS.recommended.frequencies,
                    });
                },
            },
        ],
        [navigation]
    );

    // For each checklist, if there exists some task with the same frequencies, display it
    let filteredChecklists: Checklist[] = [];

    if (maintenanceTasks.length > 0) {
        filteredChecklists = maintenanceChecklists.filter((checklist) =>
            maintenanceTasks.some((task) =>
                task.frequencies.some((freq) =>
                    checklist.frequencies.includes(freq)
                )
            )
        );
    }

    return (
        <StackSection hasBorder={true}>
            {isLoading ? (
                <LoadingView />
            ) : filteredChecklists.length === 0 ? (
                <ErrorView
                    text="Unable to load maintenance checklists"
                    onButtonPressed={updateMaintenanceTasks}
                />
            ) : (
                filteredChecklists.map(
                    (row: {
                        frequencies: MaintenanceTaskFrequency[];
                        title: string;
                        onPress: () => void;
                    }) => (
                        <LabeledRow
                            key={row.frequencies.join(";")}
                            onPress={row.onPress}
                            leftText={row.title}
                            leftTextStyle={[
                                TextStyles.listItemSmall,
                                { color: theme.color.text.main },
                            ]}
                            leftView={
                                <View
                                    style={{
                                        width: 32,
                                        height: 32,
                                        borderRadius: 4,
                                        backgroundColor:
                                            theme.color.background.elevation2,
                                        justifyContent: "center",
                                        alignItems: "center",
                                    }}>
                                    <ListIcon
                                        fill={theme.color.blue.brand}
                                        width={24}
                                        height={24}
                                    />
                                </View>
                            }
                        />
                    )
                )
            )}
        </StackSection>
    );
});

export default MaintenanceChecklistRows;
