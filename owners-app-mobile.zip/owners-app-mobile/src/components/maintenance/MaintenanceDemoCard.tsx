import React from "react";
import { View, Text } from "react-native";
import { useTheme } from "../../context";
import { TextStyles, LightTheme } from "../../styles";
import StackView from "../StackView";
import {
    EmailIcon,
    PhoneIcon,
    HeadsetIcon,
    HeartIcon,
} from "../../assets/icons";
import CheckBox from "../CheckBox";

const MaintenanceDemoCard: React.FunctionComponent = () => {
    const [theme] = useTheme();

    const shadowStyle = {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    };

    return (
        <View
            style={{
                backgroundColor: theme.color.background.elevation3,
                ...shadowStyle,
                elevation: 5,
                borderRadius: 28,
                paddingTop: 16,
                paddingHorizontal: 20,
                marginHorizontal: 20,
            }}>
            <View
                style={{
                    flex: 1,
                    height: 4,
                    width: 60,
                    backgroundColor: LightTheme.color.black,
                    borderRadius: 8,
                    alignSelf: "center",
                }}
            />
            <View style={{ paddingVertical: 20 }}>
                <View
                    style={{
                        position: "absolute",
                        top: 10,
                        right: -40,
                        left: 0,
                        bottom: 0,
                        height: 105,
                        justifyContent: "space-between",
                        alignItems: "flex-end",
                    }}>
                    <View
                        style={{
                            backgroundColor: theme.color.background.elevation3,
                            padding: 5,
                            borderRadius: 8,
                            ...shadowStyle,
                        }}>
                        <EmailIcon fill={theme.color.blue.brand.toString()} />
                    </View>
                    <View
                        style={{
                            backgroundColor: theme.color.background.elevation3,
                            padding: 8,
                            borderRadius: 8,
                            ...shadowStyle,
                        }}>
                        <PhoneIcon fill={theme.color.blue.brand.toString()} />
                    </View>
                </View>
                <Text
                    style={[
                        TextStyles.bold15,
                        {
                            color: theme.color.text.main,
                            marginBottom: 12,
                        },
                    ]}>
                    Dealer Finder
                </Text>
                <View>
                    <View
                        style={{
                            flexDirection: "row",
                            justifyContent: "flex-start",
                            marginBottom: 32,
                        }}>
                        <View
                            style={{
                                height: 90,
                                width: 90,
                                backgroundColor:
                                    theme.color.background.elevation2,
                                borderRadius: 8,
                                marginRight: 20,
                            }}>
                            <View
                                style={{
                                    position: "absolute",
                                    top: 70,
                                    right: 35,
                                    backgroundColor:
                                        theme.color.background.elevation3,
                                    padding: 8,
                                    borderRadius: 8,
                                    alignItems: "center",
                                    ...shadowStyle,
                                }}>
                                <HeartIcon
                                    stroke={theme.color.blue.brand.toString()}
                                />
                            </View>
                        </View>
                        <View>
                            <Text
                                style={[
                                    TextStyles.semibold17,
                                    {
                                        color: theme.color.text.main,
                                    },
                                ]}>
                                Winnebago{"\n"}
                                Service
                            </Text>
                            <StackView spacing={12}>
                                <Text
                                    style={[
                                        TextStyles.semibold15,
                                        { color: LightTheme.color.green.brand },
                                    ]}>
                                    Open
                                </Text>
                                <View
                                    style={{
                                        backgroundColor:
                                            theme.color.background.elevation1,
                                        height: 8,
                                        width: 90,
                                        borderRadius: 10,
                                    }}
                                />
                                <View
                                    style={{
                                        backgroundColor:
                                            theme.color.background.elevation1,
                                        height: 8,
                                        width: 110,
                                        borderRadius: 10,
                                    }}
                                />
                                <View
                                    style={{
                                        backgroundColor:
                                            theme.color.background.elevation1,
                                        height: 8,
                                        width: 90,
                                        borderRadius: 10,
                                    }}
                                />
                            </StackView>
                        </View>
                    </View>
                    <View
                        style={{
                            marginBottom: 16,
                        }}>
                        <Text
                            style={[
                                TextStyles.bold15,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            Maintenance Checklist
                        </Text>
                    </View>
                    <View
                        style={{
                            flexDirection: "row",
                            marginBottom: 8,
                            alignItems: "center",
                        }}>
                        <CheckBox
                            isChecked={true}
                            fillColor={theme.color.blue.brand}
                            style={{
                                marginRight: 16,
                            }}
                        />
                        <Text
                            style={[
                                TextStyles.semibold17,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            Test Smoke Alarm
                        </Text>
                    </View>
                    <View
                        style={{
                            flexDirection: "row",
                            marginBottom: 8,
                            alignItems: "center",
                        }}>
                        <CheckBox
                            isChecked={false}
                            style={{
                                marginRight: 16,
                            }}
                        />
                        <View>
                            <View
                                style={{
                                    height: 8,
                                    width: 80,
                                    borderRadius: 10,
                                    marginBottom: 8,
                                    backgroundColor:
                                        theme.color.background.elevation1,
                                }}
                            />
                            <View
                                style={{
                                    height: 8,
                                    width: 110,
                                    borderRadius: 10,
                                    backgroundColor:
                                        theme.color.background.elevation1,
                                }}
                            />
                        </View>
                        <View
                            style={{
                                top: 20,
                                right: -15,
                                padding: 8,
                                flexDirection: "row",
                                justifyContent: "flex-end",
                                alignItems: "center",
                                borderRadius: 8,
                                backgroundColor:
                                    theme.color.background.elevation3,
                                ...shadowStyle,
                            }}>
                            <HeadsetIcon
                                style={{ marginRight: 4 }}
                                fill={theme.color.blue.brand.toString()}
                            />
                            <Text
                                style={[
                                    TextStyles.bold15,
                                    { color: theme.color.text.main },
                                ]}>
                                Helpline
                            </Text>
                        </View>
                    </View>
                    <View
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                            marginBottom: 16,
                        }}>
                        <CheckBox
                            isChecked={false}
                            style={{
                                marginRight: 16,
                            }}
                        />
                        <View>
                            <View
                                style={{
                                    height: 8,
                                    width: 80,
                                    borderRadius: 10,
                                    marginBottom: 8,
                                    backgroundColor:
                                        theme.color.background.elevation1,
                                }}
                            />
                            <View
                                style={{
                                    height: 8,
                                    width: 110,
                                    borderRadius: 10,
                                    backgroundColor:
                                        theme.color.background.elevation1,
                                }}
                            />
                        </View>
                    </View>
                </View>
            </View>
        </View>
    );
};

export default MaintenanceDemoCard;
