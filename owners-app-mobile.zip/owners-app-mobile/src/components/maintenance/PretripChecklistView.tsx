import React from "react";
import { useTheme } from "../../context";
import { PretripChecklistItem } from "../../models/domain/maintenance";
import { TextStyles } from "../../styles";
import CheckBox from "../CheckBox";
import LabeledRow from "../LabeledRow";
import StackSection from "../StackSection";

export const PretripChecklistView: React.FunctionComponent<{
    items: PretripChecklistItem[];
    toggleChecked: (taskId: number) => void;
}> = ({ items, toggleChecked }) => {
    const [theme] = useTheme();

    return (
        <StackSection hasBorder={true}>
            {items.map((i) => {
                const isComplete = i.isComplete;
                const { id, description } = i.task;

                return (
                    <LabeledRow
                        key={id}
                        rightIconVisible={false}
                        onPress={() => toggleChecked(id)}
                        leftText={description}
                        leftTextStyle={[
                            TextStyles.semibold17,
                            {
                                color: theme.color.text.main,
                            },
                        ]}
                        leftView={
                            <CheckBox
                                isChecked={isComplete}
                                onToggleChecked={() => toggleChecked(id)}
                            />
                        }
                    />
                );
            })}
        </StackSection>
    );
};
