import React from "react";
import { StyleProp, Text, View, ViewStyle } from "react-native";
import StackView from "../StackView";
import { EllipsisIcon, HomeOutlineIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import { ImageButton } from "../Buttons";

const MaintentanceTaskRow: React.FunctionComponent<{
    zone: string;
    title: string;
    style?: StyleProp<ViewStyle>;
}> = ({ zone, title, style }) => {
    const [theme] = useTheme();

    function onEllipsisPressed() {
        console.log("Ellipses pressed");
    }

    return (
        <StackView
            spacing={16}
            style={[
                {
                    padding: 20,
                    backgroundColor: theme.color.background.elevation2,
                    borderRadius: 8,
                    flexDirection: "row",
                    alignItems: "center",
                },
                style,
            ]}>
            {/* Icon */}
            <View
                style={{
                    width: 60,
                    height: 60,
                    borderRadius: 8,
                    backgroundColor: theme.color.blue.brand,
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                <HomeOutlineIcon fill={theme.color.white.toString()} />
            </View>

            <View
                style={{
                    flex: 1,
                }}>
                <Text
                    numberOfLines={1}
                    style={[
                        TextStyles.listEyebrow,
                        {
                            color: theme.color.text.deemphasized,
                        },
                    ]}>
                    {zone}
                </Text>
                <Text
                    numberOfLines={2}
                    style={[
                        TextStyles.listItemSmall,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {title}
                </Text>
            </View>

            <ImageButton
                image={EllipsisIcon}
                imageProps={{
                    fill: theme.color.text.main.toString(),
                }}
                onPress={onEllipsisPressed}
            />
        </StackView>
    );
};

export default MaintentanceTaskRow;
