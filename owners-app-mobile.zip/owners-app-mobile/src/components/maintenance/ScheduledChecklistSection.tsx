import React from "react";
import { Text, View } from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import {
    MaintenanceTask,
    UserVehicleMaintenanceTask,
} from "../../models/domain/maintenance";
import { TextStyles } from "../../styles";
import { ArrayUtils, DateUtil } from "../../utils";
import LabeledRow from "../LabeledRow";
import StackSection from "../StackSection";

export type ScheduledChecklistItem = {
    task: MaintenanceTask;
    userVehicleTask?: UserVehicleMaintenanceTask;
};

export type ScheduledChecklistSectionProps = {
    zoneId: string;
    displayName: string;
    displayOrder: number;
    icon: React.FunctionComponent<SvgProps>;
    items: ScheduledChecklistItem[];
    showModal: (item: ScheduledChecklistItem) => void;
};

export const ScheduledChecklistSection: React.FunctionComponent<
    ScheduledChecklistSectionProps
> = ({ displayName, items, icon, showModal }) => {
    const [theme] = useTheme();

    const numCompleted = ArrayUtils.sum(items, (x) =>
        x.userVehicleTask?.dateCompleted ? 1 : 0
    );

    return (
        <View>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 16,
                }}>
                <View
                    style={{
                        flex: 1,
                        flexDirection: "row",
                        justifyContent: "center",
                        alignItems: "center",
                    }}>
                    <View
                        style={{
                            backgroundColor: theme.color.background.elevation2,
                            marginRight: 12,
                            padding: 2,
                            borderRadius: 4,
                        }}>
                        {icon({
                            width: 24,
                            height: 24,
                            fill: theme.color.blue.brand.toString(),
                        })}
                    </View>
                    <Text
                        style={[
                            TextStyles.listItemLarge,
                            { flex: 1, color: theme.color.text.main },
                        ]}>
                        {displayName}
                    </Text>
                </View>
                <Text
                    style={[
                        TextStyles.medium15,
                        { color: theme.color.text.deemphasized },
                    ]}>
                    {numCompleted}/{items.length}
                </Text>
            </View>
            <StackSection hasBorder={true} style={{ marginBottom: 45 }}>
                {items.map((item) => {
                    const dateString = item.userVehicleTask?.dateCompleted;
                    let completedText: string | undefined;

                    if (dateString) {
                        completedText = `Completed: ${DateUtil.toDateString(
                            DateUtil.parseDateOnlyString(dateString)
                        )}`;
                    }

                    return (
                        <LabeledRow
                            key={item.task.id.toString()}
                            leftText={item.task.description}
                            leftTextStyle={[
                                TextStyles.listItemSmall,
                                { color: theme.color.text.main },
                            ]}
                            onPress={() => showModal(item)}
                            leftSubtext={completedText}
                        />
                    );
                })}
            </StackSection>
        </View>
    );
};
