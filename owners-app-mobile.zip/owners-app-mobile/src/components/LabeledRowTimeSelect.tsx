import React, { useState } from "react";
import { StyleProp, Text, TextStyle } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { DateTimePicker } from "./DateTimePicker";
import StackView from "./StackView";

interface LabeledRowTimeSelectProps {
    label: string;
    mode: "date" | "time";
    disabled?: boolean;
    value: string | number | boolean;
    subTextStyle?: StyleProp<TextStyle>;
    onPress?: () => void;
    onValueChanged: (time: any) => void;
}

export const LabeledRowTimeSelect: React.FunctionComponent<
    LabeledRowTimeSelectProps
> = ({ label, mode, disabled = false, value, onPress, onValueChanged }) => {
    const [theme] = useTheme();
    const [isOpen, setIsOpen] = useState(false);

    return (
        <StackView
            spacing={4}
            style={{
                flexDirection: "row",
                height: 56,
                paddingLeft: 20,
                backgroundColor: theme.color.background.elevation3,
            }}>
            <Text
                numberOfLines={1}
                style={[
                    TextStyles.listItemSmall,
                    {
                        flex: 1,
                        alignSelf: "center",
                        color: disabled
                            ? theme.color.text.disabled
                            : isOpen
                            ? theme.color.blue.brand
                            : theme.color.text.main,
                    },
                ]}>
                {label}
            </Text>

            <DateTimePicker
                value={value}
                mode={mode}
                disabled={disabled}
                containerStyle={{
                    flex: 2,
                    justifyContent: "center",
                }}
                textStyle={[
                    TextStyles.body,
                    {
                        color: disabled
                            ? theme.color.text.disabled
                            : isOpen
                            ? theme.color.blue.brand
                            : theme.color.text.main,
                    },
                ]}
                subTextStyle={[
                    TextStyles.body,
                    {
                        color: disabled
                            ? theme.color.text.disabled
                            : isOpen
                            ? theme.color.blue.brand
                            : theme.color.text.deemphasized,
                    },
                ]}
                onChange={onValueChanged}
                onOpen={() => {
                    setIsOpen(true);
                    onPress?.();
                }}
                onClose={() => {
                    setIsOpen(false);
                }}
            />
        </StackView>
    );
};
