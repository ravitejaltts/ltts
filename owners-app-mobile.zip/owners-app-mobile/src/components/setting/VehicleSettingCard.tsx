import { observer } from "mobx-react-lite";
import React from "react";
import {
    ActivityIndicator,
    Text,
    TouchableHighlight,
    View,
} from "react-native";
import FastImage from "react-native-fast-image";
import { AddCircleIcon, ChevronRightIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { VehicleConnectionState } from "../../models/domain/connection";
import { AvatarImageItem } from "../../models/domain/content";
import { SmartVehicle } from "../../models/domain/vehicle";
import { TextStyles } from "../../styles";
import { ButtonRow } from "../ButtonRow";
import StackSection from "../StackSection";
import StackView from "../StackView";

type VehicleSettingCardProps = {
    onVehiclePress: () => void;
    onPairPress: () => void;
    disabled?: boolean;
};

export const VehicleSettingCard: React.FunctionComponent<
    VehicleSettingCardProps
> = ({ onVehiclePress, onPairPress, disabled = false }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const vehicleStore = container.stores.vehicle;
    const vehicle = vehicleStore.associatedVehicle;
    const isUnpaired =
        vehicle instanceof SmartVehicle &&
        vehicle.connectionState === VehicleConnectionState.Unpaired;
    const isRemovingVehcle = vehicleStore.isRemovingVehicle;

    let vehicleHeading = "Add Your RV";
    let vehicleSubheading = "Get personalized content";
    let vehicleAvatar: AvatarImageItem | undefined;

    if (vehicle) {
        vehicleAvatar = vehicle.avatar;
        vehicleHeading = `${vehicle.year} ${vehicle.seriesName} ${vehicle.shortenedFloorPlan}`;
        vehicleSubheading = vehicle.vin ?? "";
    }

    const isDisabled = disabled || isRemovingVehcle;

    return (
        <StackSection>
            <TouchableHighlight
                underlayColor={theme.color.background.labeledRowUnderlay}
                onPress={onVehiclePress}
                disabled={isDisabled}
                style={{
                    opacity: isDisabled ? 0.5 : 1,
                    borderTopLeftRadius: 8,
                    borderTopRightRadius: 8,
                    borderBottomLeftRadius: isUnpaired ? 0 : 8,
                    borderBottomRightRadius: isUnpaired ? 0 : 8,
                    backgroundColor: theme.color.background.elevation3,
                }}>
                <StackView
                    spacing={20}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                        padding: 20,
                    }}>
                    {isRemovingVehcle ? (
                        <ActivityIndicator
                            animating={true}
                            color={theme.color.blue.brand}
                        />
                    ) : vehicleAvatar ? (
                        <View
                            style={{
                                backgroundColor:
                                    theme.color.background.elevation1,
                                width: 60,
                                height: 60,
                                borderRadius: 30,
                                justifyContent: "center",
                                alignItems: "center",
                            }}>
                            <FastImage
                                resizeMode="contain"
                                source={{ uri: vehicleAvatar.url }}
                                style={{
                                    width: 50,
                                    height: 50,
                                }}
                            />
                        </View>
                    ) : !vehicle ? (
                        <View
                            style={{
                                backgroundColor: theme.color.red.brand,
                                borderRadius: 4,
                                padding: 10,
                            }}>
                            <AddCircleIcon
                                width={24}
                                height={24}
                                fill={theme.color.white.toString()}
                            />
                        </View>
                    ) : null}

                    {/* Text */}
                    <StackView
                        spacing={4}
                        style={{
                            flex: 1,
                        }}>
                        <Text
                            style={[
                                TextStyles.listItemLarge,
                                {
                                    color: theme.color.text.main,
                                },
                            ]}>
                            {vehicleHeading}
                        </Text>

                        {Boolean(vehicleSubheading) && (
                            <Text
                                style={[
                                    TextStyles.subheading,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {vehicleSubheading}
                            </Text>
                        )}
                    </StackView>

                    {/* Right Chevron */}
                    <ChevronRightIcon
                        width={28}
                        height={28}
                        fill={theme.color.components.gray2}
                    />
                </StackView>
            </TouchableHighlight>

            {isUnpaired && !isRemovingVehcle && (
                <ButtonRow
                    text="Connect to Bluetooth"
                    disabled={isDisabled}
                    onPress={onPairPress}
                />
            )}
        </StackSection>
    );
};

export default observer(VehicleSettingCard);
