import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React, { useCallback, useState } from "react";
import { Alert, ViewStyle } from "react-native";
import { env } from "../../config/env";
import { useRootContainer } from "../../context";
import { useLogger } from "../../hooks";
import {
    BleVehicleConnection,
    CloudVehicleConnection,
    LocalVehicleConnection,
    VehicleConnectionState,
    VehicleConnectionType,
} from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { DebugScreenNavigationProp } from "../../screens/settings/debug";
import { WgoSetting } from "../../services/WgoSettingService";
import { ButtonRow } from "../ButtonRow";
import LabeledRow from "../LabeledRow";
import LabeledRowSelect from "../LabeledRowSelect";
import LabeledRowSwitch from "../LabeledRowSwitch";
import { PickerItem } from "../Picker";
import SettingSection from "../SettingSection";
import StackView from "../StackView";

type WinnConnectDebugSectionProps = {
    vehicle: SmartVehicle;
};

const WinnConnectDebugSection: React.FunctionComponent<
    WinnConnectDebugSectionProps
> = ({ vehicle }) => {
    const navigation = useNavigation<DebugScreenNavigationProp>();
    const { logError } = useLogger("WinnConnectDebugSection");

    const bleAuthStore = vehicle.bleAuthStore;

    const container = useRootContainer();
    const settingService = container.services.setting;

    const connectionState = vehicle.connectionState;
    const [connectionType, setConnectionType] = useState<VehicleConnectionType>(
        () => {
            if (vehicle.connectionType !== null) {
                return vehicle.connectionType;
            }

            return vehicle.storedConnectionType;
        }
    );

    const pollingVisible = connectionType !== VehicleConnectionType.Mock;
    const deviceTemplatesVisible =
        connectionType === VehicleConnectionType.Bluetooth ||
        connectionType === VehicleConnectionType.Local;

    const deviceVersion = vehicle.deviceVersion;
    const deviceId = vehicle.deviceId;
    const deviceType = vehicle.deviceType;
    const bluetoothId = vehicle.bluetoothId;
    const templateVersion = vehicle.componentTemplates.version;

    const getDefaultPollingInterval = useCallback(
        (type: VehicleConnectionType) => {
            switch (type) {
                case VehicleConnectionType.Bluetooth:
                    return BleVehicleConnection.DefaultPollingIntervalMillis;
                case VehicleConnectionType.Cloud:
                    return CloudVehicleConnection.DefaultPollingIntervalMillis;
                case VehicleConnectionType.Local:
                    return LocalVehicleConnection.DefaultPollingIntervalMillis;
                default:
                    return 0;
            }
        },
        []
    );

    const [baseUrl, setBaseUrl] = useState("");

    const [pollingEnabled, setPollingEnabled] = useState(true);

    const [pollingInterval, setPollingInterval] = useState(0);

    const [vinOverride, setVinOverride] = useState("");

    const [deviceIdOverride, setDeviceIdOverride] = useState("");

    const [deviceTypeOverride, setDeviceTypeOverride] = useState("");

    const [useDeviceTemplates, setUseDeviceTemplates] = useState(
        settingService.useDeviceTemplates
    );

    // When screen is focused, update the screen states
    useFocusEffect(
        useCallback(() => {
            setBaseUrl(settingService.winnConnectBaseUrl);

            setVinOverride(settingService.winnConnectVinOverride || "Not set");

            setPollingEnabled(settingService.winnConnectPollingEnabled);

            let settingsPollingInterval =
                settingService.winnConnectPollingInterval;

            if (!settingsPollingInterval) {
                settingsPollingInterval =
                    getDefaultPollingInterval(connectionType);
                settingService.winnConnectPollingInterval =
                    settingsPollingInterval;
            }

            setPollingInterval(settingsPollingInterval);

            setDeviceIdOverride(
                settingService.winnConnectDeviceIdOverride || "Not set"
            );
            setDeviceTypeOverride(
                settingService.winnConnectDeviceTypeOverride || "Not set"
            );
        }, [settingService, connectionType, getDefaultPollingInterval])
    );

    const disconnect = () => {
        Alert.alert("Disconnect?", undefined, [
            {
                text: "Cancel",
                style: "cancel",
            },
            {
                text: "Disconnect",
                style: "destructive",
                onPress: () => {
                    vehicle.disconnect();
                },
            },
        ]);
    };

    const disconnectAndUnpair = () => {
        Alert.alert("Disconnect & Unpair device?", undefined, [
            {
                text: "Cancel",
                style: "cancel",
            },
            {
                text: "Unpair",
                style: "destructive",
                onPress: () => {
                    vehicle.disconnectAndUnpair();
                },
            },
        ]);
    };

    const connectionTypeItems: PickerItem[] = [];

    if (env.name === "mock") {
        connectionTypeItems.push({
            label: "Mock",
            value: VehicleConnectionType.Mock,
        });
    } else {
        connectionTypeItems.push(
            {
                label: "Bluetooth",
                value: VehicleConnectionType.Bluetooth,
            },
            {
                label: "Cloud",
                value: VehicleConnectionType.Cloud,
            },
            {
                label: "Local Network",
                value: VehicleConnectionType.Local,
            }
        );
    }

    const labeledRowStyle: ViewStyle = {
        height: 54,
        paddingVertical: 0,
        justifyContent: "center",
    };

    return (
        <StackView spacing={24}>
            <SettingSection title="VEHICLE INFO">
                <LabeledRow
                    leftText="State"
                    rightText={connectionState.toString()}
                    rightIconVisible={false}
                    style={labeledRowStyle}
                />
                <LabeledRow
                    leftText="Device ID"
                    rightText={deviceId ? deviceId : "Unknown"}
                    rightIconVisible={false}
                />
                <LabeledRow
                    leftText="Device Type"
                    rightText={deviceType ? deviceType : "Unknown"}
                    rightIconVisible={false}
                />
                <LabeledRow
                    leftText="Bluetooth ID"
                    rightText={bluetoothId ? bluetoothId : "Unknown"}
                    rightIconVisible={false}
                />
                <LabeledRow
                    leftText="Device Version"
                    rightText={deviceVersion?.toString() ?? "Unknown"}
                    rightIconVisible={false}
                />
                <LabeledRow
                    leftText="Template Version"
                    rightText={templateVersion?.toString() ?? "Unknown"}
                    rightIconVisible={false}
                />
            </SettingSection>

            <SettingSection title="VEHICLE SETTINGS">
                <LabeledRowSelect
                    label="Connection"
                    items={connectionTypeItems}
                    value={connectionType}
                    disabled={
                        connectionState === VehicleConnectionState.Connected
                    }
                    onValueChanged={(item) => {
                        const type = item.value as VehicleConnectionType;
                        setConnectionType(type);
                    }}
                    onClose={(item) => {
                        const type = item.value as VehicleConnectionType;
                        // Set connection type on vehicle
                        vehicle.setConnectionType(type);
                        vehicle.storeMetadata();

                        const defaultPollingInterval =
                            getDefaultPollingInterval(type);
                        setPollingInterval(defaultPollingInterval);
                        settingService.winnConnectPollingInterval =
                            defaultPollingInterval;
                    }}
                />
                {pollingVisible && (
                    <LabeledRowSwitch
                        leftText="API Polling"
                        value={pollingEnabled}
                        onValueChanged={(value) => {
                            setPollingEnabled(value);
                            settingService.winnConnectPollingEnabled = value;
                        }}
                    />
                )}
                {pollingVisible && (
                    <LabeledRow
                        leftText="Polling Interval"
                        rightText={pollingInterval.toString()}
                        onPress={() => {
                            navigation.navigate("numberSetting", {
                                settingKey:
                                    WgoSetting.WinnConnectPollingInterval,
                                settingName: "Polling Interval",
                                defaultValue: connectionType
                                    ? getDefaultPollingInterval(connectionType)
                                    : 0,
                            });
                        }}
                    />
                )}
                {
                    // Base URL
                    connectionType === VehicleConnectionType.Local && (
                        <LabeledRow
                            leftText="Base URL"
                            rightText={baseUrl}
                            rightIconVisible={true}
                            style={labeledRowStyle}
                            onPress={() => {
                                navigation.navigate("stringSetting", {
                                    settingKey: WgoSetting.WinnConnectBaseUrl,
                                    settingName: "Base URL",
                                    autoCapitalize: "none",
                                });
                            }}
                        />
                    )
                }
                {
                    // VIN Override
                    connectionType === VehicleConnectionType.Bluetooth && (
                        <LabeledRow
                            leftText="VIN Override"
                            rightText={vinOverride}
                            rightIconVisible={true}
                            style={labeledRowStyle}
                            onPress={() => {
                                navigation.navigate("stringSetting", {
                                    settingKey:
                                        WgoSetting.WinnConnectVinOverride,
                                    settingName: "VIN Override",
                                    autoCapitalize: "characters",
                                });
                            }}
                        />
                    )
                }
                <LabeledRow
                    leftText="Device ID Override"
                    rightText={deviceIdOverride}
                    rightIconVisible={true}
                    style={labeledRowStyle}
                    onPress={() => {
                        navigation.navigate("stringSetting", {
                            settingKey: WgoSetting.WinnConnectDeviceIdOverride,
                            settingName: "Device ID Override",
                            autoCapitalize: "none",
                        });
                    }}
                />
                <LabeledRow
                    leftText="Device Type Override"
                    rightText={deviceTypeOverride}
                    rightIconVisible={true}
                    style={labeledRowStyle}
                    onPress={() => {
                        navigation.navigate("stringSetting", {
                            settingKey:
                                WgoSetting.WinnConnectDeviceTypeOverride,
                            settingName: "Device Type Override",
                            autoCapitalize: "none",
                        });
                    }}
                />
                {deviceTemplatesVisible && (
                    <LabeledRowSwitch
                        leftText="Use Device Templates"
                        value={useDeviceTemplates}
                        onValueChanged={(value) => {
                            setUseDeviceTemplates(value);
                            settingService.useDeviceTemplates = value;
                        }}
                    />
                )}
            </SettingSection>

            <SettingSection title="VEHICLE ACTIONS">
                {
                    // Component Scenarios
                    connectionState === VehicleConnectionState.Connected && (
                        <LabeledRow
                            leftText="Component Scenarios"
                            rightIconVisible={true}
                            style={labeledRowStyle}
                            onPress={() => {
                                navigation.navigate("systemStores");
                            }}
                        />
                    )
                }
                {
                    // Refresh Component Templates Button
                    connectionState === VehicleConnectionState.Connected && (
                        <ButtonRow
                            text="Refresh Component Templates"
                            action={async () => {
                                vehicle.componentTemplates.resetComponentTemplates(
                                    vehicle.deviceId
                                );

                                try {
                                    await vehicle.componentTemplates.update();
                                } catch (error) {
                                    if (error instanceof Error) {
                                        logError(error);
                                    }

                                    // Rethrow for button
                                    throw error;
                                }
                            }}
                        />
                    )
                }
                {
                    // Connect Button
                    (connectionState === VehicleConnectionState.Disconnected ||
                        connectionState ===
                            VehicleConnectionState.Unpaired) && (
                        <ButtonRow
                            text="Connect"
                            action={async () => {
                                try {
                                    await vehicle.connect(
                                        connectionType,
                                        false
                                    );
                                } catch (error) {
                                    if (error instanceof Error) {
                                        logError(error);
                                    }

                                    // Rethrow for button
                                    throw error;
                                }
                            }}
                        />
                    )
                }
                {
                    // Disconnect Button
                    connectionState === VehicleConnectionState.Connected && (
                        <ButtonRow
                            text="Disconnect"
                            isDestructive={true}
                            onPress={disconnect}
                        />
                    )
                }
                {
                    // Disconnect & Unpair Button
                    connectionState !== VehicleConnectionState.Unpaired && (
                        <ButtonRow
                            text="Disconnect & Unpair"
                            isDestructive={true}
                            onPress={disconnectAndUnpair}
                        />
                    )
                }

                {Boolean(bluetoothId) && (
                    <ButtonRow
                        text="Delete Bluetooth ID"
                        isDestructive={true}
                        onPress={() => {
                            vehicle.setBluetoothId("");
                            vehicle.storeMetadata();
                        }}
                    />
                )}
                {Boolean(deviceId) && (
                    <ButtonRow
                        text="Delete Bluetooth Cert"
                        isDestructive={true}
                        action={async () => {
                            await bleAuthStore.deleteStoredAuthValues(deviceId);
                        }}
                    />
                )}
            </SettingSection>
        </StackView>
    );
};

export default observer(WinnConnectDebugSection);
