import { useNavigation } from "@react-navigation/native";
import React from "react";
import { Platform, StyleProp, View, ViewStyle } from "react-native";
import { useTheme } from "../context";
import { HeaderSecondaryButton } from "./Buttons";

const ModalHeaderView: React.FunctionComponent<{
    style?: StyleProp<ViewStyle>;
    onClose?: () => void;
    handleVisible?: boolean;
}> = ({ style, handleVisible = true, onClose }) => {
    const [theme] = useTheme();
    const navigation = useNavigation();

    return (
        <View
            style={[
                {
                    flexDirection: "row",
                    justifyContent: "space-between",
                    paddingHorizontal: 20,
                },
                style,
            ]}>
            {/* Invisible Spacer View */}
            <View
                style={{
                    flex: 1,
                }}
            />

            {/* Handle */}
            {handleVisible && (
                <View
                    style={{
                        width: 75,
                        height: 4,
                        borderRadius: 2,
                        marginTop: 16,
                        backgroundColor:
                            Platform.OS == "ios"
                                ? theme.color.components.gray2
                                : theme.color.transparent,
                    }}
                />
            )}

            {/* Close Button */}
            <HeaderSecondaryButton
                style={{
                    flex: 1,
                    marginTop: 8,
                    paddingRight: 8,
                }}
                textStyle={{
                    textAlign: "right",
                }}
                text="Close"
                onPress={() => {
                    if (onClose) {
                        onClose();
                    } else {
                        navigation.goBack();
                    }
                }}
            />
        </View>
    );
};

export default ModalHeaderView;
