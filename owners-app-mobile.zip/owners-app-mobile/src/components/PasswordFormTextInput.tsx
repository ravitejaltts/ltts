import React, { useState } from "react";
import { TextInput } from "react-native";
import { EyeClosedIcon, EyeOpenIcon } from "../assets/icons";
import { useTheme } from "../context";
import { ImageButton } from "./Buttons";
import FormTextInput, { FormTextInputProps } from "./FormTextInput";

const PasswordFormTextInput = React.forwardRef<TextInput, FormTextInputProps>(
    (props, ref) => {
        const [theme] = useTheme();
        const [isHidden, setIsHidden] = useState(true);

        const image = isHidden || props.disabled ? EyeOpenIcon : EyeClosedIcon;

        return (
            <FormTextInput
                ref={ref}
                {...props}
                secureTextEntry={isHidden || props.disabled}
                autoCapitalize="none"
                rightView={
                    <ImageButton
                        image={image}
                        imageProps={{
                            fill: theme.color.components.gray1.toString(),
                        }}
                        onPress={() => {
                            setIsHidden(!isHidden);
                        }}
                        style={{
                            paddingHorizontal: 20,
                            paddingVertical: 12,
                        }}
                    />
                }
            />
        );
    }
);

export default PasswordFormTextInput;
