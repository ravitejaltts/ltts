import React from "react";
import {
    Text,
    TouchableOpacity,
    ColorValue,
    StyleProp,
    ViewStyle,
} from "react-native";
import { FontWeight, TextStyles } from "../styles";
import { useTheme } from "../context";
import { SvgProps } from "react-native-svg";
import StackView from "./StackView";

export type SectionProps<ValueType> = {
    label: string;
    value: ValueType;
    icon?: React.FunctionComponent<SvgProps>;
    selectedStyle?: {
        backgroundColor?: ColorValue;
        textColor?: ColorValue;
    };
    textStyle?: {
        fontSize: number;
        fontWeight: FontWeight;
    };
};

export type Props<ValueType> = {
    sections: SectionProps<ValueType>[];
    value: string | number;
    onValueChanged: (value: ValueType) => void;
    disabled?: boolean;
    style?: StyleProp<ViewStyle>;
};

const HEIGHT = 36;
const BORDER_RADIUS = HEIGHT / 2;

export default function PillSelect<ValueType>(props: Props<ValueType>) {
    const { sections = [], value, onValueChanged, disabled = false } = props;

    const [theme] = useTheme();

    const sectionViews = sections.map((section, index) => {
        const {
            label,
            value: sectionValue,
            icon,
            selectedStyle,
            textStyle = TextStyles.semibold15,
        } = section;

        const isSelected = !disabled && sectionValue === value;
        const isFirstSection = index === 0;
        const isLastSection = index === sections.length - 1;

        let backgroundColor: ColorValue;
        let textColor: ColorValue;
        let borderColor: ColorValue | undefined;
        let borderTopWidth = 0;
        let borderBottomWidth = 0;
        let borderLeftWidth = 0;
        let borderRightWidth = 0;
        let borderTopLeftRadius = 0;
        let borderTopRightRadius = 0;
        let borderBottomLeftRadius = 0;
        let borderBottomRightRadius = 0;

        if (isSelected) {
            backgroundColor =
                selectedStyle?.backgroundColor ?? theme.color.text.main;
            textColor =
                selectedStyle?.textColor ?? theme.color.text.mainInverted;
        } else {
            backgroundColor = theme.color.background.elevation3;
            textColor = disabled
                ? theme.color.text.disabled
                : theme.color.text.main;
            borderColor = disabled
                ? theme.color.text.disabled
                : theme.color.dividers.gray1;

            // Show border for unselected sections
            borderTopWidth = 1;
            borderBottomWidth = 1;

            if (isFirstSection) {
                borderLeftWidth = 1;
            } else if (isLastSection) {
                borderRightWidth = 1;
            }
        }

        if (isFirstSection) {
            borderTopLeftRadius = BORDER_RADIUS;
            borderBottomLeftRadius = BORDER_RADIUS;
        } else if (isLastSection) {
            borderTopRightRadius = BORDER_RADIUS;
            borderBottomRightRadius = BORDER_RADIUS;
        }

        return (
            <TouchableOpacity
                key={index.toString()}
                activeOpacity={0.5}
                disabled={disabled}
                onPress={() => onValueChanged(sectionValue)}
                style={{
                    flex: 1,
                    flexDirection: "row",
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: backgroundColor,
                    borderColor: borderColor,
                    borderTopWidth: borderTopWidth,
                    borderBottomWidth: borderBottomWidth,
                    borderLeftWidth: borderLeftWidth,
                    borderRightWidth: borderRightWidth,
                    borderTopLeftRadius: borderTopLeftRadius,
                    borderTopRightRadius: borderTopRightRadius,
                    borderBottomLeftRadius: borderBottomLeftRadius,
                    borderBottomRightRadius: borderBottomRightRadius,
                }}>
                <StackView
                    spacing={4}
                    style={{
                        flexDirection: "row",
                    }}>
                    {icon &&
                        icon({
                            width: 20,
                            height: 20,
                            fill: textColor.toString(),
                        })}

                    <Text
                        style={[
                            textStyle,
                            {
                                color: textColor,
                            },
                        ]}>
                        {label}
                    </Text>
                </StackView>
            </TouchableOpacity>
        );
    });

    return (
        <StackView
            spacing={1}
            spacerColor={
                disabled
                    ? theme.color.text.disabled
                    : theme.color.dividers.gray1
            }
            style={[
                {
                    flexDirection: "row",
                    height: HEIGHT,
                    borderRadius: BORDER_RADIUS,
                    backgroundColor: theme.color.background.elevation2,
                },
                props.style,
            ]}>
            {sectionViews}
        </StackView>
    );
}
