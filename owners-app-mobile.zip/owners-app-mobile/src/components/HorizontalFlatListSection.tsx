import React from "react";
import {
    FlatList,
    ListRenderItem,
    StyleProp,
    Text,
    View,
    ViewStyle,
} from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { LinkButton } from "./Buttons";

const HorizontalFlatListSection: React.FunctionComponent<{
    headerText: string;
    data: any[];
    isLoading?: boolean;
    renderLoading?: React.FunctionComponent;
    renderEmpty?: React.FunctionComponent;
    renderItem: ListRenderItem<any>;
    onSeeAllPressed?: () => void;
    getItemLayout?: (
        data: any,
        index: number
    ) => { length: number; offset: number; index: number };
    style?: StyleProp<ViewStyle>;
}> = ({
    headerText,
    data,
    isLoading = false,
    renderLoading,
    renderEmpty,
    renderItem,
    onSeeAllPressed,
    getItemLayout,
    style,
}) => {
    const [theme] = useTheme();

    let childElement: React.ReactNode;

    if (isLoading) {
        if (renderLoading) {
            childElement = renderLoading({});
        } else {
            childElement = renderAllItems();
        }
    } else {
        if (data.length === 0 && renderEmpty) {
            childElement = renderEmpty({});
        } else {
            childElement = renderAllItems();
        }
    }

    function renderAllItems() {
        return (
            <FlatList
                horizontal={true}
                data={data}
                renderItem={renderItem}
                ItemSeparatorComponent={() => <View style={{ width: 12 }} />}
                keyExtractor={(item, index) => index.toString()}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{
                    paddingHorizontal: 20,
                }}
                getItemLayout={getItemLayout}
            />
        );
    }

    return (
        <View style={style}>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    paddingHorizontal: 20,
                    paddingBottom: onSeeAllPressed ? 6 : 20,
                }}>
                {Boolean(headerText) && (
                    <Text
                        style={[
                            TextStyles.sectionBreak,
                            {
                                color: theme.color.text.main,
                            },
                        ]}>
                        {headerText}
                    </Text>
                )}

                {onSeeAllPressed && (
                    <LinkButton
                        text="See All"
                        onPress={onSeeAllPressed}
                        disabled={data.length === 0}
                    />
                )}
            </View>

            {childElement}
        </View>
    );
};

export default HorizontalFlatListSection;
