import React, { useEffect, useState } from "react";
import { StyleProp, TouchableHighlight, View, ViewStyle } from "react-native";
import { SvgProps } from "react-native-svg";
import { WarningFillIcon } from "../assets/icons";
import { useTheme } from "../context";
import ThemedSwitch from "./ThemedSwitch";

type SwitchCardProps = {
    isOn: boolean;
    disabled?: boolean;
    icon?: React.FunctionComponent<SvgProps>;
    onSwitchValueChanged: (isOn: boolean) => void;
    onCardPress?: () => void;
    error?: boolean;
    style?: StyleProp<ViewStyle>;
    children: React.ReactNode;
};

const SwitchCard: React.FunctionComponent<SwitchCardProps> = ({
    isOn,
    icon,
    disabled = false,
    onSwitchValueChanged,
    onCardPress,
    error,
    style,
    children,
}) => {
    const [theme] = useTheme();

    const styles: ViewStyle = {
        height: 80,
        borderRadius: 8,
        borderWidth: 1,
        paddingVertical: 8,
        paddingHorizontal: 20,
        borderColor: theme.color.dividers.gray1,
        backgroundColor: theme.color.background.elevation3,
    };

    const [switchValue, setSwitchValue] = useState(isOn);

    useEffect(() => {
        setSwitchValue(isOn);
    }, [isOn]);

    function updateSwitchValue(value: boolean) {
        setSwitchValue(value);
        onSwitchValueChanged(value);
    }

    return (
        <TouchableHighlight
            disabled={disabled}
            underlayColor={theme.color.background.elevation1}
            onPress={() => {
                if (onCardPress) {
                    onCardPress();
                } else {
                    // By default, toggle switch
                    updateSwitchValue(!switchValue);
                }
            }}
            style={[styles, style]}>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    height: "100%",
                }}>
                {error ? (
                    <WarningFillIcon
                        width={24}
                        height={24}
                        fill={theme.color.error.toString()}
                    />
                ) : icon ? (
                    <View
                        style={{
                            aspectRatio: 1,
                            width: 25,
                        }}>
                        {icon({
                            width: 24,
                            height: 24,
                            fill: isOn
                                ? undefined // Use icon color when "on"
                                : theme.color.text.disabled.toString(),
                        })}
                    </View>
                ) : (
                    <View />
                )}
                <View
                    style={{
                        justifyContent: "flex-start",
                        alignItems: "flex-start",
                        flex: 1,
                    }}>
                    {children}
                </View>
                <ThemedSwitch
                    disabled={error}
                    value={switchValue}
                    onValueChange={updateSwitchValue}
                    style={{}}
                />
            </View>
        </TouchableHighlight>
    );
};

export default SwitchCard;
