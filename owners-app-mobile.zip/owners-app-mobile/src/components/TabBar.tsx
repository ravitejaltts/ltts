import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import React from "react";
import { Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import StackView from "./StackView";

// https://reactnavigation.org/docs/bottom-tab-navigator/#tabbar
export const TabBar: React.FunctionComponent<BottomTabBarProps> = ({
    state,
    descriptors,
    navigation,
}) => {
    const [theme] = useTheme();
    const safeAreaInsets = useSafeAreaInsets();

    const focusedColor = theme.color.red.brand;
    const unfocusedColor = theme.color.text.main;

    return (
        <View
            style={{
                flexDirection: "row",
                paddingBottom: safeAreaInsets.bottom + 8,
                paddingTop: 16,
                paddingHorizontal: 8,
                borderTopWidth: 1,
                borderColor: theme.color.dividers.gray1,
                backgroundColor: theme.color.background.elevation3,
            }}>
            {state.routes.map((route, index) => {
                const isFocused = state.index === index;
                const { options } = descriptors[route.key];

                let icon: React.ReactNode;
                const tabBarIcon = options.tabBarIcon;

                if (tabBarIcon) {
                    icon = tabBarIcon({
                        focused: isFocused,
                        color: isFocused
                            ? focusedColor.toString()
                            : unfocusedColor.toString(),
                        size: 24,
                    });
                }

                const onPress = () => {
                    const event = navigation.emit({
                        type: "tabPress",
                        target: route.key,
                        canPreventDefault: true,
                    });

                    if (!isFocused && !event.defaultPrevented) {
                        navigation.navigate(route.name, route.params);
                    }
                };

                const onLongPress = () => {
                    navigation.emit({
                        type: "tabLongPress",
                        target: route.key,
                    });
                };

                return (
                    <Pressable
                        key={route.name}
                        accessibilityRole="button"
                        accessibilityState={isFocused ? { selected: true } : {}}
                        accessibilityLabel={options.tabBarAccessibilityLabel}
                        onPress={onPress}
                        onLongPress={onLongPress}
                        style={{
                            flex: 1,
                        }}>
                        <StackView
                            spacing={4}
                            style={{
                                alignItems: "center",
                            }}>
                            {Boolean(icon) && icon}
                            <Text
                                numberOfLines={1}
                                ellipsizeMode="tail"
                                style={[
                                    TextStyles.regular13,
                                    {
                                        color: isFocused
                                            ? focusedColor
                                            : unfocusedColor,
                                    },
                                ]}>
                                {options.title ?? route.name}
                            </Text>
                        </StackView>
                    </Pressable>
                );
            })}
        </View>
    );
};
