import React, {
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import {
    Animated,
    ColorValue,
    GestureResponderEvent,
    LayoutChangeEvent,
    PanResponder,
    PanResponderGestureState,
    TouchableOpacity,
    View,
} from "react-native";
import { useTheme } from "../context";
import { MathUtils } from "../utils";
import StackView from "./StackView";

type ColorPickerProps = {
    color: ColorValue;
    presets?: ColorValue[];
    onPresetSelected: (presetColor: ColorValue) => void;
    circle: React.FunctionComponent<{ size: number }>;
    thumbSize?: number;
    thumbBorderWidth?: number;
    thumbPosition: {
        x: number;
        y: number;
    };
    onThumbPanStart?: (
        e: GestureResponderEvent,
        state: PanResponderGestureState
    ) => void;

    onThumbPanEnd?: (
        e: GestureResponderEvent,
        state: PanResponderGestureState,
        isWithinCircle: boolean
    ) => void;

    onThumbMoved?: (
        e: GestureResponderEvent,
        state: PanResponderGestureState
    ) => void;

    onLayout?: (e: LayoutChangeEvent) => void;
};

const ColorPicker: React.FunctionComponent<ColorPickerProps> = ({
    color,
    presets,
    onPresetSelected,
    circle,
    thumbSize = 48,
    thumbBorderWidth = 6,
    thumbPosition,
    onThumbPanStart,
    onThumbPanEnd,
    onThumbMoved,
    onLayout,
}) => {
    const [theme] = useTheme();
    const [pickerWidth, setPickerWidth] = useState(0);

    const halfThumbSize = thumbSize / 2;

    const circleRadius = pickerWidth / 2;

    const presetPadding = 12;
    const presetSpacing = 10;
    const presetCount = presets?.length ?? 0;

    const presetSectionWidth = pickerWidth - 2 * presetPadding;
    const presetSize =
        (presetSectionWidth - (presetCount - 1) * presetSpacing) / presetCount;
    const innerPresetSize = 0.75 * presetSize;
    const presetSectionHeight = 2 * presetPadding + presetSize;
    const presetSectionBorderRadius = presetSectionHeight / 2;

    const opacityRef = useRef(new Animated.Value(0));

    const panX = useRef(new Animated.Value(0)).current;
    const panY = useRef(new Animated.Value(0)).current;

    const panEventRef = useRef(
        Animated.event(
            [
                {
                    locationX: panX,
                    locationY: panY,
                },
            ],
            {
                useNativeDriver: false,
            }
        )
    );

    const isWithinCircle = useCallback(
        (e: GestureResponderEvent) => {
            const { locationX, locationY } = e.nativeEvent;
            const x = locationX - circleRadius;
            const y = locationY - circleRadius;

            return MathUtils.isWithinCircle(circleRadius, x, y);
        },
        [circleRadius]
    );

    const panResponder = useMemo(
        () =>
            PanResponder.create({
                onStartShouldSetPanResponder: (e) => isWithinCircle(e),
                onStartShouldSetPanResponderCapture: (e) => isWithinCircle(e),
                onMoveShouldSetPanResponder: (e) => isWithinCircle(e),
                onMoveShouldSetPanResponderCapture: (e) => isWithinCircle(e),
                onPanResponderGrant(e, state) {
                    panEventRef.current(e.nativeEvent);

                    onThumbPanStart?.(e, state);
                    onThumbMoved?.(e, state);
                },
                onPanResponderMove: (e, state) => {
                    e.preventDefault();
                    e.stopPropagation();

                    if (isWithinCircle(e)) {
                        panEventRef.current(e.nativeEvent);
                        onThumbMoved?.(e, state);
                    }
                },
                onPanResponderRelease: (e, state) => {
                    onThumbPanEnd?.(e, state, isWithinCircle(e));
                },
            }),
        [isWithinCircle, onThumbPanStart, onThumbPanEnd, onThumbMoved]
    );

    useEffect(() => {
        Animated.timing(opacityRef.current, {
            toValue: 1,
            duration: 300,
            useNativeDriver: true,
        }).start();
    }, []);

    useEffect(() => {
        // Move the pan varaibles to the thumb position
        panEventRef.current({
            locationX: thumbPosition.x,
            locationY: thumbPosition.y,
        });
    }, [thumbPosition]);

    function onRootLayout(e: LayoutChangeEvent) {
        const width = e.nativeEvent.layout.width;

        if (width > 0) {
            setPickerWidth(width);

            // Forward the layout event
            onLayout?.(e);
        }
    }

    return (
        <StackView spacing={20} onLayout={onRootLayout}>
            <Animated.View style={{ opacity: opacityRef.current }}>
                {circle({ size: pickerWidth })}
                {/* Thumb */}
                <Animated.View
                    style={{
                        position: "absolute",
                        left: panX,
                        top: panY,
                        transform: [
                            { translateX: -halfThumbSize },
                            { translateY: -halfThumbSize },
                        ],
                        width: thumbSize,
                        height: thumbSize,
                        borderRadius: thumbSize,
                        borderWidth: thumbBorderWidth,
                        borderColor: theme.color.white,
                        backgroundColor: color,
                        elevation: 3,
                        shadowColor: theme.color.black,
                        shadowOpacity: 0.25,
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                    }}
                />
                {/* Pan Responder View */}
                <View
                    {...panResponder.panHandlers}
                    style={{
                        position: "absolute",
                        left: 0,
                        right: 0,
                        top: 0,
                        bottom: 0,
                    }}
                />
            </Animated.View>

            {pickerWidth > 0 && presets && presets.length > 0 && (
                <StackView
                    spacing={10}
                    style={{
                        flexDirection: "row",
                        height: presetSectionHeight,
                        borderRadius: presetSectionBorderRadius,
                        padding: presetPadding,
                        backgroundColor: theme.color.background.elevation3,
                    }}>
                    {presets.map((preset) => (
                        <TouchableOpacity
                            key={preset.toString()}
                            activeOpacity={0.5}
                            onPress={() => {
                                onPresetSelected(preset);
                            }}
                            style={{
                                height: presetSize,
                                width: presetSize,
                                borderRadius: presetSize,
                                justifyContent: "center",
                                alignItems: "center",
                                backgroundColor:
                                    theme.color.background.elevation2,
                            }}>
                            <View
                                style={{
                                    height: innerPresetSize,
                                    width: innerPresetSize,
                                    borderRadius: innerPresetSize,
                                    backgroundColor: preset,
                                }}
                            />
                        </TouchableOpacity>
                    ))}
                </StackView>
            )}
        </StackView>
    );
};

export default ColorPicker;
