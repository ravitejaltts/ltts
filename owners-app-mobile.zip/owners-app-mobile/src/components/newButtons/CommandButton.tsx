import React, { useCallback, useRef, useState } from "react";
import { Animated, Pressable, StyleProp, ViewStyle } from "react-native";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";

export const CommandButton: React.FunctionComponent<{
    text: string;
    disabled?: boolean;
    sendCommand: () => Promise<void>;
    style?: StyleProp<ViewStyle>;
}> = ({ text, disabled = false, sendCommand, style }) => {
    const [theme] = useTheme();

    const [isSending, setIsSending] = useState(false);

    const animationRef = useRef<Animated.CompositeAnimation>();
    const colorValueRef = useRef(new Animated.Value(0));
    const opacityValueRef = useRef(new Animated.Value(1));

    const textStart = theme.color.text.main;
    const textEnd = theme.color.text.mainInverted;
    const backgroundStart = theme.color.background.elevation3;
    const backgroundEnd = theme.color.background.defaultInverted;

    const animateOut = useCallback(() => {
        if (animationRef.current) {
            animationRef.current.stop();
        }

        // Animations are delayed for the "sent" toast
        // 400ms to show toast
        // 2000ms duration
        const animation = Animated.parallel([
            Animated.timing(colorValueRef.current, {
                delay: 2400,
                toValue: 0,
                duration: 400,
                useNativeDriver: false,
            }),
            Animated.timing(opacityValueRef.current, {
                toValue: 1,
                duration: 100,
                useNativeDriver: false,
            }),
        ]);

        animationRef.current = animation;

        animation.start(({ finished }) => {
            if (finished) {
                animationRef.current = undefined;
            }
        });
    }, []);

    const animateIn = useCallback(() => {
        if (animationRef.current) {
            animationRef.current.stop();
        }

        // Opacity animation is delayed for "in progress" toast
        // 400ms to show toast
        // 1s total delay before toast is shown
        const animation = Animated.sequence([
            Animated.timing(colorValueRef.current, {
                toValue: 1,
                duration: 200,
                useNativeDriver: false,
            }),
            Animated.timing(opacityValueRef.current, {
                delay: 800, // Wait before decreasing opacity
                toValue: 0.6,
                duration: 400,
                useNativeDriver: false,
            }),
        ]);

        animationRef.current = animation;

        animation.start(({ finished }) => {
            if (finished) {
                animationRef.current = undefined;
            }
        });
    }, []);

    return (
        <Pressable
            style={style}
            disabled={disabled}
            onPress={() => {
                if (isSending) {
                    // Sending
                    return;
                }

                setIsSending(true);
                animateIn();

                sendCommand()
                    .catch(() => {
                        // Do nothing
                    })
                    .finally(() => {
                        animateOut();
                        setIsSending(false);
                    });
            }}>
            <Animated.View
                style={{
                    height: 44,
                    justifyContent: "center",
                    borderRadius: 22,
                    borderWidth: 1,
                    opacity: opacityValueRef.current,
                    backgroundColor: colorValueRef.current.interpolate({
                        inputRange: [0, 1],
                        outputRange: [
                            backgroundStart.toString(),
                            backgroundEnd.toString(),
                        ],
                    }),
                    borderColor: theme.color.dividers.gray1,
                }}>
                <Animated.Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            textAlign: "center",
                            color: colorValueRef.current.interpolate({
                                inputRange: [0, 1],
                                outputRange: [
                                    textStart.toString(),
                                    textEnd.toString(),
                                ],
                            }),
                        },
                    ]}>
                    {text}
                </Animated.Text>
            </Animated.View>
        </Pressable>
    );
};
