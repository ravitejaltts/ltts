import React from "react";
import {
    Text,
    TouchableHighlight,
    TouchableHighlightProps,
} from "react-native";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import { GradientLoadingView } from "../animated";

interface GradientLoadingButtonProps extends TouchableHighlightProps {
    icon: React.FunctionComponent<SvgProps>;
    text: string;
}

export const GradientLoadingButton: React.FunctionComponent<
    GradientLoadingButtonProps
> = ({ icon, text, ...touchableHighlightProps }) => {
    const [theme] = useTheme();

    return (
        <TouchableHighlight
            underlayColor={theme.color.blue.brand}
            {...touchableHighlightProps}
            style={[
                {
                    borderRadius: 8,
                    overflow: "hidden",
                },
                touchableHighlightProps.style,
            ]}>
            <GradientLoadingView
                animating={true}
                direction="horizontal"
                duration={2000}
                backgroundColor={theme.color.blue.brand12}
                highlightColor={theme.color.blue.brand25}
                style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                {icon({
                    width: 32,
                    height: 32,
                    fill: touchableHighlightProps.disabled
                        ? theme.color.text.disabled
                        : theme.color.blue.brand,
                })}
                <Text
                    style={[
                        TextStyles.calloutTitle,
                        {
                            color: touchableHighlightProps.disabled
                                ? theme.color.text.disabled
                                : theme.color.blue.brand,
                            textAlign: "center",
                        },
                    ]}>
                    {text}
                </Text>
            </GradientLoadingView>
        </TouchableHighlight>
    );
};
