import React, { useCallback, useEffect, useRef, useState } from "react";
import {
    Animated,
    ColorValue,
    Pressable,
    StyleProp,
    View,
    ViewStyle,
} from "react-native";
import { ClipPath, Defs, Rect, Svg } from "react-native-svg";
import { AnimatedSvgRect } from "../animated";

const PROGRESS_VALUE_MIN = 0;
const PROGRESS_VALUE_MAX = 100;

type ProgressButtonProps = {
    onPress?: () => void;
    onLongPressComplete: () => void;
    onLongPressCanceled?: () => void;
    backgroundColor: ColorValue;
    borderColor: ColorValue;
    disabled?: boolean;
    longPressDuration?: number;
    style?: StyleProp<ViewStyle>;
    children?: React.ReactNode;
};

export const ProgressButton: React.FunctionComponent<ProgressButtonProps> = ({
    onPress,
    onLongPressComplete,
    onLongPressCanceled,
    backgroundColor,
    borderColor,
    disabled,
    longPressDuration = 1000,
    style,
    children,
}) => {
    const progressValueRef = useRef(new Animated.Value(PROGRESS_VALUE_MIN));
    const animationRef = useRef<Animated.CompositeAnimation>();
    const isLongPress = useRef(false);

    const [svgWidth, setSvgWidth] = useState(0);
    const [svgHeight, setSvgHeight] = useState(0);

    const dashLength = 2 * svgWidth + 2 * svgHeight;

    const resetAnimation = useCallback(() => {
        animationRef.current?.stop();
        progressValueRef.current.setValue(0);
    }, []);

    useEffect(() => {
        if (disabled) {
            resetAnimation();
        }
    }, [disabled, resetAnimation]);

    return (
        <Pressable
            disabled={disabled}
            onPress={onPress}
            delayLongPress={200}
            style={style}
            onLayout={(e) => {
                const { width, height } = e.nativeEvent.layout;
                setSvgWidth(width);
                setSvgHeight(height);
            }}
            onLongPress={() => {
                isLongPress.current = true;

                // Start animating from 0-100 over the press duration
                const animation = Animated.timing(progressValueRef.current, {
                    toValue: PROGRESS_VALUE_MAX,
                    duration: longPressDuration,
                    useNativeDriver: true,
                });

                animationRef.current = animation;
                animation.start(({ finished }) => {
                    if (finished && isLongPress.current) {
                        // When the animation finishes, press completes
                        onLongPressComplete?.();
                    }
                });
            }}
            onPressOut={() => {
                const wasLongPress = isLongPress.current;

                // Cancel any long press immediately
                isLongPress.current = false;

                if (wasLongPress) {
                    // Long press was cancelled, send event
                    resetAnimation();
                    onLongPressCanceled?.();
                }
            }}>
            {/* SVG Background */}
            <Svg
                width={svgWidth}
                height={svgHeight}
                viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                fill="none"
                style={{
                    position: "absolute",
                }}>
                <Defs>
                    <ClipPath id="clip">
                        <Rect width={svgWidth} height={svgHeight} rx={8} />
                    </ClipPath>
                </Defs>
                <AnimatedSvgRect
                    width={svgWidth}
                    height={svgHeight}
                    rx={8}
                    fill={backgroundColor}
                    stroke={borderColor.toString()}
                    strokeWidth={5}
                    strokeDasharray={[dashLength, dashLength]}
                    strokeDashoffset={progressValueRef.current.interpolate({
                        inputRange: [PROGRESS_VALUE_MIN, PROGRESS_VALUE_MAX],
                        outputRange: [dashLength, 0],
                    })}
                    clipPath="url(#clip)"
                />
            </Svg>
            {/* Children Container */}
            <View
                style={{
                    flex: 1,
                }}>
                {children}
            </View>
        </Pressable>
    );
};
