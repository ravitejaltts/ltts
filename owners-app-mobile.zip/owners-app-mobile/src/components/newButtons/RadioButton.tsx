import React from "react";
import { Pressable } from "react-native";
import { Circle, Svg } from "react-native-svg";
import { useTheme } from "../../context";

const STROKE_WIDTH = 2;

export const RadioButton: React.FunctionComponent<{
    size: number;
    isSelected: boolean;
    onPress?: () => void;
    disabled?: boolean;
}> = ({ size, isSelected, onPress, disabled = false }) => {
    const [theme] = useTheme();

    const halfSize = size * 0.5;
    const quarterSize = size * 0.25;

    return (
        <Pressable disabled={disabled} onPress={onPress}>
            <Svg
                width={size}
                height={size}
                viewBox={`0 0 ${size} ${size}`}
                fill={"transparent"}>
                <Circle
                    x={halfSize}
                    y={halfSize}
                    r={halfSize - STROKE_WIDTH}
                    strokeWidth={STROKE_WIDTH}
                    stroke={
                        disabled
                            ? theme.color.text.deemphasized
                            : theme.color.text.main
                    }
                />
                {isSelected && (
                    <Circle
                        x={halfSize}
                        y={halfSize}
                        r={quarterSize}
                        fill={
                            disabled
                                ? theme.color.text.deemphasized
                                : theme.color.text.main
                        }
                    />
                )}
            </Svg>
        </Pressable>
    );
};
