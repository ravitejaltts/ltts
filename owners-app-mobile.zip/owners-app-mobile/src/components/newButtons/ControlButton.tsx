import React, { useState } from "react";
import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";
import { Pressable, PressableProps, StyleProp, ViewStyle } from "react-native";

interface ControlButtonProps extends PressableProps {
    icon: React.FunctionComponent<SvgProps>;
    onLongPress: () => void;
    onPressOut: () => void;
    style: StyleProp<ViewStyle>;
}

export const ControlButton: React.FunctionComponent<ControlButtonProps> = ({
    icon,
    onLongPress,
    onPressOut,
    ...pressableProps
}) => {
    const [theme] = useTheme();
    const [activeBorder, setActiveBorder] = useState(false);

    return (
        <Pressable
            onLongPress={() => {
                setActiveBorder(true);
                onLongPress();
            }}
            onPressOut={() => {
                setActiveBorder(false);
                onPressOut();
            }}
            delayLongPress={200}
            {...pressableProps}
            style={[
                {
                    justifyContent: "center",
                    alignItems: "center",
                    height: 80,
                    backgroundColor: theme.color.background.elevation3,
                    borderRadius: 8,
                },
                activeBorder
                    ? { borderColor: theme.color.blue.brand, borderWidth: 2 }
                    : { borderColor: theme.color.transparent, borderWidth: 2 },
                pressableProps.style,
            ]}>
            {icon({
                width: 28,
                height: 28,
                fill: pressableProps.disabled
                    ? theme.color.text.disabled
                    : theme.color.blue.brand,
            })}
        </Pressable>
    );
};
