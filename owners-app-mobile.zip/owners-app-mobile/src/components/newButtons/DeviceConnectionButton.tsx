import { observer } from "mobx-react-lite";
import React from "react";
import { TouchableOpacity } from "react-native";
import { SvgProps } from "react-native-svg";
import { CloudOffIcon, CloudOnIcon } from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { VehicleConnectionType } from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { IconToastProps } from "../toast";
import { WgoToastType } from "../../models/ui";
import { ToastIdentifier } from "../../stores";

export const DeviceConnectionButton: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
}> = observer(({ smartVehicle: smartVehicle }) => {
    const [theme] = useTheme();
    const container = useRootContainer();
    const toastStore = container.stores.toast;

    switch (smartVehicle.connectionType) {
        case VehicleConnectionType.Cloud:
            let text: string;
            let icon: React.FunctionComponent<SvgProps>;

            if (smartVehicle.isCloudDeviceDisconnected) {
                text = "RV disconnected from internet";
                icon = CloudOffIcon;
            } else {
                text = "RV connected to internet";
                icon = CloudOnIcon;
            }

            return (
                <TouchableOpacity
                    activeOpacity={0.5}
                    onPress={() => {
                        toastStore.show<IconToastProps>({
                            id: ToastIdentifier.DeviceConnectionType,
                            type: WgoToastType.Icon,
                            props: {
                                text: text,
                                icon: icon,
                            },
                        });
                    }}>
                    {icon({
                        width: 24,
                        height: 24,
                        fill: theme.color.text.deemphasized,
                    })}
                </TouchableOpacity>
            );
        default:
            return null;
    }
});
