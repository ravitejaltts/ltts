import React, { useEffect, useRef } from "react";
import { Animated } from "react-native";
import { useTheme } from "../../context";

export const ButtonOverlay: React.FunctionComponent<{
    visible: boolean;
    children: React.ReactNode;
    onAnimationFinish?: () => void;
}> = ({ visible, children, onAnimationFinish }) => {
    const [theme] = useTheme();
    const animationRef = useRef<Animated.CompositeAnimation>();
    const animationValueRef = useRef(new Animated.Value(0));

    useEffect(() => {
        animationRef.current?.stop();
        animationValueRef.current.setValue(0);

        if (visible) {
            const animation = Animated.sequence([
                Animated.timing(animationValueRef.current, {
                    toValue: 1,
                    duration: 200,
                    useNativeDriver: true,
                }),
                Animated.timing(animationValueRef.current, {
                    toValue: 0,
                    delay: 1000,
                    duration: 100,
                    useNativeDriver: true,
                }),
            ]);

            animationRef.current = animation;

            animation.start(() => {
                onAnimationFinish?.(); // call on end of animation
            });
        }
    }, [visible, onAnimationFinish]);

    return (
        <Animated.View
            style={{
                position: "absolute",
                left: 0,
                top: 0,
                width: "100%",
                height: "100%",
                backgroundColor: theme.color.black,
                opacity: animationValueRef.current.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, 0.8],
                }),
                justifyContent: "center",
                alignItems: "center",
                borderRadius: 8,
            }}>
            {children}
        </Animated.View>
    );
};
