import React, { useState } from "react";
import { useTheme } from "../../context";
import { SvgProps } from "react-native-svg";
import { View, Text, ViewStyle, StyleProp } from "react-native";
import { TextStyles } from "../../styles";
import { ProgressButton } from "./ProgressButton";
import { ButtonOverlay } from "./ButtonOverlay";

type ControlProgressButtonProps = {
    text: string;
    icon: React.FunctionComponent<SvgProps>;
    disabled: boolean;
    onLongPressComplete: () => void;
    onLongPressCancelled?: () => void;
    style?: StyleProp<ViewStyle>;
};

export const ControlProgressButton: React.FunctionComponent<
    ControlProgressButtonProps
> = ({
    text,
    icon,
    disabled,
    onLongPressComplete,
    onLongPressCancelled,
    style,
}) => {
    const [theme] = useTheme();

    const [overlay, setOverlay] = useState(false);

    const textColor = disabled
        ? theme.color.text.disabled
        : theme.color.blue.brand;

    return (
        <ProgressButton
            style={style}
            backgroundColor={
                disabled
                    ? theme.color.background.elevation2
                    : theme.color.blue.brand12
            }
            borderColor={textColor}
            disabled={disabled}
            onPress={() => setOverlay(true)}
            onLongPressComplete={onLongPressComplete}
            onLongPressCanceled={onLongPressCancelled}>
            <View
                style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                }}>
                {icon({
                    width: 32,
                    height: 32,
                    fill: textColor,
                })}
                <Text
                    style={[
                        TextStyles.sectionBreak,
                        {
                            color: textColor,
                            textAlign: "center",
                        },
                    ]}>
                    {text}
                </Text>
            </View>
            <ButtonOverlay
                visible={overlay}
                onAnimationFinish={() => setOverlay(false)}>
                <Text
                    style={[
                        TextStyles.listItemSmall,
                        {
                            textAlign: "center",
                            color: theme.color.white,
                        },
                    ]}>
                    Press and Hold
                </Text>
            </ButtonOverlay>
        </ProgressButton>
    );
};
