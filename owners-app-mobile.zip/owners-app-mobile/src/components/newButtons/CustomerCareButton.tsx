import React, { useState } from "react";
import { HeadsetIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import { useCallCustomerCare } from "../../hooks";
import { SecondaryButton } from "../Buttons";

export const CustomerCareButton: React.FunctionComponent<{
    type: "customer_care" | "winnebago_connect";
}> = ({ type = "customer_care" }) => {
    const [theme] = useTheme();

    const [height, setHeight] = useState(48);

    const { call } = useCallCustomerCare();

    let text: string;

    switch (type) {
        case "winnebago_connect":
            text = "Talk with a Winnebago Connect Specialist";
            break;
        case "customer_care":
        default:
            text = "Talk with Customer Care";
            break;
    }

    return (
        <SecondaryButton
            onLayout={(e) => {
                setHeight(e.nativeEvent.layout.height);
            }}
            style={{
                height: -1,
                borderRadius: height / 2,
                paddingVertical: 12,
                paddingHorizontal: 24,
                backgroundColor: theme.color.background.elevation3,
            }}
            textStyle={{
                color: theme.color.text.main,
            }}
            text={text}
            onPress={() => {
                call(type);
            }}
            leftView={
                <HeadsetIcon
                    width={24}
                    height={24}
                    fill={theme.color.background.defaultInverted}
                />
            }
        />
    );
};
