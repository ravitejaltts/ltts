import { NetInfoStateType, useNetInfo } from "@react-native-community/netinfo";
import { observer } from "mobx-react-lite";
import React from "react";
import { TouchableOpacity } from "react-native";
import { SvgProps } from "react-native-svg";
import {
    AirplaneModeIcon,
    BluetoothOffIcon,
    BluetoothOnIcon,
    CellularOffIcon,
    CellularOnIcon,
    SmartPhoneIcon,
    WifiOffIcon,
    WifiOnIcon,
} from "../../assets/icons";
import { useRootContainer, useTheme } from "../../context";
import { BleManagerState } from "../../models/domain/bluetooth";
import {
    VehicleConnectionState,
    VehicleConnectionType,
} from "../../models/domain/connection";
import { SmartVehicle } from "../../models/domain/vehicle";
import { WgoToastType } from "../../models/ui";
import { ToastIdentifier } from "../../stores";
import { IconToastProps } from "../toast";

export const MobileConnectionButton: React.FunctionComponent<{
    smartVehicle: SmartVehicle;
}> = observer(({ smartVehicle }) => {
    const [theme] = useTheme();

    const container = useRootContainer();
    const toastStore = container.stores.toast;
    const bluetoothStore = container.stores.bluetooth;

    const connectionType = smartVehicle.storedConnectionType;
    const connectionState = smartVehicle.connectionState;

    const netInfo = useNetInfo();

    let icon: React.FunctionComponent<SvgProps>;
    let toastText: string | undefined;
    let toastAction: (() => void) | undefined;

    switch (connectionType) {
        case VehicleConnectionType.Bluetooth:
            switch (connectionState) {
                case VehicleConnectionState.Connected:
                    toastText = "Connected via bluetooth";
                    icon = BluetoothOnIcon;
                    break;
                case VehicleConnectionState.Connecting:
                    // Connecting toast should already be shown
                    icon = BluetoothOnIcon;
                    break;
                case VehicleConnectionState.Disconnected:
                    icon = BluetoothOffIcon;

                    switch (bluetoothStore.state) {
                        case BleManagerState.PoweredOff:
                            toastText = "Bluetooth is powered off";
                            break;
                        case BleManagerState.PoweredOn:
                            toastText = "Disconnected via bluetooth";
                            break;
                        case BleManagerState.Resetting:
                            toastText = "Bluetooth is resetting";
                            icon = BluetoothOffIcon;
                            break;
                        case BleManagerState.Unauthorized:
                            toastText = "Bluetooth is unauthorized";
                            icon = BluetoothOffIcon;
                            break;
                        case BleManagerState.Unknown:
                            toastText = "Unknown bluetooth state";
                            icon = BluetoothOffIcon;
                            break;
                        case BleManagerState.Unsupported:
                            toastText = "Bluetooth is unsupported";
                            icon = BluetoothOffIcon;
                            break;
                    }
                    break;
                case VehicleConnectionState.Uninitialized:
                    // Display nothing until the connection state has been determined
                    return null;
                case VehicleConnectionState.Unpaired:
                    // Display nothing until pairing occurs
                    return null;
            }
            break;
        case VehicleConnectionType.Cloud:
        case VehicleConnectionType.Local:
            const networkType = netInfo.type;
            const isInternetReachable = netInfo.isInternetReachable;

            switch (networkType) {
                case NetInfoStateType.none:
                    toastText = "No network connection";
                    icon = AirplaneModeIcon;
                    break;
                case NetInfoStateType.unknown:
                    // Display nothing until the network type is determined
                    return null;
                case NetInfoStateType.cellular:
                    switch (connectionState) {
                        case VehicleConnectionState.Connected:
                            if (isInternetReachable) {
                                toastText = "Connected via cellular network";
                                icon = CellularOnIcon;
                            } else {
                                toastText = "Disconnected via cellular network";
                                icon = CellularOffIcon;
                            }
                            break;
                        case VehicleConnectionState.Connecting:
                            icon = CellularOnIcon;
                            break;
                        case VehicleConnectionState.Disconnected:
                            toastText = "Disconnected via cellular network";
                            icon = CellularOffIcon;
                            break;
                        case VehicleConnectionState.Uninitialized:
                            // Display nothing until the connection state has been determined
                            return null;
                        case VehicleConnectionState.Unpaired:
                            // Display nothing until pairing occurs
                            return null;
                    }
                    break;
                default:
                    switch (connectionState) {
                        case VehicleConnectionState.Connected:
                            if (isInternetReachable) {
                                toastText = `Connected via ${networkType} network`;
                                icon = WifiOnIcon;
                            } else {
                                toastText = `Disconnected via ${networkType} network`;
                                icon = WifiOffIcon;
                            }
                            break;
                        case VehicleConnectionState.Connecting:
                            icon = WifiOnIcon;
                            break;
                        case VehicleConnectionState.Disconnected:
                            toastText = `Disconnected via ${networkType} network`;
                            icon = WifiOffIcon;
                            break;
                        case VehicleConnectionState.Uninitialized:
                            // Display nothing until the connection state has been determined
                            return null;
                        case VehicleConnectionState.Unpaired:
                            // Display nothing until pairing occurs
                            return null;
                    }
                    break;
            }
            break;
        case VehicleConnectionType.Mock:
            icon = SmartPhoneIcon;
            toastText = "Connected via Mock";
            break;
        default:
            // Display nothing until a connection type is determined
            return null;
    }

    let onPress: (() => void) | undefined;

    if (toastText) {
        onPress = () => {
            if (!toastText) {
                return;
            }

            toastStore.show<IconToastProps>({
                id: ToastIdentifier.MobileConnectionType,
                type: WgoToastType.Icon,
                props: {
                    text: toastText,
                    icon: icon,
                    onPress: toastAction,
                },
            });
        };
    }

    return (
        <TouchableOpacity activeOpacity={0.5} onPress={onPress}>
            {icon({
                width: 24,
                height: 24,
                fill: theme.color.white,
            })}
        </TouchableOpacity>
    );
});
