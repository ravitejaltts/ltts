import React from "react";
import {
    ActivityIndicator,
    GestureResponderEvent,
    Text,
    TouchableOpacity,
    View,
} from "react-native";
import StackView from "./StackView";
import { InfoOutlineIcon } from "../assets/icons";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { ImageButton } from "./Buttons";
import StackSection, { StackSectionProps } from "./StackSection";

export type SettingSectionProps = StackSectionProps & {
    title?: string;
    isLoading?: boolean;
    showInfo?: boolean;
    onInfoPress?: (event: GestureResponderEvent) => void;
    subtitle?: string;
    onSubtitlePress?: (event: GestureResponderEvent) => void;
    footerText?: string;
};

const SettingSection: React.FunctionComponent<SettingSectionProps> = (
    props
) => {
    const [theme] = useTheme();

    const {
        title,
        isLoading,
        showInfo,
        onInfoPress,
        subtitle,
        onSubtitlePress,
        footerText,
        ...stackSectionProps
    } = props;

    const headerVisible = Boolean(title) || Boolean(subtitle);

    return (
        <StackView spacing={8}>
            {/* Header */}
            {headerVisible && (
                <View
                    style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                    }}>
                    {Boolean(title) && (
                        <StackView
                            spacing={12}
                            style={{
                                flexDirection: "row",
                                justifyContent: "center",
                                alignItems: "center",
                            }}>
                            <Text
                                style={[
                                    TextStyles.contentEyebrow,
                                    {
                                        color: theme.color.text.deemphasized,
                                    },
                                ]}>
                                {title}
                            </Text>

                            {isLoading && (
                                <ActivityIndicator
                                    animating={true}
                                    color={theme.color.text.main}
                                />
                            )}

                            {showInfo && (
                                <ImageButton
                                    image={InfoOutlineIcon}
                                    imageProps={{
                                        width: 23,
                                        height: 23,
                                        fill: theme.color.blue.brand.toString(),
                                    }}
                                    onPress={onInfoPress}
                                />
                            )}
                        </StackView>
                    )}
                    {Boolean(subtitle) && (
                        <TouchableOpacity onPress={onSubtitlePress}>
                            <Text
                                style={[
                                    TextStyles.regular15,
                                    {
                                        color: theme.color.blue.brand.toString(),
                                    },
                                ]}>
                                {subtitle}
                            </Text>
                        </TouchableOpacity>
                    )}
                </View>
            )}

            {/* Content */}
            <StackSection {...stackSectionProps} />

            {Boolean(footerText) && (
                <Text
                    style={[
                        TextStyles.listEyebrow,
                        {
                            color: theme.color.text.deemphasized,
                        },
                    ]}>
                    {footerText}
                </Text>
            )}
        </StackView>
    );
};

export default SettingSection;
