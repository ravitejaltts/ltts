import React from "react";
import { useRootContainer, useTheme } from "../context";
import { Text, TouchableOpacity, View, Dimensions } from "react-native";
import { BarCodeScanningResult } from "expo-camera";
import { BarCodeScanner } from "expo-barcode-scanner";
import { useIsFocused, useNavigation } from "@react-navigation/native";
import { ChevronLeftIcon, RoundedCornerBracketIcon } from "../assets/icons";
import { TextStyles } from "../styles";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type WgoCameraProps = {
    onBarCodeScan: (scannedUrl: string) => void;
};

const WgoCamera: React.FunctionComponent<WgoCameraProps> = ({
    onBarCodeScan,
}) => {
    const navigation = useNavigation<any>();
    const safeAreaInsets = useSafeAreaInsets();
    const isFocused = useIsFocused();

    const [theme] = useTheme();

    const container = useRootContainer();
    const cameraStore = container.stores.camera;

    const { height, width } = Dimensions.get("window");
    const maskRowHeight = Math.round((height - 200) / 18);
    const maskColWidth = (width - 300) / 2;

    const onBarCodeScanned = (scanningResult: BarCodeScanningResult) => {
        cameraStore.setQRCode(scanningResult);
        onBarCodeScan(scanningResult.data);
    };

    return (
        <>
            {isFocused && (
                <>
                    {/* Back button */}
                    <TouchableOpacity
                        activeOpacity={0.5}
                        onPress={() => {
                            navigation.goBack();
                        }}
                        style={{
                            zIndex: 1,
                            width: 80,
                            height: 30,
                            marginLeft: 20,
                            marginTop: safeAreaInsets.top + 12,
                            flexDirection: "row",
                            alignSelf: "flex-start",
                            position: "absolute",
                        }}>
                        <ChevronLeftIcon fill={theme.color.white} />
                        <Text
                            style={[
                                TextStyles.listItemSmall,
                                { color: theme.color.white },
                            ]}>
                            Back
                        </Text>
                    </TouchableOpacity>
                    {/* Camera */}
                    <BarCodeScanner
                        onBarCodeScanned={onBarCodeScanned}
                        style={{
                            position: "absolute",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            alignItems: "center",
                            justifyContent: "space-around",
                            flexWrap: "wrap",
                        }}>
                        {/* top opacity bar */}
                        <View
                            style={{
                                flex: maskRowHeight - 10,
                                backgroundColor: theme.color.black,
                                opacity: 0.4,
                                width: "100%",
                            }}
                        />
                        {/* center row opacity bars with centered transparent square */}
                        <View
                            style={{
                                flex: 40,
                                flexDirection: "row",
                                zIndex: 1,
                            }}>
                            {/* center-left opacity bar */}
                            <View
                                style={{
                                    width: maskColWidth,
                                    backgroundColor: theme.color.black,
                                    opacity: 0.4,
                                }}
                            />
                            {/* centered transparent square */}
                            <View
                                style={{
                                    width: 300,
                                    backgroundColor: theme.color.transparent,
                                }}>
                                {/* corner bracket - top left */}
                                <RoundedCornerBracketIcon
                                    style={{
                                        position: "absolute",
                                        top: -9,
                                        left: -9,
                                    }}
                                />
                                {/* corner bracket - top right */}
                                <RoundedCornerBracketIcon
                                    style={{
                                        position: "absolute",
                                        transform: [{ rotateZ: "90deg" }],
                                        top: -9,
                                        right: -9,
                                    }}
                                />
                                {/* corner bracket - bottom left */}

                                <RoundedCornerBracketIcon
                                    style={{
                                        position: "absolute",
                                        transform: [{ rotateZ: "-90deg" }],
                                        left: -9,
                                        bottom: -9,
                                    }}
                                />
                                {/* corner bracket - bottom right */}
                                <RoundedCornerBracketIcon
                                    style={{
                                        position: "absolute",
                                        transform: [{ rotateZ: "180deg" }],
                                        right: -9,
                                        bottom: -9,
                                    }}
                                />
                            </View>
                            {/* center-right opacity bar */}
                            <View
                                style={{
                                    width: maskColWidth,
                                    backgroundColor: theme.color.black,
                                    opacity: 0.4,
                                    zIndex: -1,
                                }}
                            />
                        </View>
                        {/* bottom opacity bar */}
                        <View
                            style={{
                                flex: maskRowHeight,
                                width: "100%",
                                opacity: 0.4,
                                backgroundColor: theme.color.black,
                            }}
                        />
                    </BarCodeScanner>
                </>
            )}
        </>
    );
};

export default WgoCamera;
