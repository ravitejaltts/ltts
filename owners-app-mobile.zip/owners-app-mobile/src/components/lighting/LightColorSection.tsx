import React, { useCallback, useState } from "react";
import { ColorValue, StyleProp, Text, ViewStyle } from "react-native";
import { PillSelectSectionProps } from "..";
import { useTheme } from "../../context";
import { RgbwLightingZone } from "../../models/domain/lighting";
import { TextStyles } from "../../styles";
import { ColorUtils } from "../../utils";
import PillSelect from "../PillSelect";
import StackView from "../StackView";
import LightColorPicker from "./LightColorPicker";
import LightTemperaturePicker from "./LightTemperaturePicker";

type ColorSectionValue = "white" | "color";

const SECTIONS: PillSelectSectionProps<ColorSectionValue>[] = [
    {
        label: "White",
        value: "white",
    },
    {
        label: "Color",
        value: "color",
    },
];

type Props = {
    zone: RgbwLightingZone;
    onChangeStarted: () => void;
    onColorChanged: (newColor: ColorValue) => void;
    onTemperatureChanged: (temp: number) => void;
    onChangeEnded: () => void;
    style?: StyleProp<ViewStyle>;
};

const LightColorSection: React.FunctionComponent<Props> = ({
    zone,
    onChangeStarted,
    onColorChanged,
    onTemperatureChanged,
    onChangeEnded,
    style,
}) => {
    const [theme] = useTheme();

    const color = zone.rgb ?? theme.color.white;
    const temperature = zone.colorTemp ?? 4100;

    const [selectedSection, setSelectedSection] = useState<ColorSectionValue>(
        ColorUtils.isEqual(color, theme.color.white) ? "white" : "color"
    );

    const onColorChangeEnd = useCallback(
        (newColor: ColorValue) => {
            onChangeEnded();

            zone.updateColor(newColor);
        },
        [zone, onChangeEnded]
    );

    const onTemperatureChangeEnd = useCallback(
        (newTemp: number) => {
            onChangeEnded();

            zone.updateTemperature(newTemp);
        },
        [zone, onChangeEnded]
    );

    return (
        <StackView spacing={12} style={style}>
            <Text
                style={[
                    TextStyles.listItemSmall,
                    {
                        color: theme.color.text.main,
                    },
                ]}>
                Color
            </Text>

            <StackView
                spacing={20}
                style={{
                    paddingTop: 24,
                    paddingHorizontal: 20,
                    paddingBottom: 20,
                    backgroundColor: theme.color.background.elevation3,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                }}>
                <PillSelect
                    sections={SECTIONS}
                    value={selectedSection}
                    onValueChanged={setSelectedSection}
                />

                {selectedSection === "color" && (
                    <LightColorPicker
                        color={color}
                        onColorChangeStart={onChangeStarted}
                        onColorChanged={onColorChanged}
                        onColorChangeEnd={onColorChangeEnd}
                    />
                )}

                {selectedSection === "white" && (
                    <LightTemperaturePicker
                        temperature={temperature}
                        onTemperatureChangeStart={onChangeStarted}
                        onTemperatureChanged={onTemperatureChanged}
                        onTemperatureChangeEnd={onTemperatureChangeEnd}
                    />
                )}
            </StackView>
        </StackView>
    );
};

export default LightColorSection;
