import { useNavigation } from "@react-navigation/native";
import { observer } from "mobx-react-lite";
import React from "react";
import { ColorValue, Text, View } from "react-native";
import { StackView, SwitchCard } from "..";
import { useTheme } from "../../context";
import {
    DimmableLightingZone,
    LightingZone,
    RgbwLightingZone,
} from "../../models/domain/lighting";
import { LightingScreenNavigationProp } from "../../screens/lighting";
import { TextStyles } from "../../styles";
import { ColorUtils, MathUtils, StringUtils } from "../../utils";

export const LightSwitchCard: React.FunctionComponent<{
    zone: LightingZone;
}> = observer(({ zone }) => {
    const navigation = useNavigation<LightingScreenNavigationProp>();
    const [theme] = useTheme();

    const error = false;

    const isOn = zone.isOn;
    let brightness: number | undefined;
    let maxBrightness: number | undefined;
    let lightColor: ColorValue | undefined;

    if (zone instanceof DimmableLightingZone) {
        brightness = zone.brightness;
        maxBrightness = zone.maxBrightness;
    }

    if (zone instanceof RgbwLightingZone) {
        lightColor = zone.rgb;

        if (lightColor?.toString() === theme.color.white.toString()) {
            // Use color temperature
            const temp = zone.colorTemp;

            if (temp) {
                lightColor = ColorUtils.temperatureToHex(temp);
            }
        }
    }

    const onCardPress = () => {
        if (
            zone instanceof DimmableLightingZone ||
            zone instanceof RgbwLightingZone
        ) {
            navigation.navigate("lightingDetail", {
                zoneId: zone.instance,
            });
        } else {
            zone.toggle(!isOn);
        }
    };

    return (
        <SwitchCard
            isOn={isOn}
            onSwitchValueChanged={(value) => {
                zone.toggle(value);
            }}
            onCardPress={onCardPress}
            error={error}
            disabled={brightness === undefined || error}
            style={{
                flex: 1,
                marginHorizontal: 20,
            }}>
            <View>
                {/* Zone Name */}
                <Text
                    style={[
                        TextStyles.listItemLarge,
                        {
                            color: isOn
                                ? theme.color.text.main
                                : theme.color.text.deemphasized,
                        },
                    ]}>
                    {zone.name ?? ""}
                </Text>

                {/* Color and Brightness */}
                <StackView
                    spacing={4}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    {lightColor && (
                        <View
                            style={{
                                height: 10,
                                width: 10,
                                borderRadius: 10,
                                marginRight: 4,
                                backgroundColor: lightColor,
                                borderWidth: 1,
                                borderColor: theme.color.dividers.gray1,
                            }}
                        />
                    )}
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.deemphasized,
                            },
                        ]}>
                        {isOn
                            ? MathUtils.isNumber(brightness) &&
                              MathUtils.isNumber(maxBrightness) &&
                              maxBrightness !== 0
                                ? StringUtils.toPercentageString(
                                      brightness / maxBrightness
                                  )
                                : "On"
                            : "Off"}
                    </Text>
                </StackView>
            </View>
        </SwitchCard>
    );
});
