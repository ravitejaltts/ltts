import React, { useCallback, useRef, useState } from "react";
import {
    ColorValue,
    GestureResponderEvent,
    LayoutChangeEvent,
    PanResponderGestureState,
} from "react-native";
import { ColorUtils, MathUtils } from "../../utils";
import { SAT_VAL_MAX } from "../../utils/ColorUtils";
import ColorPicker from "../ColorPicker";
import FastImage from "react-native-fast-image";

const PRESET_COLORS = ["#0ca9da", "#0bbfbf", "#ffc20f", "#f15f31", "#e06bc6"];

type Props = {
    color: ColorValue;
    onColorChangeStart: () => void;
    onColorChanged: (newColor: ColorValue) => void;
    onColorChangeEnd: (color: ColorValue) => void;
};

const LightColorPicker: React.FunctionComponent<Props> = ({
    color,
    onColorChangeStart,
    onColorChanged,
    onColorChangeEnd,
}) => {
    const circleSize = useRef(0);

    const [currentColor, setCurrentColor] = useState<ColorValue>(color);
    const currentColorRef = useRef(color);
    const [thumbPosition, setThumbPosition] = useState({
        x: 0,
        y: 0,
    });

    const normalizeDegrees = useCallback((degrees: number) => {
        return ((-degrees % 360) + 360) % 360;
    }, []);

    // Based on the color, update the thumb position
    const updateThumbPosition = useCallback(
        (newColor: ColorValue) => {
            const circleRadius = circleSize.current / 2;

            const { h, s } = ColorUtils.HexToHsv(newColor.toString());

            const angle = normalizeDegrees(h);

            const radiusPercentage = s / SAT_VAL_MAX;
            const panRadius = radiusPercentage * circleRadius;

            const { x, y } = MathUtils.polarToCartesian(
                circleRadius,
                circleRadius,
                panRadius,
                angle
            );

            setThumbPosition({ x, y });
        },
        [normalizeDegrees]
    );

    // Based on the thumb position, update the color
    const updateCurrentColor = useCallback(
        (e: GestureResponderEvent) => {
            const circleRadius = circleSize.current / 2;
            const { locationX, locationY } = e.nativeEvent;
            const x = locationX - circleRadius;
            const y = locationY - circleRadius;

            const { radius, angle } = MathUtils.cartesianToPolar(x, y);

            const h = normalizeDegrees(angle);
            const s = (radius / circleRadius) * SAT_VAL_MAX; // Percentage of circle radius 0-100

            const newColor = ColorUtils.HsvToHex({
                h: h,
                s: s,
                v: SAT_VAL_MAX,
            });

            setCurrentColor(newColor);
            onColorChanged(newColor);
            currentColorRef.current = newColor;

            return newColor;
        },
        [normalizeDegrees, onColorChanged]
    );

    const onLayout = useCallback(
        (e: LayoutChangeEvent) => {
            circleSize.current = e.nativeEvent.layout.width;

            // Update thumb position
            updateThumbPosition(currentColor);
        },
        [currentColor, updateThumbPosition]
    );

    const onPresetSelected = useCallback(
        (presetColor: ColorValue) => {
            setCurrentColor(presetColor);
            currentColorRef.current = presetColor;
            updateThumbPosition(presetColor);
            onColorChangeEnd(presetColor);
        },
        [updateThumbPosition, onColorChangeEnd]
    );

    const onThumbPanStart = useCallback(
        (e: GestureResponderEvent) => {
            onColorChangeStart();
            updateCurrentColor(e);
        },
        [onColorChangeStart, updateCurrentColor]
    );

    const onThumbPanEnd = useCallback(
        (
            e: GestureResponderEvent,
            _: PanResponderGestureState,
            isWithinCircle: boolean
        ) => {
            if (isWithinCircle) {
                const newColor = updateCurrentColor(e);
                onColorChangeEnd(newColor);
            } else {
                // Outside circle.
                // Change color to last color before thumb was dragged outside circle.
                onColorChangeEnd(currentColorRef.current);
            }
        },
        [updateCurrentColor, onColorChangeEnd]
    );

    return (
        <ColorPicker
            onLayout={onLayout}
            circle={({ size }) => (
                <FastImage
                    source={require("../../assets/images/lighting/lightColor/LightColor.png")}
                    style={{
                        width: size,
                        height: size,
                    }}
                />
            )}
            color={currentColor}
            presets={PRESET_COLORS}
            onPresetSelected={onPresetSelected}
            thumbPosition={thumbPosition}
            onThumbPanStart={onThumbPanStart}
            onThumbPanEnd={onThumbPanEnd}
            onThumbMoved={updateCurrentColor}
        />
    );
};

export default LightColorPicker;
