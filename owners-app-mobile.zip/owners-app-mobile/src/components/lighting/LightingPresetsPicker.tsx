import React, { useState } from "react";
import {
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { TextStyles } from "../../styles";
import StackView from "../StackView";
import { useTheme } from "../../context";
import { observer } from "mobx-react-lite";
import { PresetLightingGroup } from "../../models/domain/lighting";

export const LightingPresetsPicker: React.FunctionComponent<{
    presetGroups: PresetLightingGroup[];
    style?: StyleProp<ViewStyle>;
}> = observer(({ presetGroups, style }) => {
    const [theme] = useTheme();

    const [isSendingCommand, setIsSendingCommand] = useState(false);

    return (
        <StackView
            spacing={1}
            spacerColor={theme.color.dividers.gray1}
            style={[
                {
                    borderWidth: 1,
                    borderColor: theme.color.dividers.gray1,
                    flexDirection: "row",
                    minHeight: 121,
                    borderRadius: 8,
                    backgroundColor: theme.color.background.elevation3,
                },
                style,
            ]}>
            {presetGroups.map((group, index) => {
                const borderLeftRadius = index === 0 ? 8 : 0;
                const borderRightRadius =
                    index === presetGroups.length - 1 ? 8 : 0;

                const color = group.isActive
                    ? theme.color.blue.brand
                    : theme.color.components.gray1;

                return (
                    <TouchableHighlight
                        key={group.instance}
                        underlayColor={theme.color.background.elevation1}
                        disabled={isSendingCommand}
                        style={{
                            flex: 1,
                            borderTopLeftRadius: borderLeftRadius,
                            borderBottomLeftRadius: borderLeftRadius,
                            borderTopRightRadius: borderRightRadius,
                            borderBottomRightRadius: borderRightRadius,
                        }}
                        onPress={() => {
                            setIsSendingCommand(true);
                            group
                                .sendActivateCommand()
                                .catch(() => {
                                    // Do nothing
                                })
                                .finally(() => {
                                    setIsSendingCommand(false);
                                });
                        }}
                        onLongPress={() => {
                            setIsSendingCommand(true);
                            group
                                .sendSaveCommand()
                                .catch(() => {
                                    // Do nothing
                                })
                                .finally(() => {
                                    setIsSendingCommand(false);
                                });
                        }}>
                        <View
                            style={{
                                paddingVertical: 12,
                                minHeight: 121,
                                alignItems: "center",
                            }}>
                            <View
                                style={{
                                    width: 42,
                                    height: 4,
                                    borderRadius: 2,
                                    marginTop: 2,
                                    marginBottom: 10,
                                    backgroundColor: color,
                                }}
                            />
                            <Text
                                style={[
                                    TextStyles.bold34,
                                    {
                                        color: isSendingCommand
                                            ? theme.color.text.deemphasized
                                            : theme.color.text.main,
                                    },
                                ]}>
                                {group.instance}
                            </Text>
                            <Text
                                style={[
                                    TextStyles.regular15,
                                    {
                                        color: theme.color.text.deemphasized,
                                        textAlign: "center",
                                    },
                                ]}>
                                {`Light\nPreset`}
                            </Text>
                        </View>
                    </TouchableHighlight>
                );
            })}
        </StackView>
    );
});
