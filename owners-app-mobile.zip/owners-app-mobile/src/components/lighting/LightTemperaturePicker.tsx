import React, { useCallback, useRef, useState } from "react";
import {
    ColorValue,
    GestureResponderEvent,
    LayoutChangeEvent,
    PanResponderGestureState,
} from "react-native";
import Svg, { Circle, Defs, LinearGradient, Stop } from "react-native-svg";
import { useTheme } from "../../context";
import { ColorUtils } from "../../utils";
import ColorPicker from "../ColorPicker";

const MIN_TEMP = 2700;
const MAX_TEMP = 6500;

const PRESETS = new Map<string, number>([
    [ColorUtils.temperatureToHex(2700), 2700],
    [ColorUtils.temperatureToHex(3000), 3000],
    [ColorUtils.temperatureToHex(4100), 4100],
    [ColorUtils.temperatureToHex(5000), 5000],
    [ColorUtils.temperatureToHex(6500), 6500],
]);

type LightTemperaturePickerProps = {
    temperature: number;
    onTemperatureChangeStart: () => void;
    onTemperatureChanged: (newTemp: number) => void;
    onTemperatureChangeEnd: (newTemp: number) => void;
};

const LightTemperaturePicker: React.FunctionComponent<
    LightTemperaturePickerProps
> = ({
    temperature,
    onTemperatureChangeStart,
    onTemperatureChanged,
    onTemperatureChangeEnd,
}) => {
    const [theme] = useTheme();

    const currentTemperature = useRef(temperature);
    const circleSize = useRef(0);

    const [currentColor, setCurrentColor] = useState<ColorValue>(
        ColorUtils.temperatureToHex(temperature)
    );

    const [thumbPosition, setThumbPosition] = useState({
        x: 0,
        y: 0,
    });

    // Based on the temperature, update the thumb position
    const updateThumbPosition = useCallback((temp: number) => {
        const size = circleSize.current;

        const percentage = (temp - MIN_TEMP) / (MAX_TEMP - MIN_TEMP);

        const y = percentage * size;

        setThumbPosition({
            x: size / 2,
            y: y,
        });
    }, []);

    // Based on the thumb position, update the temperature
    const updateTemperature = useCallback(
        (e: GestureResponderEvent) => {
            const locationY = e.nativeEvent.locationY;
            const height = circleSize.current;

            if (height > 0) {
                const percentage = locationY / height;
                const newTemp = MIN_TEMP + percentage * (MAX_TEMP - MIN_TEMP);

                currentTemperature.current = newTemp;
                setCurrentColor(ColorUtils.temperatureToHex(newTemp));
                onTemperatureChanged(newTemp);
            }
        },
        [onTemperatureChanged]
    );

    const onLayout = useCallback(
        (e: LayoutChangeEvent) => {
            circleSize.current = e.nativeEvent.layout.width;

            // Update thumb position
            updateThumbPosition(currentTemperature.current);
        },
        [updateThumbPosition]
    );

    const onPresetSelected = useCallback(
        (presetColor: ColorValue) => {
            const colorString = presetColor.toString();
            const temp = PRESETS.get(colorString) ?? MIN_TEMP;

            // Update the temp and color
            currentTemperature.current = temp;
            setCurrentColor(presetColor);

            // Update the thumb position based on temp
            updateThumbPosition(currentTemperature.current);

            onTemperatureChangeEnd(temp);
        },
        [updateThumbPosition, onTemperatureChangeEnd]
    );

    const onThumbPanStart = useCallback(
        (e: GestureResponderEvent) => {
            onTemperatureChangeStart();
            updateTemperature(e);
        },
        [onTemperatureChangeStart, updateTemperature]
    );

    const onThumbPanEnd = useCallback(
        (
            e: GestureResponderEvent,
            _state: PanResponderGestureState,
            isWithinCircle: boolean
        ) => {
            if (isWithinCircle) {
                updateTemperature(e);
            }

            onTemperatureChangeEnd(currentTemperature.current);
        },
        [updateTemperature, onTemperatureChangeEnd]
    );

    const presets = useRef(Array.from(PRESETS.keys())).current;

    return (
        <ColorPicker
            onLayout={onLayout}
            circle={({ size }) => {
                const radius = size / 2;
                const startColor = ColorUtils.temperatureToHex(MIN_TEMP);
                const endColor = ColorUtils.temperatureToHex(MAX_TEMP);
                return (
                    <Svg width={size} height={size}>
                        <Defs>
                            <LinearGradient
                                id="gradient"
                                x1="0"
                                y1="0"
                                x2="0"
                                y2="1">
                                <Stop offset="0" stopColor={startColor} />
                                <Stop offset="1" stopColor={endColor} />
                            </LinearGradient>
                        </Defs>

                        <Circle
                            cx={radius}
                            cy={radius}
                            r={radius}
                            fill="url(#gradient)"
                            stroke={theme.color.dividers.gray1.toString()}
                        />
                    </Svg>
                );
            }}
            color={currentColor}
            presets={presets}
            onPresetSelected={onPresetSelected}
            thumbPosition={thumbPosition}
            onThumbPanStart={onThumbPanStart}
            onThumbPanEnd={onThumbPanEnd}
            onThumbMoved={updateTemperature}
        />
    );
};

export default LightTemperaturePicker;
