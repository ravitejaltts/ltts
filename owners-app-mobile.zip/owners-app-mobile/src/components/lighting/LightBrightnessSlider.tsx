import React, { useCallback, useEffect, useState } from "react";
import { ColorValue, StyleProp, Text, View, ViewStyle } from "react-native";
import { useTheme } from "../../context";
import { DimmableLightingZone } from "../../models/domain/lighting";
import { TextStyles } from "../../styles";
import { MathUtils, StringUtils } from "../../utils";
import { BarSlider } from "../BarSlider";
import StackView from "../StackView";
import ThemedSwitch from "../ThemedSwitch";
import { observer } from "mobx-react-lite";

export const LightBrightnessSlider: React.FunctionComponent<{
    lz: DimmableLightingZone;
    progressColor?: ColorValue;
    nameVisible?: boolean;
    toggleVisible?: boolean;
    onChangeStarted?: () => void;
    onChangeEnded?: (progress: number) => void;
    style?: StyleProp<ViewStyle>;
}> = observer(
    ({
        lz,
        progressColor,
        nameVisible = false,
        toggleVisible = false,
        onChangeStarted,
        onChangeEnded,
        style,
    }) => {
        const [theme] = useTheme();

        if (!progressColor) {
            progressColor = theme.color.yellow.progress;
        }

        const isOn = lz.isOn;
        const brightness = lz.brightness;
        const minBrightness = lz.minBrightness;
        const maxBrightness = lz.maxBrightness;
        const rangeMax = DimmableLightingZone.brightnessRangeMax;

        const getBrightnessProgress = useCallback(
            (value: number | null | undefined) => {
                if (MathUtils.isNumber(value)) {
                    // Round to the nearest integer
                    value = Math.round(value);

                    // Clamp within min/max
                    value = MathUtils.clamp(
                        value,
                        minBrightness,
                        maxBrightness
                    );

                    // Convert to progress value
                    // within the range
                    return value / rangeMax;
                } else {
                    // Default to min brightness progress
                    return minBrightness / rangeMax;
                }
            },
            [minBrightness, maxBrightness, rangeMax]
        );

        const getBrightnessValue = useCallback(
            (progress: number) => {
                try {
                    // Calculate value within range
                    let value = progress * rangeMax;

                    // Round to the nearest integer
                    value = Math.round(value);

                    // Clamp within min/max
                    return MathUtils.clamp(value, minBrightness, maxBrightness);
                } catch {
                    // Default to the min brightness
                    return minBrightness;
                }
            },
            [minBrightness, maxBrightness, rangeMax]
        );

        const [brightnessProgress, setBrightnessProgress] = useState(
            getBrightnessProgress(brightness)
        );

        // Listen for changes to the zone's brightness
        // and set the component's progress
        useEffect(() => {
            setBrightnessProgress(getBrightnessProgress(brightness));
        }, [brightness, getBrightnessProgress]);

        const _onBrightnessChangeEnded = useCallback(
            (progress: number) => {
                onChangeEnded?.(progress);

                // TODO: Update zone brightness
                lz.updateBrightness(getBrightnessValue(progress));
            },
            [lz, onChangeEnded, getBrightnessValue]
        );

        return (
            <StackView spacing={12} style={style}>
                <View
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                flex: 1,
                                color: theme.color.text.main,
                            },
                        ]}>
                        {nameVisible ? lz.name : "Brightness"}
                    </Text>

                    <StackView
                        spacing={16}
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                        }}>
                        <Text
                            style={[
                                TextStyles.body,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {isOn
                                ? StringUtils.toPercentageString(
                                      brightnessProgress
                                  )
                                : "Off"}
                        </Text>
                        {toggleVisible && (
                            <ThemedSwitch
                                value={isOn}
                                onValueChange={(value) => lz.toggle(value)}
                            />
                        )}
                    </StackView>
                </View>

                <BarSlider
                    disabled={!isOn}
                    progressColor={progressColor}
                    progress={brightnessProgress}
                    minProgress={minBrightness / rangeMax}
                    maxProgress={maxBrightness / rangeMax}
                    onProgressChange={setBrightnessProgress}
                    onChangeStarted={onChangeStarted}
                    onChangeEnded={_onBrightnessChangeEnded}
                />
            </StackView>
        );
    }
);
