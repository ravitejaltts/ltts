import { observer } from "mobx-react-lite";
import React, { useState } from "react";
import {
    ColorValue,
    StyleProp,
    Text,
    TextInput,
    View,
    ViewStyle,
} from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { PhoneInput, PhoneInputProps } from "./PhoneInput";

export interface PhoneMaskInputProps extends PhoneInputProps {
    name?: string;
    disabled?: boolean;
    nextRef?: React.RefObject<TextInput>;
    containerStyle?: StyleProp<ViewStyle>;
}

export const FormPhoneInput = observer(
    React.forwardRef<TextInput, PhoneMaskInputProps>((props, ref) => {
        const {
            name,
            disabled = false,
            nextRef,
            containerStyle,
            ...phoneInputProps
        } = props;

        const [theme] = useTheme();
        const [isFocused, setIsFocused] = useState(false);

        const field = phoneInputProps.field;
        const isValid = field.isValid;
        const validationText = field.validationText;

        let borderColor: ColorValue;
        if (isValid) {
            borderColor = isFocused
                ? theme.color.text.main
                : theme.color.dividers.gray1;
        } else {
            borderColor = theme.color.error;
        }

        return (
            <View>
                {/* Input Name */}
                {Boolean(name) && (
                    <Text
                        style={[
                            TextStyles.listEyebrow,
                            {
                                color: isValid
                                    ? theme.color.text.main
                                    : theme.color.error,
                            },
                        ]}>
                        {name}
                    </Text>
                )}
                {/* Container */}
                <View
                    style={[
                        {
                            flexDirection: "row",
                            backgroundColor: theme.color.background.default,
                            borderColor: borderColor,
                            borderWidth: 1,
                            borderRadius: 8,
                            marginTop: 4,
                            opacity: disabled ? 0.5 : 1,
                        },
                        containerStyle,
                    ]}>
                    <PhoneInput
                        ref={ref}
                        placeholderTextColor={theme.color.text.deemphasized}
                        {...phoneInputProps}
                        onFocus={(e) => {
                            phoneInputProps.onFocus?.(e);
                            setIsFocused(true);
                        }}
                        onBlur={(e) => {
                            phoneInputProps.onBlur?.(e);
                            setIsFocused(false);
                        }}
                        onSubmitEditing={(e) => {
                            phoneInputProps.onSubmitEditing?.(e);
                            nextRef?.current?.focus();
                        }}
                        style={[
                            {
                                flex: 1,
                                color: theme.color.text.main,
                                fontSize: 17,
                                paddingHorizontal: 20,
                                paddingVertical: 12,
                            },
                            phoneInputProps.style,
                        ]}
                    />
                </View>

                {
                    // Validation Text
                    !isValid && validationText ? (
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.error,
                                    marginTop: 8,
                                },
                            ]}>
                            {validationText}
                        </Text>
                    ) : null
                }
            </View>
        );
    })
);
