import React from "react";
import { StyleProp, Text, TextStyle } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import Picker, { PickerItem } from "./Picker";
import StackView from "./StackView";

interface LabeledRowSelectProps {
    label: string;
    labelTextStyle?: StyleProp<TextStyle>;
    valueTextStyle?: StyleProp<TextStyle>;
    usePlaceHolder?: boolean;
    placeholder?: string;
    disabled?: boolean;
    items: PickerItem[];
    value: string | number | boolean;
    chevronVisible?: boolean;
    onValueChanged: (selection: PickerItem) => void;
    onClose?: (selection: PickerItem) => void;
}

const LabeledRowSelect: React.FunctionComponent<LabeledRowSelectProps> = ({
    label,
    labelTextStyle,
    valueTextStyle = TextStyles.body,
    usePlaceHolder = true,
    placeholder,
    disabled = false,
    value,
    items,
    chevronVisible = true,
    onValueChanged,
    onClose,
}) => {
    const [theme] = useTheme();

    return (
        <StackView
            spacing={4}
            style={{
                flexDirection: "row",
                paddingLeft: 20,
                height: 56,
                backgroundColor: theme.color.background.elevation3,
            }}>
            <Text
                numberOfLines={1}
                style={[
                    TextStyles.body,
                    {
                        flex: 1,
                        alignSelf: "center",
                        color: theme.color.text.main,
                    },
                    labelTextStyle,
                ]}>
                {label}
            </Text>

            <Picker
                usePlaceHolder={usePlaceHolder}
                placeholder={placeholder}
                items={items}
                value={value}
                onValueChanged={onValueChanged}
                disabled={disabled}
                containerStyle={{
                    flex: 2,
                    paddingRight: 20,
                }}
                textStyle={valueTextStyle}
                chevronVisible={chevronVisible}
                onClose={onClose}
            />
        </StackView>
    );
};

export default LabeledRowSelect;
