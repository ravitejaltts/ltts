import React, { useRef } from "react";
import { useState } from "react";
import { ColorValue, ViewStyle } from "react-native";
import {
    Animated,
    Modal,
    NativeScrollEvent,
    NativeSyntheticEvent,
    Pressable,
    ScrollView,
    StyleProp,
    Text,
    TextStyle,
    View,
} from "react-native";
import { ChevronDownIcon } from "../assets/icons";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { HeaderSecondaryButton, HEADER_BUTTON_HEIGHT } from "./Buttons";
import StackView from "./StackView";

const PICKER_HEIGHT = 300;
const HEADER_PADDING_VERTICAL = 4;
const HEADER_SEPARATOR = 1;
const ITEM_HEIGHT = 48;

// To allow centering of the selected item in the ScrollView
// prettier-ignore
const SPACER_HEIGHT = (PICKER_HEIGHT - (HEADER_PADDING_VERTICAL * 2) - HEADER_BUTTON_HEIGHT - HEADER_SEPARATOR - ITEM_HEIGHT) / 2;

export type PickerItem = {
    label: string;
    value: any;
};

type Props = {
    items: PickerItem[];
    usePlaceHolder?: boolean;
    placeholder?: string;
    value: any;
    onValueChanged: (selection: PickerItem) => void;
    onOpen?: () => void;
    onClose?: (selection: PickerItem) => void;
    disabled?: boolean;
    containerStyle?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    chevronVisible?: boolean;
};

const Picker: React.FunctionComponent<Props> = ({
    items,
    usePlaceHolder = true,
    placeholder,
    value,
    onValueChanged,
    onOpen,
    onClose,
    disabled = false,
    containerStyle,
    textStyle,
    chevronVisible = false,
}) => {
    const placeholderItem = {
        label: placeholder ?? "Select",
        value: "",
    };

    const internalItems: PickerItem[] = usePlaceHolder
        ? [placeholderItem, ...items]
        : items;

    let pickedItemIndex = internalItems.findIndex((i) => i.value === value);
    const [scrolledIndex, setScrolledIndex] = useState<number>(pickedItemIndex);

    let pickedItem: PickerItem;

    if (pickedItemIndex > -1) {
        pickedItem = internalItems[pickedItemIndex];
    } else {
        pickedItemIndex = 0;
        pickedItem = placeholderItem;
    }

    const pickedLabel = pickedItem.label;

    const snapToOffsets: number[] = [];

    for (let i = 0; i < internalItems.length; i++) {
        snapToOffsets.push(i * ITEM_HEIGHT);
    }

    const [theme] = useTheme();

    const [isVisible, setIsVisible] = useState(false);

    const scrollView = useRef<ScrollView>(null);
    const bottomPosition = useRef(new Animated.Value(-PICKER_HEIGHT)).current;

    function open() {
        setIsVisible(true);
        onOpen?.();

        Animated.timing(bottomPosition, {
            toValue: 0,
            duration: 200,
            useNativeDriver: false,
        }).start(() => {
            // Scroll to the picked item
            const yPos = pickedItemIndex * ITEM_HEIGHT;

            scrollView.current?.scrollTo({
                y: yPos,
                animated: false,
            });
        });
    }

    function close() {
        onClose?.(pickedItem);

        Animated.timing(bottomPosition, {
            toValue: -PICKER_HEIGHT,
            duration: 200,
            useNativeDriver: false,
        }).start(() => {
            setIsVisible(false);
        });
    }

    function onScroll(e: NativeSyntheticEvent<NativeScrollEvent>) {
        const yPos = e.nativeEvent.contentOffset.y;
        const index = Math.round(yPos / ITEM_HEIGHT);

        if (index > -1 && index < internalItems.length) {
            setScrolledIndex(index);
            if (index != pickedItemIndex) {
                onValueChanged(internalItems[index]);
            }
        }
    }

    return (
        <Pressable
            disabled={disabled}
            onPress={open}
            style={[
                {
                    justifyContent: "center",
                },
                containerStyle,
            ]}>
            <StackView
                spacing={4}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                <Text
                    style={[
                        {
                            color: disabled
                                ? theme.color.text.disabled
                                : theme.color.text.main,
                            flex: 1,
                        },
                        textStyle,
                    ]}>
                    {pickedLabel}
                </Text>

                {chevronVisible ? (
                    <ChevronDownIcon
                        width={28}
                        height={28}
                        fill={
                            disabled
                                ? theme.color.text.disabled
                                : theme.color.components.gray1
                        }
                    />
                ) : null}
            </StackView>

            <Modal
                visible={isVisible}
                animationType="none"
                transparent={true}
                onRequestClose={close}>
                {/* Background */}
                <Pressable
                    onPress={close}
                    style={{
                        position: "absolute",
                        top: 0,
                        bottom: PICKER_HEIGHT,
                        left: 0,
                        right: 0,
                    }}
                />
                {/* Picker */}
                <Animated.View
                    style={{
                        position: "absolute",
                        left: 0,
                        right: 0,
                        bottom: bottomPosition,
                        height: PICKER_HEIGHT,
                        borderRadius: 8,
                        backgroundColor: theme.color.background.elevation3,
                        shadowColor: theme.color.black,
                        shadowOpacity: 0.4,
                        shadowOffset: {
                            width: 0,
                            height: -2,
                        },
                    }}>
                    <View
                        style={{
                            paddingHorizontal: 20,
                            paddingVertical: HEADER_PADDING_VERTICAL,
                        }}>
                        <HeaderSecondaryButton
                            text="Done"
                            onPress={close}
                            style={{
                                alignSelf: "flex-end",
                            }}
                        />
                    </View>

                    {/* Header Separator */}
                    <View
                        style={{
                            height: HEADER_SEPARATOR,
                            backgroundColor: theme.color.dividers.gray1,
                        }}
                    />

                    {/* Body */}
                    <View
                        style={{
                            flex: 1,
                            backgroundColor: theme.color.background.elevation2,
                        }}>
                        {/* Selection Indicator */}
                        <View
                            style={{
                                position: "absolute",
                                top: SPACER_HEIGHT,
                                left: 20,
                                right: 20,
                                height: ITEM_HEIGHT,
                                borderRadius: 8,
                                backgroundColor:
                                    theme.color.background.elevation1,
                            }}
                        />

                        {/* Options */}
                        <ScrollView
                            ref={scrollView}
                            showsVerticalScrollIndicator={false}
                            scrollEventThrottle={16}
                            onScroll={onScroll}
                            decelerationRate="fast"
                            snapToOffsets={snapToOffsets}
                            snapToStart={false}
                            snapToEnd={false}
                            contentContainerStyle={{
                                flexGrow: 1,
                                paddingHorizontal: 20,
                            }}
                            style={{
                                flex: 1,
                                backgroundColor: theme.color.transparent,
                            }}>
                            {/* Spacer */}
                            <View
                                style={{
                                    height: SPACER_HEIGHT,
                                }}
                            />

                            {internalItems.map((i, index) => {
                                let textColor: ColorValue;

                                if (scrolledIndex == index) {
                                    textColor = theme.color.text.main;
                                } else {
                                    textColor = theme.color.text.disabled;
                                }

                                return (
                                    <View
                                        key={i.value}
                                        style={{
                                            height: ITEM_HEIGHT,
                                            justifyContent: "center",
                                        }}>
                                        <Text
                                            numberOfLines={1}
                                            ellipsizeMode="tail"
                                            style={[
                                                TextStyles.listItemLarge,
                                                {
                                                    color: textColor,
                                                    textAlign: "center",
                                                },
                                            ]}>
                                            {i.label}
                                        </Text>
                                    </View>
                                );
                            })}

                            {/* Spacer */}
                            <View
                                style={{
                                    height: SPACER_HEIGHT,
                                }}
                            />
                        </ScrollView>
                    </View>
                </Animated.View>
            </Modal>
        </Pressable>
    );
};

export default Picker;
