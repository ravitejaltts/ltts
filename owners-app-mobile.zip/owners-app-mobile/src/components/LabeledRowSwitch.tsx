import React from "react";
import {
    StyleProp,
    Text,
    TextStyle,
    TouchableHighlight,
    ViewStyle,
} from "react-native";
import { ChevronRightIcon } from "../assets/icons";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import StackView from "./StackView";
import ThemedSwitch from "./ThemedSwitch";

type LabeledRowSwitchProps = {
    leftText: string;
    leftTextStyle?: StyleProp<TextStyle>;
    leftSubtext?: string;
    rightText?: string;
    rightTextStyle?: StyleProp<TextStyle>;
    style?: StyleProp<ViewStyle>;
    value: boolean;
    disabled?: boolean;
    rightIcon?: boolean;
    onValueChanged: (newValue: boolean) => void;
    onPress?: () => void;
};

const LabeledRowSwitch: React.FunctionComponent<LabeledRowSwitchProps> = ({
    leftText,
    leftTextStyle,
    leftSubtext,
    rightText,
    rightTextStyle,
    style,
    value,
    disabled = false,
    rightIcon = false,
    onValueChanged,
    onPress,
}) => {
    const [theme] = useTheme();

    return (
        <TouchableHighlight
            onPress={onPress}
            underlayColor={theme.color.background.labeledRowUnderlay}
            style={[
                {
                    paddingVertical: 12,
                    paddingHorizontal: 20,
                    backgroundColor: theme.color.background.elevation3,
                },
                style,
            ]}>
            {/* Root View */}
            <StackView
                spacing={16}
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                {/* Left Text & Subtext */}
                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                        justifyContent: "center",
                    }}>
                    <Text
                        numberOfLines={1}
                        style={[
                            TextStyles.body,
                            { color: theme.color.text.main },
                            leftTextStyle,
                        ]}>
                        {leftText}
                    </Text>
                    {leftSubtext && (
                        <Text
                            style={[
                                TextStyles.subheading,
                                { color: theme.color.text.deemphasized },
                            ]}>
                            {leftSubtext}
                        </Text>
                    )}
                </StackView>

                {/* Right Text */}
                {rightText && (
                    <Text
                        style={[
                            TextStyles.body,
                            {
                                textAlign: "right",
                                color: theme.color.text.deemphasized,
                            },
                            rightTextStyle,
                        ]}>
                        {rightText}
                    </Text>
                )}

                <StackView
                    spacing={8}
                    style={{
                        flexDirection: "row",
                        alignItems: "center",
                    }}>
                    <ThemedSwitch
                        value={value}
                        onValueChange={onValueChanged}
                        disabled={disabled}
                    />

                    {rightIcon && (
                        <ChevronRightIcon
                            width={28}
                            height={28}
                            fill={theme.color.components.gray2}
                        />
                    )}
                </StackView>
            </StackView>
        </TouchableHighlight>
    );
};

export default LabeledRowSwitch;
