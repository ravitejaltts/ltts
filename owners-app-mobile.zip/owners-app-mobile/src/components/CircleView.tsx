import React from "react";
import { ColorValue, View } from "react-native";

type CircleViewProps = {
    size: number;
    color: ColorValue;
};

const CircleView: React.FunctionComponent<CircleViewProps> = ({
    size,
    color,
}) => {
    return (
        <View
            style={{
                width: size,
                height: size,
                borderRadius: size / 2,
                backgroundColor: color,
            }}
        />
    );
};

export default CircleView;
