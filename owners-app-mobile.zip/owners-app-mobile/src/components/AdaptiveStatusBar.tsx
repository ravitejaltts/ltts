import { useIsFocused } from "@react-navigation/native";
import React, { useEffect } from "react";
import { useWindowDimensions } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Svg, { Defs, LinearGradient, Rect, Stop } from "react-native-svg";
import { useTheme } from "../context";
import { setThemedStatusBar } from "../hooks";

const AdaptiveStatusBar: React.FunctionComponent<{
    isOpaque: boolean;
}> = ({ isOpaque }) => {
    const [theme] = useTheme();
    const isFocused = useIsFocused();
    const safeAreaInsets = useSafeAreaInsets();
    const windowDimensions = useWindowDimensions();

    useEffect(() => {
        if (!isFocused) {
            return;
        }

        if (isOpaque) {
            setThemedStatusBar(theme);
        } else {
            setThemedStatusBar(theme, "light-content");
        }
    }, [isOpaque, isFocused, theme]);

    return (
        <Svg
            width={windowDimensions.width}
            height={safeAreaInsets.top}
            style={{
                position: "absolute",
                left: 0,
                right: 0,
                top: 0,
            }}>
            <Defs>
                <LinearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                    <Stop
                        offset="0"
                        stopColor={theme.color.background.statusBar.toString()}
                        stopOpacity="0.5"
                    />
                    <Stop
                        offset="1"
                        stopColor={theme.color.transparent.toString()}
                        stopOpacity="0"
                    />
                </LinearGradient>
            </Defs>
            <Rect
                x="0"
                y="0"
                width={windowDimensions.width}
                height={safeAreaInsets.top}
                fill={
                    isOpaque
                        ? theme.color.background.default.toString()
                        : "url(#gradient)"
                }
            />
        </Svg>
    );
};

export default AdaptiveStatusBar;
