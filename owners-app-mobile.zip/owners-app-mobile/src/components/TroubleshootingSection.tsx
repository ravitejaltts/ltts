import React from "react";
import { ListRenderItemInfo, StyleProp, ViewStyle } from "react-native";
import TroubleshootingCardView from "./TroubleshootingCardView";
import { TroubleshootingContent } from "../models/domain/content";
import HorizontalFlatListSection from "./HorizontalFlatListSection";
import { useNavigation } from "@react-navigation/native";
import { getIcon } from "../constants/ZoneData";
import { SupportScreenNavigationProp } from "../screens/support";

const TroubleshootingSection: React.FunctionComponent<{
    contents: TroubleshootingContent[];
    onSeeAllPressed?: () => void;
    style?: StyleProp<ViewStyle>;
}> = ({ contents, onSeeAllPressed, style }) => {
    const navigation = useNavigation<SupportScreenNavigationProp>();

    function renderTroubleshootingItem(
        info: ListRenderItemInfo<TroubleshootingContent>
    ) {
        const item = info.item;
        return (
            <TroubleshootingCardView
                icon={getIcon(item.zoneName)}
                zone={item.zoneName}
                title={item.title}
                onPress={() => {
                    navigation.push("troubleshootingContent", item);
                }}
            />
        );
    }

    return (
        <HorizontalFlatListSection
            headerText="Troubleshooting"
            data={contents}
            renderItem={renderTroubleshootingItem}
            onSeeAllPressed={onSeeAllPressed}
            style={style}
        />
    );
};

export default TroubleshootingSection;
