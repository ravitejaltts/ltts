import React, { useRef } from "react";
import { Text, TextInput } from "react-native";
import { useTheme } from "../context";
import { TextStyles } from "../styles";
import { PhoneInput, PhoneInputProps } from "./PhoneInput";
import StackView from "./StackView";

interface LabeledRowPhoneInput extends PhoneInputProps {
    leftText?: string;
    disabled?: boolean;
}

export const LabeledRowPhoneInput: React.FunctionComponent<
    LabeledRowPhoneInput
> = ({ leftText, disabled = false, ...phoneInputProps }) => {
    const [theme] = useTheme();
    const inputRef = useRef<TextInput>(null);

    return (
        <StackView
            spacing={4}
            style={{
                flexDirection: "row",
                alignItems: "center",
                paddingHorizontal: 20,
                height: 56,
                backgroundColor: theme.color.background.elevation3,
                opacity: disabled ? 0.5 : 1,
            }}>
            {Boolean(leftText) && (
                <Text
                    style={[
                        TextStyles.body,
                        {
                            color: theme.color.text.main,
                        },
                    ]}>
                    {leftText}
                </Text>
            )}

            <PhoneInput
                ref={inputRef}
                placeholderTextColor={theme.color.text.deemphasized}
                editable={!disabled}
                {...phoneInputProps}
                style={[
                    TextStyles.regular17,
                    {
                        flex: 1,
                        color: theme.color.text.main,
                    },
                    phoneInputProps.style,
                ]}
            />
        </StackView>
    );
};
