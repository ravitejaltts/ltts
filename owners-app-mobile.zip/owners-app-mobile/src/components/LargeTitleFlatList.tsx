import React from "react";
import {
    FlatList,
    FlatListProps,
    NativeScrollEvent,
    NativeSyntheticEvent,
    StyleSheet,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "../context";
import { useLargeTitleNavigation } from "../hooks";
import { LargeTitleHeaderView } from "./LargeTitleHeaderView";

interface LargeTitleFlatListProps<ItemT = any> extends FlatListProps<ItemT> {
    title: string;
    navigationHeaderShown?: boolean;
    titleHeaderView?: React.ReactNode;
    bodyHeaderView?: React.ReactNode;
}

export const LargeTitleFlatList: React.FunctionComponent<
    LargeTitleFlatListProps
> = (props) => {
    const {
        title,
        navigationHeaderShown = true,
        titleHeaderView,
        bodyHeaderView,
        ...flatListProps
    } = props;

    const [theme] = useTheme();
    const safeAreaInsets = useSafeAreaInsets();

    const { headerHeightRef, onScroll } = useLargeTitleNavigation(
        title,
        navigationHeaderShown
    );

    const _onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
        flatListProps.onScroll?.(event);
        onScroll(event);
    };

    const contentContainerStyle = StyleSheet.flatten(
        flatListProps.contentContainerStyle
    );
    const contentContainerBackgroundColor =
        contentContainerStyle?.backgroundColor ??
        theme.color.background.elevation3;

    return (
        <View
            style={{
                flex: 1,
            }}>
            {!navigationHeaderShown && (
                <View
                    style={{
                        backgroundColor: theme.color.black,
                        height: safeAreaInsets.top,
                    }}
                />
            )}
            <FlatList
                {...flatListProps}
                onScroll={_onScroll}
                scrollEventThrottle={16}
                style={[
                    flatListProps.style,
                    {
                        backgroundColor: theme.color.black,
                    },
                ]}
                contentContainerStyle={[
                    {
                        flexGrow: 1,
                        paddingBottom: 40,
                        backgroundColor: contentContainerBackgroundColor,
                    },
                    flatListProps.contentContainerStyle,
                ]}
                ListHeaderComponent={
                    <LargeTitleHeaderView
                        title={title}
                        headerHeightRef={headerHeightRef}
                        titleHeaderView={titleHeaderView}
                        bodyHeaderView={bodyHeaderView}
                    />
                }
                ListFooterComponent={
                    <View
                        style={{
                            backgroundColor: contentContainerBackgroundColor,
                            position: "absolute",
                            height: 500,
                            bottom: -500,
                            left: 0,
                            right: 0,
                        }}
                    />
                }
            />
        </View>
    );
};
