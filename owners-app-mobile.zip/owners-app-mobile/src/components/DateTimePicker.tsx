import RNDateTimePicker, {
    DateTimePickerAndroid,
} from "@react-native-community/datetimepicker";
import React, { useRef, useState } from "react";
import {
    Animated,
    Modal,
    Platform,
    Pressable,
    StyleProp,
    Text,
    TextStyle,
    View,
    ViewStyle,
} from "react-native";
import { useTheme } from "../context";

const PICKER_HEIGHT = 250;
const HEADER_PADDING_VERTICAL = 4;

export const DateTimePicker: React.FunctionComponent<{
    value: any;
    mode: "date" | "time";
    disabled?: boolean;
    containerStyle?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    subTextStyle?: StyleProp<TextStyle>;
    onChange: (selection: any) => void;
    onOpen?: () => void;
    onClose?: () => void;
}> = ({
    value: timestamp,
    mode,
    disabled,
    containerStyle,
    textStyle,
    subTextStyle,
    onChange,
    onOpen,
    onClose,
}) => {
    const [theme] = useTheme();
    const [isVisible, setIsVisible] = useState(false);

    const bottomPosition = useRef(new Animated.Value(-PICKER_HEIGHT)).current;

    // take timestamp and process it to local time
    const time = new Date(timestamp);
    const localeTime = time.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "numeric",
    });

    // i.e. '9:00 AM' extracted to: 9:00 and AM/PM
    const timeParts = localeTime.split(/\s+/);
    const hhmm = timeParts[0];
    const ampm = timeParts[1];

    const open = () => {
        setIsVisible(true);

        if (Platform.OS === "ios") {
            setIsVisible(true);
            onOpen?.();

            Animated.timing(bottomPosition, {
                toValue: 0,
                duration: 200,
                useNativeDriver: false,
            }).start();
        } else {
            // Android
            DateTimePickerAndroid.open({
                mode: "time",
                display: "spinner",
                minuteInterval: 15,
                value: time,
                onChange: onChange,
            });
        }
    };

    const close = () => {
        if (Platform.OS === "ios") {
            onClose?.();

            Animated.timing(bottomPosition, {
                toValue: -PICKER_HEIGHT,
                duration: 200,
                useNativeDriver: false,
            }).start(() => {
                setIsVisible(false);
            });
        } else {
            // Android
            DateTimePickerAndroid.dismiss("time");
        }
    };

    return (
        <Pressable disabled={disabled} onPress={open} style={containerStyle}>
            <Text>
                <Text style={textStyle}>{hhmm}</Text>
                <Text style={subTextStyle}> {ampm}</Text>
            </Text>

            {Platform.OS === "ios" && (
                <Modal
                    visible={isVisible}
                    animationType="none"
                    transparent={true}
                    onRequestClose={close}>
                    <Pressable
                        onPress={close}
                        style={{
                            position: "absolute",
                            top: 0,
                            bottom: PICKER_HEIGHT,
                            left: 0,
                            right: 0,
                        }}
                    />
                    <Animated.View
                        style={{
                            position: "absolute",
                            left: 0,
                            right: 0,
                            bottom: bottomPosition,
                            height: PICKER_HEIGHT,
                            borderRadius: 8,
                            backgroundColor: theme.color.background.elevation2,
                            // shadow
                            shadowColor: theme.color.black,
                            shadowOpacity: 0.4,
                            shadowOffset: {
                                width: 0,
                                height: -2,
                            },
                        }}>
                        <View
                            style={{
                                paddingHorizontal: 20,
                                paddingVertical: HEADER_PADDING_VERTICAL,
                            }}>
                            <RNDateTimePicker
                                value={time}
                                onChange={onChange}
                                mode={mode}
                                display="spinner"
                                minuteInterval={15}
                                themeVariant={
                                    theme.name === "light" ? "light" : "dark"
                                }
                            />
                        </View>
                    </Animated.View>
                </Modal>
            )}
        </Pressable>
    );
};
