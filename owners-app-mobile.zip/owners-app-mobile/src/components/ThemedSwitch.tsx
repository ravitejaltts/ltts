import React from "react";
import { Switch, SwitchProps } from "react-native";
import { useTheme } from "../context";

const ThemedSwitch: React.FunctionComponent<SwitchProps> = (props) => {
    const [theme] = useTheme();

    return (
        <Switch
            {...props}
            thumbColor={theme.color.white}
            trackColor={{
                true: theme.color.green.bright,
                false: theme.color.background.elevation1,
            }}
            ios_backgroundColor={theme.color.background.elevation1}
        />
    );
};

export default ThemedSwitch;
