import { observer } from "mobx-react-lite";
import React, { useEffect, useMemo, useRef } from "react";
import {
    View,
    Animated,
    ScrollView,
    ActivityIndicator,
    PanResponder,
    ViewStyle,
    useWindowDimensions,
} from "react-native";
import { useTheme } from "../context";

const GESTURE_HANDLE_HEIGHT = 40;
const TOP_TRANSLATE_Y = 10;

type BottomSheetProps = {
    height: number;
    loading: boolean;
    children: React.ReactNode;
};

const BottomSheet: React.FunctionComponent<BottomSheetProps> = observer(
    ({ height, loading, children }) => {
        const [theme] = useTheme();
        const width = useWindowDimensions().width;
        const bottomTranslateY = height - GESTURE_HANDLE_HEIGHT;

        const translateYValue = useRef(0);
        const translateYRef = useRef(new Animated.Value(0));

        useEffect(() => {
            translateYRef.current.setValue(bottomTranslateY);
            translateYValue.current = bottomTranslateY;
        }, [bottomTranslateY]);

        const panResponder = useMemo(
            () =>
                PanResponder.create({
                    onStartShouldSetPanResponder: () => true,
                    onMoveShouldSetPanResponder: () => true,
                    onPanResponderGrant: () => {
                        // The offset is the current translation Y
                        // The gesture will add to it
                        translateYRef.current.setOffset(
                            translateYValue.current
                        );
                    },
                    onPanResponderMove: Animated.event(
                        [
                            null,
                            {
                                dy: translateYRef.current,
                            },
                        ],
                        {
                            useNativeDriver: false,
                        }
                    ),
                    onPanResponderRelease: (_, state) => {
                        // Flattening the offset combines value and the offset
                        translateYRef.current.flattenOffset();

                        let desiredTranslateY: number;

                        if (state.dy < 0) {
                            desiredTranslateY = TOP_TRANSLATE_Y;
                        } else {
                            desiredTranslateY = bottomTranslateY;
                        }

                        Animated.timing(translateYRef.current, {
                            toValue: desiredTranslateY,
                            duration: 100,
                            useNativeDriver: false,
                        }).start(() => {
                            translateYValue.current = desiredTranslateY;
                        });
                    },
                }),
            [bottomTranslateY]
        );

        const animatedStyle = useMemo<Animated.AnimatedProps<ViewStyle>>(() => {
            if (height === 0) {
                return { transform: undefined };
            }

            return {
                transform: [
                    {
                        translateY: translateYRef.current,
                    },
                ],
            };
        }, [height]);

        return (
            <Animated.View
                style={[
                    {
                        position: "absolute",
                        width: width,
                        height: height,
                        zIndex: 2,
                        borderTopLeftRadius: 8,
                        borderTopRightRadius: 8,
                        backgroundColor: theme.color.background.elevation3,
                    },
                    animatedStyle,
                ]}>
                {/* Gesture Handle */}
                <Animated.View
                    style={{ height: GESTURE_HANDLE_HEIGHT }}
                    {...panResponder.panHandlers}>
                    <View
                        style={{
                            height: 3,
                            width: 81,
                            backgroundColor: theme.color.text.deemphasized,
                            borderRadius: 8,
                            alignSelf: "center",
                            marginTop: 12,
                        }}
                    />
                </Animated.View>
                {loading ? (
                    <View
                        style={{
                            flex: 1,
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        <ActivityIndicator size="large" animating={true} />
                    </View>
                ) : (
                    <ScrollView
                        contentContainerStyle={{
                            flexGrow: 1,
                            paddingHorizontal: 20,
                            marginBottom: 20,
                        }}>
                        {children}
                    </ScrollView>
                )}
            </Animated.View>
        );
    }
);

export default BottomSheet;
