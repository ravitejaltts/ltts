import React, { useState } from "react";
import {
    StyleProp,
    Text,
    TouchableHighlight,
    View,
    ViewStyle,
} from "react-native";
import { TextStyles } from "../styles";
import { useTheme } from "../context";
import { ChevronRightIcon, CloseIcon } from "../assets/icons";
import { ImageButton } from "./Buttons";
import FastImage from "react-native-fast-image";

const RoutePlannerCard: React.FunctionComponent<{
    text?: string;
    onPress: () => void;
    showClose?: boolean;
    style?: StyleProp<ViewStyle>;
}> = ({ text, style, onPress, showClose = true }) => {
    const [theme] = useTheme();
    const [isVisible, setIsVisible] = useState(true);

    function onClose() {
        setIsVisible(false);
    }

    return isVisible ? (
        <TouchableHighlight
            onPress={onPress}
            underlayColor={theme.color.background.labeledRowUnderlay}
            activeOpacity={0.5}
            style={[
                {
                    flex: 1,
                    padding: 20,
                    borderRadius: 8,
                    backgroundColor: theme.color.background.elevation3,
                },
                style,
            ]}>
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                }}>
                <FastImage
                    style={{ marginRight: 16 }}
                    source={require("../assets/images/helpers/routePlanning.png")}
                />
                <View style={{ flex: 7 }}>
                    <Text
                        style={[
                            TextStyles.listEyebrow,
                            {
                                color: theme.color.text.deemphasized,
                                marginBottom: 4,
                            },
                        ]}>
                        eRV Trip Planning
                    </Text>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            { color: theme.color.text.main },
                        ]}>
                        {text
                            ? text
                            : `Explore tools that make planning your next trip easier.`}
                    </Text>
                </View>
                {showClose ? (
                    <ImageButton
                        style={{ bottom: 10, left: 10 }}
                        image={() => <CloseIcon fill={theme.color.text.main} />}
                        onPress={onClose}
                    />
                ) : (
                    <View
                        style={{
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                        <ChevronRightIcon fill={theme.color.dividers.gray2} />
                    </View>
                )}
            </View>
        </TouchableHighlight>
    ) : null;
};

export default RoutePlannerCard;
