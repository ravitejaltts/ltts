import React, { useState } from "react";
import { View } from "react-native";
import { Defs, Mask, Rect, Svg } from "react-native-svg";
import { useTheme } from "../../context";
import { RoundedSvgRect } from "../svg";

const HEIGHT = 45;

export const StatusAlertLoadingView: React.FunctionComponent = () => {
    const [theme] = useTheme();
    const [viewWidth, setViewWidth] = useState(100);

    return (
        <View
            onLayout={(e) => {
                const { width } = e.nativeEvent.layout;
                setViewWidth(width);
            }}>
            <Svg width={viewWidth} height={HEIGHT}>
                <Defs>
                    <Mask id="mask">
                        <Rect
                            x={0}
                            y={0}
                            width={viewWidth}
                            height={HEIGHT}
                            fill="white"
                        />

                        <RoundedSvgRect
                            x={0}
                            y={0}
                            width={50}
                            height={HEIGHT}
                            rtl={8}
                            rbl={8}
                            fill="black"
                        />

                        <Rect
                            x={66}
                            y={HEIGHT / 2 - 4}
                            width={viewWidth - 50 - 32}
                            height={8}
                            fill="black"
                        />
                    </Mask>
                </Defs>

                {/* Background Color */}
                <Rect
                    x={0}
                    y={0}
                    width={viewWidth}
                    height={HEIGHT}
                    fill={theme.color.background.settings}
                    mask="url(#mask)"
                />

                {/* Card */}
                <Rect
                    x={0}
                    y={0}
                    width={viewWidth}
                    height={HEIGHT}
                    rx={8}
                    fill={theme.color.background.elevation3}
                    mask="url(#mask)"
                />
            </Svg>
        </View>
    );
};
