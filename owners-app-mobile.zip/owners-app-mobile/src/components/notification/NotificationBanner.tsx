import React from "react";
import { ColorValue, Pressable, Text, View } from "react-native";
import { SvgProps } from "react-native-svg";
import { StackView } from "..";
import { ErrorFillIcon, WLogoIcon, WarningFillIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import {
    WgoNotification,
    WgoNotificationPriorityType,
} from "../../models/domain/notification";
import { FontWeight, LightTheme, TextStyles } from "../../styles";
import { DateUtil } from "../../utils";

export const NotificationBanner: React.FunctionComponent<{
    notification: WgoNotification;
    onPress: () => void;
}> = ({ notification, onPress }) => {
    const [theme] = useTheme();

    const { priority, title, body, receivedTimestampMilliseconds } =
        notification;

    if (!title && !body) {
        return null;
    }

    const timeAgoText = DateUtil.timeAgo(receivedTimestampMilliseconds);

    let iconBackgroundColor: ColorValue;
    let icon: React.FunctionComponent<SvgProps>;

    switch (priority) {
        case WgoNotificationPriorityType.High:
            iconBackgroundColor = theme.color.error;
            icon = WarningFillIcon;
            break;
        case WgoNotificationPriorityType.Medium:
            iconBackgroundColor = theme.color.yellow.warning;
            icon = ErrorFillIcon;
            break;
        case WgoNotificationPriorityType.Low:
        default:
            iconBackgroundColor = theme.color.blue.brand;
            icon = WLogoIcon;
            break;
    }

    return (
        <Pressable onPress={onPress}>
            <View
                style={{
                    height: 80,
                    backgroundColor: theme.color.white,
                    flexDirection: "row",
                    borderRadius: 8,
                    shadowColor: theme.color.black,
                    shadowOpacity: 0.25,
                    shadowRadius: 10,
                    shadowOffset: {
                        width: 0,
                        height: 2,
                    },
                }}>
                {/* Icon Column */}
                <View
                    style={{
                        backgroundColor: iconBackgroundColor,
                        width: 57,
                        justifyContent: "center",
                        alignItems: "center",
                        borderTopLeftRadius: 8,
                        borderBottomLeftRadius: 8,
                    }}>
                    {icon({
                        width: 24,
                        height: 24,
                        fill: theme.color.white,
                    })}
                </View>

                <StackView
                    spacing={4}
                    style={{
                        flex: 1,
                        paddingHorizontal: 12,
                        paddingVertical: 10,
                        justifyContent: body ? "flex-start" : "center",
                    }}>
                    {/* Title and Time */}
                    <View
                        style={{
                            flexDirection: "row",
                            alignItems: "center",
                        }}>
                        <Text
                            style={{
                                flex: 1,
                                fontWeight: FontWeight.Semibold,
                                fontSize: 15,
                                color: theme.color.black,
                            }}>
                            {title}
                        </Text>
                        <Text
                            style={{
                                fontWeight: FontWeight.Regular,
                                fontSize: 13,
                                color: LightTheme.color.text.deemphasized,
                            }}>
                            {timeAgoText}
                        </Text>
                    </View>

                    {/* Body */}
                    {Boolean(body) && (
                        <Text
                            numberOfLines={2}
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.black,
                                },
                            ]}>
                            {body}
                        </Text>
                    )}
                </StackView>
            </View>
        </Pressable>
    );
};
