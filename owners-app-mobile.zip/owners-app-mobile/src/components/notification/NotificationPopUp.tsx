import { observer } from "mobx-react-lite";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { Animated, useWindowDimensions } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRootContainer } from "../../context";
import { useLogger } from "../../hooks";
import { WgoNotification } from "../../models/domain/notification";
import { NotificationBanner } from "./NotificationBanner";

const HORIZONTAL_MARGIN = 8; // left/right margin to screen edge
const TOP_MARGIN = 10;
const SLIDE_DURATION_MS = 400;

export const NotificationPopUp: React.FunctionComponent<{
    onPress: (notif: WgoNotification) => void;
    slideOutTime?: number;
}> = observer(({ onPress, slideOutTime = 5000 }) => {
    const container = useRootContainer();
    const notificationStore = container.stores.notification;
    const notification = notificationStore.foregroundNotification;

    const deviceWidth = useWindowDimensions().width;
    const slideOutTimerRef = useRef<NodeJS.Timeout>();

    const [show, setShow] = useState(Boolean(notification));
    const slideAnimationValueRef = useRef(new Animated.Value(0));
    const slideAnimationRef = useRef<Animated.CompositeAnimation>();

    const safeInsets = useSafeAreaInsets();
    const { logMessage } = useLogger("NotificationPopUp");

    // Sync show variable with notification
    useEffect(() => {
        setShow(Boolean(notification));
    }, [notification]);

    const clearSlideOutTimer = useCallback(() => {
        const slideOutTimer = slideOutTimerRef.current;

        if (slideOutTimer) {
            logMessage("Clear slide-out timer");
            clearTimeout(slideOutTimer);
        }
    }, [logMessage]);

    useEffect(() => {
        clearSlideOutTimer();
        slideAnimationRef.current?.stop();

        if (show) {
            logMessage("Show notification");

            slideAnimationValueRef.current.setValue(0);

            const animation = Animated.timing(slideAnimationValueRef.current, {
                toValue: 1,
                duration: SLIDE_DURATION_MS,
                useNativeDriver: false,
            });

            slideAnimationRef.current = animation;

            animation.start(() => {
                logMessage("Starting countdownToSlideOut");

                slideOutTimerRef.current = setTimeout(() => {
                    // After the timeout, hide
                    setShow(false);
                }, slideOutTime);
            });
        } else {
            logMessage("Hide notification");

            slideAnimationValueRef.current.setValue(1);

            // Reset animation to 0 && show it && animate
            const animation = Animated.timing(slideAnimationValueRef.current, {
                toValue: 0,
                duration: SLIDE_DURATION_MS,
                useNativeDriver: false,
            });

            slideAnimationRef.current = animation;

            animation.start(({ finished }) => {
                if (finished) {
                    // When the foreground notification disappears,
                    // clear the cached notification
                    notificationStore.clearForegroundNotification();
                }
            });
        }
    }, [show, slideOutTime, notificationStore, clearSlideOutTimer, logMessage]);

    // Clear timer when unmounting
    useEffect(() => {
        return clearSlideOutTimer;
    }, [clearSlideOutTimer]);

    if (!notification) {
        return null;
    }

    return (
        <Animated.View
            style={{
                position: "absolute",
                width: deviceWidth - HORIZONTAL_MARGIN * 2,
                left: safeInsets.left + HORIZONTAL_MARGIN,
                top: safeInsets.top + TOP_MARGIN,
                transform: [
                    {
                        translateY: slideAnimationValueRef.current.interpolate({
                            inputRange: [0, 1],
                            outputRange: [-300, 0],
                        }),
                    },
                ],
            }}>
            <NotificationBanner
                notification={notification}
                onPress={() => {
                    setShow(false);
                    onPress(notification);
                }}
            />
        </Animated.View>
    );
});
