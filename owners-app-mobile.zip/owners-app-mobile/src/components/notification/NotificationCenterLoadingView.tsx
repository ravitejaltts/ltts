import React from "react";
import { Text, View } from "react-native";
import { StackView } from "../../components";
import { GradientLoadingView } from "../../components/animated";
import { useTheme } from "../../context";
import { TextStyles } from "../../styles";
import { GenericNotificationLoadingView } from "./GenericNotificationLoadingView";
import { StatusAlertLoadingView } from "./StatusAlertLoadingView";

export const NotificationCenterLoadingView: React.FunctionComponent = () => {
    const [theme] = useTheme();

    return (
        <GradientLoadingView
            animating={true}
            direction="vertical"
            duration={2000}
            backgroundColor={theme.color.text.disabled}
            highlightColor={theme.color.background.elevation1}>
            <Text
                style={[
                    TextStyles.contentEyebrow,
                    {
                        paddingBottom: 12,
                        backgroundColor: theme.color.background.settings,
                        color: theme.color.text.main,
                    },
                ]}>
                STATUS ALERTS
            </Text>
            <StackView
                spacing={8}
                spacerColor={theme.color.background.settings}>
                <StatusAlertLoadingView />
                <StatusAlertLoadingView />
                <StatusAlertLoadingView />
            </StackView>

            {/* General Notifications Header */}
            <View
                style={{
                    flexDirection: "row",
                    alignItems: "center",
                    backgroundColor: theme.color.background.settings,
                    paddingTop: 10,
                    paddingBottom: 2,
                }}>
                <Text
                    style={[
                        TextStyles.contentEyebrow,
                        {
                            flex: 1,
                            color: theme.color.text.main,
                        },
                    ]}>
                    GENERAL
                </Text>

                <View
                    style={{
                        height: 40,
                        justifyContent: "center",
                    }}>
                    <Text
                        style={[
                            TextStyles.listItemSmall,
                            {
                                color: theme.color.text.disabled,
                            },
                        ]}>
                        Clear All
                    </Text>
                </View>
            </View>

            {/* General Notifications */}
            <StackView
                spacing={8}
                spacerColor={theme.color.background.settings}>
                <GenericNotificationLoadingView />
                <GenericNotificationLoadingView />
                <GenericNotificationLoadingView />
                <GenericNotificationLoadingView />
            </StackView>
        </GradientLoadingView>
    );
};
