import React, { useState } from "react";
import { View } from "react-native";
import Svg, { Defs, Mask, Rect } from "react-native-svg";
import { useTheme } from "../../context";

const HEIGHT = 88;

export const GenericNotificationLoadingView: React.FunctionComponent = () => {
    const [theme] = useTheme();
    const [viewWidth, setViewWidth] = useState(100);

    return (
        <View
            onLayout={(e) => {
                const { width } = e.nativeEvent.layout;
                setViewWidth(width);
            }}>
            <Svg width={viewWidth} height={HEIGHT}>
                <Defs>
                    <Mask id="mask">
                        <Rect
                            x={0}
                            y={0}
                            width={viewWidth}
                            height={HEIGHT}
                            fill="white"
                        />
                        <Rect
                            x={8}
                            y={8}
                            width={32}
                            height={32}
                            rx={8}
                            fill="black"
                        />

                        <Rect
                            x={52}
                            y={20}
                            width={120}
                            height={8}
                            fill="black"
                        />

                        <Rect
                            x={8}
                            y={52}
                            width={viewWidth - 38}
                            height={8}
                            fill="black"
                        />

                        <Rect
                            x={8}
                            y={68}
                            width={viewWidth - 98}
                            height={8}
                            fill="black"
                        />
                    </Mask>
                </Defs>

                {/* Background Color */}
                <Rect
                    x={0}
                    y={0}
                    width={viewWidth}
                    height={HEIGHT}
                    fill={theme.color.background.settings}
                    mask="url(#mask)"
                />

                {/* Card */}
                <Rect
                    x={0}
                    y={0}
                    width={viewWidth}
                    height={HEIGHT}
                    rx={8}
                    fill={theme.color.background.elevation3}
                    mask="url(#mask)"
                />
            </Svg>
        </View>
    );
};
