import React from "react";
import { ColorValue, Text, View } from "react-native";
import {
    GestureHandlerRootView,
    Swipeable,
    TouchableHighlight,
} from "react-native-gesture-handler";
import { SvgProps } from "react-native-svg";
import {
    DeleteOutlineIcon,
    ErrorFillIcon,
    WLogoIcon,
    WarningFillIcon,
} from "../../assets/icons";
import { useTheme } from "../../context";
import {
    WgoNotification,
    WgoNotificationPriorityType,
} from "../../models/domain/notification";
import { TextStyles } from "../../styles";
import { DateUtil } from "../../utils";
import StackView from "../StackView";

export const GenericNotificationView: React.FunctionComponent<{
    notification: WgoNotification;
    onPress: () => void;
    onDelete: () => void;
}> = ({ notification, onPress, onDelete }) => {
    const { title, body, isRead, receivedTimestampMilliseconds } = notification;
    const dateText = DateUtil.timeAgo(receivedTimestampMilliseconds);

    const [theme] = useTheme();

    function renderDeleteButton() {
        return (
            <TouchableHighlight
                onPress={onDelete}
                style={{
                    flex: 1,
                    borderRadius: 8,
                    width: 80,
                    marginLeft: 8,
                }}>
                <View
                    style={{
                        flex: 1,
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor: theme.color.error,
                        borderRadius: 8,
                    }}>
                    <DeleteOutlineIcon
                        style={{ marginBottom: 4 }}
                        width={24}
                        height={24}
                        fill={theme.color.white.toString()}
                    />
                    <Text
                        style={{
                            color: theme.color.white,
                            ...TextStyles.regular15,
                        }}>
                        Delete
                    </Text>
                </View>
            </TouchableHighlight>
        );
    }

    let icon: React.FunctionComponent<SvgProps>;
    let iconBackgroundColor: ColorValue;

    switch (notification.priority) {
        case WgoNotificationPriorityType.High:
            icon = WarningFillIcon;
            iconBackgroundColor = theme.color.error;
            break;
        case WgoNotificationPriorityType.Medium:
            icon = ErrorFillIcon;
            iconBackgroundColor = theme.color.yellow.warning;
            break;
        case WgoNotificationPriorityType.Low:
        default:
            icon = WLogoIcon;
            iconBackgroundColor = theme.color.blue.brand;
            break;
    }

    return (
        <GestureHandlerRootView>
            <Swipeable renderRightActions={renderDeleteButton}>
                <TouchableHighlight
                    onPress={onPress}
                    underlayColor={theme.color.background.elevation1}
                    style={{
                        borderRadius: 8,
                        overflow: "hidden",
                        backgroundColor: theme.color.background.elevation3,
                    }}>
                    <StackView
                        spacing={4}
                        style={{
                            padding: 8,
                        }}>
                        {/* Top Row */}
                        <View
                            style={{
                                flexDirection: "row",
                                alignItems: "center",
                            }}>
                            {/* Icon */}
                            <View
                                style={{
                                    justifyContent: "center",
                                    alignItems: "center",
                                    width: 32,
                                    height: 32,
                                    borderRadius: 4,
                                    backgroundColor: isRead
                                        ? theme.color.components.gray1
                                        : iconBackgroundColor,
                                }}>
                                {icon({
                                    width: 24,
                                    height: 24,
                                    fill: theme.color.white,
                                })}
                            </View>

                            {/* Title */}
                            <Text
                                style={[
                                    TextStyles.semibold15,
                                    {
                                        flex: 1,
                                        marginLeft: 16,
                                        marginRight: 8,
                                        color: theme.color.text.main,
                                    },
                                ]}>
                                {title}
                            </Text>

                            {/* Date */}
                            <Text
                                style={{
                                    fontSize: 13,
                                    color: theme.color.text.deemphasized,
                                }}>
                                {dateText}
                            </Text>
                        </View>

                        {/* Body Row */}
                        <Text
                            style={[
                                TextStyles.subheading,
                                {
                                    color: theme.color.text.deemphasized,
                                },
                            ]}>
                            {body}
                        </Text>
                    </StackView>
                </TouchableHighlight>
            </Swipeable>
        </GestureHandlerRootView>
    );
};
