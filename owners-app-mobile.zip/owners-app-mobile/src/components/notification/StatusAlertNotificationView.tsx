import React from "react";
import { ColorValue, Text, TouchableHighlight, View } from "react-native";
import { SvgProps } from "react-native-svg";
import { ErrorFillIcon, WarningFillIcon } from "../../assets/icons";
import { useTheme } from "../../context";
import {
    DeviceAlert,
    DeviceAlertPriorityType,
} from "../../models/domain/device";
import { TextStyles } from "../../styles";

export const StatusAlertNotificationView: React.FunctionComponent<{
    deviceAlert: DeviceAlert;
    onPress: () => void;
}> = ({ deviceAlert, onPress }) => {
    const { priorityType, header } = deviceAlert;

    const [theme] = useTheme();

    let icon: React.FunctionComponent<SvgProps>;
    let iconBackgroundColor: ColorValue;

    switch (priorityType) {
        case DeviceAlertPriorityType.Critical:
            icon = WarningFillIcon;
            iconBackgroundColor = theme.color.error;
            break;
        case DeviceAlertPriorityType.Medium:
            icon = ErrorFillIcon;
            iconBackgroundColor = theme.color.yellow.warning;
            break;
        case DeviceAlertPriorityType.Low:
        case DeviceAlertPriorityType.Info:
        default:
            icon = WarningFillIcon;
            iconBackgroundColor = theme.color.blue.brand;
            break;
    }

    return (
        <TouchableHighlight
            onPress={onPress}
            underlayColor={theme.color.background.elevation1}
            style={{
                borderRadius: 8,
                overflow: "hidden",
                backgroundColor: theme.color.background.elevation3,
            }}>
            <View
                style={{
                    flexDirection: "row",
                }}>
                {/* Icon */}
                <View
                    style={{
                        width: 50,
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor: iconBackgroundColor,
                    }}>
                    {icon({
                        width: 24,
                        height: 24,
                        fill: theme.color.white,
                    })}
                </View>

                {/* Header & Nav Icon */}
                <Text
                    style={[
                        TextStyles.semibold17,
                        {
                            flex: 1,
                            padding: 12,
                            color: theme.color.text.main,
                        },
                    ]}>
                    {header}
                </Text>
            </View>
        </TouchableHighlight>
    );
};
