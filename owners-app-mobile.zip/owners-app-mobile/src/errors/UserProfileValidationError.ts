import { UserProfile } from "../models/domain/user";

export class UserProfileValidationError extends Error {
    public profileProp?: string;

    public constructor(profile: UserProfile, detail: string) {
        let profileProp: string | undefined;

        for (const key of Object.keys(profile)) {
            if (detail.includes(key)) {
                profileProp = key;
            }
        }

        super(`Invalid profile field: ${profileProp}`);

        this.profileProp = profileProp;
    }
}
