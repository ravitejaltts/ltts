class InvalidRefreshTokenError extends Error {
    public constructor() {
        super("Invalid or missing refresh token");
    }
}

export default InvalidRefreshTokenError;
