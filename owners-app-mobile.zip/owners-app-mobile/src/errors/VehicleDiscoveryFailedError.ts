export default class VehicleDiscoveryFailedError extends Error {
    public constructor() {
        super("Vehicle discovery failed");
    }
}
