export type AzureApiError = {
    type: string;
    title: string;
    status: number;
    detail: string;
    instance: string;
};
