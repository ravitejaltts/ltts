export default class EmailFactorNotFoundError extends Error {
    public constructor() {
        super("Email factor not enrolled");
    }
}
