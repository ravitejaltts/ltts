export const REUSED_PASSWORD_ERROR_MESSAGE =
    "Password has been used too recently";

class ReusedPasswordError extends Error {
    public constructor() {
        super(REUSED_PASSWORD_ERROR_MESSAGE);
    }
}

export default ReusedPasswordError;
