export const COMMON_PASSWORD_ERROR_MESSAGE =
    "This password was found in a list of commonly used passwords. Please try another password.";

class CommonPasswordError extends Error {
    public constructor() {
        super(COMMON_PASSWORD_ERROR_MESSAGE);
    }
}

export default CommonPasswordError;
