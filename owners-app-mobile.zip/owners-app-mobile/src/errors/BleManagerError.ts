import { BleManagerState } from "../models/domain/bluetooth";

export class BleManagerInitializedError extends Error {
    public constructor() {
        super("The Bluetooth manager has already been initialized");
    }
}

export class BleManagerUninitializedError extends Error {
    public constructor() {
        super("The Bluetooth manager has not been initialized");
    }
}

export class UnexpectedBleManagerStateError extends Error {
    public readonly currentState: BleManagerState;
    public readonly expectedState: BleManagerState;

    public constructor(
        currentState: BleManagerState,
        expectedState: BleManagerState
    ) {
        super(
            `Unexpected bluetooth manager state. Current: '${currentState}', Expected: '${expectedState}'`
        );

        this.currentState = currentState;
        this.expectedState = expectedState;
    }
}
