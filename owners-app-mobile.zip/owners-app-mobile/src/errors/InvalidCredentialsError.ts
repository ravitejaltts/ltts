export default class InvalidCredentialsError extends Error {
    public constructor() {
        super("Invalid email or password");
    }
}
