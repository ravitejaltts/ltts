class AccountExistsError extends Error {
    public constructor() {
        super(`Account already exists`);
    }
}

export default AccountExistsError;
