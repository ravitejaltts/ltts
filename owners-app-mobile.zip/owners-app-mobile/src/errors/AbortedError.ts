export class AbortedError extends Error {
    public constructor() {
        super("Aborted");
    }
}
