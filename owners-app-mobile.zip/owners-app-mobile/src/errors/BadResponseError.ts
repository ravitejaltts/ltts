class BadResponseError extends Error {
    public constructor() {
        super("Unexpected response received");
    }
}

export default BadResponseError;
