import { ContactData } from "../models/domain/maintenance";

export class ContactFormValidationError extends Error {
    public formProp?: string;

    public constructor(form: ContactData, detail: string) {
        let formProp: string | undefined;

        for (const key of Object.keys(form)) {
            if (detail.includes(key)) {
                formProp = key;
            }
        }

        super(`Invalid contact form field: ${formProp}`);

        this.formProp = formProp;
    }
}
