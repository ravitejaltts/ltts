import { OktaFactor } from "../models/domain/auth";

class MfaVerificationRequiredError extends Error {
    public stateToken: string;
    public factors: OktaFactor[];

    public constructor(stateToken: string, factors: OktaFactor[]) {
        super("MFA verification required");
        this.stateToken = stateToken;
        this.factors = factors;
    }
}

export default MfaVerificationRequiredError;
