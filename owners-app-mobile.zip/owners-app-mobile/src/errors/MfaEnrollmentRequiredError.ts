class MfaEnrollmentRequiredError extends Error {
    public constructor() {
        super("MFA enrollment required");
    }
}

export default MfaEnrollmentRequiredError;
