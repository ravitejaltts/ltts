export default class DownloadFailedError extends Error {
    public constructor() {
        super("Download failed");
    }
}
