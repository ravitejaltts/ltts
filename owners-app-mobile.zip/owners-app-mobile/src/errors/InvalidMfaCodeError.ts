export class InvalidMfaCodeError extends Error {
    public constructor() {
        super("Invalid MFA code");
    }
}
