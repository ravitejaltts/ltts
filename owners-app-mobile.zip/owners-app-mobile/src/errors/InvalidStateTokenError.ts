export class InvalidStateTokenError extends Error {
    public constructor() {
        super("Invalid state token");
    }
}
