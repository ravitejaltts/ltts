export const PASSWORD_REQUIREMENTS_ERROR_MESSAGE =
    "Password requirements were not met";

class PasswordRequirementsError extends Error {
    public constructor() {
        super("Password does not meet requirements");
    }
}

export default PasswordRequirementsError;
