import { HttpStatusCode } from "../models/http";

class HttpError extends Error {
    public body?: any;
    public readonly statusCode: HttpStatusCode;

    public constructor(statusCode: HttpStatusCode, body?: any) {
        super(
            `HTTP ${statusCode} ${
                body !== undefined ? JSON.stringify(body) : ""
            }`
        );
        this.statusCode = statusCode;
        this.body = body;
    }
}

export default HttpError;
