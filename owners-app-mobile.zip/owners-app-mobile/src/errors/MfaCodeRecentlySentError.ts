export class MfaCodeRecentlySentError extends Error {
    public constructor() {
        super(
            "A code was recently sent. Please wait 30 seconds before trying again."
        );
    }
}
