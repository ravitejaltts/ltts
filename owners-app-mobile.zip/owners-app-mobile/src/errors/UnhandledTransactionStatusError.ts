import { OktaTransactionStatus } from "../models/domain/auth";

export default class UnhandledTransactionStatusError extends Error {
    public constructor(status: OktaTransactionStatus) {
        super(`Unhandled transaction status '${status}'`);
    }
}
