class InvalidAccessTokenError extends Error {
    public constructor() {
        super("Invalid or missing access token");
    }
}

export default InvalidAccessTokenError;
