import { OktaTransactionStatus } from "../models/domain/auth";

export default class AuthenticationTransactionError extends Error {
    public constructor(status: OktaTransactionStatus, message: string) {
        super(`Status '${status}': ${message}`);
    }
}
