export default class DownloadCancelledError extends Error {
    public constructor() {
        super("Download cancelled");
    }
}
