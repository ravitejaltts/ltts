import { Platform } from "react-native";
import { useRootContainer } from "../context";
import { SmartVehicle } from "../models/domain/vehicle";
import { useCallback } from "react";
import { AnalyticsDataKey } from "../models/analytics";

export const useGenerateAnalyticsData = () => {
    const container = useRootContainer();

    const generateAnalyticsData = useCallback(() => {
        const authStore = container.stores.auth;
        const user = authStore.user;

        const appStore = container.stores.app;

        const vehicleStore = container.stores.vehicle;
        const vehicle = vehicleStore.associatedVehicle;

        const deviceStore = container.stores.device;
        const subscription = deviceStore.subscription;

        const analyticsData: { [key: string]: string } = {};

        // User supplemental data
        if (user) {
            analyticsData[AnalyticsDataKey.UserOktaId] = user.id;
        }

        // App supplemental data
        analyticsData[AnalyticsDataKey.AppVersion] = appStore.appVersion;
        analyticsData[AnalyticsDataKey.AppBuild] = appStore.buildVersion;

        // Mobile Device supplemental data
        analyticsData[AnalyticsDataKey.MobileOs] = Platform.OS;
        const mobileVersion = Platform.Version;
        let mobileVersionString: string;
        if (typeof mobileVersion === "number") {
            mobileVersionString = mobileVersion.toString();
        } else {
            mobileVersionString = mobileVersion;
        }
        analyticsData[AnalyticsDataKey.MobileVersion] = mobileVersionString;

        // Smart Vehicle supplemental data
        if (vehicle instanceof SmartVehicle) {
            if (vehicle.deviceId) {
                analyticsData[AnalyticsDataKey.WinnConnectDeviceId] =
                    vehicle.deviceId;
            }

            if (vehicle.deviceType) {
                analyticsData[AnalyticsDataKey.WinnConnectDeviceType] =
                    vehicle.deviceType;
            }

            if (vehicle.deviceVersion) {
                analyticsData[AnalyticsDataKey.WinnConnectDeviceVersion] =
                    vehicle.deviceVersion;
            }

            analyticsData[AnalyticsDataKey.WinnConnectConnectionState] =
                vehicle.connectionState;

            if (vehicle.connectionType) {
                analyticsData[AnalyticsDataKey.WinnConnectConnectionType] =
                    vehicle.connectionType;
            }
        }

        // WinnConnect Plan supplemental data
        if (subscription) {
            analyticsData[AnalyticsDataKey.WinnConnectPlanCode] =
                subscription.plan.planCode;

            analyticsData[AnalyticsDataKey.WinnConnectSubscriptionStatus] =
                subscription.status;
        }

        return analyticsData;
    }, [container]);

    return generateAnalyticsData;
};
