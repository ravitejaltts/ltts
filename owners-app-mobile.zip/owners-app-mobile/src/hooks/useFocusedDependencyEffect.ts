import { useIsFocused } from "@react-navigation/native";
import { EffectCallback, useEffect, useRef } from "react";

export function useFocusedDependencyEffect(effect: EffectCallback) {
    const isFocused = useIsFocused();

    // Remember if deps have changed
    const depsChangedRef = useRef(true);

    useEffect(() => {
        // When any of the dependencies change, we should update
        depsChangedRef.current = true;
    }, [effect]);

    useEffect(() => {
        // When focused and one of the dependencies has changed, update
        if (isFocused && depsChangedRef.current) {
            // Reset the state until the deps change again
            depsChangedRef.current = false;
            effect();
        }
    }, [isFocused, effect]);
}
