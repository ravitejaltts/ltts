import { useEffect } from "react";
import { useRootContainer } from "../context";
import { useAppState } from "./useAppState";
import { useLogger } from "./useLogger";

export const useEvaluateAuthState = () => {
    const container = useRootContainer();
    const authStore = container.stores.auth;

    const { logError } = useLogger("useEvaluateAuthState");

    const { prevAppState, appState } = useAppState();

    useEffect(() => {
        // Only evauluate the auth state when authenticated
        if (!authStore.isAuthenticated) {
            return;
        }

        switch (prevAppState) {
            case "background":
            case "inactive":
                if (appState === "active") {
                    authStore.evaluateAuthState(false).catch((error) => {
                        logError(error);
                    });
                }
                break;
            default:
                // Do nothing
                break;
        }
    }, [appState, prevAppState, authStore, logError]);
};
