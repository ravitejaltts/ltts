import { Alert } from "react-native";
import { useRootContainer } from "../context";
import { useLogger } from "./useLogger";
import { useCallback, useMemo } from "react";
import { BleManagerState } from "../models/domain/bluetooth";
import { UnexpectedBleManagerStateError } from "../errors";
import { env } from "../config/env";

export function useBluetoothPermission() {
    const { logMessage } = useLogger("useBluetoothPermission");
    const container = useRootContainer();

    const linkingService = container.services.linking;

    const bluetoothStore = container.stores.bluetooth;
    const managerState = bluetoothStore.state;

    let isGranted: boolean;
    switch (managerState) {
        case BleManagerState.PoweredOn:
            isGranted = true;
            break;
        case BleManagerState.Unsupported:
            isGranted = env.name === "mock";
            break;
        default:
            isGranted = false;
            break;
    }

    const showPowerAlert = useCallback(() => {
        Alert.alert(
            "Enable Bluetooth",
            "Turn on Bluetooth to connect to your RV.",
            [
                {
                    text: "Settings",
                    style: "default",
                    onPress: () => {
                        linkingService.openSettings();
                    },
                },
                {
                    text: "OK",
                    style: "cancel",
                },
            ]
        );
    }, [linkingService]);

    const showUnauthorizedAlert = useCallback(() => {
        Alert.alert(
            "Authorize Bluetooth",
            "Allow Winnebago to access Bluetooth to connect to your RV.",
            [
                {
                    text: "Settings",
                    style: "default",
                    onPress: () => {
                        linkingService.openSettings();
                    },
                },
                {
                    text: "OK",
                    style: "cancel",
                },
            ]
        );
    }, [linkingService]);

    const showUnsupportedAlert = useCallback(() => {
        Alert.alert(
            "Bluetooth Unsupported",
            "Bluetooth is unsupported on your device."
        );
    }, []);

    const request = useCallback(async () => {
        logMessage("Requesting bluetooth permission");

        const state = await bluetoothStore.init();

        switch (state) {
            case BleManagerState.PoweredOff:
            case BleManagerState.Resetting:
                // Ask user to power on
                showPowerAlert();
                break;
            case BleManagerState.Unauthorized:
                // Ask the user to change their settings
                showUnauthorizedAlert();

                break;
            case BleManagerState.Unsupported:
                if (env.name !== "mock") {
                    // Tell the user their device is unsupported (simulators/emulators)
                    showUnsupportedAlert();
                }
                break;
        }

        if (state !== BleManagerState.PoweredOn && env.name !== "mock") {
            throw new UnexpectedBleManagerStateError(
                state,
                BleManagerState.PoweredOn
            );
        }
    }, [
        bluetoothStore,
        showPowerAlert,
        showUnauthorizedAlert,
        showUnsupportedAlert,
        logMessage,
    ]);

    return useMemo(
        () => ({
            isGranted,
            request,
            showPowerAlert,
            showUnauthorizedAlert,
            showUnsupportedAlert,
        }),
        [
            isGranted,
            request,
            showPowerAlert,
            showUnauthorizedAlert,
            showUnsupportedAlert,
        ]
    );
}
