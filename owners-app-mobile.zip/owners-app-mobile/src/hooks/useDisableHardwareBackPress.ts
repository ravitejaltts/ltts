import { useFocusEffect } from "@react-navigation/native";
import { useCallback } from "react";
import { BackHandler } from "react-native";

export function useDisableHardwareBackPress() {
    useFocusEffect(
        useCallback(() => {
            const handler = () => true;

            BackHandler.addEventListener("hardwareBackPress", handler);

            return () =>
                BackHandler.removeEventListener("hardwareBackPress", handler);
        }, [])
    );
}
