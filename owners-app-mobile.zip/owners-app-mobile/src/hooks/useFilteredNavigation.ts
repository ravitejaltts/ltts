import { CommonActions, NavigationProp } from "@react-navigation/native";
import { useLayoutEffect, useRef } from "react";

export function useFilteredNavigation<T extends {}>(
    navigation: NavigationProp<T>,
    filter: (routeName: keyof T) => boolean
) {
    const isFirstLayoutRef = useRef(true);

    useLayoutEffect(() => {
        if (!isFirstLayoutRef.current) {
            return;
        }

        isFirstLayoutRef.current = false;

        navigation.dispatch((state) => {
            const routes = state.routes.filter((r) => filter(r.name));

            return CommonActions.reset({
                ...state,
                routes,
                index: routes.length - 1,
            });
        });
    }, [navigation, filter]);
}
