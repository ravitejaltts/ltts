import { useState, useEffect, useRef } from "react";

export const useEllipsisAnimation = (
    isAnimating = false,
    intervalMillis = 250
) => {
    const [text, setText] = useState("");
    const intervalRef = useRef<any>(null);

    useEffect(() => {
        // Always clear interval if deps change
        clearInterval(intervalRef.current);

        if (isAnimating) {
            // Start interval
            intervalRef.current = setInterval(() => {
                setText((prevText) =>
                    prevText === "..." ? "" : prevText + "."
                );
            }, intervalMillis);
        } else {
            // Not animating, clear text
            setText("");
        }

        return () => {
            clearInterval(intervalRef.current);
        };
    }, [intervalMillis, isAnimating]);

    return text;
};
