import { useEffect } from "react";
import { GeneratorLockoutToastProps } from "../components/toast";
import { useRootContainer } from "../context";
import { TimedLockout } from "../models/domain/metaSystem";
import { SystemLockoutOrWarning } from "../models/domain/system";
import { WgoToastType } from "../models/ui";
import { ToastIdentifier } from "../stores";
import { useSmartVehicle } from "./useSmartVehicle";

export const useGeneratorTimedLockoutToast = (
    lockoutInstance: SystemLockoutOrWarning
) => {
    const container = useRootContainer();
    const toastStore = container.stores.toast;

    const smartVehicle = useSmartVehicle();
    const lockout = smartVehicle?.metaSystem.lockouts.find(
        (x) => x.instance === lockoutInstance
    );

    let isActive = false;
    let expiry = 0;

    if (lockout instanceof TimedLockout) {
        isActive = lockout.isActive;
        expiry = lockout.expiry ?? 0;
    }

    useEffect(() => {
        const remainingMillis = expiry - Date.now();

        const toastId = `${ToastIdentifier.GeneratorLockout}_${lockoutInstance}`;

        if (
            isActive &&
            remainingMillis > 0 &&
            !toastStore.isShown((x) => x.type === WgoToastType.GeneratorLockout)
        ) {
            toastStore.show<GeneratorLockoutToastProps>({
                id: toastId,
                type: WgoToastType.GeneratorLockout,
                props: {
                    lockoutInstance: lockoutInstance,
                },
                duration: remainingMillis,
            });
        } else {
            toastStore.hideById(toastId);
        }
    }, [toastStore, lockoutInstance, isActive, expiry]);
};
