import { useCallback, useState } from "react";
import { useRootContainer } from "../context";
import { useFirstFocusedEffect } from "./useFirstFocusedEffect";
import { useLogger } from "./useLogger";

export const useDeepLink = () => {
    const { logError } = useLogger("useDeepLink");

    const container = useRootContainer();
    const linkingService = container.services.linking;

    const [isLoading, setIsLoading] = useState(true);
    const [deepLink, setDeepLink] = useState("");

    useFirstFocusedEffect(
        useCallback(() => {
            setIsLoading(true);
            linkingService
                .getDeepLink()
                .then((url) => {
                    if (url) {
                        setDeepLink(url);
                    }
                })
                .catch((error) => {
                    logError(error);
                })
                .finally(() => {
                    setIsLoading(false);
                });
        }, [linkingService, logError])
    );

    return {
        isLoading,
        deepLink,
        setDeepLink,
    };
};
