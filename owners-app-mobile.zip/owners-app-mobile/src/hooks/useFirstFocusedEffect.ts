import { useIsFocused } from "@react-navigation/native";
import { EffectCallback, useEffect, useRef } from "react";

export function useFirstFocusedEffect(effect: EffectCallback) {
    const isFocused = useIsFocused();
    const isFirstFocusRef = useRef(true);

    useEffect(() => {
        if (isFocused && isFirstFocusRef.current) {
            isFirstFocusRef.current = false;
            effect();
        }
    }, [isFocused, effect]);
}
