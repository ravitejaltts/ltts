import { useActionSheet } from "@expo/react-native-action-sheet";
import { useRootContainer } from "../context";
import { useCallback } from "react";

const CUSTOMER_CARE = "(800) 537-1885";
const WINNEBAGO_CONNECT = "(855) 861-4886";

type NumberType = "customer_care" | "winnebago_connect";

export const useCallCustomerCare = () => {
    const container = useRootContainer();
    const linkingService = container.services.linking;
    const { showActionSheetWithOptions } = useActionSheet();

    const call = useCallback(
        (numberType: NumberType) => {
            let phoneNumber: string;
            let title: string;

            switch (numberType) {
                case "winnebago_connect":
                    phoneNumber = WINNEBAGO_CONNECT;
                    title = "Talk with a Winnebago Connect Specialist?";
                    break;
                case "customer_care":
                default:
                    phoneNumber = CUSTOMER_CARE;
                    title = "Talk with Winnebago Customer Care?";
                    break;
            }

            showActionSheetWithOptions(
                {
                    options: [`Call ${phoneNumber}`, "Cancel"],
                    title: title,
                    cancelButtonIndex: 1,
                },
                (selectedIndex) => {
                    switch (selectedIndex) {
                        case 0:
                            linkingService.call(phoneNumber);
                            break;
                        case 1:
                            // cancel
                            break;
                        default:
                            break;
                    }
                }
            );
        },
        [linkingService, showActionSheetWithOptions]
    );

    return {
        call,
    };
};
