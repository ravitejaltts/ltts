import { useCallback } from "react";
import { Alert } from "react-native";
import { useRootContainer } from "../context";
import { AbortedError } from "../errors";
import { DeviceSubscription } from "../models/domain/device";
import { useCallCustomerCare } from "./useCallCustomerCare";
import { useLogger } from "./useLogger";
import { useSmartVehicle } from "./useSmartVehicle";
import { useZohoHostedPage } from "./useZohoHostedPage";

export const useDeviceSubscriptionPayment = (
    source: string,
    onSuccess?: (newSub: DeviceSubscription) => void
) => {
    const smartVehicle = useSmartVehicle();
    const container = useRootContainer();
    const deviceStore = container.stores.device;

    const { logError } = useLogger(source);
    const { call } = useCallCustomerCare();

    const onFailure = useCallback(
        (error: Error) => {
            if (error instanceof AbortedError) {
                // User left the screen
                // Do not show or log an error
                return;
            }

            logError(error);
            Alert.alert(
                "We've Run Into an Issue Processing Your Request",
                "If the problem persists, please contact Customer Service.",
                [
                    {
                        text: "OK",
                        style: "default",
                        isPreferred: true,
                    },
                    {
                        text: "Contact a Winnebago Connect Specialist",
                        style: "default",
                        onPress: () => {
                            call("winnebago_connect");
                        },
                    },
                ]
            );
        },
        [logError, call]
    );

    const { isBusy: isUpdatingPayment, openHostedPage } = useZohoHostedPage(
        source,
        onSuccess,
        onFailure
    );

    const updatePayment = useCallback(() => {
        const deviceId = smartVehicle?.deviceId;
        const subscription = deviceStore.subscription;

        if (!deviceId || !subscription) {
            onFailure(
                new Error(
                    "Update payment failed: missing device ID or subscription"
                )
            );
            return;
        }

        openHostedPage(
            deviceStore.startUpdateSubscriptionPayment({
                deviceId,
                subscriptionId: subscription.subscriptionId,
                planCode: subscription.plan.planCode,
            })
        );
    }, [smartVehicle, deviceStore, onFailure, openHostedPage]);

    return {
        isUpdatingPayment,
        updatePayment,
    };
};
