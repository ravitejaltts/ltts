import { useStores } from "../context";
import { Coordinates } from "../models/domain/location";
import { DistanceUtil } from "../utils";

export function useDistance(location?: Coordinates): string {
    const userLocationStore = useStores().userLocation;
    const currentLocation = userLocationStore.currentLocation;

    let distance = "";

    if (location && currentLocation) {
        const miles = DistanceUtil.calculateDistance(
            currentLocation,
            location,
            "mi"
        );
        distance = `${miles} mi`;
    }

    return distance;
}
