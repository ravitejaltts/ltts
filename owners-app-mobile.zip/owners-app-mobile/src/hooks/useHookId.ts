import { useRef } from "react";
import { RandomUtil } from "../utils";

export function useHookId(id: number = RandomUtil.getIntInclusive(1000, 9999)) {
    return useRef(id).current;
}
