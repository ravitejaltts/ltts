import { useCallback, useState } from "react";
import { useRootContainer } from "../context";
import { useInitEffect } from "./useInitEffect";
import { useLogger } from "./useLogger";

export const useInitApp = (source: string) => {
    const { logError } = useLogger(source);

    const container = useRootContainer();
    const authStore = container.stores.auth;
    const profileStore = container.stores.profile;
    const deviceStore = container.stores.device;
    const notificationStore = container.stores.notification;
    const userLocationStore = container.stores.userLocation;
    const migrationStore = container.stores.migration;

    const [isInitializing, setIsInitializing] = useState(true);

    const init = useCallback(async () => {
        await authStore.evaluateAuthState(true);
        await profileStore.init();
        await deviceStore.loadStoredSubscription();
        await notificationStore.updatePermissionStatus();
        await userLocationStore.checkPermission();

        try {
            // Run async migrations
            await migrationStore.run();
        } catch {
            // Do nothing
        }
    }, [
        authStore,
        profileStore,
        deviceStore,
        notificationStore,
        userLocationStore,
        migrationStore,
    ]);

    // Run the init once
    useInitEffect(
        useCallback(() => {
            if (!isInitializing) {
                return;
            }

            init()
                .catch((error) => logError(error))
                .finally(() => {
                    setIsInitializing(false);
                });
        }, [isInitializing, init, logError])
    );

    return { isInitializing };
};
