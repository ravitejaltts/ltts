export function duplicateElements(
    count: number,
    generateElement: (key: number) => JSX.Element
): JSX.Element[] {
    const elements: JSX.Element[] = [];

    for (let i = 0; i < count; i++) {
        elements.push(generateElement(i));
    }

    return elements;
}
