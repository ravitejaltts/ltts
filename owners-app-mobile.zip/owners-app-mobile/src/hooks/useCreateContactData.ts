import { useCallback } from "react";
import { useRootContainer } from "../context";
import { ContactData } from "../models/domain/maintenance";
import { VehicleClassType } from "../models/domain/vehicle";
import { useGenerateAnalyticsData } from "./useGenerateAnalyticsData";

export const useCreateContactData = () => {
    const container = useRootContainer();
    const generateAnalyticsData = useGenerateAnalyticsData();

    const createContactData = useCallback(
        (isVehicleConfirmed: boolean) => {
            const authStore = container.stores.auth;

            const profileStore = container.stores.profile;

            const vehicleStore = container.stores.vehicle;
            const vehicle = vehicleStore.associatedVehicle;

            const user = authStore.user;
            const profile = profileStore.profile;

            let vin: string | undefined;
            let classType: VehicleClassType | undefined;

            // Vehicle data
            if (isVehicleConfirmed) {
                vin = vehicle?.vin;
                classType = vehicle?.classType;
            }

            const analyticsData = generateAnalyticsData();

            const data: Partial<ContactData> = {
                firstName: user?.firstName,
                lastName: user?.lastName,
                address1: profile?.address1,
                address2: profile?.address2,
                city: profile?.city,
                state: profile?.state,
                postalCode: profile?.postalCode,
                country: profile?.countryCode,
                phoneNumber: profile?.phoneNumber,
                emailAddress: user?.email,
                vin: vin,
                vehicleClassType: classType,
                supplementalData: analyticsData,
            };

            return data;
        },
        [container, generateAnalyticsData]
    );

    return { createContactData };
};
