import { useCallback } from "react";
import { VehicleConnectionState } from "../models/domain/connection";
import { DeviceAlert } from "../models/domain/device";
import { NavigationActionUtils } from "../utils";
import { useSmartVehicle } from "./useSmartVehicle";

export const useGetDeviceAlertAction = () => {
    const smartVehicle = useSmartVehicle();

    const getDeviceAlertAction = useCallback(
        (deviceAlert: DeviceAlert) => {
            /*
            Conditions to navigate for a device alert:
            • Smart vehicle exists
            • Smart vehicle is connected
            • If smart vehicle is connected via cloud,
                both the device and network are connected
                and the user has subscribed to WinnConnect
            */
            if (
                !smartVehicle ||
                smartVehicle.connectionState !==
                    VehicleConnectionState.Connected ||
                smartVehicle.isCloudDeviceDisconnected ||
                smartVehicle.isCloudNetworkDisconnected ||
                smartVehicle.isCloudInactiveSub
            ) {
                return null;
            }

            return NavigationActionUtils.getDeviceAlertAction(deviceAlert);
        },
        [smartVehicle]
    );

    return getDeviceAlertAction;
};
