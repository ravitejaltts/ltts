import { useEffect, useState } from "react";
import { ContentFile } from "../models/domain/content";
import { StringUtils } from "../utils";

export function useContentFileSize(file?: ContentFile) {
    const [byteString, setByteString] = useState("Calculating...");

    useEffect(() => {
        if (file) {
            file.calculateSize()
                .then((bytes) => {
                    if (bytes) {
                        setByteString(StringUtils.bytesToString(bytes));
                    } else {
                        setByteString("");
                    }
                })
                .catch(() => {
                    setByteString("");
                });
        } else {
            setByteString("");
        }
    }, [file]);

    return byteString;
}
