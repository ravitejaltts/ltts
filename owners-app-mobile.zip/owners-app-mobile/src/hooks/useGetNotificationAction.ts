import { useCallback } from "react";
import {
    WgoNotification,
    WgoNotificationType,
} from "../models/domain/notification";
import { NavigationActionUtils } from "../utils";
import { useGetDeviceAlertAction } from "./useGetDeviceAlertAction";

export const useGetNotificationAction = () => {
    const getDeviceAlertAction = useGetDeviceAlertAction();

    const getNotificationAction = useCallback(
        (notification: WgoNotification) => {
            switch (notification.type) {
                case WgoNotificationType.EventDeviceAlert:
                case WgoNotificationType.StatusDeviceAlert:
                    const deviceAlert = notification.deviceAlert;

                    if (!deviceAlert) {
                        return null;
                    }

                    return getDeviceAlertAction(deviceAlert);
                case WgoNotificationType.Generic:
                    return NavigationActionUtils.getGenericNotificationAction(
                        notification
                    );
                default:
                    return null;
            }
        },
        [getDeviceAlertAction]
    );

    return getNotificationAction;
};
