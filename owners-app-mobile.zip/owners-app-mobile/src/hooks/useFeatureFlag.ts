import { useRootContainer } from "../context";
import { FeatureFlagKey } from "../models/domain/featureFlag";

export const useFeatureFlag = (key: FeatureFlagKey) => {
    const container = useRootContainer();
    const featureFlagStore = container.stores.featureFlag;
    const flag = featureFlagStore.flags.get(key);

    return flag ? flag.value : false;
};
