import { useEffect, useRef, useState } from "react";
import { AppState } from "react-native";

export function useAppState() {
    const prevAppStateRef = useRef(AppState.currentState);
    const [appState, setAppState] = useState(AppState.currentState);

    useEffect(() => {
        const subscription = AppState.addEventListener("change", setAppState);
        return () => {
            subscription.remove();
        };
    }, []);

    useEffect(() => {
        prevAppStateRef.current = appState;
    }, [appState]);

    return {
        prevAppState: prevAppStateRef.current,
        appState: appState,
    };
}
