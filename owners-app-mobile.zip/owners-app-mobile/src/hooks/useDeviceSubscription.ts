import { useCallback, useState } from "react";
import { Alert } from "react-native";
import { useRootContainer } from "../context";
import { AnalyticsEventName } from "../models/analytics";
import { DevicePlan, DeviceSubscription } from "../models/domain/device";
import { useLogger } from "./useLogger";
import { useSmartVehicle } from "./useSmartVehicle";
import { useZohoHostedPage } from "./useZohoHostedPage";
import { MathUtils } from "../utils";
import { useCallCustomerCare } from "./useCallCustomerCare";
import { AbortedError } from "../errors";

export const useDeviceSubscription = (
    source: string,
    onSuccess?: (newSub: DeviceSubscription) => void
) => {
    const { logEvent, logError } = useLogger(source);

    const smartVehicle = useSmartVehicle();

    const container = useRootContainer();
    const deviceStore = container.stores.device;

    const { call } = useCallCustomerCare();

    const onFailure = useCallback(
        (error: Error) => {
            if (error instanceof AbortedError) {
                // User left the screen
                // Do not show or log an error
                return;
            }

            logError(error);
            Alert.alert(
                "We've Run Into an Issue Processing Your Request",
                "If the problem persists, please contact Customer Service.",
                [
                    {
                        text: "OK",
                    },
                    {
                        text: "Contact a Winnebago Connect Specialist",
                        onPress: () => {
                            call("winnebago_connect");
                        },
                    },
                ]
            );
        },
        [logError, call]
    );

    const { isBusy, openHostedPage } = useZohoHostedPage(
        source,
        onSuccess,
        onFailure
    );

    const [isCancelling, setIsCancelling] = useState(false);

    const isSubscribing = isBusy || isCancelling;

    const subscribe = useCallback(
        (desiredPlan: DevicePlan) => {
            const deviceId = smartVehicle?.deviceId;

            if (!deviceId) {
                onFailure(new Error("Subscribe failed: missing device ID"));
                return;
            }

            const subscription = deviceStore.subscription;
            let isOwnedByCurrentUser = false;
            let isActive = false;

            if (subscription) {
                isOwnedByCurrentUser = subscription.ownerByCurrentUser;
                isActive = deviceStore.isActiveSubscription(subscription);
            }

            const desiredPlanPrice = Number.parseInt(
                desiredPlan.recurringPrice
            );

            let isDowngrade = false;
            if (subscription && MathUtils.isNumber(desiredPlanPrice)) {
                // Downgrade if the desired plan has a lower price than the current subscription
                isDowngrade = desiredPlanPrice < subscription.amount;
            }

            const createSubscription = () => {
                logEvent(AnalyticsEventName.DeviceSubscription, {
                    action: "create",
                    planCode: desiredPlan.planCode,
                });

                // Create a new subscription if...
                // there is no subscription ||
                // subscription is not active ||
                // subscription is not owned by the current user ||
                // subscription is a downgrade
                openHostedPage(
                    deviceStore.startCreateSubscription(deviceId, desiredPlan)
                );
            };

            if (subscription) {
                // Existing subscription
                if (isActive) {
                    // Existing, active subscription
                    if (isOwnedByCurrentUser) {
                        // Existing active subscription, owned by the current user
                        if (isDowngrade) {
                            // Downgrade for existing, active subscription, owned by the current user
                            // Must cancel before continuing
                            Alert.alert(
                                "Are You Sure?",
                                "The current plan must be cancelled to downgrade to a lower tier plan.",
                                [
                                    {
                                        text: "Cancel & Downgrade",
                                        style: "destructive",
                                        onPress: () => {
                                            setIsCancelling(true);
                                            deviceStore
                                                .cancelSubscription(
                                                    deviceId,
                                                    subscription.subscriptionId,
                                                    false
                                                )
                                                .then(() => {
                                                    // Retry
                                                    subscribe(desiredPlan);
                                                })
                                                .catch(onFailure)
                                                .finally(() => {
                                                    setIsCancelling(false);
                                                });
                                        },
                                    },
                                    {
                                        text: "Back",
                                        style: "cancel",
                                    },
                                ]
                            );
                        } else {
                            // Upgrade for existing, active subscription, owned by the current user
                            // Update plan
                            logEvent(AnalyticsEventName.DeviceSubscription, {
                                action: "update_plan",
                                planCode: desiredPlan.planCode,
                            });

                            openHostedPage(
                                deviceStore.startUpdateSubscriptionPlan({
                                    deviceId: deviceId,
                                    subscriptionId: subscription.subscriptionId,
                                    newPlanCode: desiredPlan.planCode,
                                })
                            );
                        }
                    } else {
                        // Existing, active subscription, owned by another user
                        // Must cancel before continuing
                        Alert.alert(
                            "Are You Sure?",
                            "The current plan must be cancelled before you can begin a new one.",
                            [
                                {
                                    text: "Cancel & Re-Subscribe",
                                    style: "destructive",
                                    onPress: () => {
                                        setIsCancelling(true);
                                        deviceStore
                                            .cancelSubscription(
                                                deviceId,
                                                subscription.subscriptionId,
                                                false
                                            )
                                            .then(() => {
                                                // Retry
                                                subscribe(desiredPlan);
                                            })
                                            .catch(onFailure)
                                            .finally(() => {
                                                setIsCancelling(false);
                                            });
                                    },
                                },
                                {
                                    text: "Back",
                                    style: "cancel",
                                },
                            ]
                        );
                    }
                } else {
                    // Existing, inactive subscription
                    // Create
                    createSubscription();
                }
            } else {
                // No existing subscription
                // Create
                createSubscription();
            }
        },
        [smartVehicle, deviceStore, openHostedPage, onFailure, logEvent]
    );

    return {
        isSubscribing,
        subscribe,
    };
};
