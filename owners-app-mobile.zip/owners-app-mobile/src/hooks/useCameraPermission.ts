import { useCallback, useMemo } from "react";
import { Alert } from "react-native";
import { useRootContainer } from "../context";
import { useLogger } from "./useLogger";

export function useCameraPermission() {
    const { logMessage } = useLogger("useCameraPermission");

    const container = useRootContainer();

    const linkingService = container.services.linking;

    const cameraStore = container.stores.camera;
    const isGranted = cameraStore.hasPermissionGranted;
    const canRequest = cameraStore.canAskAgain;

    const showUnauthorizedAlert = useCallback(() => {
        Alert.alert(
            "Camera Permission Denied",
            "Owner's App needs access to your camera.",
            [
                {
                    text: "Dismiss",
                    style: "cancel",
                },
                {
                    text: "Settings",
                    style: "default",
                    onPress: () => linkingService.openSettings(),
                },
            ]
        );
    }, [linkingService]);

    const request = useCallback(async () => {
        logMessage("Requesting camera permission");

        await cameraStore.checkPermission();

        if (!cameraStore.hasPermissionGranted) {
            if (cameraStore.canAskAgain) {
                await cameraStore.requestPermission();

                if (!cameraStore.hasPermissionGranted) {
                    showUnauthorizedAlert();
                    throw new Error("Camera permission denied");
                }
            } else {
                throw new Error(
                    "Camera permission denied and canot be requested"
                );
            }
        }
    }, [cameraStore, showUnauthorizedAlert, logMessage]);

    return useMemo(
        () => ({
            isGranted,
            canRequest,
            request,
            showUnauthorizedAlert,
        }),
        [isGranted, canRequest, request, showUnauthorizedAlert]
    );
}
