import { useEffect } from "react";
import { useRootContainer } from "../context";
import { Generator, GeneratorMode } from "../models/domain/energy";
import { useQuietHoursInEffect } from "./useQuietHoursInEffect";
import { useSmartVehicle } from "./useSmartVehicle";

export const useGeneratorQuietHoursOverrideToast = () => {
    const smartVehicle = useSmartVehicle();

    const container = useRootContainer();
    const toastStore = container.stores.toast;

    let generator: Generator | null = null;

    if (smartVehicle) {
        generator = smartVehicle.energy.generator;
    }

    const mode = generator?.mode;
    const quietHoursEnabled = Boolean(generator?.quietHoursEnabled);
    const quietHoursInEffect = useQuietHoursInEffect();

    // Quiet Hours Override Toast
    useEffect(() => {
        if (
            quietHoursEnabled &&
            quietHoursInEffect &&
            mode === GeneratorMode.Run
        ) {
            toastStore.showGeneratorQuietHoursOverrideToast();
        }
    }, [toastStore, quietHoursEnabled, quietHoursInEffect, mode]);
};
