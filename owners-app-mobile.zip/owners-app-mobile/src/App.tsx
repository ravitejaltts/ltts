import { ActionSheetProvider } from "@expo/react-native-action-sheet";
import React from "react";
import Orientation from "react-native-orientation-locker";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { RootContainerProvider, ThemeProvider } from "./context";
import { RootScreen } from "./screens";

Orientation.lockToPortrait();

const App = () => {
    return (
        <RootContainerProvider>
            <ThemeProvider>
                <SafeAreaProvider>
                    <ActionSheetProvider>
                        <RootScreen />
                    </ActionSheetProvider>
                </SafeAreaProvider>
            </ThemeProvider>
        </RootContainerProvider>
    );
};

export default App;
