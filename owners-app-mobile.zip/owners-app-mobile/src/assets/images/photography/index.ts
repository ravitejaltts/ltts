export const GetStartedRoadImageSource = require("./GetStartedRoad.png");
export const HomeRoadImageSource = require("./HomeRoad.png");
export const LoungingLakesideImageSource = require("./LoungingLakeside.png");
export const MistyRiverImageSource = require("./MistyRiver.png");
export const TranquilRiverImageSource = require("./TranquilRiver.png");
