import AnimatedLottieView from "lottie-react-native";
import React from "react";
import { StyleProp, ViewStyle } from "react-native";
import { useTheme } from "../../context";

// Copied from "lottie-react-native" typescript definition
export interface LottieAnimationObject {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: any[];
    layers: any[];
}

export type LottieViewProps = {
    light: LottieAnimationObject;
    dark: LottieAnimationObject;
    autoPlay?: boolean;
    loop?: boolean;
    style?: StyleProp<ViewStyle>;
};

const LottieView: React.FunctionComponent<LottieViewProps> = ({
    light,
    dark,
    autoPlay,
    loop,
    style,
}) => {
    const [theme] = useTheme();

    return (
        <AnimatedLottieView
            source={theme.name === "light" ? light : dark}
            autoPlay={autoPlay}
            loop={loop}
            style={style}
        />
    );
};

export default LottieView;
