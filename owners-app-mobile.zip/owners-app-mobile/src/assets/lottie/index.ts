import { LottieAnimationObject } from "./LottieView";
export { default as LottieView } from "./LottieView";
export type { LottieViewProps, LottieAnimationObject } from "./LottieView";

const BluetoothConnectingDarkAnimation: LottieAnimationObject = require("./dark/BluetoothConnecting.json");
const BluetoothConnectingLightAnimation: LottieAnimationObject = require("./light/BluetoothConnecting.json");
const BluetoothSearchDarkAnimation: LottieAnimationObject = require("./dark/BluetoothSearch.json");
const BluetoothSearchLightAnimation: LottieAnimationObject = require("./light/BluetoothSearch.json");
const DealerFinderAnimation: LottieAnimationObject = require("./light/DealerFinder.json");
const HowToAnimation: LottieAnimationObject = require("./light/HowTo.json");
const PairingSuccessDarkAnimation: LottieAnimationObject = require("./dark/PairingSuccess.json");
const PairingSuccessLightAnimation: LottieAnimationObject = require("./light/PairingSuccess.json");
const SavedContentAnimation: LottieAnimationObject = require("./light/SavedContent.json");

export {
    BluetoothConnectingDarkAnimation,
    BluetoothConnectingLightAnimation,
    BluetoothSearchDarkAnimation,
    BluetoothSearchLightAnimation,
    DealerFinderAnimation,
    HowToAnimation,
    PairingSuccessDarkAnimation,
    PairingSuccessLightAnimation,
    SavedContentAnimation,
};
