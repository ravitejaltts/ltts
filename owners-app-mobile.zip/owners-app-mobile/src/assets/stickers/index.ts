import AccountCreatedDarkSticker from "./dark/AccountCreated.svg";
import AccountCreatedLightSticker from "./light/AccountCreated.svg";
import AddVehicleDarkSticker from "./dark/AddVehicle.svg";
import AddVehicleLightSticker from "./light/AddVehicle.svg";
import PairingStartDarkSticker from "./dark/PairingStart.svg";
import PairingStartLightSticker from "./light/PairingStart.svg";
import EmailDarkSticker from "./dark/Email.svg";
import EmailLightSticker from "./light/Email.svg";
import EnterVinDarkSticker from "./dark/EnterVin.svg";
import EnterVinLightSticker from "./light/EnterVin.svg";
import ErrorDarkSticker from "./dark/Error.svg";
import ErrorLightSticker from "./light/Error.svg";
import LetterCheckMarkDarkSticker from "./dark/LetterCheckMark.svg";
import LetterCheckMarkLightSticker from "./light/LetterCheckMark.svg";
import LocationDarkSticker from "./dark/Location.svg";
import LocationLightSticker from "./light/Location.svg";
import NotificationDarkSticker from "./dark/Notification.svg";
import NotificationLightSticker from "./light/Notification.svg";
import MountainsSticker from "./light/Mountains.svg";
import PairingInstructionDarkSticker from "./dark/PairingInstruction.svg";
import PairingInstructionLightSticker from "./light/PairingInstruction.svg";
import PasswordUpdateDarkSticker from "./dark/PasswordUpdate.svg";
import PasswordUpdateLightSticker from "./light/PasswordUpdate.svg";
import WinnConnectDarkSticker from "./dark/WinnConnect.svg";
import WinnConnectLightSticker from "./light/WinnConnect.svg";

import { SvgProps } from "react-native-svg";
import { useTheme } from "../../context";

export {
    AccountCreatedDarkSticker,
    AccountCreatedLightSticker,
    AddVehicleDarkSticker,
    AddVehicleLightSticker,
    PairingStartDarkSticker,
    PairingStartLightSticker,
    EmailDarkSticker,
    EmailLightSticker,
    EnterVinDarkSticker,
    EnterVinLightSticker,
    ErrorDarkSticker,
    ErrorLightSticker,
    LetterCheckMarkDarkSticker,
    LetterCheckMarkLightSticker,
    LocationDarkSticker,
    LocationLightSticker,
    NotificationDarkSticker,
    NotificationLightSticker,
    MountainsSticker,
    PairingInstructionDarkSticker,
    PairingInstructionLightSticker,
    PasswordUpdateDarkSticker,
    PasswordUpdateLightSticker,
    WinnConnectDarkSticker,
    WinnConnectLightSticker,
};

export interface StickerProps extends SvgProps {
    light: React.FunctionComponent<SvgProps>;
    dark: React.FunctionComponent<SvgProps>;
}

export const Sticker: React.FunctionComponent<StickerProps> = (props) => {
    const [theme] = useTheme();

    const { light, dark, ...svgProps } = props;

    return theme.name === "light" ? light(svgProps) : dark(svgProps);
};
