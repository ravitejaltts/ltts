import { Theme } from "../../styles";

export function getManualCss(theme: Theme): string {
    return `
    /* Tag Styles */

    body {
        background-color: ${theme.color.background.elevation3.toString()};
        font-family: system-ui;
        margin: 0px;
        padding: 10px 20px 28px 20px;
        color: ${theme.color.text.main.toString()};
    }

    h1 {
        font-size: 28px;
        line-height: 31px;
        margin: 20px 0px 16px 0px;
        padding: 0px;
    }
    
    h2 {
        font-size: 22px;
        letter-spacing: -0.44px;
        margin: 24px 0px 16px 0px;
        padding: 0px;
    }

    h3 {
        font-size: 20px;
        letter-spacing: -0.4px;
        margin: 16px 0px;
        padding: 0px;
    }

    h4 {
        font-size: 17px;
        letter-spacing: -0.34px;
        margin: 8px 0px;
        padding: 0px;
    }
    
    p {
        font-size: 17px;
        line-height: 24px;
        margin: 0px;
        padding: 0px;
    }
    
    ul {
        margin-left: 0px;
        padding-left: 20px;
    }
    
    ul ul {
        margin-left: 0px;
        padding-left: 24px;
    }
        
    ol {
        margin-left: 0px;
        padding-left: 20px;
    }
    
    ol ol {
        margin-left: 0px;
        padding-left: 24px;
    }

    li {
        padding-bottom: 8px;
    }

    table, table tr, table th, table td {
        margin: 0px;
        padding: 0px;
        border: none;
        border-spacing: 0px;
    }

    br {
        display: none;
    }

    svg, .pdf-img {
        background-color: white;
        border-radius: 8px;
        border-width: 1px;
        border-color: ${
            theme.name === "light"
                ? theme.color.dividers.gray1.toString()
                : theme.color.dividers.gray2.toString()
        };
        border-style: solid;
        overflow: hidden;
        width: 100%;
        margin: 16px 0px;
    }

    /* Class Styles */

    .note, .warning, .caution, .danger {
        background-color: ${
            theme.name === "light"
                ? theme.color.background.elevation2.toString()
                : theme.color.background.elevation1.toString()
        };
        border-radius: 8px;
        padding: 20px 20px 24px 20px;
        margin: 12px 0px;
    }

    .note p, .warning p, .caution p, .danger p {
        text-align: left;
    }

    /* Warning Children */
    .note .warning, .warning .warning, .caution .warning, .danger .warning {
        padding: 0px;
        margin: 0px;
    }

    /* Warning- & Caution-Specific */

    .warning h1,
    .caution h1 {
        margin: 0px 0px 20px 0px;
        padding: 0px;
        text-align: left;
        font-size: 20px;
        letter-spacing: -0.4px;
        line-height: unset;
    }

    .warning h1::before,
    .caution h1::before {
        content: url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='-2 -2 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 5.99L19.53 19H4.47L12 5.99ZM12 2L1 21H23L12 2ZM13 16H11V18H13V16ZM13 10H11V14H13V10Z' fill='%23ED0202'/%3E%3C/svg%3E%0A");
        padding: 0px 8px 0px 0px;
        margin: 0px;
    }

    .warning h1::after,
    .caution h1::after {
        color: ${theme.color.error.toString()};
    }

    .warning h1::after {
        content: "Warning";
    }

    .caution h1::after {
        content: "Caution";
    }

    /* Danger Specific */

    .danger .danger {
        margin: 0px;
        padding: 0px;
    }

    .danger h1 {
        margin: 0px 0px 20px 0px;
        padding: 0px;
        text-align: left;
        font-size: 20px;
        letter-spacing: -0.4px;
        line-height: unset;
    }

    .danger h1::before {
        content: url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='-2 -2 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 15H13V17H11V15ZM11 7H13V13H11V7ZM11.99 2C6.47 2 2 6.48 2 12C2 17.52 6.47 22 11.99 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 11.99 2ZM12 20C7.58 20 4 16.42 4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20Z' fill='%23ed0202'/%3E%3C/svg%3E%0A");
        padding: 0px 8px 0px 0px;
        margin: 0px;
    }

    .danger h1::after {
        content: "Caution";
        color: ${theme.color.error.toString()};
    }

    /* Note Specific */
    .note p::before {
        display: block;
        content: "Note";
        font-size: 20;
        font-weight: bold;
        letter-spacing: -0.4px;
        padding-bottom: 20px;
    }

    `.replace(/\n/g, "");
}
