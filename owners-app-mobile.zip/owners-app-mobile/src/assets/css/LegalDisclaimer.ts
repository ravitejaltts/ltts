import { Theme } from "../../styles";

export function getLegalDisclaimerCss(theme: Theme): string {
    return `
    body {
        background-color: ${theme.color.background.settings.toString()};
        font-family: system-ui;
        margin: 0px;
        padding: 20px 20px 20px 20px;
        color: ${theme.color.text.main.toString()};
    }

    .nested-box {
        padding: 5px 20px 5px 20px;
        border-radius: 8px;
        background-color: ${theme.color.background.elevation3.toString()};
    }
    
    #section-title {
        margin-top: 0.5em;
        margin-bottom: 0.5em;
        font-size: 20px;
        font-weight: bold;
        letter-spacing: -0.4px;
    }

    #section-subtitle {
        font-size: 15px;
        margin-top: 0.5em;
    }
    `;
}
