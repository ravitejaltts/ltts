import { Theme } from "../../styles";

export function getDynamicArticleCss(theme: Theme): string {
    return `
    body {
        background-color: ${theme.color.background.elevation3.toString()};
        font-family: system-ui;
        margin: 0px;
        padding: 20px 20px 28px 20px;
        color: ${theme.color.text.main.toString()};
    }

    h1 {
        font-size: 28px;
        line-height: 31px;
        margin: 32px 0px 16px 0px;
        padding: 0px;
    }
    
    h2 {
        font-size: 22px;
        letter-spacing: -0.44px;
        margin: 24px 0px 16px 0px;
        padding: 0px;
    }

    h3 {
        font-size: 20px;
        letter-spacing: -0.4px;
        margin: 16px 0px;
        padding: 0px;
    }

    h4 {
        font-size: 17px;
        letter-spacing: -0.34px;
        margin: 8px 0px;
        padding: 0px;
    }
    
    p {
        font-size: 17px;
        line-height: 24px;
        margin: 0px;
        padding: 8px 0px;
    }
    
    ul {
        margin-left: 0px;
        padding-left: 20px;
    }
    
    ul ul {
        margin-left: 0px;
        padding-left: 24px;
    }
        
    ol {
        margin-left: 0px;
        padding-left: 20px;
    }
    
    ol ol {
        margin-left: 0px;
        padding-left: 24px;
    }

    li {
        padding-bottom: 8px;
    }
    
    img {
        height: 300px !important;
        width: 100% !important;
        object-fit: scale-down; !important
    }

    br {
        display: none;
    }
    `;
}
