import AddIcon from "./Add.svg";
import AddCircleIcon from "./AddCircle.svg";
import AirplaneModeIcon from "./AirplaneMode.svg";
import AppGridIcon from "./AppGrid.svg";
import ArrowDownIcon from "./ArrowDown.svg";
import ArrowUpIcon from "./ArrowUp.svg";
import ArticleIcon from "./Article.svg";
import BackArrowIcon from "./BackArrow.svg";
import BatchPredicationIcon from "./BatchPrediction.svg";
import BatteryIcon from "./Battery.svg";
import BatteryAlertIcon from "./BatteryAlert.svg";
import BatteryChargingIcon from "./BatteryCharging.svg";
import BlackTankIcon from "./BlackTank.svg";
import BluetoothDetailIcon from "./BluetoothDetail.svg";
import BluetoothOffIcon from "./BluetoothOff.svg";
import BluetoothOnIcon from "./BluetoothOn.svg";
import BooksFillIcon from "./BooksFill.svg";
import BooksOutlineIcon from "./BooksOutline.svg";
import BugIcon from "./Bug.svg";
import CalendarIcon from "./Calendar.svg";
import CellularOffIcon from "./CellularOff.svg";
import CellularOnIcon from "./CellularOn.svg";
import CheckCircleIcon from "./CheckCircle.svg";
import CheckMarkIcon from "./CheckMark.svg";
import ChecklistIcon from "./Checklist.svg";
import ChevronDownIcon from "./ChevronDown.svg";
import ChevronLeftIcon from "./ChevronLeft.svg";
import ChevronLeftRoundedIcon from "./ChevronLeftRounded.svg";
import ChevronRightIcon from "./ChevronRight.svg";
import CircularPinFilledIcon from "./CircularPinFilled.svg";
import CleaningServicesIcon from "./CleaningServices.svg";
import ClearFilledIcon from "./ClearFilled.svg";
import ClockIcon from "./Clock.svg";
import CloseIcon from "./Close.svg";
import CloudOffIcon from "./CloudOff.svg";
import CloudOnIcon from "./CloudOn.svg";
import ConstructionIcon from "./Construction.svg";
import CouchIcon from "./Couch.svg";
import DataUsageIcon from "./DataUsage.svg";
import DeleteOutlineIcon from "./DeleteOutline.svg";
import DirectionsIcon from "./Directions.svg";
import DoorLockIcon from "./DoorLock.svg";
import DownloadIcon from "./Download.svg";
import ElectricalServicesIcon from "./ElectricalServices.svg";
import EllipsisIcon from "./Ellipsis.svg";
import EmailIcon from "./Email.svg";
import ErrorFillIcon from "./ErrorFill.svg";
import ErrorOutlineIcon from "./ErrorOutline.svg";
import EyeClosedIcon from "./EyeClosed.svg";
import EyeOpenIcon from "./EyeOpen.svg";
import FeedbackIcon from "./Feedback.svg";
import FilterIcon from "./Filter.svg";
import ForkKnifeIcon from "./ForkKnife.svg";
import ForwardArrowIcon from "./ForwardArrow.svg";
import FrameChassisIcon from "./FrameChassis.svg";
import FurnaceIcon from "./Furnace.svg";
import GearIcon from "./Gear.svg";
import GearOutlineIcon from "./GearOutline.svg";
import GeneratorIcon from "./Generator.svg";
import GeneratorToastIcon from "./GeneratorToast.svg";
import GridViewIcon from "./GridView.svg";
import HeadsetIcon from "./Headset.svg";
import HeartIcon from "./Heart.svg";
import HeartBrokenIcon from "./HeartBroken.svg";
import HeartOutlineIcon from "./HeartOutline.svg";
import HikerIcon from "./Hiker.svg";
import HistoryIcon from "./History.svg";
import HomeFillIcon from "./HomeFill.svg";
import HomeOutlineIcon from "./HomeOutline.svg";
import InfoOutlineIcon from "./InfoOutline.svg";
import InverterIcon from "./Inverter.svg";
import LaunchIcon from "./Launch.svg";
import LeftTriangleIcon from "./LeftTriangle.svg";
import LightBulbIcon from "./LightBulb.svg";
import LightningIcon from "./Lightning.svg";
import LightningStrikethroughIcon from "./LightningStrikethrough.svg";
import ListIcon from "./List.svg";
import LocationPinIcon from "./LocationPin.svg";
import LockedIcon from "./Locked.svg";
import LogoIcon from "./Logo.svg";
import MagnifyingGlassIcon from "./MagnifyingGlass.svg";
import MarkerIcon from "./Marker.svg";
import MenuIcon from "./Menu.svg";
import MicrowaveIcon from "./Microwave.svg";
import MiscellaneousIcon from "./Miscellaneous.svg";
import MoonIcon from "./Moon.svg";
import NearMeIcon from "./NearMe.svg";
import NearMeDisabledIcon from "./NearMeDisabled.svg";
import NotificationFillIcon from "./NotificationFill.svg";
import NotificationOutlineIcon from "./NotificationOutline.svg";
import OpenAwningIcon from "./OpenAwning.svg";
import OpenSlideOutIcon from "./OpenSlideOut.svg";
import OutletIcon from "./Outlet.svg";
import PaintRollerIcon from "./PaintRoller.svg";
import PawIcon from "./Paw.svg";
import PhoneIcon from "./Phone.svg";
import PhoneCheckmarkIcon from "./PhoneCheckmark.svg";
import PhoneSignalIcon from "./PhoneSignal.svg";
import PinIcon from "./Pin.svg";
import PlayArrowIcon from "./PlayArrow.svg";
import PlayCircleFilledIcon from "./PlayCircleFilled.svg";
import PlumbingIcon from "./Plumbing.svg";
import PowerSettingsIcon from "./PowerSettings.svg";
import ProfileFillIcon from "./ProfileFill.svg";
import ProfileOutlineIcon from "./ProfileOutline.svg";
import PropaneTankIcon from "./PropaneTank.svg";
import PropaneTankFilledIcon from "./PropaneTankFilled.svg";
import QuestionMarkCircleIcon from "./QuestionMarkCircle.svg";
import RangeTopIcon from "./RangeTop.svg";
import RefreshIcon from "./Refresh.svg";
import RefrigeratorFilledIcon from "./RefrigeratorFilled.svg";
import RefrigeratorOutlineIcon from "./RefrigeratorOutline.svg";
import RemoveCircleOutlineIcon from "./RemoveCircleOutline.svg";
import ReportIcon from "./Report.svg";
import RoofVentIcon from "./RoofVent.svg";
import RoundedCornerBracketIcon from "./RoundedCornerBracket.svg";
import RvFillIcon from "./RvFill.svg";
import RvOutlineIcon from "./RvOutline.svg";
import SavedContentIcon from "./SavedContent.svg";
import SealantsIcon from "./Sealants.svg";
import ServiceFillIcon from "./ServiceFill.svg";
import ServiceOutlineIcon from "./ServiceOutline.svg";
import ShieldCheckIcon from "./ShieldCheck.svg";
import ShieldInfoIcon from "./ShieldInfo.svg";
import ShowerHeadIcon from "./ShowerHead.svg";
import ShuttleIcon from "./Shuttle.svg";
import SignOutIcon from "./SignOut.svg";
import SignalTowerIcon from "./SignalTower.svg";
import SlideoutIcon from "./Slideout.svg";
import SmartPhoneIcon from "./SmartPhone.svg";
import SnowFlakeIcon from "./SnowFlake.svg";
import SolarIcon from "./Solar.svg";
import SolarGridIcon from "./SolarGrid.svg";
import SpeedIcon from "./Speed.svg";
import SubtractIcon from "./Subtract.svg";
import SunIcon from "./Sun.svg";
import SupportIcon from "./Support.svg";
import TabletIcon from "./Tablet.svg";
import TankHeatingPadIcon from "./TankHeatingPad.svg";
import TapasIcon from "./Tapas.svg";
import TerrainIcon from "./Terrain.svg";
import TextMessageIcon from "./TextMessage.svg";
import ThemeIcon from "./Theme.svg";
import ThermostatAutoIcon from "./ThermostatAuto.svg";
import ThermostatFanIcon from "./ThermostatFan.svg";
import ThermostatHeatIcon from "./ThermostatHeat.svg";
import ThermostatSystemIcon from "./ThermostatSystem.svg";
import TimelapseIcon from "./Timelapse.svg";
import TireIcon from "./Tire.svg";
import ToolsIcon from "./Tools.svg";
import TrailerIcon from "./Trailer.svg";
import TvIcon from "./Tv.svg";
import UnlockedIcon from "./Unlocked.svg";
import VanIcon from "./Van.svg";
import WLogoIcon from "./WLogo.svg";
import WLogoFillIcon from "./WLogoFill.svg";
import WLogoOutlineIcon from "./WLogoOutline.svg";
import WarningFillIcon from "./WarningFill.svg";
import WarningOutlineIcon from "./WarningOutline.svg";
import WasteIcon from "./Waste.svg";
import WaterDropIcon from "./WaterDrop.svg";
import WaterDropArrowUpIcon from "./WaterDropArrowUp.svg";
import WaterHeaterIcon from "./WaterHeater.svg";
import WifiOffIcon from "./WifiOff.svg";
import WifiOnIcon from "./WifiOn.svg";
import WrenchFillIcon from "./WrenchFill.svg";
import WrenchOutlineIcon from "./WrenchOutline.svg";

export {
    AddCircleIcon,
    AddIcon,
    AirplaneModeIcon,
    AppGridIcon,
    ArrowDownIcon,
    ArrowUpIcon,
    ArticleIcon,
    BackArrowIcon,
    BatchPredicationIcon,
    BatteryAlertIcon,
    BatteryChargingIcon,
    BatteryIcon,
    BlackTankIcon,
    BluetoothDetailIcon,
    BluetoothOffIcon,
    BluetoothOnIcon,
    BooksFillIcon,
    BooksOutlineIcon,
    BugIcon,
    CalendarIcon,
    CellularOffIcon,
    CellularOnIcon,
    CheckCircleIcon,
    CheckMarkIcon,
    ChecklistIcon,
    ChevronDownIcon,
    ChevronLeftIcon,
    ChevronLeftRoundedIcon,
    ChevronRightIcon,
    CircularPinFilledIcon,
    CleaningServicesIcon,
    ClearFilledIcon,
    ClockIcon,
    CloseIcon,
    CloudOffIcon,
    CloudOnIcon,
    ConstructionIcon,
    CouchIcon,
    DataUsageIcon,
    DeleteOutlineIcon,
    DirectionsIcon,
    DoorLockIcon,
    DownloadIcon,
    ElectricalServicesIcon,
    EllipsisIcon,
    EmailIcon,
    ErrorFillIcon,
    ErrorOutlineIcon,
    EyeClosedIcon,
    EyeOpenIcon,
    FeedbackIcon,
    FilterIcon,
    ForkKnifeIcon,
    ForwardArrowIcon,
    FrameChassisIcon,
    FurnaceIcon,
    GearIcon,
    GearOutlineIcon,
    GeneratorIcon,
    GeneratorToastIcon,
    GridViewIcon,
    HeadsetIcon,
    HeartBrokenIcon,
    HeartIcon,
    HeartOutlineIcon,
    HikerIcon,
    HistoryIcon,
    HomeFillIcon,
    HomeOutlineIcon,
    InfoOutlineIcon,
    InverterIcon,
    LaunchIcon,
    LeftTriangleIcon,
    LightBulbIcon,
    LightningIcon,
    LightningStrikethroughIcon,
    ListIcon,
    LocationPinIcon,
    LockedIcon,
    LogoIcon,
    MagnifyingGlassIcon,
    MarkerIcon,
    MenuIcon,
    MicrowaveIcon,
    MiscellaneousIcon,
    MoonIcon,
    NearMeDisabledIcon,
    NearMeIcon,
    NotificationFillIcon,
    NotificationOutlineIcon,
    OpenAwningIcon,
    OpenSlideOutIcon,
    OutletIcon,
    PaintRollerIcon,
    PawIcon,
    PhoneCheckmarkIcon,
    PhoneIcon,
    PhoneSignalIcon,
    PinIcon,
    PlayArrowIcon,
    PlayCircleFilledIcon,
    PlumbingIcon,
    PowerSettingsIcon,
    ProfileFillIcon,
    ProfileOutlineIcon,
    PropaneTankFilledIcon,
    PropaneTankIcon,
    QuestionMarkCircleIcon,
    RangeTopIcon,
    RefreshIcon,
    RefrigeratorFilledIcon,
    RefrigeratorOutlineIcon,
    RemoveCircleOutlineIcon,
    ReportIcon,
    RoofVentIcon,
    RoundedCornerBracketIcon,
    RvFillIcon,
    RvOutlineIcon,
    SavedContentIcon,
    SealantsIcon,
    ServiceFillIcon,
    ServiceOutlineIcon,
    ShieldCheckIcon,
    ShieldInfoIcon,
    ShowerHeadIcon,
    ShuttleIcon,
    SignOutIcon,
    SignalTowerIcon,
    SlideoutIcon,
    SmartPhoneIcon,
    SnowFlakeIcon,
    SolarGridIcon,
    SolarIcon,
    SpeedIcon,
    SubtractIcon,
    SunIcon,
    SupportIcon,
    TabletIcon,
    TankHeatingPadIcon,
    TapasIcon,
    TerrainIcon,
    TextMessageIcon,
    ThemeIcon,
    ThermostatAutoIcon,
    ThermostatFanIcon,
    ThermostatHeatIcon,
    ThermostatSystemIcon,
    TimelapseIcon,
    TireIcon,
    ToolsIcon,
    TrailerIcon,
    TvIcon,
    UnlockedIcon,
    VanIcon,
    WLogoFillIcon,
    WLogoIcon,
    WLogoOutlineIcon,
    WarningFillIcon,
    WarningOutlineIcon,
    WasteIcon,
    WaterDropArrowUpIcon,
    WaterDropIcon,
    WaterHeaterIcon,
    WifiOffIcon,
    WifiOnIcon,
    WrenchFillIcon,
    WrenchOutlineIcon,
};
