export const TroubleshootingHtml = `
<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <title>Troubleshooting</title>
</head>
<body>
    <h1>Lorem Ipsum Dolor</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu metus risus. Etiam ex sem, ultrices a condimentum id, posuere vitae ex. Suspendisse ut neque lorem. Suspendisse eu finibus est:</p>

    <ul>
        <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
        <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
    </ul>

    <h1>Lorem Ipsum Dolor</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu metus risus. Etiam ex sem, ultrices a condimentum id, posuere vitae ex. Suspendisse ut neque lorem. Suspendisse eu finibus est. Aenean vestibulum metus metus, sit amet dictum libero euismod vel. Donec vitae bibendum magna. Integer eu vulputate lorem. Aenean sed porta metus.</p>

    <h1>Lorem Ipsum Dolor</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu metus risus. Etiam ex sem, ultrices a condimentum id, posuere vitae ex.</p>
</body>
</html>
`;
