export function generateHtml(body: string) {
    return `
        <!DOCTYPE html>\n
        <html>
        <head>
            <meta http-equiv="content-type" content="text/html; charset=utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        </head>
        <body>
            ${body}
        </body>
        </html>
    `;
}
