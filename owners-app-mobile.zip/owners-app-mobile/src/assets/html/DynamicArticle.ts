export const DYNAMIC_ARTICLE_HTML = `
<p>
    Hitting the road with your kids or grandkids sounds like a great adventure
    and an amazing family trip. Then you start looking at the logistics and
    realize that RVs aren't really made for kids' car seats.
</p>

<p>
    Sure, back in the day, kids would just run around the RV and climb up on
    the beds and basically play while their parents or grandparents drove down
    the road. In this day and age, that is not what people do. There are many
    more people on the roads now. And with so much access to online media, you
    constantly see images of the bad things that can happen.
</p>

<p>
    Don't worry, there is a solution -- or at least a way that we have figured
    out to make it work.
</p>

<p>
    <em
    >Please note: I am not a professional and nothing I share here has been
    approved by anyone official. This is just our journey through coming up
    with a solution, so we can travel full time with our young kids in a
    motorhome (not a truck and trailer).</em
    >
</p>

<p>
    <img
    alt="Four kids buckled in along the couch."
    class="size-full wp-image-6273 aligncenter"
    src="https://qa2.winnebago.com/Admin/Public/GetImage.ashx?Image=/files/images/winnebago/lifestyle/golife2/2017/06/Photo01.jpg&Width=99999&Height=99999"
    style="width: 1024px; height: 768px"
    />
</p>

<p><strong>The Motorhome</strong></p>

<p>
    Prior to purchasing any of our motorhomes, one of the main criteria was
    that it had to come with enough seat belts for our whole family. In our
    case, that meant six. Yes, there are aftermarket ways you can get them
    installed. But we didn't want to deal with the hassle and felt much better
    going with a motorhome that had factory installed seat belts.
</p>

<p>
    Take note: Just because a motorhome has a booth in it DOES NOT mean that
    there are four seat belts. There are times when a water tank is located
    under a seat or the manufacturer did not add a seat belt to each seat at
    the booth for another reason.
</p>

<p>
    We originally had a large, 39-foot diesel pusher motorhome. In this case,
    we were one of the largest vehicles on the road, so we were okay with the
    kids' car seats sitting on the sideways facing couch -- as long as all the
    car seats could be buckled into a lap belt.
</p>

<p>
    We also made sure that each kid had a five-point harness car seat -- even
    our then 8-year-old, who we had to find a special car seat for that could
    hold his weight (they are out there!). The lap belt held the car seat in
    place, and the five-point harness held the kid in place.
</p>

<p>
    Is a lap belt the best bet for installing a car seat? No. Would we rather
    have a shoulder-strap car seat? Yes. Are there RVs with seats in the back
    with shoulder belts? No. This was our only option.
</p>

<p>
    When we decided to downsize to a smaller rig -- a Class C, 23-foot
    Winnebago View -- we decided that we were no longer comfortable with the
    sideways facing couch, but instead wanted a table setup. This way two kids
    could face backward and two forward.
</p>

<p><strong>Choosing the car seat over a harness</strong></p>

<p>
    When we downsized to the Class C, we thought about adding in a harness
    seat belt -- similar to a race car driver's seat belt. We went down this
    path and talked to one of the owners of a company that sells this kind of
    seat belt for people looking for an option other than a car seat.
</p>

<p>
    He actually talked us out of buying his product and instead recommended we
    stick with the five-point harness car seats and the lap belt. After being
    a firefighter for many years, he saw a lot of reasons for car seat
    failure.
</p>

<p>Here were his reasons:</p>

<p>
    1. You don't want to tether a belt down to the floor when it doesn't have
    the solid support of a car bucket seat behind it. He said it could have a
    negative impact if it were only connected with an RV bench seat (which is
    made of wood) behind it. The reason being, it could put added pressure on
    the child, since the seat is not strong enough.
</p>

<p>
    2. Five-point harness car seats are safety tested with only a lap belt.
</p>

<p>
    3. The majority of automobile accidents occur in residential areas. The
    fact that the RV was a larger vehicle on the road meant that it was more
    likely for someone to see it coming and in turn, less likely to get into
    an accident.
</p>

<p>
    4. In a head-on collision or a rear-end accident that the kids being in a
    five-point harness in a forward or rear facing seat were going to be
    almost as safe as in a car with shoulder belts and tethers. Maybe even
    more so, since the RV is larger.
</p>

<p>
    5. If you are in an accident on the highway -- no matter what you are
    driving -- the main goal is staying in the vehicle and not being thrown
    from it, he explained. With a five-point harness seat and a seat belt, you
    should be secure in the vehicle.
</p>

<p>
    <strong
    >What about a child who is too big for a five-point harness car
    seat?</strong
    >
</p>

<p>
    Our oldest is now too heavy for his car seat -- granted he is on the
    larger end of the scale, so your 9-year-old may still be within the range
    of a five-point harness car seat. This left us with a dilemma to figure
    out where he could sit.
</p>

<p>
    After talking with the same gentleman mentioned above, we made the
    decision that our 9-year-old would ride in the front passenger seat. This
    meant he would have a shoulder belt. I (the Mom) would ride in the back at
    the booth with the kids with just a lap belt.
</p>

<p>
    The reasoning for this is the more developed your pelvis area is, the
    safer it is with just a lap belt. Plus, I am taller than him, so the lap
    belt hits my body at a better place than his.
</p>

<p>
    Is any of this the perfect solution? No. Can we hope RV manufacturers will
    start to seriously look at car seat safety in RVs and design models with
    this in mind? For sure! But for the time being, this situation is working
    for us and we feel comfortable with our kids riding in the RV in their
    five-point harness car seat if:
</p>

<p>
    1. In a large motorhome, they have a lap belt holding the five-point
    harness car seat down.
</p>

<p>
    2. In a smaller Class C, they are forward or backward facing with a lap
    belt holding the five-point harness car seat down.
</p>

<p>
    3. They meet the weight and height restrictions of the five-point harness
    car seat.
</p>

<p>
    4. We drive carefully and cautiously on the road and stay at 65 mph or
    under.
</p>

<p>
    Here is a video of us putting the car seats into the Class A motorhome (it
    starts at 42 seconds):
    <a
    href="https://youtu.be/dGe4BXu9LYk"
    rel="noopener noreferrer"
    target="_blank"
    >https://youtu.be/dGe4BXu9LYk</a
    >
</p>

<p>
    For more information about the five-point harness car seat that we have
    for our kids,
    <a
    href="https://www.amazon.com/Britax-Frontier-Clicktight-Combination-Harness-2-Booster/dp/B00OTXUO2S?th=1"
    rel="noopener noreferrer"
    target="_blank"
    >click here</a
    >. Be sure to read about the weight. This one is good in harness mode up
    to 90 pounds and 58 inches in height. It goes higher in booster mode, when
    the seat belt is used.
</p>
`;
