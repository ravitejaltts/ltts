export const legalDisclaimerPlaceholderHtml = `
<p id="section-title">Heading</p>

<p id="section-subtitle">Effective March 31, 2020</p>

<div class="nested-box">
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean suscipit felis nisi. 
        Proin gravida turpis et efficitur tincidunt. Nulla imperdiet accumsan urna, ac tristique tortor iaculis non. 
        Pellentesque nec iaculis diam. Integer vel convallis ipsum.
    </p>
</div>

<p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean suscipit felis nisi. 
    Proin gravida turpis et efficitur tincidunt. Nulla imperdiet accumsan urna, ac tristique tortor iaculis non. 
    Pellentesque nec iaculis diam. Integer vel convallis ipsum. 
    Pellentesque lacinia aliquet nulla eu facilisis. Donec et vestibulum tortor, nec vulputate ante.
</p>

<p>
    Praesent quis leo eget nisi tempor luctus eget vel turpis. 
    Vivamus varius ipsum non mauris malesuada, eu tempus nisi maximus. Aenean rhoncus dui in volutpat commodo. 
    Aliquam nulla quam, accumsan at egestas sed, pulvinar in arcu. Donec venenatis, arcu in viverra dictum, risus nisi euismod felis, non porttitor velit nulla nec turpis. 
    Etiam finibus hendrerit imperdiet. Sed efficitur arcu ipsum, vel consectetur dolor suscipit at. Curabitur nisi sem, bibendum ac aliquam eget, pulvinar sed purus. 
    Etiam fermentum dui in rutrum sodales.
</p>
`;
