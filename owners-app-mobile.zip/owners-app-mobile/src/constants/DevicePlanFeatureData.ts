import {
    ChecklistIcon,
    GearOutlineIcon,
    PhoneSignalIcon,
} from "../assets/icons";
import { DevicePlanFeatureCardProps } from "../components/device";

export const getDevicePlanFeatureData = (
    cardWidth: number
): DevicePlanFeatureCardProps[] => {
    return [
        {
            title: "Take Control from Anywhere",
            body: "Monitor your RV remotely, receive maintenance alerts, stay informed about local weather, and keep your pets comfortable when you're away.",
            icon: PhoneSignalIcon,
            width: cardWidth,
        },
        {
            title: "Keep Your RV in Top Shape",
            body: "Get automatic software updates, access remote diagnostics, and receive monthly health reports for optimal performance.",
            icon: GearOutlineIcon,
            width: cardWidth,
        },
        {
            title: "Get Ready & Roll with Ease",
            body: "Seamlessly enter the world of RV ownership with tutorials and helpful setup instructions.",
            icon: ChecklistIcon,
            width: cardWidth,
        },
    ];
};
