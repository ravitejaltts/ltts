import { VehicleClassType } from "../models/domain/vehicle/VehicleClass";
import VehicleDetails from "../models/domain/vehicle/VehicleDetails";

const VEHICLE_DATA: VehicleDetails[] = [
    // REVEL
    {
        vehicleId: 40407,
        classId: 1,
        className: "Class A",
        classType: VehicleClassType.Motorhome,
        classCode: "A",
        seriesId: 12,
        seriesName: "REVEL",
        seriesDescription: "REVEL",
        seriesCode: "B",
        modelId: 772,
        modelYear: 2020,
        floorPlan: "BMB44E",
        revision: 1,
        serialNumber: "19239",
        serialNumberLong: "1923919239",
        vehicleIdentification: "12345678901234567",
        interiorColorCode: "K1B",
        interiorColor: "GRAVITY/GRAY/SILVER SPRINGS",
        exteriorColorCode: "33C",
        exteriorColor: "BLUE GREY",
        fuelType: "DIESEL",
        fuelAmount: 20,
        hasContentAvailable: true,
        hasWinnConnect: false,
    },
    // JOURNEY
    {
        vehicleId: 3684,
        classId: 0,
        className: "Class A",
        classType: VehicleClassType.Motorhome,
        classCode: "A",
        seriesId: 24,
        seriesName: "JOURNEY",
        seriesDescription: "JOURNEY",
        seriesCode: "P",
        modelId: 424,
        modelYear: 2019,
        floorPlan: "WKP40A",
        revision: 1,
        serialNumber: "51064",
        serialNumberLong: "5106451064",
        vehicleIdentification: "ABC1234567890WXYZ",
        interiorColorCode: "JPH",
        interiorColor: "HEMATITE/STONE/BRIAR W/GUNME",
        exteriorColorCode: "95K",
        exteriorColor: "LAVA GRAY",
        fuelType: "DIESEL",
        fuelAmount: 80,
        hasContentAvailable: true,
        hasWinnConnect: true,
    },
    // ERV2
    {
        // ID
        vehicleId: 144413,

        // Class
        classId: 2,
        className: "Camper Van",
        classType: VehicleClassType.Motorhome,
        classCode: "B",

        // Series
        seriesId: 9,
        seriesName: "PASEO",
        seriesDescription: "ERV2",
        seriesCode: "8",

        // Model
        modelId: 1915,
        modelYear: 2024,
        floorPlan: "BF848EC",
        revision: 2,

        // Serial/VIN
        serialNumber: "22348",
        serialNumberLong: "2234822348",
        vehicleIdentification: "11111111111111111", // 1FTBW1XK4NKA12930

        // Interior/Exterior
        interiorColorCode: "R8E",
        interiorColor: "CHAKRA/AQUA/NATURAL BAMBOO",
        exteriorColorCode: "33C",
        exteriorColor: "INGOT SILVER",

        // Fuel
        fuelType: null,
        fuelAmount: 20,

        // Flags
        hasContentAvailable: true,
        hasWinnConnect: true,
    },
    // WM524T
    {
        // ID
        vehicleId: 379437,

        // Class
        classId: 3,
        className: "Class C",
        classType: VehicleClassType.Motorhome,
        classCode: "C",

        // Series
        seriesId: 6,
        seriesName: "NAVION,VIEW",
        seriesDescription: "VIEW",
        seriesCode: "5",

        // Model
        modelId: 4728,
        modelYear: 2024,
        floorPlan: "WM524T",
        revision: 2,

        // Serial/VIN
        serialNumber: "75000",
        serialNumberLong: "7500075000",
        vehicleIdentification: "00000000000000000", // W1X8E33Y3NN201781

        // Interior/Exterior
        interiorColorCode: "R51",
        interiorColor: "MOD ALLURE/TAUPE/GRAU PACWHT",
        exteriorColorCode: "95F",
        exteriorColor: "GLACIER II",

        // Fuel
        fuelType: "DIESEL",
        fuelAmount: 20,

        // Flags
        hasContentAvailable: true,
        hasWinnConnect: true,
    },
];

export function getVehicleDetailsByVin(vin: string) {
    return VEHICLE_DATA.find((v) => v.vehicleIdentification === vin);
}

export function getVehicleDetailsById(
    vehicleId: number
): VehicleDetails | undefined {
    return VEHICLE_DATA.find((v) => v.vehicleId === vehicleId);
}
