import { ModelDetails } from "../models/domain/vehicle/ModelDetails";
import {
    VehicleClass,
    VehicleClassType,
} from "../models/domain/vehicle/VehicleClass";
import { VehicleSeries } from "../models/domain/vehicle/VehicleSeries";

type ClassData = {
    name: string;
    type: VehicleClassType;
    series: {
        name: string;
        description: string;
    }[];
};

const SEED_DATA: ClassData[] = [
    {
        name: "Class A",
        type: VehicleClassType.Motorhome,
        series: [
            {
                name: "Journey",
                description: "Journey",
            },
            {
                name: "Forza",
                description: "Forza",
            },
        ],
    },
    {
        name: "Camper Van",
        type: VehicleClassType.Motorhome,
        series: [
            {
                name: "Solis Pocket",
                description: "Solis Pocket",
            },
            {
                name: "Revel",
                description: "Revel",
            },
        ],
    },
    {
        name: "Class C",
        type: VehicleClassType.Motorhome,
        series: [
            {
                name: "EKKO",
                description: "EKKO",
            },
            {
                name: "Minnie Winnie",
                description: "Minnie Winnie",
            },
            {
                name: "VIEW/NAVION",
                description: "VIEW",
            },
            {
                name: "VIEW/NAVION",
                description: "NAVION",
            },
        ],
    },
    {
        name: "Travel Trailer",
        type: VehicleClassType.Towable,
        series: [
            {
                name: "HIKE",
                description: "HIKE",
            },
            {
                name: "HIKE",
                description: "HIKE 100",
            },
            {
                name: "Micro Minie",
                description: "Micro Minie",
            },
        ],
    },
    {
        name: "Fifth Wheel",
        type: VehicleClassType.Towable,
        series: [
            {
                name: "Voyage",
                description: "Voyage",
            },
        ],
    },
];

type Series = VehicleSeries & {
    classId: number;
};

const CLASSES: VehicleClass[] = [];
const SERIES: Series[] = [];
const MODELS: ModelDetails[] = [];

generateData();

function generateData() {
    let modelId = 1;
    let seriesId = 1;
    const letters = "ABCDE";

    // Iterate through all classes
    for (let classIndex = 0; classIndex < SEED_DATA.length; classIndex++) {
        const classId = classIndex + 1;
        const classData = SEED_DATA[classIndex];

        const vehicleClass: VehicleClass = {
            classId: classId,
            name: classData.name,
            type: classData.type,
        };

        CLASSES.push(vehicleClass);

        // Iterate through all series in a class
        for (const seriesData of classData.series) {
            let loopSeriesId: number;

            // Check if we've already added a series of the same name
            const exisitngSeries = SERIES.find(
                (s) => s.name === seriesData.name
            );

            if (exisitngSeries) {
                // There is an existing series of the same name, re-use the ID
                loopSeriesId = exisitngSeries.seriesId;
            } else if (SERIES.length > 0) {
                // Next series
                seriesId++;
                loopSeriesId = seriesId;
            } else {
                // First series in iteration
                loopSeriesId = seriesId;
            }

            const vehicleSeries: Series = {
                seriesId: loopSeriesId,
                classId: classId,
                name: seriesData.name,
                description: seriesData.description,
            };

            SERIES.push(vehicleSeries);

            for (let modelYear = 2002; modelYear < 2023; modelYear++) {
                for (
                    let floorPlanIndex = 0;
                    floorPlanIndex < 5;
                    floorPlanIndex++
                ) {
                    const prefix = seriesData.description
                        .substring(0, 3)
                        .toUpperCase();
                    const year = modelYear.toString().substring(2);
                    const suffix = letters[floorPlanIndex];

                    const floorPlan = `${prefix}${year}${suffix}`;

                    const modelDetails: ModelDetails = {
                        modelId: modelId,
                        modelCode: modelId.toString(),
                        classId: classId,
                        className: classData.name,
                        classType: classData.type,
                        classCode: classId.toString(),
                        seriesId: loopSeriesId,
                        seriesName: seriesData.name,
                        seriesDescription: seriesData.description,
                        seriesCode: loopSeriesId.toString(),
                        floorPlan: floorPlan,
                        modelYear: modelYear,
                        revision: 0,
                        hasContentAvailable: true,
                    };

                    MODELS.push(modelDetails);
                    modelId++;
                }
            }
        }
    }
}

export function getAllClasses(): VehicleClass[] {
    return CLASSES;
}

export function getSeriesIdByName(seriesName: string): number {
    return SERIES.find((s) => s.name === seriesName)?.seriesId ?? 0;
}

export function getSeriesByClass(classId: number) {
    return SERIES.filter((s) => s.classId === classId);
}

export function getModels(classId: number, seriesDescription: string) {
    return MODELS.filter(
        (m) =>
            m.classId === classId && m.seriesDescription === seriesDescription
    );
}

export function getModelDetails(
    seriesId: number,
    modelYear: number,
    floorPlan: string
) {
    return MODELS.find(
        (m) =>
            m.seriesId === seriesId &&
            m.modelYear === modelYear &&
            m.floorPlan === floorPlan
    );
}

export function getModelDetailsBySeriesDescription(
    seriesDescription: string,
    modelYear: number,
    floorPlan: string
) {
    return MODELS.find(
        (m) =>
            m.seriesDescription === seriesDescription &&
            m.modelYear === modelYear &&
            m.floorPlan === floorPlan
    );
}

export function getModelById(modelId: number) {
    return MODELS.find((m) => m.modelId === modelId);
}
