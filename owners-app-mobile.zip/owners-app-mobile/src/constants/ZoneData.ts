import { SvgProps } from "react-native-svg";
import {
    BatchPredicationIcon,
    ConstructionIcon,
    CouchIcon,
    DirectionsIcon,
    ElectricalServicesIcon,
    EllipsisIcon,
    MicrowaveIcon,
    PlumbingIcon,
    SnowFlakeIcon,
    SupportIcon,
    TapasIcon,
    WLogoIcon,
} from "../assets/icons";
import { ContentZone } from "../models/domain/content";

type ZoneData = {
    name: string;
    description: string;
    icon: React.FunctionComponent<SvgProps>;
};

const ZONE_DATA = new Map<string, ZoneData>([
    [
        ContentZone.Introduction,
        {
            name: "Introduction",
            description: "An introduction to your RV.",
            icon: WLogoIcon,
        },
    ],
    [
        ContentZone.SafetyPrecautions,
        {
            name: "Safety Precautions",
            description: "",
            icon: SupportIcon,
        },
    ],
    [
        ContentZone.DrivingYourVehicle,
        {
            name: "Driving Your Vehicle",
            description: "",
            icon: DirectionsIcon,
        },
    ],
    [
        ContentZone.Recommendations,
        {
            name: "Recommendations",
            description: "",
            icon: TapasIcon,
        },
    ],
    [
        ContentZone.AppliancesAndSystems,
        {
            name: "Appliances and Systems",
            description: "",
            icon: MicrowaveIcon,
        },
    ],
    [
        ContentZone.Propane,
        {
            name: "Propane",
            description: "",
            icon: WLogoIcon,
        },
    ],
    [
        ContentZone.Electrical,
        {
            name: "Electrical",
            description:
                "Understanding and operating your RV's electrical systems.",
            icon: ElectricalServicesIcon,
        },
    ],
    [
        ContentZone.Plumbing,
        {
            name: "Plumbing",
            description:
                "A how-to guide fro using your RV's water system and components.",
            icon: PlumbingIcon,
        },
    ],
    [
        ContentZone.Entertainment,
        {
            name: "Entertainment",
            description: "",
            icon: WLogoIcon,
        },
    ],
    [
        ContentZone.FurnitureAndSoftGoods,
        {
            name: "Furniture and Soft Goods",
            description: "",
            icon: CouchIcon,
        },
    ],
    [
        ContentZone.SlideoutRoom,
        {
            name: "Slideout Room",
            description: "",
            icon: WLogoIcon,
        },
    ],
    [
        ContentZone.MaintenanceAndStorage,
        {
            name: "Maintenance and Storage",
            description: "",
            icon: ConstructionIcon,
        },
    ],
    [
        ContentZone.Miscellaneous,
        {
            name: "Miscellaneous",
            description: "",
            icon: EllipsisIcon,
        },
    ],
    [
        ContentZone.WinnebagoConnect,
        {
            name: "Winnebago Connect™",
            description: "",
            icon: WLogoIcon,
        },
    ],
    // Everything below is not in the list given by content team. Keeping here for visibility.
    [
        ContentZone.HeatingAndCooling,
        {
            name: "Heating and Cooling",
            description: "How to control your RV's climate.",
            icon: SnowFlakeIcon,
        },
    ],
    [
        ContentZone.TravelTips,
        {
            name: "Travel Tips",
            description: "Quick reference checklist and travel advice.",
            icon: TapasIcon,
        },
    ],
    [
        ContentZone.BasicOperations,
        {
            name: "Basic Operations",
            description:
                "Understanding and operating basic features of your RV.",
            icon: BatchPredicationIcon,
        },
    ],
]);

export function getName(id: string) {
    return ZONE_DATA.get(id)?.name ?? id;
}

export function getDescription(id: string) {
    return ZONE_DATA.get(id)?.description ?? "";
}

export function getIcon(id: string): React.FunctionComponent<SvgProps> {
    return ZONE_DATA.get(id)?.icon ?? WLogoIcon;
}
