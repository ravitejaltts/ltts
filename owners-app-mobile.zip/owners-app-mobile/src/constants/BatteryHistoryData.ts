export const batteryHistoryData = [
    [
        {
            value: 25,
            timestamp: "12 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "1 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "2 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "3 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "4 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "5 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "6 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "7 AM",
            isCharging: false,
        },
        {
            value: 80,
            timestamp: "8 AM",
            isCharging: false,
        },
        {
            value: 85,
            timestamp: "9 AM",
            isCharging: true,
        },
        {
            value: 90,
            timestamp: "10 AM",
            isCharging: true,
        },
        {
            value: 95,
            timestamp: "11 AM",
            isCharging: true,
        },
        {
            value: 100,
            timestamp: "12 PM",
            isCharging: false,
        },
        {
            value: 95,
            timestamp: "1 PM",
            isCharging: false,
        },
        {
            value: 100,
            timestamp: "2 PM",
            isCharging: false,
        },
        {
            value: 100,
            timestamp: "3 PM",
            isCharging: false,
        },
        {
            value: 95,
            timestamp: "4 PM",
            isCharging: false,
        },
        {
            value: 90,
            timestamp: "5 PM",
            isCharging: false,
        },
        {
            value: 80,
            timestamp: "6 PM",
            isCharging: false,
        },
        {
            value: 50,
            timestamp: "7 PM",
            isCharging: false,
        },
        {
            value: 60,
            timestamp: "8 PM",
            isCharging: true,
        },
        {
            value: 70,
            timestamp: "9 PM",
            isCharging: true,
        },
        {
            value: 80,
            timestamp: "10 PM",
            isCharging: true,
        },
        {
            value: 30,
            timestamp: "11 PM",
            isCharging: false,
        },
        {
            value: 5,
            timestamp: "12 PM",
            isCharging: false,
        },
    ],
    [
        {
            value: 25,
            timestamp: "12 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "1 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "2 AM",
            isCharging: true,
        },
        {
            value: 35,
            timestamp: "3 AM",
            isCharging: true,
        },
        {
            value: 45,
            timestamp: "4 AM",
            isCharging: true,
        },
        {
            value: 55,
            timestamp: "5 AM",
            isCharging: false,
        },
        {
            value: 45,
            timestamp: "6 AM",
            isCharging: false,
        },
        {
            value: 35,
            timestamp: "7 AM",
            isCharging: false,
        },
        {
            value: 25,
            timestamp: "8 AM",
            isCharging: false,
        },
        {
            value: 85,
            timestamp: "9 AM",
            isCharging: true,
        },
        {
            value: 90,
            timestamp: "10 AM",
            isCharging: true,
        },
        {
            value: 95,
            timestamp: "11 AM",
            isCharging: true,
        },
        {
            value: 100,
            timestamp: "12 PM",
            isCharging: false,
        },
        {
            value: 95,
            timestamp: "1 PM",
            isCharging: false,
        },
        {
            value: 100,
            timestamp: "2 PM",
            isCharging: false,
        },
        {
            value: 100,
            timestamp: "3 PM",
            isCharging: false,
        },
        {
            value: 95,
            timestamp: "4 PM",
            isCharging: false,
        },
        {
            value: 90,
            timestamp: "5 PM",
            isCharging: false,
        },
        {
            value: 80,
            timestamp: "6 PM",
            isCharging: false,
        },
        {
            value: 50,
            timestamp: "7 PM",
            isCharging: false,
        },
        {
            value: 60,
            timestamp: "8 PM",
            isCharging: true,
        },
        {
            value: 70,
            timestamp: "9 PM",
            isCharging: true,
        },
        {
            value: 80,
            timestamp: "10 PM",
            isCharging: true,
        },
        {
            value: 30,
            timestamp: "11 PM",
            isCharging: false,
        },
        {
            value: 5,
            timestamp: "12 PM",
            isCharging: false,
        },
    ],
];
