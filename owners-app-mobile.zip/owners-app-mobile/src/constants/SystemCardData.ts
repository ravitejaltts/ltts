import { ColorValue } from "react-native";
import { SvgProps } from "react-native-svg";
import {
    BatteryIcon,
    DoorLockIcon,
    GeneratorIcon,
    LightBulbIcon,
    OpenAwningIcon,
    OpenSlideOutIcon,
    PawIcon,
    RefrigeratorFilledIcon,
    ThermostatSystemIcon,
    WLogoIcon,
    WaterDropIcon,
} from "../assets/icons";
import { SystemCardType } from "../models/ui";
import { SystemsNavigatorParamList } from "../navigators/SystemsNavigator";

type SystemCardData = {
    name: string;
    icon: React.FunctionComponent<SvgProps>;
    iconFillColor: ColorValue;
    iconStrokeColor?: ColorValue;
    screen: keyof SystemsNavigatorParamList;
};

const DATA = new Map<string, SystemCardData>([
    [
        SystemCardType.Pet,
        {
            name: "Pet Minder",
            icon: PawIcon,
            iconFillColor: "#7D69DE",
            screen: "petMinder",
        },
    ],
    [
        SystemCardType.Refrigeration,
        {
            name: "Refrigeration",
            icon: RefrigeratorFilledIcon,
            iconFillColor: "#0ca8da",
            screen: "refrigeration",
        },
    ],
    [
        SystemCardType.Lighting,
        {
            name: "Lights",
            icon: LightBulbIcon,
            iconFillColor: "#ffc20f",
            screen: "lighting",
        },
    ],
    [
        SystemCardType.Water,
        {
            name: "Water Systems",
            icon: WaterDropIcon,
            iconFillColor: "#0ca8da",
            screen: "water",
        },
    ],
    [
        SystemCardType.Energy,
        {
            name: "Energy Management",
            icon: BatteryIcon,
            iconFillColor: "#55b966",
            screen: "energy",
        },
    ],
    [
        SystemCardType.Climate,
        {
            name: "Climate Control",
            icon: ThermostatSystemIcon,
            iconFillColor: "#ff5c00",
            screen: "climate",
        },
    ],
    [
        SystemCardType.Awning,
        {
            name: "Awning",
            icon: OpenAwningIcon,
            iconFillColor: "#0bbfbf",
            screen: "awning",
        },
    ],
    [
        SystemCardType.SlideOut,
        {
            name: "Slide-Outs",
            icon: OpenSlideOutIcon,
            iconFillColor: "#0bbfbf",
            iconStrokeColor: "#0bbfbf",
            screen: "slideOuts",
        },
    ],
    [
        SystemCardType.DoorLock,
        {
            name: "Door Locks",
            icon: DoorLockIcon,
            iconFillColor: "#7D69DE",
            screen: "doorLock",
        },
    ],
    [
        SystemCardType.Generator,
        {
            name: "Generator",
            icon: GeneratorIcon,
            iconFillColor: "#55b966",
            screen: "generator",
        },
    ],
]);

export function getSystemCardData(
    systemCardType: SystemCardType
): SystemCardData {
    return (
        DATA.get(systemCardType) ?? {
            name: "Unknown System",
            icon: WLogoIcon,
            iconFillColor: "#ff5c00",
            screen: "systems",
        }
    );
}
