import React from "react";
import { SvgProps } from "react-native-svg";
import { ContactCategory } from "../models/domain/maintenance";
import {
    AppGridIcon,
    QuestionMarkCircleIcon,
    TabletIcon,
    VanIcon,
    WLogoIcon,
} from "../assets/icons";

type ContactCategoryData = {
    text: string;
    icon: React.FunctionComponent<SvgProps>;
};

const CONTACT_CATEGORY_DATA = new Map<ContactCategory, ContactCategoryData>([
    [
        ContactCategory.CoachChassis,
        {
            text: "Coach/Chassis",
            icon: VanIcon,
        },
    ],
    [
        ContactCategory.CoachComponent,
        {
            text: "Coach Component Issue",
            icon: VanIcon,
        },
    ],
    [
        ContactCategory.Chassis,
        {
            text: "Chassis Issue",
            icon: VanIcon,
        },
    ],
    [
        ContactCategory.Warranty,
        {
            text: "Warranty Question",
            icon: VanIcon,
        },
    ],
    [
        ContactCategory.MobileApp,
        {
            text: "Mobile App",
            icon: AppGridIcon,
        },
    ],
    [
        ContactCategory.WinnebagoConnectPanel,
        {
            text: "Winnebago Connect Panel",
            icon: TabletIcon,
        },
    ],
    [
        ContactCategory.ConnectedSubscription,
        {
            text: "Connected Subscription",
            icon: WLogoIcon,
        },
    ],
    [
        ContactCategory.SomethingElse,
        {
            text: "Something Else",
            icon: QuestionMarkCircleIcon,
        },
    ],
]);

export const getContactCategoryData = (
    category: ContactCategory
): ContactCategoryData => {
    const data = CONTACT_CATEGORY_DATA.get(category);

    let text: string;
    let icon: React.FunctionComponent<SvgProps>;

    if (data) {
        text = data.text;
        icon = data.icon;
    } else {
        text = "Something Else";
        icon = QuestionMarkCircleIcon;
    }

    return {
        text,
        icon,
    };
};
