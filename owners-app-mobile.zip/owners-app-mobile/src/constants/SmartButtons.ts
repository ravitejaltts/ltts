import {
    CouchIcon,
    ForkKnifeIcon,
    HikerIcon,
    MoonIcon,
    PawIcon,
    ShowerHeadIcon,
    ShuttleIcon,
    SunIcon,
    TerrainIcon,
} from "../assets/icons";

export const smartButtons = [
    {
        title: "Wake Up",
        icon: SunIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
            { name: "Action 4" },
            { name: "Action 5" },
        ],
    },
    {
        title: "Away",
        icon: HikerIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
        ],
    },
    {
        title: "Movie Time",
        icon: CouchIcon,
        actions: [{ name: "Action 1" }],
    },
    {
        title: "Sleep",
        icon: MoonIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
        ],
    },
    {
        title: "Shower",
        icon: ShowerHeadIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
        ],
    },
    {
        title: "Hanging Outside",
        icon: TerrainIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
        ],
    },
    {
        title: "Pack Up",
        icon: ShuttleIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
            { name: "Action 4" },
        ],
    },
    {
        title: "Cooking",
        icon: ForkKnifeIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
            { name: "Action 4" },
        ],
    },
    {
        title: "Away from BooBoo",
        icon: PawIcon,
        actions: [
            { name: "Action 1" },
            { name: "Action 2" },
            { name: "Action 3" },
            { name: "Action 4" },
        ],
    },
];
