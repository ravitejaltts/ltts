import {
    MaintenanceTask,
    MaintenanceTaskFrequency,
} from "../models/domain/maintenance";

const MAINTENANCE_TASK_DATA: MaintenanceTask[] = [
    {
        id: 1,
        description: "Check battery condition meter",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 2,
        description: "Check headlights, taillights, and marker lights",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 3,
        description: "Check turn signals",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 4,
        description: "Check horn",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 5,
        description: "Check hazard warning flashers",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 6,
        description: "Check windshield wipers and washers",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 7,
        description: "Check charge indicator on fire extinguisher",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 8,
        description: "Test smoke alarm operation",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 9,
        description: "Test carbon monoxide alarm operation",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 10,
        description: "Inspect and clean exterior vent on water heater",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 11,
        description:
            "Inspect and clean exterior vent/drip tray drain tube on fridge",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 12,
        description: "Inspect and clean exterior vent on furnace",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 13,
        description: "Check and adjust air pressure on tires",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
    {
        id: 14,
        description: "Check tread wear on tires",
        frequencies: [MaintenanceTaskFrequency.BeforeEachUse],
        zone: "",
    },
];

export function getAll(): MaintenanceTask[] {
    return MAINTENANCE_TASK_DATA;
}
