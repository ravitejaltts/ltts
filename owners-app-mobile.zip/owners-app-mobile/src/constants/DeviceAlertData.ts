import { v4 as uuidV4 } from "uuid";
import {
    DeviceAlert,
    DeviceAlertPriorityType,
    DeviceAlertType,
} from "../models/domain/device";
import { SystemComponentType, SystemType } from "../models/domain/system";
import { DateUtil, RandomUtil } from "../utils";

// See examples here:
// https://dev.azure.com/WGO-Web-Development/SmartRV/_wiki/wikis/SmartRV.wiki/807/Listing-Of-All-Notifications

export type DeviceAlertData = {
    alertType: DeviceAlertType;
    category: SystemType;
    component: SystemComponentType;
    instance: number;
    priorityType: DeviceAlertPriorityType;

    header: string;
    message: string;

    opened?: number;
};

export const STATUS_ALERTS: DeviceAlertData[] = [
    {
        alertType: DeviceAlertType.Status,
        category: SystemType.Energy,
        component: SystemComponentType.EnergyManager,
        instance: 1,
        priorityType: DeviceAlertPriorityType.Low,
        header: "Energy Status Alert",
        message: "Coach is connected to shore power",
    },
    {
        alertType: DeviceAlertType.Status,
        category: SystemType.Water,
        component: SystemComponentType.WaterTank,
        instance: 1,
        priorityType: DeviceAlertPriorityType.Critical,
        header: "Water Status Alert",
        message: "Your Fresh Water Tank is now empty.",
    },
    // {
    //     alertType: DeviceAlertType.Status,
    //     category: SystemType.Features,
    //     component: SystemComponentType.PetMinder,
    //     instance: 1,
    //     priorityType: DeviceAlertPriorityType.Critical,
    //     header: "Battery is Dangerously Low and RV Temp is Above Comfort",
    //     message: "Your fuel tank level is depleted and your RV battery is low.",
    // },
    // {
    //     alertType: DeviceAlertType.Status,
    //     category: SystemType.Features,
    //     component: SystemComponentType.PetMinder,
    //     instance: 1,
    //     priorityType: DeviceAlertPriorityType.Medium,
    //     header: "RV Temp Above Comfort",
    //     message: "Please turn on your RV's air conditioning.",
    // },
];

export const EVENT_ALERTS: DeviceAlertData[] = [
    {
        alertType: DeviceAlertType.Event,
        category: SystemType.Energy,
        component: SystemComponentType.BatteryManager,
        priorityType: DeviceAlertPriorityType.Critical,
        instance: 1,
        header: "Your house battery was shut off",
        message:
            "Your house battery was shut off because of a lack of sufficient charge.",
    },
    {
        alertType: DeviceAlertType.Event,
        category: SystemType.Movables,
        component: SystemComponentType.Awning,
        priorityType: DeviceAlertPriorityType.Medium,
        instance: 1,
        header: "Your awning retracted automatically",
        message:
            "Your sensors tracked wind speeds that had potential to damage your awning.",
    },
];

export function generateDeviceAlert(
    deviceId: string,
    data: DeviceAlertData
): DeviceAlert {
    const {
        alertType,
        category,
        component,
        instance,
        priorityType,
        header,
        message,
        opened,
    } = data;

    return {
        id: uuidV4(),
        deviceId: deviceId,
        alertType: alertType,
        priorityType: priorityType,

        category: category,
        code: `${component}${RandomUtil.getIntInclusive(1000, 2000)}`,
        instance: instance,

        header: header,
        message: message,

        opened:
            opened ??
            DateUtil.nowAddMinutes(
                -RandomUtil.getIntInclusive(0, 480)
            ).getTime(),
        closed: 0,
        dismissed: 0,
    };
}
