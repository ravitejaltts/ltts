import { SvgProps } from "react-native-svg";
import {
    ArticleIcon,
    ChecklistIcon,
    ErrorOutlineIcon,
    PlayArrowIcon,
    WLogoIcon,
} from "../assets/icons";
import { ContentCategory } from "../models/domain/content";

type CategoryData = {
    name: string;
    icon: React.FunctionComponent<SvgProps>;
};

const CATEGORY_DATA = new Map<string, CategoryData>([
    [
        ContentCategory.About,
        {
            name: "About",
            icon: ArticleIcon,
        },
    ],
    [
        ContentCategory.HowTo,
        {
            name: "How To's",
            icon: PlayArrowIcon,
        },
    ],
    [
        ContentCategory.Troubleshooting,
        {
            name: "Troubleshooting",
            icon: ErrorOutlineIcon,
        },
    ],
    [
        ContentCategory.Maintenance,
        {
            name: "Maintenance",
            icon: ChecklistIcon,
        },
    ],
    [
        ContentCategory.Supplement,
        {
            name: "Additional Resources",
            icon: ArticleIcon,
        },
    ],
]);

export function getName(categoryId: string) {
    return CATEGORY_DATA.get(categoryId)?.name;
}

export function getIcon(categoryId: string) {
    return CATEGORY_DATA.get(categoryId)?.icon ?? WLogoIcon;
}
