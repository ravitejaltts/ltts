import { ColorValue } from "react-native";
import { SvgProps } from "react-native-svg";
import {
    LightBulbIcon,
    LightningIcon,
    OutletIcon,
    RefrigeratorFilledIcon,
    SnowFlakeIcon,
    ThermostatFanIcon,
    ThermostatHeatIcon,
    WaterDropArrowUpIcon,
    WaterHeaterIcon,
} from "../assets/icons";
import { EnergyConsumerType } from "../models/domain/energy";

type EnergyConsumerData = {
    name: string;
    icon: React.FunctionComponent<SvgProps>;
    iconFillColor: ColorValue;
    consumerType: EnergyConsumerType;
    // systemType?: EnergyConsumerSystemType;
};

const Consumers: EnergyConsumerData[] = [
    // Lighting
    {
        name: "Lighting",
        icon: LightBulbIcon,
        iconFillColor: "#ffc20f",
        consumerType: EnergyConsumerType.DC,
        // systemType: EnergyConsumerSystemType.Lighting,
    },
    // Water
    {
        name: "Water Heater",
        icon: WaterHeaterIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.AC,
        // systemType: EnergyConsumerSystemType.Water,
    },
    {
        name: "Fresh Water Pump",
        icon: WaterDropArrowUpIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.DC,
        // systemType: EnergyConsumerSystemType.Water,
    },
    {
        name: "Gray Water Pump",
        icon: WaterDropArrowUpIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.DC,
        // systemType: EnergyConsumerSystemType.Water,
    },
    {
        name: "Water Systems",
        icon: WaterHeaterIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.AC,
        // systemType: EnergyConsumerSystemType.Water,
    },
    // Climate
    {
        name: "Refrigerator",
        icon: RefrigeratorFilledIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.DC,
        // systemType: EnergyConsumerSystemType.Climate,
    },
    {
        name: "Air Conditioner",
        icon: SnowFlakeIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.DC,
        // systemType: EnergyConsumerSystemType.Climate,
    },
    {
        name: "Roof Fan",
        icon: ThermostatFanIcon,
        iconFillColor: "#0ca8da",
        consumerType: EnergyConsumerType.DC,
        // systemType: EnergyConsumerSystemType.Climate,
    },
    {
        name: "Heater",
        icon: ThermostatHeatIcon,
        iconFillColor: "#f15f31",
        consumerType: EnergyConsumerType.AC,
        // systemType: EnergyConsumerSystemType.Climate,
    },
    // AC/DC
    {
        name: "AC Outlets",
        icon: OutletIcon,
        iconFillColor: "#55b966",
        consumerType: EnergyConsumerType.AC,
        //     systemType: EnergyConsumerSystemType.Energy,
    },
    {
        name: "DC Consumers",
        icon: LightningIcon,
        iconFillColor: "#55b966",
        consumerType: EnergyConsumerType.DC,
    },
];

export function getEnergyConsumerData(
    consumerType: EnergyConsumerType
    // systemType?: EnergyConsumerSystemType
): EnergyConsumerData {
    const data = Consumers.find(
        (c) => c.consumerType === consumerType // && c.systemType === systemType
    );

    if (data) {
        return data;
    }

    return {
        name: "Unknown",
        icon: LightningIcon,
        iconFillColor: "#55b966",
        consumerType: EnergyConsumerType.DC,
    };
}
