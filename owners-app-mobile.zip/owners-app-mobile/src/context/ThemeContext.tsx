import React from "react";
import { createContext, useContext, useEffect, useState } from "react";
import { ColorSchemeName, useColorScheme } from "react-native";
import { useServices } from "./ContainerContext";
import { DarkTheme, LightTheme, Theme } from "../styles";

type ThemeSource = "system" | "user";

type ThemeContextValue = {
    theme: Theme;
    setTheme: (name: ColorSchemeName) => void;
    source: ThemeSource;
};

const ThemeContext = createContext<ThemeContextValue>({
    theme: LightTheme,
    setTheme: () => {
        throw new Error("ThemeContext is not initialized");
    },
    source: "system",
});

export function useTheme() {
    const value = useContext<ThemeContextValue>(ThemeContext);
    return [value.theme, value.setTheme, value.source] as const;
}

export const ThemeProvider: React.FunctionComponent<{
    children: React.ReactNode;
}> = ({ children }) => {
    // The color scheme provided by the OS
    const systemColorScheme = useColorScheme();

    // User color scheme is initially not set, initialized by effect
    const [userColorScheme, setUserColorScheme] =
        useState<ColorSchemeName>(null);

    function getTheme(name: ColorSchemeName) {
        return name === "dark" ? DarkTheme : LightTheme;
    }

    // Default to system color scheme
    const [source, setSource] = useState<ThemeSource>("system");
    const [theme, setTheme] = useState<Theme>(getTheme(systemColorScheme));

    const services = useServices();
    const settingService = services.setting;
    const logger = services.logger;

    useEffect(() => {
        logger.log("ThemeProvider", `System: ${systemColorScheme}`);
        logger.log("ThemeProvider", `User: ${userColorScheme}`);

        // React to changes when the system or user color scheme changes
        if (userColorScheme) {
            setSource("user");
            setTheme(getTheme(userColorScheme));
        } else {
            setSource("system");
            setTheme(getTheme(systemColorScheme));
        }
    }, [logger, systemColorScheme, userColorScheme]);

    useEffect(() => {
        // Initialize the user color scheme from settings

        try {
            const colorScheme = settingService.colorScheme;

            // Will trigger an update to the theme state
            setUserColorScheme(colorScheme);
        } catch (error) {
            if (error instanceof Error) {
                logger.log(
                    "ThemeProvider",
                    "Error retrieving user color scheme"
                );
                logger.error("ThemeProvider", error);
            }
        }
    }, [logger, settingService]);

    const _setUserColorScheme = (colorScheme: ColorSchemeName) => {
        // Will trigger an update to the theme state
        setUserColorScheme(colorScheme);

        try {
            // Store locally
            settingService.colorScheme = colorScheme;
        } catch (error) {
            if (error instanceof Error) {
                logger.log("ThemeProvider", "Error setting user color scheme");
                logger.error("ThemeProvider", error);
            }
        }
    };

    return (
        <ThemeContext.Provider
            value={{
                theme: theme,
                setTheme: _setUserColorScheme,
                source,
            }}>
            {children}
        </ThemeContext.Provider>
    );
};
