import { useEffect, useState } from "react";
import { ColorSchemeName, ImageRequireSource } from "react-native";
import { useTheme } from "../ThemeContext";

export type ThemedImages = {
    ThumbsUp: ImageRequireSource;
    VINMotorhome: ImageRequireSource;
    VINTowable: ImageRequireSource;
    SystemDemo: ImageRequireSource;
};

const getLightThemedImages = (): ThemedImages => {
    return {
        ThumbsUp: require("../../assets/images/helpers/ThumbsUp.png"),
        VINMotorhome: require("../../assets/images/helpers/VINMotorhome.png"),
        VINTowable: require("../../assets/images/helpers/VINTowable.png"),
        SystemDemo: require("../../assets/images/helpers/SystemDemo.png"),
    };
};

const getDarkThemedImages = (): ThemedImages => {
    return {
        ThumbsUp: require("../../assets/images/helpers/ThumbsUpDark.png"),
        VINMotorhome: require("../../assets/images/helpers/VINMotorhomeDark.png"),
        VINTowable: require("../../assets/images/helpers/VINTowableDark.png"),
        SystemDemo: require("../../assets/images/helpers/SystemDemoDark.png"),
    };
};

const getThemedImages = (themeName: ColorSchemeName): ThemedImages => {
    if (themeName === "light") {
        return getLightThemedImages();
    }

    return getDarkThemedImages();
};

export function useThemedImages() {
    const [theme] = useTheme();
    const [themedImages, setThemedImages] = useState(
        getThemedImages(theme.name)
    );

    useEffect(() => {
        setThemedImages(getThemedImages(theme.name));
    }, [theme.name]);

    return themedImages;
}
