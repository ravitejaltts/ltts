import React, { createContext, useContext } from "react";
import { env } from "../config/env";
import { BleDevice } from "../models/domain/bluetooth";
import {
    ApiBleService,
    ApiBleServiceFactory,
    BleServiceMetadata,
    SecurityBleService,
    SecurityBleServiceFactory,
} from "../models/domain/bluetooth/services";
import {
    BleVehicleConnection,
    BleVehicleConnectionFactory,
    CloudVehicleConnection,
    CloudVehicleConnectionFactory,
    LocalVehicleConnection,
    LocalVehicleConnectionFactory,
    MockVehicleConnection,
    MockVehicleConnectionFactory,
} from "../models/domain/connection";
import { SmartVehicle, SmartVehicleFactory } from "../models/domain/vehicle";
import {
    AuthenticationService,
    AuthorizationService,
    ClipboardService,
    ContentService,
    DealerService,
    DeviceAlertService,
    DeviceRequestService,
    DeviceService,
    FileService,
    GooglePlacesService,
    HttpService,
    KeychainService,
    LinkingService,
    Logger,
    PlatformVehicleService,
    SecureStorageService,
    SystemNotificationService,
    TrackingService,
    UserService,
    WgoSettingService,
} from "../services";
import {
    AppCenterTrackingService,
    AzureAuthenticationService,
    AzureContentService,
    AzureDealerService,
    AzureDeviceAlertService,
    AzureDeviceRequestService,
    AzureDeviceService,
    AzureUserService,
    DeviceAlertStorageService,
    ExpoClipboardService,
    ExpoFileService,
    ExpoSystemNotificationService,
    OktaAuthorizationService,
    PlxBleManagerService,
    TemporaryAzurePlatformVehicleService,
    TrackingLogger,
    WgoNotificationStorageService,
} from "../services/impl";
import { NativeKeychainService } from "../services/impl/NativeKeychainService";
import {
    MockAuthenticationService,
    MockAuthorizationService,
    MockContentService,
    MockDealerService,
    MockDeviceAlertService,
    MockDeviceService,
    MockKeychainService,
    MockPlatformVehicleService,
    MockSystemNotificationService,
    MockUserService,
} from "../services/mock";
import {
    MockClimateService,
    MockEnergyService,
    MockFeaturesService,
    MockLightingService,
    MockMetaService,
    MockMetaSystemService,
    MockMovableService,
    MockVehicleSystemService,
    MockWaterService,
} from "../services/mock/smartVehicle";
import { RealmStorageService } from "../services/realm";
import { BleManagerService } from "../services/smartVehicle";
import {
    AppStore,
    AsyncMigrationStore,
    AuthStore,
    BluetoothStore,
    CameraStore,
    ClipboardStore,
    ContactStore,
    ContentStore,
    DealerStore,
    DeviceStore,
    FeatureFlagStore,
    MaintenanceStore,
    NotificationStore,
    PlacesStore,
    ProfileStore,
    SettingStore,
    ToastStore,
    UserLocationStore,
    VehicleStore,
} from "../stores";
import { BrowserService, ExpoBrowserService } from "../services/browser";
import {
    AsyncMigration_15,
    AsyncMigration_16,
} from "../models/migrations/async";

const SCREEN_NAME = "ContainerContext";

type ServiceContainer = {
    tracking: TrackingService;
    logger: Logger;
    setting: WgoSettingService;
    file: FileService;
    authorization: AuthorizationService;
    linking: LinkingService;
    bleManager: BleManagerService;
    deviceAlertStorage: DeviceAlertStorageService;
    browser: BrowserService;
};

type StoreContainer = {
    auth: AuthStore;
    vehicle: VehicleStore;
    content: ContentStore;
    contact: ContactStore;
    profile: ProfileStore;
    userLocation: UserLocationStore;
    places: PlacesStore;
    dealer: DealerStore;
    bluetooth: BluetoothStore;
    maintenance: MaintenanceStore;
    notification: NotificationStore;
    app: AppStore;
    featureFlag: FeatureFlagStore;
    camera: CameraStore;
    setting: SettingStore;
    toast: ToastStore;
    migration: AsyncMigrationStore;
    device: DeviceStore;
    clipboard: ClipboardStore;
};

type RootContainer = {
    services: ServiceContainer;
    stores: StoreContainer;
};

const RootContainerContext = createContext<RootContainer | undefined>(
    undefined
);

export const RootContainerProvider: React.FunctionComponent<{
    children: React.ReactNode;
}> = ({ children }) => {
    const isMock = env.name === "mock";

    // Services //

    const trackingService: TrackingService = new AppCenterTrackingService();
    const logger: Logger = new TrackingLogger(trackingService);

    const realmStorageService = new RealmStorageService(logger);

    const secureStorageService = new SecureStorageService(logger);

    const settingService = new WgoSettingService(logger, realmStorageService);

    const authorizationService: AuthorizationService = isMock
        ? new MockAuthorizationService(settingService)
        : new OktaAuthorizationService(logger, secureStorageService);

    const httpService = new HttpService(
        logger,
        authorizationService,
        settingService
    );

    const authenticationService: AuthenticationService = isMock
        ? new MockAuthenticationService(
              logger,
              settingService,
              secureStorageService
          )
        : new AzureAuthenticationService(httpService);

    const fileService: FileService = new ExpoFileService();
    const clipboardService: ClipboardService = new ExpoClipboardService();

    const dealerService: DealerService = isMock
        ? new MockDealerService()
        : new AzureDealerService(httpService);

    const platformVehicleService: PlatformVehicleService = isMock
        ? new MockPlatformVehicleService()
        : new TemporaryAzurePlatformVehicleService(httpService);

    const contentService: ContentService = isMock
        ? new MockContentService()
        : new AzureContentService(httpService);

    const userService: UserService = isMock
        ? new MockUserService(settingService)
        : new AzureUserService(httpService);

    const placesService = new GooglePlacesService(httpService);

    const linkingService = new LinkingService(logger);

    const bleManagerService = new PlxBleManagerService(logger);

    const systemNotificationService: SystemNotificationService = isMock
        ? new MockSystemNotificationService()
        : new ExpoSystemNotificationService(logger);

    const notificationStorageService = new WgoNotificationStorageService(
        realmStorageService
    );

    let deviceService: DeviceService;
    let mockLightingService: MockLightingService | undefined;
    let mockWaterService: MockWaterService | undefined;
    let mockClimateService: MockClimateService | undefined;
    let mockEnergyService: MockEnergyService | undefined;
    let mockMetaService: MockMetaService | undefined;
    let mockMovableService: MockMovableService | undefined;
    let mockMetaSystemService: MockMetaSystemService | undefined;
    let mockVehicleSystemService: MockVehicleSystemService | undefined;
    let mockFeaturesService: MockFeaturesService | undefined;

    if (isMock) {
        mockLightingService = new MockLightingService(logger);
        mockWaterService = new MockWaterService(logger);
        mockClimateService = new MockClimateService(logger);
        mockEnergyService = new MockEnergyService(logger);
        mockMetaService = new MockMetaService();
        mockMovableService = new MockMovableService(logger);
        mockMetaSystemService = new MockMetaSystemService(logger);
        mockVehicleSystemService = new MockVehicleSystemService(logger);
        mockFeaturesService = new MockFeaturesService(logger);

        deviceService = new MockDeviceService(
            settingService,
            mockLightingService,
            mockWaterService,
            mockClimateService,
            mockEnergyService,
            mockMovableService,
            mockVehicleSystemService,
            mockFeaturesService,
            mockMetaSystemService
        );
    } else {
        deviceService = new AzureDeviceService(httpService);
    }

    const deviceRequestService: DeviceRequestService =
        new AzureDeviceRequestService(httpService);

    const deviceAlertStorageService = new DeviceAlertStorageService(
        realmStorageService
    );

    const keychainService: KeychainService = isMock
        ? new MockKeychainService()
        : new NativeKeychainService();

    const deviceAlertService: DeviceAlertService = isMock
        ? new MockDeviceAlertService(deviceAlertStorageService)
        : new AzureDeviceAlertService(httpService);

    const browserService: BrowserService = new ExpoBrowserService();

    // Stores //

    const toastStore = new ToastStore(logger);

    const cameraStore = new CameraStore(logger);

    const userLocationStore = new UserLocationStore(logger);

    const placesStore = new PlacesStore(placesService, logger);

    const featureFlagStore = new FeatureFlagStore(realmStorageService);

    const settingStore = new SettingStore(settingService);

    const contactStore = new ContactStore(logger, contentService);

    const appStore = new AppStore(logger, settingService, secureStorageService);

    const dealerStore = new DealerStore(
        logger,
        dealerService,
        userService,
        realmStorageService
    );

    const bluetoothStore = new BluetoothStore(
        logger,
        bleManagerService,
        userLocationStore,
        realmStorageService,
        settingService
    );

    const authStore = new AuthStore(
        logger,
        authenticationService,
        authorizationService,
        secureStorageService,
        settingService,
        keychainService,
        trackingService
    );

    const profileStore = new ProfileStore(
        logger,
        userService,
        secureStorageService,
        authStore
    );

    const notificationStore = new NotificationStore(
        logger,
        settingService,
        systemNotificationService,
        notificationStorageService,
        userService,
        deviceAlertService,
        deviceAlertStorageService,
        authStore,
        appStore
    );

    const deviceStore = new DeviceStore(
        logger,
        secureStorageService,
        deviceService,
        authStore
    );

    const securityBleServiceFactory: SecurityBleServiceFactory = (
        metadata: BleServiceMetadata
    ) => {
        return new SecurityBleService(
            metadata,
            bleManagerService,
            settingService,
            logger
        );
    };

    const apiBleServiceFactory: ApiBleServiceFactory = (
        metadata: BleServiceMetadata
    ) => {
        return new ApiBleService(
            metadata,
            bleManagerService,
            settingService,
            logger
        );
    };

    const bleVehicleConnectionFactory: BleVehicleConnectionFactory = (
        vehicle: SmartVehicle,
        bleDevice: BleDevice,
        allowFallback: boolean
    ) =>
        new BleVehicleConnection(
            logger,
            vehicle,
            settingService,
            allowFallback,
            appStore,
            deviceStore,
            apiBleServiceFactory,
            securityBleServiceFactory,
            bleDevice
        );

    const cloudVehicleConnectionFactory: CloudVehicleConnectionFactory = (
        vehicle,
        allowFallback
    ) =>
        new CloudVehicleConnection(
            logger,
            vehicle,
            allowFallback,
            settingService,
            deviceService,
            deviceRequestService
        );

    const localVehicleConnectionFactory: LocalVehicleConnectionFactory = (
        vehicle
    ) =>
        new LocalVehicleConnection(
            logger,
            vehicle,
            settingService,
            httpService
        );

    let mockVehicleConnectionFactory: MockVehicleConnectionFactory;

    if (isMock) {
        mockVehicleConnectionFactory = (vehicle: SmartVehicle) =>
            new MockVehicleConnection(
                logger,
                vehicle,
                mockClimateService!,
                mockEnergyService!,
                mockLightingService!,
                mockMetaService!,
                mockMovableService!,
                mockMetaSystemService!,
                mockVehicleSystemService!,
                mockWaterService!,
                mockFeaturesService!,
                deviceStore
            );
    } else {
        mockVehicleConnectionFactory = () => {
            throw new Error(
                "Mock vehicle connection cannot be created in non-mock environment"
            );
        };
    }

    const smartVehicleFactory: SmartVehicleFactory = (metadata, vehicleStore) =>
        new SmartVehicle(
            metadata,
            vehicleStore,
            logger,
            settingService,
            secureStorageService,
            deviceService,
            deviceAlertService,
            bluetoothStore,
            toastStore,
            deviceStore,
            bleVehicleConnectionFactory,
            cloudVehicleConnectionFactory,
            localVehicleConnectionFactory,
            mockVehicleConnectionFactory
        );

    const vehicleStore = new VehicleStore(
        logger,
        settingService,
        platformVehicleService,
        userService,
        contentService,
        authStore,
        smartVehicleFactory
    );

    const contentStore = new ContentStore(
        logger,
        contentService,
        realmStorageService,
        fileService,
        authStore,
        vehicleStore,
        toastStore
    );

    const maintentanceStore = new MaintenanceStore(
        logger,
        contentService,
        userService,
        settingService,
        vehicleStore
    );

    const asyncMigrationStore = new AsyncMigrationStore(
        logger,
        realmStorageService,
        [
            () => new AsyncMigration_15(realmStorageService, authStore),
            () => new AsyncMigration_16(realmStorageService, fileService),
        ]
    );

    const clipboardStore = new ClipboardStore(
        logger,
        clipboardService,
        toastStore
    );

    const container: RootContainer = {
        services: {
            tracking: trackingService,
            logger: logger,
            setting: settingService,
            file: fileService,
            authorization: authorizationService,
            linking: linkingService,
            bleManager: bleManagerService,
            deviceAlertStorage: deviceAlertStorageService,
            browser: browserService,
        },
        stores: {
            auth: authStore,
            vehicle: vehicleStore,
            content: contentStore,
            contact: contactStore,
            profile: profileStore,
            userLocation: userLocationStore,
            places: placesStore,
            dealer: dealerStore,
            bluetooth: bluetoothStore,
            maintenance: maintentanceStore,
            notification: notificationStore,
            app: appStore,
            featureFlag: featureFlagStore,
            camera: cameraStore,
            setting: settingStore,
            toast: toastStore,
            migration: asyncMigrationStore,
            device: deviceStore,
            clipboard: clipboardStore,
        },
    };

    logger.log(SCREEN_NAME, `environment: ${env.name}`);

    return (
        <RootContainerContext.Provider value={container}>
            {children}
        </RootContainerContext.Provider>
    );
};

export function useRootContainer(): RootContainer {
    const container = useContext<RootContainer | undefined>(
        RootContainerContext
    );

    if (!container) {
        throw Error(
            "useRootContainer cannot be used outside of a RootContainerProvider"
        );
    }

    return container;
}

export function useServices(): ServiceContainer {
    const container = useRootContainer();
    return container.services;
}

export function useStores(): StoreContainer {
    const container = useRootContainer();
    return container.stores;
}
