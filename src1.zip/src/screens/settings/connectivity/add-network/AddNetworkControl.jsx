import React, { useEffect, useState } from "react";
import BackButton from "../../../../components/settings/back-button/BackButton";
import styles from "./addnetwork.module.css";
import { useLocation, useNavigate, useOutletContext } from "react-router-dom";
import HeaderCustomButton from "components/settings/header-custom-button/HeaderCustomButton";
import SecurityTypeControl from "../common/network-security/SecurityTypeControl";
import { JoinNetworkDialog } from "components/settings/join-network-dialog/JoinNetworkDialog";
import { NetworkNameDialog } from "../common/network-name-dialog/NetworkNameDialog";


const AddNetworkControl = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [setActiveTab, data, refreshDataImmediate] = useOutletContext();
  const [formStep, setFormStep] = useState(0);

  const addNetworkData = data?.[0]?.tabs?.filter(
    (tab) => `${tab.name}` === "UiSettingsConnectivity"
  )[0].details?.[0]?.data?.[0]?.data?.[0]?.items?.[1]?.data?.[0]?.data[1]?.data?.[2]?.data?.[0];

  return (
    <>
      {formStep == 0 ? (
        <>
          <div className={styles.header}>
            <div className={styles.backBtn}>
              <BackButton handler={() => navigate(-1)} />
            </div>
            <p className={styles.headingText}>Add Wi-FI Network</p>
            <div className={styles.nextBtn}>
              <HeaderCustomButton name="Next" handler={() => setFormStep(1)} />
            </div>
          </div>
          <SecurityTypeControl />
        </>
      ) : formStep == 1 ? (
        <>
          <NetworkNameDialog close={() => setFormStep(0)} next={(input) => setFormStep(2)} />
        </>
      ) : (
        <>
          <JoinNetworkDialog headerTitle={"Add Wi-Fi Network"} close={() => setFormStep(1)} next={(input) => navigate(-1)} />
        </>
      )}
    </>
  );
};

export default AddNetworkControl;
