import RefridgeratorSettingDetail from "./RefridgeratorSettingDetail";
export default RefridgeratorSettingDetail;
