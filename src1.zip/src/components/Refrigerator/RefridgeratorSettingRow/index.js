import RefridgeratorSettingRow from "./RefridgeratorSettingRow";
export default RefridgeratorSettingRow;
