import Header from "../../components/common/header/Header";

const QuickControls = () => {
  return (
    <div>
      <Header
        text="Quick Controls"
        extra={{ icon: "", text: "Edit Controls" }}
      />
    </div>
  );
};

export default QuickControls;
