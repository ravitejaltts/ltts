import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, useOutletContext, useParams } from "react-router-dom";
import Button from "../../../components/common/Button/Button";
import BackButton from "../../../components/settings/back-button/BackButton";
import Pairing from "../../../components/settings/pairing/Pairing";
import SettingRow from "../../../components/settings/setting-row/SettingRow";
import { SETTINGS_LINKS } from "../../../constants/CONST";
import styles from "./connectivity.module.css";

const ConnectiviyTypeControls = () => {
    const { index } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const [setActiveTab, data, refreshDataImmediate] = useOutletContext();
    useEffect(() => {
        setActiveTab(location?.pathname);
    }, []);
    const [selectedRowIndex, setSelectedRowIndex] = useState(index);
    
    const connectivityData = data?.[0]?.tabs?.find(
        (tab) => `${tab.name}` === SETTINGS_LINKS.CONNECTIVITY
    );
    const connectivityItems =
        connectivityData?.details?.[0]?.data?.[0]?.data?.[0]?.items;

    // This approach is assuming the Pair a device button to be the last item
    const connectivityRowData = connectivityItems.slice(0, -1);
    const pairingData = connectivityItems?.slice(-1)[0];

    let displayInnerDetail = null;

    if (
        selectedRowIndex > -1 &&
        connectivityRowData &&
        connectivityRowData.length > selectedRowIndex
    ) {
        displayInnerDetail = connectivityRowData[selectedRowIndex];
    }

    const renderSupportText = (data) => {
        return <p className={styles.extraText}>{data?.text}</p>;
    };

    function rowRenderer(dat, isLast) {
        console.log(dat);
        if (dat?.type === "Button" || dat?.type === "BUTTON") {
            console.log(dat?.actions);
            return (
                <Button
                    action={dat?.actions?.TAP?.action}
                    text={<span style={{ color: '#ADD8E6' }}>{dat?.title}</span>}
                    refreshParentData={refreshDataImmediate}
                />
            );
        } else if (dat?.type === "CELLULAR_INFO_LABEL") {
            return (
                <SettingRow
                    name={dat?.title || dat?.name}
                    text={evaluteText(dat)}
                    noBorder={isLast}
                    bottomText={dat?.subtext?.version}
                />
            );
        }
        else {
            return (
                <SettingRow
                name={<span style={dat?.title === "Add Network" ? { color: '#4c85a9' } : {}}>{dat?.title || dat?.name}</span>}
                    text={evaluteText(dat)}
                    noBorder={isLast}
                    bottomText={dat?.subtext?.version}
                    toggle={dat?.actions}
                    arrow={dat?.arrow}
                    lock ={dat?.protected}
                    WifiSymbol={dat?.wifi}
                    toggleState={
                        dat?.state?.onoff || dat?.state?.onOff || dat?.value?.onOff || 0
                    }
                    action={dat?.actions?.TOGGLE?.action || dat?.actions?.DISPLAY?.action}
                />
            );
        }
    }

    const titleRenderer = (dat) => {
        if (dat?.type === "Button") {
            return (
                <div className="flex justify-center">
                    <button
                        className={styles.pairingButton}
                        onClick={() =>
                            dat?.actions?.TAP?.action &&
                            handleBtnClick(dat?.actions?.TAP?.action)
                        }
                    >
                        {pairingData?.title}
                    </button>
                </div>
            );
        } else {
            return <p className={styles.containerHeading}>{dat?.title}</p>;
        }
    };

    const handleBtnClick = (action) => {
        axios.put(action?.href, {
            onOff: 1,
        });
    };

    const evaluteText = (data) => {
        if ("connected" in data) {
            return data.connect ? "Connected" : "Not Connected";
        }
        const value = data?.value;
        if (typeof value === "string") {
            return value;
        }
        if (typeof value === "object") {
            if ("version" in value && typeof value?.version === "string") {
                return value?.version;
            }
            if ("status" in value && typeof value?.status === "string") {
                return value?.status;
            }
        } else {
            return "";
        }
    };

    return (
        <>
            {displayInnerDetail ? (
                <div>
                    <div className={styles.header}>
                        <div className={styles.backBtn}>
                            <BackButton handler={() => navigate(-1)} />
                        </div>
                        <p className={styles.headingText}>{displayInnerDetail?.title}</p>
                    </div>
                    {displayInnerDetail?.data?.[0]?.data?.map((item, ind) => (
                        <React.Fragment key={ind} >
                            <div className={styles.itemContainer}>
                                {titleRenderer(item)}

                                <div className={styles.contentContainer}>
                                    {item?.data?.filter(dat => dat.type != 'SUPPORT_TEXT').map((dat, ind, arr) => (
                                        <React.Fragment key={ind} >
                                            <div onClick={() => { (dat?.name != "" && dat?.name != undefined)? navigate(`/setting/${dat?.name}`) :""}}>
                                                {rowRenderer(dat, ind === arr.length - 1)}
                                            </div>
                                        </React.Fragment>
                                    ))}
                                </div>
                                <div>
                                    {item?.data?.filter(dat => dat.type === 'SUPPORT_TEXT').map((dat, ind, arr) => (
                                        <React.Fragment key={ind}>
                                            {renderSupportText(dat, ind === arr.length - 1)}
                                        </React.Fragment>
                                    ))}
                                </div>
                            </div>
                        </React.Fragment>
                    ))}
                </div>
            ) : null}
        </>
    );
};

export default ConnectiviyTypeControls;
