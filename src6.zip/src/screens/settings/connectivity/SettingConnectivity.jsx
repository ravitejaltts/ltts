import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, useOutletContext } from "react-router-dom";
import Button from "../../../components/common/Button/Button";
import BackButton from "../../../components/settings/back-button/BackButton";
import Pairing from "../../../components/settings/pairing/Pairing";
import SettingRow from "../../../components/settings/setting-row/SettingRow";
import { SETTINGS_LINKS } from "../../../constants/CONST";
import styles from "./connectivity.module.css";

const SettingConnectivity = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [setActiveTab, data, refreshDataImmediate] = useOutletContext();
  useEffect(() => {
    setActiveTab(location?.pathname);
  }, []);
  const [selectedRowIndex, setSelectedRowIndex] = useState(-1);
  const [pairingMode, setPairingMode] = useState(false);

  const connectivityData = data?.[0]?.tabs?.find(
    (tab) => `${tab.name}` === SETTINGS_LINKS.CONNECTIVITY
  );
  const connectivityItems =
    connectivityData?.details?.[0]?.data?.[0]?.data?.[0]?.items;

  // This approach is assuming the Pair a device button to be the last item
  const connectivityRowData = connectivityItems.slice(0, -1);
  const pairingData = connectivityItems?.slice(-1)[0];

  let displayInnerDetail = null;

  if (
    selectedRowIndex > -1 &&
    connectivityRowData &&
    connectivityRowData.length > selectedRowIndex
  ) {
    displayInnerDetail = connectivityRowData[selectedRowIndex];
  }
  
  const togglePairingMode = () => {
    setPairingMode((p) => !p);
  };

  if (pairingMode) {
    return <Pairing close={togglePairingMode} data={pairingData?.data?.[0]} />;
  }

  return (
    <>
      {connectivityData ? (
        <>
          <div className={styles.header}>
            <p className={styles.headingText}>{connectivityData?.title}</p>
          </div>
          <div className={styles.itemContainer}>
            <p className={styles.containerHeading}>{connectivityData?.title}</p>
            <div className={styles.contentContainer}>
              {connectivityRowData?.map((dat, index, arr) => (
                <div key={index} onClick={() => navigate("./" + index)}>
                  <SettingRow
                    refreshDataImmediate={refreshDataImmediate}
                    name={dat?.title}
                    text={dat?.value}
                    noBorder={index === arr.length - 1}
                    arrow
                  />
                </div>
              ))}
            </div>
            <div className={styles.pairingContainer}>
              {pairingData && (
                <button
                  className={styles.pairingButton}
                  onClick={togglePairingMode}
                >
                  {pairingData?.title}
                </button>
              )}
            </div>
          </div>
        </>
      ) : null}
    </>
  );
};

export default SettingConnectivity;
