import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import BackButton from "../../../../components/settings/back-button/BackButton";
import { AppContext } from "../../../../context/AppContext";
import { useFetch } from "../../../../hooks/useFetch";
import { API_ENDPOINT, LOCAL_ENDPOINT } from "../../../../utils/api";
import styles from "./knownnetworks.module.css";
import SettingRow from "../../../../components/settings/setting-row/SettingRow";
import { SETTINGS_LINKS } from "constants/CONST";


const KnownNetworksControl = () => {
  const navigate = useNavigate();
  const { pollingInterval } = useContext(AppContext);
  const { data, refreshDataImmediate } = useFetch(
    API_ENDPOINT.SETTING,
    LOCAL_ENDPOINT.SETTING,
    true,
    pollingInterval
  );
  const networksData = data?.[0]?.tabs
  ?.filter((tab) => `${tab.name}` === SETTINGS_LINKS.CONNECTIVITY)[0]
  ?.details?.[0]?.data?.[0].data?.[0]?.items?.[1]?.data?.[0]?.data?.[1]?.data;

  const knowNetworks = networksData?.[networksData.length -2];


  console.log("knowNetworks?.knowNetworks", knowNetworks);


  return (
    <>
      <div className={styles.header}>
        <div className={styles.backBtn}>
          <BackButton handler={() => navigate(-1)} />
        </div>
        <p className={styles.headingText}>{knowNetworks?.title}</p>
      </div>

      {knowNetworks?.data?.map(
        (item, ind) => (
          <React.Fragment key={ind}>
            <div className={styles.itemContainer}>
              <p className={styles.containerHeading}>{item?.title}</p>
              <div className={styles.contentContainer}>
                {item?.items?.map((dat, ind, arr) => (
                  <div key={ind}>
                    <SettingRow
                      name={dat?.title}
                      text={dat?.value?.version || dat?.value}
                      toggle={dat?.state}
                      refreshDataImmediate={refreshDataImmediate}
                      action={dat?.actions?.TOGGLE?.action}
                      toggleState={dat?.state?.onoff}
                      noBorder={arr.length - 1 === ind}
                      arrow
                    />
                  </div>
                ))}
              </div>
            </div>
          </React.Fragment>
        )
      )}

    </>
  );
};

export default KnownNetworksControl;
