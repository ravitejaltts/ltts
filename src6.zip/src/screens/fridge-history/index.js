import RefridgeratorHistory from "./FridgeHistory";
export default RefridgeratorHistory;
