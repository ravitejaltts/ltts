export const SETTING_TITLE = "Refrigerator Settings";
export const MANUFACTURE_TITLE = "Manufacturer Information";
export const MAIN_MODE = "MAIN";
export const DETAIL_MODE = "DETAIL";
export const CONTROL_MODE = "CONTROL";
