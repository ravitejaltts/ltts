import TemperatureAlerts from "./TemperatureAlerts";
export default TemperatureAlerts;
